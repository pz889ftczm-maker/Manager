import type {
  AiProvider,
  AnalyzeScreenshotInput,
  AnalyzeVideoContextInput,
  ScanForCandidateMomentsInput,
  CandidateMoment,
  DetectedEventDraft,
  TacticalAnalysisDraft,
  CoachChatInput,
  CoachChatOutput,
  GameplayFrame,
  ExtractPlayerStatisticsInput,
  ExtractPlayerCardInput,
  ExtractManagerCardInput,
} from "./provider.js";
import type { PlayerStatisticsDraft, PlayerCardDraft, ManagerCardDraft } from "@efootball/shared";
import { ProviderError, isProviderError, type ProviderErrorKind } from "./providerError.js";

/**
 * BATCH 5.5B — finite AI provider fallback router.
 *
 * Wraps two existing AiProvider implementations (packages/ai/src/providers/
 * geminiProvider.ts as primary, packages/ai/src/providers/anthropicProvider.ts
 * as fallback) behind the SAME AiProvider interface, so every existing call
 * site (currently apps/worker/src/jobs/processMatchVideo.ts and
 * processScreenshot.ts, both via getAiProvider() in ./index.ts) benefits
 * without any change to calling code.
 *
 * HARD INVARIANT: at most one primary call + one fallback call PER
 * OPERATION (PROVIDER_ATTEMPT_LIMIT below). This is enforced structurally,
 * not by convention — runWithFallback() iterates a fixed two-element array
 * exactly once with a plain `for` loop. There is no recursion, no while
 * loop, and no path that calls runWithFallback() from within itself. This
 * is a SEPARATE layer from BullMQ job-level retry (apps/worker/src/index.ts,
 * `attempts: 3` with exponential backoff) — one BullMQ attempt can invoke
 * this router many times (once per operation, e.g. once per candidate
 * moment analyzed), and EACH of those invocations independently gets at
 * most 2 provider calls. Nothing here adds delay/backoff/retry of its own;
 * that remains BullMQ's job.
 *
 * FALLBACK ELIGIBILITY: driven entirely by the existing ProviderError.kind
 * classification introduced in Batch 5.5A (./providerError.ts) — see
 * isFallbackEligible() below. Only "rate_limit" / "timeout" / "transient"
 * trigger a fallback attempt. "configuration" / "authentication" /
 * "malformed_response" — and any error that isn't even a ProviderError —
 * fail immediately without contacting Anthropic, so a broken deployment
 * (e.g. missing GEMINI_API_KEY) surfaces as a clear config error instead of
 * being silently masked by a fallback that happens to succeed.
 *
 * SCOPE: this file only implements the router itself. Which provider is
 * primary/fallback for a given deployment is decided in ./index.ts
 * (getAiProvider()) based on AI_PROVIDER — this class does not read env
 * vars directly, it's handed already-configured provider factories.
 */

// ---------------------------------------------------------------------------
// Fallback eligibility policy
// ---------------------------------------------------------------------------

/**
 * The exact set of ProviderErrorKind values that are allowed to trigger a
 * fallback attempt. Everything else (including "unknown" and
 * "malformed_response") is intentionally NOT in this set — see the header
 * comment above and BATCH 5.5B section "FALLBACK POLICY" for the reasoning:
 * an unclassified/unknown failure mode might just as easily be a bug in our
 * own request as a transient provider blip, so the safe default is to fail
 * closed rather than mask it with a second provider call.
 */
export const FALLBACK_ELIGIBLE_ERROR_KINDS: readonly ProviderErrorKind[] = [
  "rate_limit",
  "timeout",
  "transient",
];

const FALLBACK_ELIGIBLE_KIND_SET = new Set(FALLBACK_ELIGIBLE_ERROR_KINDS);

/**
 * Deterministic fallback-eligibility check. Only a properly-classified
 * ProviderError (see ./providerError.ts, currently only thrown by
 * GeminiProvider) with an eligible `kind` is fallback-eligible. Any other
 * thrown value — including AnthropicProvider's current unclassified SDK
 * errors (Batch 5.5A intentionally left AnthropicProvider's error handling
 * untouched) — returns false. This function has no side effects and never
 * logs/mutates the error.
 */
export function isFallbackEligible(error: unknown): boolean {
  if (!isProviderError(error)) return false;
  return FALLBACK_ELIGIBLE_KIND_SET.has(error.kind);
}

// ---------------------------------------------------------------------------
// Combined terminal error (both providers failed)
// ---------------------------------------------------------------------------

function categoryOf(error: unknown): ProviderErrorKind | "unknown" {
  return isProviderError(error) ? error.kind : "unknown";
}

/**
 * Thrown when the primary provider failed with a fallback-eligible error
 * AND the fallback provider also failed. `message` is safe to log (no
 * secrets, no prompt/image content, no raw provider response bodies) —
 * same contract as ProviderError.message. `primaryError`/`fallbackError`
 * are NOT guaranteed sanitized (they're the original thrown values,
 * verbatim) and must never be surfaced directly to end users — same
 * contract as ProviderError.cause.
 */
export class ProviderRouterError extends Error {
  readonly operation: string;
  readonly primaryProvider: string;
  readonly fallbackProvider: string;
  readonly primaryCategory: ProviderErrorKind | "unknown";
  readonly fallbackCategory: ProviderErrorKind | "unknown";
  readonly primaryError: unknown;
  readonly fallbackError: unknown;

  constructor(options: {
    operation: string;
    primaryProviderName: string;
    fallbackProviderName: string;
    primaryError: unknown;
    fallbackError: unknown;
  }) {
    const primaryCategory = categoryOf(options.primaryError);
    const fallbackCategory = categoryOf(options.fallbackError);
    super(
      `AI providers unavailable for ${options.operation}: primary provider ` +
        `(${options.primaryProviderName}, category=${primaryCategory}) failed and fallback provider ` +
        `(${options.fallbackProviderName}, category=${fallbackCategory}) also failed.`,
      { cause: { primary: options.primaryError, fallback: options.fallbackError } }
    );
    this.name = "ProviderRouterError";
    this.operation = options.operation;
    this.primaryProvider = options.primaryProviderName;
    this.fallbackProvider = options.fallbackProviderName;
    this.primaryCategory = primaryCategory;
    this.fallbackCategory = fallbackCategory;
    this.primaryError = options.primaryError;
    this.fallbackError = options.fallbackError;
  }
}

/**
 * HARDENING (5.5B correction pass): safe type guard for ProviderRouterError,
 * mirroring isProviderError() in ./providerError.ts. Lets application code
 * (e.g. a worker job's catch block) recognize "both AI providers failed for
 * this operation" and react accordingly — show a clear "AI temporarily
 * unavailable" message, decide whether to let BullMQ retry, etc. — using
 * only the safe fields (`message`, `operation`, `primaryProvider`,
 * `fallbackProvider`, `primaryCategory`, `fallbackCategory`), without ever
 * needing to inspect `primaryError`/`fallbackError` (which are NOT
 * guaranteed sanitized) or reach into `cause`.
 */
export function isProviderRouterError(err: unknown): err is ProviderRouterError {
  return err instanceof ProviderRouterError;
}

// ---------------------------------------------------------------------------
// Safe (telemetry-only) logging
// ---------------------------------------------------------------------------

/** Never pass anything here beyond operation names, provider names, and
 * ProviderError `kind` strings — never a prompt, image, API key, or raw
 * provider response body. */
function logInfo(line: string): void {
  console.log(`[ai-provider-router] ${line}`);
}

function logError(line: string): void {
  console.error(`[ai-provider-router] ${line}`);
}

// ---------------------------------------------------------------------------
// Router
// ---------------------------------------------------------------------------

type ProviderRole = "primary" | "fallback";

export type AiProviderFactory = () => AiProvider;

export interface ProviderRouterConfig {
  /** Human-readable name for logging/error messages, e.g. "gemini". Does
   * not need to match provider.name (though it should). */
  primaryName: string;
  fallbackName: string;
  /** Lazy — only invoked the first time it's actually needed. In
   * particular, the fallback factory is NEVER invoked unless the primary
   * provider fails with a fallback-eligible error, so a deployment that
   * only ever uses the primary provider successfully is never required to
   * have the fallback provider's credentials configured. */
  primary: AiProviderFactory;
  fallback: AiProviderFactory;
}

/**
 * Implements AiProvider by running every operation against `primary`
 * first, falling back to `fallback` at most once if (and only if) the
 * primary's failure is fallback-eligible (see isFallbackEligible above).
 * Every AiProvider method is a thin wrapper around the same
 * runWithFallback() control flow — see PREFERRED CONTROL FLOW in the
 * Batch 5.5B spec.
 */
export class ProviderRouter implements AiProvider {
  readonly name: string;

  private readonly primaryName: string;
  private readonly fallbackName: string;
  private readonly primaryFactory: AiProviderFactory;
  private readonly fallbackFactory: AiProviderFactory;

  // Constructed lazily and memoized per-router-instance (not per-call) so
  // repeated operations within the same job (e.g. one analyzeVideoContext
  // call per candidate moment) reuse the same SDK client instead of
  // reconstructing it every time. A construction failure is never cached —
  // it's surfaced through the normal fallback-eligibility path below and
  // retried fresh on the next operation.
  private primaryInstance?: AiProvider;
  private fallbackInstance?: AiProvider;

  constructor(config: ProviderRouterConfig) {
    this.primaryName = config.primaryName;
    this.fallbackName = config.fallbackName;
    this.primaryFactory = config.primary;
    this.fallbackFactory = config.fallback;
    // Reports as the primary provider's identity — this router is meant to
    // be a drop-in, resilient stand-in for the primary provider, and no
    // existing call site inspects AiProvider.name today.
    this.name = config.primaryName;
  }

  private getOrConstruct(role: ProviderRole): AiProvider {
    if (role === "primary") {
      if (!this.primaryInstance) this.primaryInstance = this.primaryFactory();
      return this.primaryInstance;
    }
    if (!this.fallbackInstance) this.fallbackInstance = this.fallbackFactory();
    return this.fallbackInstance;
  }

  /**
   * PROVIDER_ATTEMPT_LIMIT: `attempts` below is a fixed, literal two-
   * element array constructed fresh on every call and iterated exactly
   * once by a plain `for` loop — there is no way for this to call itself,
   * loop unboundedly, or attempt either provider more than once. This is
   * the single choke point every AiProvider method below goes through.
   */
  private async runWithFallback<T>(
    operation: string,
    execute: (provider: AiProvider) => Promise<T>
  ): Promise<T> {
    const attempts: { role: ProviderRole; name: string }[] = [
      { role: "primary", name: this.primaryName },
      { role: "fallback", name: this.fallbackName },
    ];

    let primaryError: unknown;

    for (const attempt of attempts) {
      if (attempt.role === "fallback") {
        logInfo(`fallback: ${attempt.name} (operation=${operation})`);
      } else {
        logInfo(`attempt: ${attempt.name} (operation=${operation})`);
      }

      try {
        const provider = this.getOrConstruct(attempt.role);
        const result = await execute(provider);
        logInfo(`result: ${attempt.name} (operation=${operation})`);
        return result;
      } catch (error) {
        const category = categoryOf(error);
        logError(`error category: ${category} (provider=${attempt.name}, operation=${operation})`);

        if (attempt.role === "primary") {
          if (!isFallbackEligible(error)) {
            // configuration / authentication / malformed_response / any
            // unclassified error — fail clearly, never silently masked by
            // Anthropic fallback.
            throw error;
          }
          primaryError = error;
          continue; // exactly one more iteration: the fallback attempt
        }

        // Fallback attempt failed too — terminal. Preserves both original
        // errors (see ProviderRouterError) without exposing secrets/raw
        // payloads in the top-level message.
        throw new ProviderRouterError({
          operation,
          primaryProviderName: this.primaryName,
          fallbackProviderName: this.fallbackName,
          primaryError,
          fallbackError: error,
        });
      }
    }

    // Unreachable — the loop above always returns or throws on every
    // iteration of its fixed two-element array.
    throw new Error("ProviderRouter: exhausted providers without a result");
  }

  scanForCandidateMoments(input: ScanForCandidateMomentsInput): Promise<CandidateMoment[]> {
    return this.runWithFallback("scanForCandidateMoments", (provider) =>
      provider.scanForCandidateMoments(input)
    );
  }

  analyzeScreenshot(input: AnalyzeScreenshotInput): Promise<DetectedEventDraft[]> {
    return this.runWithFallback("analyzeScreenshot", (provider) => provider.analyzeScreenshot(input));
  }

  extractPlayerStatistics(input: ExtractPlayerStatisticsInput): Promise<PlayerStatisticsDraft[]> {
    return this.runWithFallback("extractPlayerStatistics", (provider) =>
      provider.extractPlayerStatistics(input)
    );
  }

  analyzeVideoContext(input: AnalyzeVideoContextInput): Promise<DetectedEventDraft[]> {
    return this.runWithFallback("analyzeVideoContext", (provider) => provider.analyzeVideoContext(input));
  }

  generateTacticalAnalysis(
    event: DetectedEventDraft,
    frames: GameplayFrame[]
  ): Promise<TacticalAnalysisDraft> {
    // Vision requirement (Batch 5.5B spec): `frames` — including any
    // imageBase64 — is forwarded verbatim to whichever provider is
    // attempted. No conversion, no temp files, no path rewriting; each
    // provider implementation already knows how to turn a GameplayFrame
    // into its own SDK's image representation.
    return this.runWithFallback("generateTacticalAnalysis", (provider) =>
      provider.generateTacticalAnalysis(event, frames)
    );
  }

  chat(input: CoachChatInput): Promise<CoachChatOutput> {
    return this.runWithFallback("chat", (provider) => provider.chat(input));
  }

  extractPlayerCard(input: ExtractPlayerCardInput): Promise<PlayerCardDraft> {
    return this.runWithFallback("extractPlayerCard", (provider) => provider.extractPlayerCard(input));
  }

  extractManagerCard(input: ExtractManagerCardInput): Promise<ManagerCardDraft> {
    return this.runWithFallback("extractManagerCard", (provider) => provider.extractManagerCard(input));
  }
}
