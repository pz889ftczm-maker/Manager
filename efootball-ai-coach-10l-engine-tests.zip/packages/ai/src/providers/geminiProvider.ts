import { GoogleGenAI, ApiError, type Content, type Part } from "@google/genai";
import type {
  AiProvider,
  AnalyzeScreenshotInput,
  AnalyzeVideoContextInput,
  ScanForCandidateMomentsInput,
  CandidateMoment,
  DetectedEventDraft,
  TacticalAnalysisDraft,
  CoachChatInput,
  CoachChatOutput,
  CitableEvent,
  GameplayFrame,
  ExtractPlayerStatisticsInput,
  ExtractPlayerCardInput,
  ExtractManagerCardInput,
} from "../provider.js";
import type { PlayerStatisticsDraft, PlayerCardDraft, ManagerCardDraft } from "@efootball/shared";
import { ProviderError } from "../providerError.js";

/**
 * BATCH 5.5A — Gemini provider foundation.
 *
 * This implements the same AiProvider contract as AnthropicProvider
 * (packages/ai/src/providers/anthropicProvider.ts) so calling code never
 * needs to know which vendor is in use. It is a REAL implementation using
 * Google's official server-side SDK (@google/genai) — no mocked/simulated
 * responses anywhere below.
 *
 * SCOPE (per BATCH 5.5A spec): foundation only.
 *  - Batch 5.5B (packages/ai/src/providerRouter.ts) has since wired this
 *    provider in as the primary provider behind ProviderRouter, with
 *    AnthropicProvider as its fallback — that wiring lives entirely in
 *    providerRouter.ts and index.ts, not in this file.
 *  - Batch 5.5C confirmed every real runtime AI call site now goes through
 *    getAiProvider() (packages/ai/src/index.ts): apps/worker's candidate
 *    scan / deep analysis already did before this batch; the only bypass
 *    was supabase/functions/coach-chat/index.ts, which called the
 *    Anthropic API directly with a raw fetch() — that's fixed as of this
 *    batch (see that file's header comment and its deno.json import map).
 *    AI_PROVIDER still defaults to "anthropic"; this provider is only
 *    reached (via ProviderRouter) when AI_PROVIDER=gemini is explicitly set.
 *
 * IMPORTANT: like AnthropicProvider, this class runs server-side ONLY
 * (apps/worker or a Supabase Edge Function). Never import this package
 * from apps/web client code — GEMINI_API_KEY must never reach the browser.
 */

// ---------------------------------------------------------------------------
// Model configuration (spec section 6)
// ---------------------------------------------------------------------------

interface GeminiModelConfig {
  scanModel: string;
  deepModel: string;
  coachModel: string;
}

/**
 * Unlike AnthropicProvider (which silently falls back to a hardcoded
 * default model), the spec for this batch requires Gemini to fail safely
 * if its model configuration is missing, rather than guessing a model
 * name that may not exist / may not be the one the operator intended.
 */
function loadModelConfig(): GeminiModelConfig {
  const scanModel = process.env.GEMINI_SCAN_MODEL;
  const deepModel = process.env.GEMINI_DEEP_MODEL;
  const coachModel = process.env.GEMINI_COACH_MODEL;

  const missing = [
    !scanModel && "GEMINI_SCAN_MODEL",
    !deepModel && "GEMINI_DEEP_MODEL",
    !coachModel && "GEMINI_COACH_MODEL",
  ].filter(Boolean);

  if (missing.length > 0) {
    throw new ProviderError({
      kind: "configuration",
      provider: "gemini",
      message: `Missing required Gemini model configuration: ${missing.join(", ")}. Set these ` +
        "server-side (see .env.example) before constructing GeminiProvider.",
    });
  }

  return { scanModel: scanModel!, deepModel: deepModel!, coachModel: coachModel! };
}

const DEFAULT_TIMEOUT_MS = 30_000;

function loadTimeoutMs(): number {
  const raw = process.env.GEMINI_TIMEOUT_MS;
  if (!raw) return DEFAULT_TIMEOUT_MS;
  const parsed = Number(raw);
  return Number.isFinite(parsed) && parsed > 0 ? parsed : DEFAULT_TIMEOUT_MS;
}

// ---------------------------------------------------------------------------
// Error classification (spec section 10)
// ---------------------------------------------------------------------------

/**
 * Classifies any error thrown while talking to Gemini into the shared
 * ProviderError shape (packages/ai/src/providerError.ts). Never includes
 * GEMINI_API_KEY or any other secret in the resulting message.
 */
function classifyGeminiError(err: unknown): ProviderError {
  if (err instanceof ProviderError) return err;

  if (err instanceof Error && err.name === "AbortError") {
    return new ProviderError({
      kind: "timeout",
      provider: "gemini",
      message: "Gemini request exceeded the configured timeout",
      cause: err,
    });
  }

  if (err instanceof ApiError) {
    const status = err.status;
    if (status === 401 || status === 403) {
      return new ProviderError({
        kind: "authentication",
        provider: "gemini",
        message: "Gemini rejected the request as unauthenticated/unauthorized",
        cause: err,
      });
    }
    if (status === 429) {
      return new ProviderError({
        kind: "rate_limit",
        provider: "gemini",
        message: "Gemini rate limit exceeded",
        cause: err,
      });
    }
    if (status === 400 || status === 404) {
      return new ProviderError({
        kind: "malformed_response",
        provider: "gemini",
        message: "Gemini rejected the request as invalid (bad request / unknown model)",
        cause: err,
      });
    }
    if (typeof status === "number" && status >= 500) {
      return new ProviderError({
        kind: "transient",
        provider: "gemini",
        message: "Gemini server error — likely transient",
        cause: err,
      });
    }
    return new ProviderError({
      kind: "unknown",
      provider: "gemini",
      message: "Gemini API error",
      cause: err,
    });
  }

  if (err instanceof SyntaxError) {
    return new ProviderError({
      kind: "malformed_response",
      provider: "gemini",
      message: "Gemini response could not be parsed as JSON",
      cause: err,
    });
  }

  return new ProviderError({
    kind: "unknown",
    provider: "gemini",
    message: "Unknown error while calling Gemini",
    cause: err,
  });
}

/** Runs `fn` with a bounded timeout (spec section 9), classifying any
 * failure — including the timeout itself — via classifyGeminiError. */
async function withTimeout<T>(fn: (signal: AbortSignal) => Promise<T>, timeoutMs: number): Promise<T> {
  const controller = new AbortController();
  const timer = setTimeout(() => controller.abort(), timeoutMs);
  try {
    return await fn(controller.signal);
  } catch (err) {
    throw classifyGeminiError(err);
  } finally {
    clearTimeout(timer);
  }
}

// ---------------------------------------------------------------------------
// Frame -> Gemini part conversion (spec section 8)
// ---------------------------------------------------------------------------

const DEFAULT_IMAGE_MIME_TYPE = "image/jpeg";

/** Refuses anything that looks like a local filesystem reference. Worker
 * frames must always arrive as imageBase64 (see
 * apps/worker/src/pipeline/encodeFrame.ts) — this is a defense-in-depth
 * check, not the primary mechanism, since GameplayFrame.imageUrl is a
 * legitimate field other callers may still populate with a real remote
 * signed URL. */
function isLocalFilesystemReference(value: string): boolean {
  const lowered = value.toLowerCase();
  return (
    lowered.startsWith("/") ||
    lowered.startsWith("file://") ||
    lowered.includes("localhost") ||
    lowered.includes("127.0.0.1")
  );
}

/** Converts one GameplayFrame into a Gemini inlineData Part. Gemini's
 * generateContent has no mechanism to fetch a URL on our behalf the way
 * Anthropic's `source: {type: "url"}` does, so any imageUrl must be
 * fetched here and inlined as real bytes — never passed through as a
 * bare string, and never a local/file:// path (see spec section 8/15). */
async function frameToGeminiPart(frame: GameplayFrame, timeoutMs: number): Promise<Part> {
  if (frame.imageBase64) {
    return { inlineData: { mimeType: DEFAULT_IMAGE_MIME_TYPE, data: frame.imageBase64 } };
  }

  if (frame.imageUrl) {
    if (isLocalFilesystemReference(frame.imageUrl) || !/^https?:\/\//i.test(frame.imageUrl)) {
      throw new ProviderError({
        kind: "configuration",
        provider: "gemini",
        message:
          "Refusing to send a non-http(s) / local-filesystem image reference to Gemini. Frames " +
          "must be provided as imageBase64 or a fetchable https:// URL.",
      });
    }

    return withTimeout(async (signal) => {
      const res = await fetch(frame.imageUrl!, { signal });
      if (!res.ok) {
        throw new ProviderError({
          kind: "transient",
          provider: "gemini",
          message: `Failed to fetch frame image for Gemini (HTTP ${res.status})`,
        });
      }
      const buffer = Buffer.from(await res.arrayBuffer());
      return {
        inlineData: {
          mimeType: res.headers.get("content-type") || DEFAULT_IMAGE_MIME_TYPE,
          data: buffer.toString("base64"),
        },
      };
    }, timeoutMs);
  }

  throw new ProviderError({
    kind: "configuration",
    provider: "gemini",
    message: "GameplayFrame requires imageUrl or imageBase64",
  });
}

async function framesToGeminiParts(
  frames: GameplayFrame[],
  timeoutMs: number,
  labelFn?: (index: number, frame: GameplayFrame) => string
): Promise<Part[]> {
  const parts: Part[] = [];
  for (let i = 0; i < frames.length; i++) {
    if (labelFn) parts.push({ text: labelFn(i, frames[i]) });
    parts.push(await frameToGeminiPart(frames[i], timeoutMs));
  }
  return parts;
}

// ---------------------------------------------------------------------------
// JSON parsing helpers (mirrors anthropicProvider.ts's safeParseJsonArray)
// ---------------------------------------------------------------------------

function stripJsonFences(text: string): string {
  return text.replace(/```json|```/g, "").trim();
}

function safeParseJsonArray(text: string): unknown[] {
  const parsed = JSON.parse(stripJsonFences(text));
  return Array.isArray(parsed) ? parsed : [parsed];
}

function safeParseJsonObject(text: string): unknown {
  return JSON.parse(stripJsonFences(text));
}

// ---------------------------------------------------------------------------
// AI Coach citation handling — duplicated from anthropicProvider.ts (which
// itself duplicates supabase/functions/coach-chat/index.ts, see that file's
// header comment) rather than shared, since each runtime imports
// independently. Keep all three in sync if this format ever changes.
// ---------------------------------------------------------------------------

const CITATION_REGEX = /\{\{cite:([0-9a-fA-F-]{36})\}\}/g;

function extractVerifiedCitations(text: string, allowedIds: Set<string>): string[] {
  const found = new Set<string>();
  for (const match of text.matchAll(CITATION_REGEX)) {
    const id = match[1].toLowerCase();
    if (allowedIds.has(id)) found.add(id);
  }
  return Array.from(found);
}

function formatCitableEventsBlock(events: CitableEvent[]): string {
  if (events.length === 0) {
    return "No analyzed events are available to cite for this request.";
  }
  return events.map((e) => `- ${e.id}: ${e.summary}`).join("\n");
}

const RELIABILITY_RULES = `
You are a professional football (eFootball/PES-style) analyst and coach.
Hard rules — violating any of these is a critical failure:
1. Never claim to see something not visible in the provided frames.
2. Never invent exact player positions, passes, or outcomes that aren't shown.
3. Every finding must be labeled with confidence_level: "confirmed" | "likely" | "uncertain".
4. If you cannot determine something, say so explicitly instead of guessing.
5. event_type must be chosen from the closed vocabulary provided in the prompt — never invent new ones.
6. decision_score and confidence are 0-100 integers.
7. Respond with ONLY valid JSON matching the requested schema. No prose, no markdown fences.
`;

// Batch 6A-3 — player-card extraction prompt. See anthropicProvider.ts's
// PLAYER_CARD_RULES for why this is kept separate from RELIABILITY_RULES
// (written in gameplay-analysis language) rather than reused.
const PLAYER_CARD_RULES = `
You are reading an eFootball player card from the provided image.
Extract only information visibly supported by the image.
Never use outside knowledge.
Never guess missing values.
Unknown or unreadable values must be null.
Do not convert unknown values to zero.
Do not invent attribute fields that are not visibly present on the card.
Do not infer a secondary position that isn't shown.
Do not impose an artificial maximum (such as 99) on Overall — report exactly what is displayed.
Only report a playstyle if it is visibly readable or otherwise directly supported by the image.
Respond with ONLY valid JSON matching the requested schema. No prose, no markdown fences.
`;

// Batch 6B-3 — manager-card extraction prompt. Mirrors
// anthropicProvider.ts's MANAGER_CARD_RULES exactly (see that file's
// comment for why this is its own prompt rather than a PLAYER_CARD_RULES
// variant) — kept duplicated across providers rather than shared, same
// convention as PLAYER_CARD_RULES/RELIABILITY_RULES already being
// duplicated between the two provider files.
const MANAGER_CARD_RULES = `
You are reading an eFootball manager card from the provided image.
Extract only information visibly supported by the image.
Never use outside knowledge about a real-world or in-game manager to fill in a rating.
Do not identify the manager and then supply "typical" or "expected" ratings for them —
report only what is actually printed/displayed on this specific card.
Never guess missing values.
Unknown, hidden, ambiguous, or not-present values must be null.
Do not convert unknown values to zero. Zero is only ever correct if the card literally shows 0.
Do not invent rating fields that are not visibly present on the card.
Respond with ONLY valid JSON matching the requested schema. No prose, no markdown fences.
`;

// ---------------------------------------------------------------------------
// Provider
// ---------------------------------------------------------------------------

export class GeminiProvider implements AiProvider {
  readonly name = "gemini";
  private ai: GoogleGenAI;
  private models: GeminiModelConfig;
  private timeoutMs: number;

  constructor(apiKey: string = process.env.GEMINI_API_KEY ?? "") {
    if (!apiKey) {
      throw new ProviderError({
        kind: "configuration",
        provider: "gemini",
        message:
          "GEMINI_API_KEY is not set. This must be provided server-side only (apps/worker or an " +
          "Edge Function) — never in client code.",
      });
    }
    this.models = loadModelConfig();
    this.timeoutMs = loadTimeoutMs();
    this.ai = new GoogleGenAI({ apiKey });
  }

  /** Shared single-turn generateContent call used by every method below
   * except chat() (which needs true multi-turn contents). Always enforces
   * the timeout and always routes failures through classifyGeminiError. */
  private async generateFromParts(params: {
    model: string;
    systemInstruction: string;
    parts: Part[];
    maxOutputTokens: number;
    jsonResponse?: boolean;
  }): Promise<string> {
    return this.generateFromContents({
      model: params.model,
      systemInstruction: params.systemInstruction,
      contents: [{ role: "user", parts: params.parts }],
      maxOutputTokens: params.maxOutputTokens,
      jsonResponse: params.jsonResponse,
    });
  }

  private async generateFromContents(params: {
    model: string;
    systemInstruction: string;
    contents: Content[];
    maxOutputTokens: number;
    jsonResponse?: boolean;
  }): Promise<string> {
    return withTimeout(async (signal) => {
      const response = await this.ai.models.generateContent({
        model: params.model,
        contents: params.contents,
        config: {
          systemInstruction: params.systemInstruction,
          maxOutputTokens: params.maxOutputTokens,
          ...(params.jsonResponse ? { responseMimeType: "application/json" } : {}),
          abortSignal: signal,
        },
      });

      const text = response.text;
      if (!text) {
        throw new ProviderError({
          kind: "malformed_response",
          provider: "gemini",
          message: "Gemini returned an empty response",
        });
      }
      return text;
    }, this.timeoutMs);
  }

  async scanForCandidateMoments(input: ScanForCandidateMomentsInput): Promise<CandidateMoment[]> {
    if (input.frames.length === 0) return [];

    const frameParts = await framesToGeminiParts(
      input.frames,
      this.timeoutMs,
      (i, f) => `Frame ${i} (t=${(f as { timestampSeconds: number }).timestampSeconds}s):`
    );

    const text = await this.generateFromParts({
      model: this.models.scanModel,
      systemInstruction:
        "You are doing a cheap, fast triage pass over eFootball gameplay frames — not a full " +
        "analysis. For each numbered frame, decide only whether it looks like a notable football " +
        "decision is happening (a pass, shot, tackle, dribble/1v1, key positioning moment) as " +
        "opposed to a menu screen, replay, pause, loading screen, or otherwise uninteresting " +
        "moment. Respond with ONLY valid JSON — no prose, no markdown fences.",
      parts: [
        ...frameParts,
        {
          text: `Match context: ${JSON.stringify(input.matchContext ?? {})}.

Return a JSON array of the frame indices that show a notable football decision, each matching:
{ "frameIndex": number, "reason": string }
Return [] if none of the frames above look notable. Do not flag a frame just because it was sampled — most frames in a match are not notable.`,
        },
      ],
      maxOutputTokens: 1000,
      jsonResponse: true,
    });

    let flagged: { frameIndex: number; reason?: string }[];
    try {
      flagged = safeParseJsonArray(text) as { frameIndex: number; reason?: string }[];
    } catch (err) {
      throw classifyGeminiError(err);
    }

    return flagged
      .filter((f) => typeof f.frameIndex === "number" && input.frames[f.frameIndex])
      .map((f) => ({
        timestampSeconds: input.frames[f.frameIndex].timestampSeconds,
        reason: f.reason,
      }));
  }

  async analyzeScreenshot(input: AnalyzeScreenshotInput): Promise<DetectedEventDraft[]> {
    const eventTypeVocab = await import("@efootball/shared").then((m) => m.EVENT_TYPES);
    const frameParts = await framesToGeminiParts(input.frames, this.timeoutMs);

    const text = await this.generateFromParts({
      model: this.models.deepModel,
      systemInstruction: RELIABILITY_RULES,
      parts: [
        ...frameParts,
        {
          text: `Analyze this eFootball screenshot as a coach. Match context: ${JSON.stringify(
            input.matchContext ?? {}
          )}.

Closed event_type vocabulary by category: ${JSON.stringify(eventTypeVocab)}

Return a JSON array of detected decision events, each matching this shape:
{
  "event_type": string (from vocabulary above),
  "category": "passing"|"dribbling"|"attacking"|"defending"|"transition"|"build_up",
  "severity": "excellent"|"good"|"minor_issue"|"mistake"|"critical_mistake",
  "decision_score": number 0-100,
  "confidence": number 0-100,
  "confidence_level": "confirmed"|"likely"|"uncertain",
  "description": string,
  "better_option": string | null,
  "reasoning": string | null,
  "timestamp_seconds": null,
  "context_start_seconds": null,
  "context_end_seconds": null,
  "involvesSelfPlayer": boolean (true ONLY if you can reliably tell this decision was made by the
    human user's own controlled player — e.g. the actively-controlled player indicator, or the
    action is clearly the user's team in possession with no ambiguity about who's controlling. If
    it's an AI teammate's automated action, an opponent's action, or genuinely unclear who was
    controlling, set this to false. Never guess true just because a player is on the user's team.)
}
Return [] if no clear decision is visible. Do not invent events.`,
        },
      ],
      maxOutputTokens: 4000,
      jsonResponse: true,
    });

    try {
      return safeParseJsonArray(text) as DetectedEventDraft[];
    } catch (err) {
      throw classifyGeminiError(err);
    }
  }

  /** Batch 3.5 spec section 6 (see anthropicProvider.ts): extract real
   * per-player statistics from a statistics screen. Returns [] if the
   * frame(s) don't show a stats screen at all. */
  async extractPlayerStatistics(input: ExtractPlayerStatisticsInput): Promise<PlayerStatisticsDraft[]> {
    const { PLAYER_STAT_CATEGORIES } = await import("@efootball/shared");
    const frameParts = await framesToGeminiParts(input.frames, this.timeoutMs);

    const text = await this.generateFromParts({
      model: this.models.deepModel,
      systemInstruction: `${RELIABILITY_RULES}
You are extracting REAL numbers from an eFootball statistics screen (post-match summary, player
rating screen, or in-match stats overlay) — not analyzing gameplay decisions this time.
Additional hard rules for THIS task:
8. If the frame(s) do not show a statistics screen at all (menu, gameplay, replay, loading, etc.),
   return an empty array [] immediately. Do not guess numbers from a non-statistics frame.
9. Only include a field if its number is ACTUALLY VISIBLE AND LEGIBLE on screen. Omit (do not
   include the key at all, or set it to null) any field that is not shown, blurry, cut off, or
   ambiguous — never estimate, never infer one stat from another, never carry over a "typical"
   value.
10. A player ATTRIBUTE (e.g. Ball Control on a player card, a fixed 0-99 rating) is NOT the same
    thing as a match PERFORMANCE statistic (e.g. successful dribbles actually completed this
    match). Only extract match performance numbers here — do not report card attribute ratings
    as if they were performance stats.
11. If multiple players' rows are visible (a full player-ratings list), return one array element
    per player actually shown, each with their own playerName and only the columns that list
    actually contains. If only one player's stats are shown (the common case — the human user's
    own controlled-player summary), return exactly one element with isSelf=true and playerName
    set to whatever name is shown, or null if no name is shown.`,
      parts: [
        ...frameParts,
        {
          text: `Match context: ${JSON.stringify(input.matchContext ?? {})}.

Stat fields by category (use these exact key names, only when actually visible):
${JSON.stringify(PLAYER_STAT_CATEGORIES)}

Return a JSON array. Each element:
{
  "playerName": string | null,
  "isSelf": boolean,
  "confidence": number 0-100 (your confidence in this whole extraction),
  "notes": string | null (brief note on what screen this was / anything ambiguous),
  ...any of the stat field keys above, each a number, OMITTED or null if not visible
}
Return [] if no statistics screen is visible in the provided frame(s).`,
        },
      ],
      maxOutputTokens: 4000,
      jsonResponse: true,
    });

    try {
      return safeParseJsonArray(text) as PlayerStatisticsDraft[];
    } catch (err) {
      throw classifyGeminiError(err);
    }
  }

  async analyzeVideoContext(input: AnalyzeVideoContextInput): Promise<DetectedEventDraft[]> {
    const eventTypeVocab = await import("@efootball/shared").then((m) => m.EVENT_TYPES);
    const frameParts = await framesToGeminiParts(input.frames, this.timeoutMs);

    const text = await this.generateFromParts({
      model: this.models.deepModel,
      systemInstruction: RELIABILITY_RULES,
      parts: [
        ...frameParts,
        {
          text: `These sampled frames span ${input.contextStartSeconds}s to ${input.contextEndSeconds}s
around a candidate moment at ${input.eventTimestampSeconds}s. Analyze what happened BEFORE,
DURING, and AFTER the key decision, exactly like the screenshot flow.

Closed event_type vocabulary: ${JSON.stringify(eventTypeVocab)}

Return a JSON array of confirmed decision events (same schema as screenshot analysis, including
the involvesSelfPlayer boolean described there, but
timestamp_seconds/context_start_seconds/context_end_seconds should be filled in using the
provided window). Return [] if this window does not actually contain a clear decision —
do not force a finding just because a window was sampled here.`,
        },
      ],
      maxOutputTokens: 4000,
      jsonResponse: true,
    });

    try {
      return safeParseJsonArray(text) as DetectedEventDraft[];
    } catch (err) {
      throw classifyGeminiError(err);
    }
  }

  async generateTacticalAnalysis(
    event: DetectedEventDraft,
    frames: GameplayFrame[]
  ): Promise<TacticalAnalysisDraft> {
    const frameParts = await framesToGeminiParts(frames, this.timeoutMs);

    const text = await this.generateFromParts({
      model: this.models.deepModel,
      systemInstruction: RELIABILITY_RULES,
      parts: [
        ...frameParts,
        {
          text: `Given this decision event: ${JSON.stringify(event)}

Produce tactical diagram data as JSON matching:
{
  "actual_positions": [{ "role": string, "team": "user"|"opponent", "pos": {"x":0-100,"y":0-100} }] | null,
  "recommended_positions": [...] | null,
  "passing_lanes": [{ "from": {x,y}, "to": {x,y}, "quality": "good"|"risky"|"recommended" }] | null,
  "movement_arrows": [{ "from": {x,y}, "to": {x,y}, "label": string }] | null,
  "pressure_zones": [{ "center": {x,y}, "radius": number, "intensity": 0-1 }] | null,
  "open_spaces": [{ "center": {x,y}, "radius": number }] | null,
  "is_approximate": boolean,
  "explanation": string
}
Set is_approximate=true unless positions are unambiguous from the frames. Coordinates are
percentages of pitch width(x)/length(y), 0-100. Only include fields you can reasonably infer;
use null for anything you cannot determine from the visible frames.`,
        },
      ],
      maxOutputTokens: 2000,
      jsonResponse: true,
    });

    try {
      return safeParseJsonObject(text) as TacticalAnalysisDraft;
    } catch (err) {
      throw classifyGeminiError(err);
    }
  }

  async chat(input: CoachChatInput): Promise<CoachChatOutput> {
    const contents: Content[] = [
      ...input.recentMessages.map((m) => ({
        role: m.role === "assistant" ? ("model" as const) : ("user" as const),
        parts: [{ text: m.content }],
      })),
      { role: "user" as const, parts: [{ text: input.userMessage }] },
    ];

    const systemInstruction = `${RELIABILITY_RULES}
You are the player's AI Coach. Ground every answer in the REAL match data summary below.
If the summary doesn't contain enough evidence to answer specifically, say so plainly instead
of giving generic football advice. Respond in the same language the user wrote in.

CITING SPECIFIC EVENTS: when your answer references one of the specific analyzed events listed
below, cite it inline right after the claim using exactly this format: {{cite:EVENT_ID}} — using
only an EVENT_ID that appears in the list below, copied exactly. Never invent an id, never cite
an id that is not listed, and don't force a citation where none of the listed events are actually
relevant — plenty of good coaching answers won't cite anything.

CITABLE EVENTS FOR THIS REQUEST:
${formatCitableEventsBlock(input.citableEvents)}

REAL MATCH DATA SUMMARY:
${input.userContextSummary}`;

    // Deliberately no jsonResponse here — chat replies are free-form prose
    // with inline {{cite:...}} tokens, not structured JSON.
    const reply = await this.generateFromContents({
      model: this.models.coachModel,
      systemInstruction,
      contents,
      maxOutputTokens: 1500,
    });

    const allowedIds = new Set(input.citableEvents.map((e) => e.id.toLowerCase()));
    const referencedEventIds = extractVerifiedCitations(reply, allowedIds);

    return { reply, referencedEventIds };
  }

  /** Batch 6A-3: extract a structured draft from a single uploaded
   * player-card image. Mirrors AnthropicProvider.extractPlayerCard — see
   * that method's header comment for the validation-ownership split
   * (this method may throw on malformed output; the caller's
   * validatePlayerCardDraft in packages/shared/src/playerCard.ts sanitizes
   * a structurally-valid-but-semantically-off response). */
  async extractPlayerCard(input: ExtractPlayerCardInput): Promise<PlayerCardDraft> {
    const framePart = await frameToGeminiPart(input.frame, this.timeoutMs);

    const text = await this.generateFromParts({
      model: this.models.deepModel,
      systemInstruction: PLAYER_CARD_RULES,
      parts: [
        framePart,
        {
          text: `This image is an eFootball player-card screenshot. It may show a player portrait, name,
overall, position, playstyle, attributes, and other visible eFootball information — do not assume
every card has the same layout.

Return a JSON object matching exactly this schema:
{
  "name": string | null,
  "position": string | null,
  "overall": integer | null,
  "playstyle": string | null,
  "attributes": { [visibleAttributeName: string]: number | string | null },
  "extraction_confidence": number 0-100 (your confidence in this extraction as a whole — reflects
    how legible/clear the image was, never how well-known the player is),
  "field_evidence": [
    { "field": string, "visible": boolean, "confidence": number 0-100 | null, "note": string | null }
  ] (one entry per field you attempted to read, including "attributes.<name>" for each attribute key)
}

"attributes" keys should be whatever the card actually shows (examples only, not a required list:
offensive_awareness, ball_control, dribbling, tight_possession, low_pass, lofted_pass, finishing,
heading, set_piece_taking, curl, speed, acceleration, kicking_power, jumping, physical_contact,
balance, stamina, defensive_awareness, tackling, defensive_engagement, aggression, goalkeeper
attributes). Do not include a key for an attribute that isn't visible on this specific card.`,
        },
      ],
      maxOutputTokens: 2000,
      jsonResponse: true,
    });

    try {
      return safeParseJsonObject(text) as PlayerCardDraft;
    } catch (err) {
      throw classifyGeminiError(err);
    }
  }

  /** Batch 6B-3: extract a structured draft from a single uploaded
   * manager-card image. Mirrors AnthropicProvider.extractManagerCard —
   * see that method's header comment for the validation-ownership split
   * (this method may throw on malformed output; the caller's
   * validateManagerCardDraft in packages/shared/src/managerCard.ts
   * sanitizes a structurally-valid-but-semantically-off response). */
  async extractManagerCard(input: ExtractManagerCardInput): Promise<ManagerCardDraft> {
    const framePart = await frameToGeminiPart(input.frame, this.timeoutMs);

    const text = await this.generateFromParts({
      model: this.models.deepModel,
      systemInstruction: MANAGER_CARD_RULES,
      parts: [
        framePart,
        {
          text: `This image is an eFootball manager-card screenshot. It may show a manager portrait, name,
and tactical style ratings — do not assume every card shows every rating.

Return a JSON object matching exactly this schema:
{
  "name": string | null,
  "possession_rating": integer | null,
  "quick_counter_rating": integer | null,
  "long_ball_counter_rating": integer | null,
  "out_wide_rating": integer | null,
  "long_ball_rating": integer | null,
  "extraction_confidence": number 0-100 | null (your confidence in this extraction as a whole —
    reflects how legible/clear the image was, never how well-known the manager is; use null, not 0,
    if you cannot form any meaningful confidence),
  "field_evidence": [
    { "field": string, "visible": boolean, "confidence": number 0-100 | null, "note": string | null }
  ] (one entry per field you attempted to read: "name", "possession_rating", "quick_counter_rating",
    "long_ball_counter_rating", "out_wide_rating", "long_ball_rating")
}

Only include a rating if it is actually visible and legible on this specific card. If a rating is
hidden, cropped, blurry, or simply not shown on this card layout, its value must be null — never 0,
never a value inferred from recognizing the manager.`,
        },
      ],
      maxOutputTokens: 1500,
      jsonResponse: true,
    });

    try {
      return safeParseJsonObject(text) as ManagerCardDraft;
    } catch (err) {
      throw classifyGeminiError(err);
    }
  }
}
