import Anthropic from "@anthropic-ai/sdk";
import type {
  AiProvider,
  AnalyzeScreenshotInput,
  AnalyzeVideoContextInput,
  ScanForCandidateMomentsInput,
  CandidateMoment,
  DetectedEventDraft,
  TacticalAnalysisDraft,
  CoachChatInput,
  CoachChatOutput,
  CitableEvent,
  GameplayFrame,
  ExtractPlayerStatisticsInput,
  ExtractPlayerCardInput,
  ExtractManagerCardInput,
} from "../provider.js";
import type { PlayerStatisticsDraft, PlayerCardDraft, ManagerCardDraft } from "@efootball/shared";

/**
 * Configurable per-purpose models (D.1). Every real analysis call
 * (screenshot / video-context / tactical diagram) uses DEEP_MODEL —
 * these need the strongest reasoning since they produce the findings
 * that get persisted. The candidate-moment scan is a cheap yes/no pass
 * run many times per match, so it defaults to a lighter model. Chat uses
 * its own var because supabase/functions/coach-chat/index.ts (a separate
 * Deno runtime that can't import this package) reads the same env var
 * name to stay in sync with this provider.
 *
 * Naming (Batch 3): AI_ANALYSIS_MODEL was renamed to AI_DEEP_MODEL to
 * match AI_SCAN_MODEL / AI_COACH_MODEL. No back-compat fallback to the
 * old name is provided — this repo hasn't shipped yet, so there's no
 * deployed environment relying on AI_ANALYSIS_MODEL.
 */
const DEEP_MODEL = process.env.AI_DEEP_MODEL ?? "claude-sonnet-4-6";
const SCAN_MODEL = process.env.AI_SCAN_MODEL ?? "claude-haiku-4-5-20251001";
const COACH_MODEL = process.env.AI_COACH_MODEL ?? "claude-sonnet-4-6";

const RELIABILITY_RULES = `
You are a professional football (eFootball/PES-style) analyst and coach.
Hard rules — violating any of these is a critical failure:
1. Never claim to see something not visible in the provided frames.
2. Never invent exact player positions, passes, or outcomes that aren't shown.
3. Every finding must be labeled with confidence_level: "confirmed" | "likely" | "uncertain".
4. If you cannot determine something, say so explicitly instead of guessing.
5. event_type must be chosen from the closed vocabulary provided in the prompt — never invent new ones.
6. decision_score and confidence are 0-100 integers.
7. Respond with ONLY valid JSON matching the requested schema. No prose, no markdown fences.
`;

function frameToContentBlock(frame: GameplayFrame) {
  if (frame.imageBase64) {
    return {
      type: "image" as const,
      source: { type: "base64" as const, media_type: "image/jpeg" as const, data: frame.imageBase64 },
    };
  }
  if (frame.imageUrl) {
    return { type: "image" as const, source: { type: "url" as const, url: frame.imageUrl } };
  }
  throw new Error("GameplayFrame requires imageUrl or imageBase64");
}

function safeParseJsonArray(text: string): unknown[] {
  const cleaned = text.replace(/```json|```/g, "").trim();
  const parsed = JSON.parse(cleaned);
  return Array.isArray(parsed) ? parsed : [parsed];
}

/** Batch 6A-3: single-object counterpart to safeParseJsonArray — the
 * player-card extraction returns exactly one draft, not an array. */
function safeParseJsonObject(text: string): unknown {
  const cleaned = text.replace(/```json|```/g, "").trim();
  return JSON.parse(cleaned);
}

// Batch 6A-3 — player-card extraction prompt. A card is a completely
// different source image than a gameplay/statistics screenshot: no
// event/decision to judge, no closed vocabulary, and the set of visible
// attributes varies by card layout. Kept separate from RELIABILITY_RULES
// (which is written in gameplay-analysis language) rather than bent to
// fit it.
const PLAYER_CARD_RULES = `
You are reading an eFootball player card from the provided image.
Extract only information visibly supported by the image.
Never use outside knowledge.
Never guess missing values.
Unknown or unreadable values must be null.
Do not convert unknown values to zero.
Do not invent attribute fields that are not visibly present on the card.
Do not infer a secondary position that isn't shown.
Do not impose an artificial maximum (such as 99) on Overall — report exactly what is displayed.
Only report a playstyle if it is visibly readable or otherwise directly supported by the image.
Respond with ONLY valid JSON matching the requested schema. No prose, no markdown fences.
`;

// Batch 6B-3 — manager-card extraction prompt. A manager card shows a
// fixed, small set of named tactical style ratings (unlike a player
// card's open/variable attribute set) — kept as its own prompt (not a
// variant of PLAYER_CARD_RULES) since the fabrication risk here is
// specifically "recognizing a well-known manager by name/portrait and
// filling in ratings from outside football knowledge instead of what's
// actually printed on this card", which is worth calling out explicitly.
const MANAGER_CARD_RULES = `
You are reading an eFootball manager card from the provided image.
Extract only information visibly supported by the image.
Never use outside knowledge about a real-world or in-game manager to fill in a rating.
Do not identify the manager and then supply "typical" or "expected" ratings for them —
report only what is actually printed/displayed on this specific card.
Never guess missing values.
Unknown, hidden, ambiguous, or not-present values must be null.
Do not convert unknown values to zero. Zero is only ever correct if the card literally shows 0.
Do not invent rating fields that are not visibly present on the card.
Respond with ONLY valid JSON matching the requested schema. No prose, no markdown fences.
`;

// Batch 3: AI Coach citations. Deterministic, easy to regex out of plain
// text (unlike asking the model for structured JSON, which would give up
// the free-form chat reply). NOTE: supabase/functions/coach-chat/index.ts
// runs on Deno and can't import this package (see that file's header
// comment for why), so it duplicates this same regex/format — keep the
// two in sync if this ever changes.
const CITATION_REGEX = /\{\{cite:([0-9a-fA-F-]{36})\}\}/g;

/**
 * Extracts every {{cite:UUID}} token from the model's reply and returns
 * only the ids that were actually offered to it in `allowedIds` — the
 * model is instructed to only cite from that list, but nothing here
 * *trusts* that instruction was followed. Deduplicated, order-preserving.
 */
function extractVerifiedCitations(text: string, allowedIds: Set<string>): string[] {
  const found = new Set<string>();
  for (const match of text.matchAll(CITATION_REGEX)) {
    const id = match[1].toLowerCase();
    if (allowedIds.has(id)) found.add(id);
  }
  return Array.from(found);
}

function formatCitableEventsBlock(events: CitableEvent[]): string {
  if (events.length === 0) {
    return "No analyzed events are available to cite for this request.";
  }
  return events.map((e) => `- ${e.id}: ${e.summary}`).join("\n");
}

export class AnthropicProvider implements AiProvider {
  readonly name = "anthropic";
  private client: Anthropic;

  constructor(apiKey: string = process.env.ANTHROPIC_API_KEY ?? "") {
    if (!apiKey) {
      throw new Error(
        "ANTHROPIC_API_KEY is not set. This must be provided server-side only " +
          "(apps/worker or an Edge Function) — never in client code."
      );
    }
    this.client = new Anthropic({ apiKey });
  }

  async scanForCandidateMoments(input: ScanForCandidateMomentsInput): Promise<CandidateMoment[]> {
    if (input.frames.length === 0) return [];

    const response = await this.client.messages.create({
      model: SCAN_MODEL,
      max_tokens: 1000,
      system:
        "You are doing a cheap, fast triage pass over eFootball gameplay frames — not a full " +
        "analysis. For each numbered frame, decide only whether it looks like a notable football " +
        "decision is happening (a pass, shot, tackle, dribble/1v1, key positioning moment) as " +
        "opposed to a menu screen, replay, pause, loading screen, or otherwise uninteresting " +
        "moment. Respond with ONLY valid JSON — no prose, no markdown fences.",
      messages: [
        {
          role: "user",
          content: [
            ...input.frames.flatMap((frame, i) => [
              { type: "text" as const, text: `Frame ${i} (t=${frame.timestampSeconds}s):` },
              frameToContentBlock(frame),
            ]),
            {
              type: "text",
              text: `Match context: ${JSON.stringify(input.matchContext ?? {})}.

Return a JSON array of the frame indices that show a notable football decision, each matching:
{ "frameIndex": number, "reason": string }
Return [] if none of the frames above look notable. Do not flag a frame just because it was sampled — most frames in a match are not notable.`,
            },
          ],
        },
      ],
    });

    const textBlock = response.content.find((b) => b.type === "text");
    if (!textBlock || textBlock.type !== "text") return [];

    const flagged = safeParseJsonArray(textBlock.text) as { frameIndex: number; reason?: string }[];
    return flagged
      .filter((f) => typeof f.frameIndex === "number" && input.frames[f.frameIndex])
      .map((f) => ({
        timestampSeconds: input.frames[f.frameIndex].timestampSeconds,
        reason: f.reason,
      }));
  }

  async analyzeScreenshot(input: AnalyzeScreenshotInput): Promise<DetectedEventDraft[]> {
    const eventTypeVocab = await import("@efootball/shared").then((m) => m.EVENT_TYPES);

    const response = await this.client.messages.create({
      model: DEEP_MODEL,
      max_tokens: 4000,
      system: RELIABILITY_RULES,
      messages: [
        {
          role: "user",
          content: [
            ...input.frames.map(frameToContentBlock),
            {
              type: "text",
              text: `Analyze this eFootball screenshot as a coach. Match context: ${JSON.stringify(
                input.matchContext ?? {}
              )}.

Closed event_type vocabulary by category: ${JSON.stringify(eventTypeVocab)}

Return a JSON array of detected decision events, each matching this shape:
{
  "event_type": string (from vocabulary above),
  "category": "passing"|"dribbling"|"attacking"|"defending"|"transition"|"build_up",
  "severity": "excellent"|"good"|"minor_issue"|"mistake"|"critical_mistake",
  "decision_score": number 0-100,
  "confidence": number 0-100,
  "confidence_level": "confirmed"|"likely"|"uncertain",
  "description": string,
  "better_option": string | null,
  "reasoning": string | null,
  "timestamp_seconds": null,
  "context_start_seconds": null,
  "context_end_seconds": null,
  "involvesSelfPlayer": boolean (true ONLY if you can reliably tell this decision was made by the
    human user's own controlled player — e.g. the actively-controlled player indicator, or the
    action is clearly the user's team in possession with no ambiguity about who's controlling. If
    it's an AI teammate's automated action, an opponent's action, or genuinely unclear who was
    controlling, set this to false. Never guess true just because a player is on the user's team.)
}
Return [] if no clear decision is visible. Do not invent events.`,
            },
          ],
        },
      ],
    });

    const textBlock = response.content.find((b) => b.type === "text");
    if (!textBlock || textBlock.type !== "text") return [];
    return safeParseJsonArray(textBlock.text) as DetectedEventDraft[];
  }

  /** Batch 3.5 spec section 6: extract real per-player statistics from a
   * statistics screen. Returns [] if the frame(s) don't show a stats
   * screen at all — the model is explicitly told not to force a finding. */
  async extractPlayerStatistics(input: ExtractPlayerStatisticsInput): Promise<PlayerStatisticsDraft[]> {
    const { PLAYER_STAT_CATEGORIES } = await import("@efootball/shared");

    const response = await this.client.messages.create({
      model: DEEP_MODEL,
      max_tokens: 4000,
      system: `${RELIABILITY_RULES}
You are extracting REAL numbers from an eFootball statistics screen (post-match summary, player
rating screen, or in-match stats overlay) — not analyzing gameplay decisions this time.
Additional hard rules for THIS task:
8. If the frame(s) do not show a statistics screen at all (menu, gameplay, replay, loading, etc.),
   return an empty array [] immediately. Do not guess numbers from a non-statistics frame.
9. Only include a field if its number is ACTUALLY VISIBLE AND LEGIBLE on screen. Omit (do not
   include the key at all, or set it to null) any field that is not shown, blurry, cut off, or
   ambiguous — never estimate, never infer one stat from another, never carry over a "typical"
   value.
10. A player ATTRIBUTE (e.g. Ball Control on a player card, a fixed 0-99 rating) is NOT the same
    thing as a match PERFORMANCE statistic (e.g. successful dribbles actually completed this
    match). Only extract match performance numbers here — do not report card attribute ratings
    as if they were performance stats.
11. If multiple players' rows are visible (a full player-ratings list), return one array element
    per player actually shown, each with their own playerName and only the columns that list
    actually contains. If only one player's stats are shown (the common case — the human user's
    own controlled-player summary), return exactly one element with isSelf=true and playerName
    set to whatever name is shown, or null if no name is shown.`,
      messages: [
        {
          role: "user",
          content: [
            ...input.frames.map(frameToContentBlock),
            {
              type: "text",
              text: `Match context: ${JSON.stringify(input.matchContext ?? {})}.

Stat fields by category (use these exact key names, only when actually visible):
${JSON.stringify(PLAYER_STAT_CATEGORIES)}

Return a JSON array. Each element:
{
  "playerName": string | null,
  "isSelf": boolean,
  "confidence": number 0-100 (your confidence in this whole extraction),
  "notes": string | null (brief note on what screen this was / anything ambiguous),
  ...any of the stat field keys above, each a number, OMITTED or null if not visible
}
Return [] if no statistics screen is visible in the provided frame(s).`,
            },
          ],
        },
      ],
    });

    const textBlock = response.content.find((b) => b.type === "text");
    if (!textBlock || textBlock.type !== "text") return [];
    return safeParseJsonArray(textBlock.text) as PlayerStatisticsDraft[];
  }

  async analyzeVideoContext(input: AnalyzeVideoContextInput): Promise<DetectedEventDraft[]> {
    const eventTypeVocab = await import("@efootball/shared").then((m) => m.EVENT_TYPES);

    const response = await this.client.messages.create({
      model: DEEP_MODEL,
      max_tokens: 4000,
      system: RELIABILITY_RULES,
      messages: [
        {
          role: "user",
          content: [
            ...input.frames.map(frameToContentBlock),
            {
              type: "text",
              text: `These sampled frames span ${input.contextStartSeconds}s to ${input.contextEndSeconds}s
around a candidate moment at ${input.eventTimestampSeconds}s. Analyze what happened BEFORE,
DURING, and AFTER the key decision, exactly like the screenshot flow.

Closed event_type vocabulary: ${JSON.stringify(eventTypeVocab)}

Return a JSON array of confirmed decision events (same schema as screenshot analysis, including
the involvesSelfPlayer boolean described there, but
timestamp_seconds/context_start_seconds/context_end_seconds should be filled in using the
provided window). Return [] if this window does not actually contain a clear decision —
do not force a finding just because a window was sampled here.`,
            },
          ],
        },
      ],
    });

    const textBlock = response.content.find((b) => b.type === "text");
    if (!textBlock || textBlock.type !== "text") return [];
    return safeParseJsonArray(textBlock.text) as DetectedEventDraft[];
  }

  async generateTacticalAnalysis(
    event: DetectedEventDraft,
    frames: GameplayFrame[]
  ): Promise<TacticalAnalysisDraft> {
    const response = await this.client.messages.create({
      model: DEEP_MODEL,
      max_tokens: 2000,
      system: RELIABILITY_RULES,
      messages: [
        {
          role: "user",
          content: [
            ...frames.map(frameToContentBlock),
            {
              type: "text",
              text: `Given this decision event: ${JSON.stringify(event)}

Produce tactical diagram data as JSON matching:
{
  "actual_positions": [{ "role": string, "team": "user"|"opponent", "pos": {"x":0-100,"y":0-100} }] | null,
  "recommended_positions": [...] | null,
  "passing_lanes": [{ "from": {x,y}, "to": {x,y}, "quality": "good"|"risky"|"recommended" }] | null,
  "movement_arrows": [{ "from": {x,y}, "to": {x,y}, "label": string }] | null,
  "pressure_zones": [{ "center": {x,y}, "radius": number, "intensity": 0-1 }] | null,
  "open_spaces": [{ "center": {x,y}, "radius": number }] | null,
  "is_approximate": boolean,
  "explanation": string
}
Set is_approximate=true unless positions are unambiguous from the frames. Coordinates are
percentages of pitch width(x)/length(y), 0-100. Only include fields you can reasonably infer;
use null for anything you cannot determine from the visible frames.`,
            },
          ],
        },
      ],
    });

    const textBlock = response.content.find((b) => b.type === "text");
    if (!textBlock || textBlock.type !== "text") {
      throw new Error("No tactical analysis returned");
    }
    const cleaned = textBlock.text.replace(/```json|```/g, "").trim();
    return JSON.parse(cleaned) as TacticalAnalysisDraft;
  }

  async chat(input: CoachChatInput): Promise<CoachChatOutput> {
    const response = await this.client.messages.create({
      model: COACH_MODEL,
      max_tokens: 1500,
      system: `${RELIABILITY_RULES}
You are the player's AI Coach. Ground every answer in the REAL match data summary below.
If the summary doesn't contain enough evidence to answer specifically, say so plainly instead
of giving generic football advice. Respond in the same language the user wrote in.

CITING SPECIFIC EVENTS: when your answer references one of the specific analyzed events listed
below, cite it inline right after the claim using exactly this format: {{cite:EVENT_ID}} — using
only an EVENT_ID that appears in the list below, copied exactly. Never invent an id, never cite
an id that is not listed, and don't force a citation where none of the listed events are actually
relevant — plenty of good coaching answers won't cite anything.

CITABLE EVENTS FOR THIS REQUEST:
${formatCitableEventsBlock(input.citableEvents)}

REAL MATCH DATA SUMMARY:
${input.userContextSummary}`,
      messages: [
        ...input.recentMessages.map((m) => ({ role: m.role, content: m.content })),
        { role: "user" as const, content: input.userMessage },
      ],
    });

    const textBlock = response.content.find((b) => b.type === "text");
    const reply = textBlock && textBlock.type === "text" ? textBlock.text : "";

    const allowedIds = new Set(input.citableEvents.map((e) => e.id.toLowerCase()));
    const referencedEventIds = extractVerifiedCitations(reply, allowedIds);

    return { reply, referencedEventIds };
  }

  /** Batch 6A-3: extract a structured draft from a single uploaded
   * player-card image. Never persists anything — the caller (an Edge
   * Function today, later the Player Library UI) owns validation/save.
   * Malformed/unparsable model output is allowed to throw here (same as
   * generateTacticalAnalysis above); the caller's validatePlayerCardDraft
   * (packages/shared/src/playerCard.ts) is the layer that sanitizes a
   * structurally-valid-but-semantically-off response, not this method. */
  async extractPlayerCard(input: ExtractPlayerCardInput): Promise<PlayerCardDraft> {
    const response = await this.client.messages.create({
      model: DEEP_MODEL,
      max_tokens: 2000,
      system: PLAYER_CARD_RULES,
      messages: [
        {
          role: "user",
          content: [
            frameToContentBlock(input.frame),
            {
              type: "text",
              text: `This image is an eFootball player-card screenshot. It may show a player portrait, name,
overall, position, playstyle, attributes, and other visible eFootball information — do not assume
every card has the same layout.

Return a JSON object matching exactly this schema:
{
  "name": string | null,
  "position": string | null,
  "overall": integer | null,
  "playstyle": string | null,
  "attributes": { [visibleAttributeName: string]: number | string | null },
  "extraction_confidence": number 0-100 (your confidence in this extraction as a whole — reflects
    how legible/clear the image was, never how well-known the player is),
  "field_evidence": [
    { "field": string, "visible": boolean, "confidence": number 0-100 | null, "note": string | null }
  ] (one entry per field you attempted to read, including "attributes.<name>" for each attribute key)
}

"attributes" keys should be whatever the card actually shows (examples only, not a required list:
offensive_awareness, ball_control, dribbling, tight_possession, low_pass, lofted_pass, finishing,
heading, set_piece_taking, curl, speed, acceleration, kicking_power, jumping, physical_contact,
balance, stamina, defensive_awareness, tackling, defensive_engagement, aggression, goalkeeper
attributes). Do not include a key for an attribute that isn't visible on this specific card.`,
            },
          ],
        },
      ],
    });

    const textBlock = response.content.find((b) => b.type === "text");
    if (!textBlock || textBlock.type !== "text") {
      throw new Error("No player-card extraction returned");
    }
    return safeParseJsonObject(textBlock.text) as PlayerCardDraft;
  }

  /** Batch 6B-3: extract a structured draft from a single uploaded
   * manager-card image. Never persists anything — the caller (this
   * batch's Edge Function, later the Manager Library review/save flow in
   * 6B-4) owns validation/save. Malformed/unparsable model output is
   * allowed to throw here (same as extractPlayerCard above); the
   * caller's validateManagerCardDraft (packages/shared/src/
   * managerCard.ts) is the layer that sanitizes a structurally-valid-but-
   * semantically-off response, not this method. */
  async extractManagerCard(input: ExtractManagerCardInput): Promise<ManagerCardDraft> {
    const response = await this.client.messages.create({
      model: DEEP_MODEL,
      max_tokens: 1500,
      system: MANAGER_CARD_RULES,
      messages: [
        {
          role: "user",
          content: [
            frameToContentBlock(input.frame),
            {
              type: "text",
              text: `This image is an eFootball manager-card screenshot. It may show a manager portrait, name,
and tactical style ratings — do not assume every card shows every rating.

Return a JSON object matching exactly this schema:
{
  "name": string | null,
  "possession_rating": integer | null,
  "quick_counter_rating": integer | null,
  "long_ball_counter_rating": integer | null,
  "out_wide_rating": integer | null,
  "long_ball_rating": integer | null,
  "extraction_confidence": number 0-100 | null (your confidence in this extraction as a whole —
    reflects how legible/clear the image was, never how well-known the manager is; use null, not 0,
    if you cannot form any meaningful confidence),
  "field_evidence": [
    { "field": string, "visible": boolean, "confidence": number 0-100 | null, "note": string | null }
  ] (one entry per field you attempted to read: "name", "possession_rating", "quick_counter_rating",
    "long_ball_counter_rating", "out_wide_rating", "long_ball_rating")
}

Only include a rating if it is actually visible and legible on this specific card. If a rating is
hidden, cropped, blurry, or simply not shown on this card layout, its value must be null — never 0,
never a value inferred from recognizing the manager.`,
            },
          ],
        },
      ],
    });

    const textBlock = response.content.find((b) => b.type === "text");
    if (!textBlock || textBlock.type !== "text") {
      throw new Error("No manager-card extraction returned");
    }
    return safeParseJsonObject(textBlock.text) as ManagerCardDraft;
  }
}
