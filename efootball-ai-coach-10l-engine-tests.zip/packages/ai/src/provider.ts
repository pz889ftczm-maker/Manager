import type { AnalysisEvent, TacticalAnalysis } from "@efootball/shared";
import type { PlayerStatisticsDraft } from "@efootball/shared";
import type { PlayerCardDraft } from "@efootball/shared";
import type { ManagerCardDraft } from "@efootball/shared";

/**
 * Every AI provider (Anthropic today, others later) implements this
 * interface. Nothing outside this package should call a provider SDK
 * directly — always go through AiProvider so swapping models/vendors
 * never touches calling code (worker, edge functions).
 *
 * IMPORTANT: implementations of this interface run server-side ONLY
 * (apps/worker, or a Supabase Edge Function). Never import this package
 * from apps/web client code — the API key must never reach the browser.
 */

export interface GameplayFrame {
  /** Signed URL or base64 — implementations should accept either. */
  imageUrl?: string;
  imageBase64?: string;
  timestampSeconds?: number;
}

export interface AnalyzeScreenshotInput {
  frames: GameplayFrame[]; // one or more screenshots of the same moment
  matchContext?: {
    userTeamSide?: "left" | "right";
    competitionType?: string;
    notes?: string;
  };
}

export interface ScanFrame extends GameplayFrame {
  /** Index frames always have a known timestamp — required here (unlike
   * the base GameplayFrame) so scan results can be mapped back to a
   * moment in the match. */
  timestampSeconds: number;
}

export interface ScanForCandidateMomentsInput {
  /** One batch of index frames (recommended batch size ~20) to scan
   * cheaply for notable football decisions, before spending a full
   * analyzeVideoContext() call on any of them. */
  frames: ScanFrame[];
  matchContext?: Record<string, unknown>;
}

export interface CandidateMoment {
  timestampSeconds: number;
  /** Short reason the scan flagged this moment — useful for debugging,
   * not persisted anywhere. */
  reason?: string;
}

export interface AnalyzeVideoContextInput {
  /** Sampled frames spanning contextStart..contextEnd around a candidate moment. */
  frames: GameplayFrame[];
  contextStartSeconds: number;
  contextEndSeconds: number;
  eventTimestampSeconds: number;
  matchContext?: Record<string, unknown>;
}

export interface DetectedEventDraft
  extends Omit<
    AnalysisEvent,
    "id" | "match_id" | "created_at" | "before_frame_url" | "decision_frame_url" | "after_frame_url" | "player_id" | "statistics_evidence"
  > {
  /** Index into the frames array used as before/decision/after — resolved to
   * storage URLs by the caller once frames are persisted. */
  beforeFrameIndex?: number;
  decisionFrameIndex?: number;
  afterFrameIndex?: number;
  /** Batch 3.5 remaining-work item 1: true only when the model can reliably
   * tell this decision was made by the human user's own controlled player
   * (the only player identity a gameplay screenshot/video frame can support
   * without inventing an identity — see migration 0006's design notes).
   * false/omitted whenever the acting player is an AI teammate, an
   * opponent, or genuinely unclear. Never set true as a default/guess. */
  involvesSelfPlayer?: boolean;
}

export interface TacticalAnalysisDraft
  extends Omit<TacticalAnalysis, "id" | "event_id" | "created_at"> {}

export interface CitableEvent {
  id: string;
  /** Short human-readable summary shown to the model next to the id, e.g.
   * "[bad_pass, mistake] Played a central pass directly into a double press". */
  summary: string;
}

export interface CoachChatInput {
  userMessage: string;
  /** Pre-fetched summary of the user's real match history — the provider
   * must ground its answer in this, never invent statistics. */
  userContextSummary: string;
  recentMessages: { role: "user" | "assistant"; content: string }[];
  /** Batch 3: the closed set of analysis_events the model is allowed to
   * cite with {{cite:UUID}} for THIS request — always pre-scoped to the
   * authenticated user's own real (non-demo) events by the caller. The
   * model must never cite an id outside this list, and the id is
   * re-verified server-side after the call regardless (see chat()). */
  citableEvents: CitableEvent[];
}

export interface CoachChatOutput {
  reply: string;
  referencedEventIds: string[];
}

// Batch 3.5 — individual player statistics extraction.
export interface ExtractPlayerStatisticsInput {
  /** One or more screenshots of the SAME post-match/in-match statistics
   * screen (e.g. multiple frames if the user scrolled a stats list). */
  frames: GameplayFrame[];
  matchContext?: Record<string, unknown>;
}

// Batch 6A-3 — AI player-card image extraction.
export interface ExtractPlayerCardInput {
  /** The single uploaded player-card image. Exactly one frame — a card is
   * one screenshot, unlike the multi-frame statistics/gameplay flows. */
  frame: GameplayFrame;
}

// Batch 6B-3 — AI manager-card image extraction.
export interface ExtractManagerCardInput {
  /** The single uploaded manager-card image. Exactly one frame — same
   * reasoning as ExtractPlayerCardInput above. */
  frame: GameplayFrame;
}

export interface AiProvider {
  readonly name: string;

  /** Spec section 11/12: cheap batched scan of index frames to flag which
   * timestamps look like they contain a notable football decision, so the
   * expensive analyzeVideoContext() call is only spent on candidates that
   * survived this pass. Implementations should use a lighter/cheaper
   * model than the other methods (see AI_SCAN_MODEL). */
  scanForCandidateMoments(input: ScanForCandidateMomentsInput): Promise<CandidateMoment[]>;

  /** Screenshot flow (spec section 5 / 13). Returns 0+ detected decisions. */
  analyzeScreenshot(input: AnalyzeScreenshotInput): Promise<DetectedEventDraft[]>;

  /** Batch 3.5 spec section 6: identify whether the given frame(s) show a
   * statistics screen and, if so, extract the real visible per-player
   * numbers. Returns [] when no statistics screen is present — this must
   * NOT be forced to return something just because it was called. One
   * element per player identified on screen; each field is null when not
   * visible. Never invents a value for a field the screen doesn't show. */
  extractPlayerStatistics(input: ExtractPlayerStatisticsInput): Promise<PlayerStatisticsDraft[]>;

  /** Video context window flow (spec section 10 / 14). One call per
   * candidate moment, using only the T-10s..T+10s sampled frames — never
   * the whole match at once. */
  analyzeVideoContext(input: AnalyzeVideoContextInput): Promise<DetectedEventDraft[]>;

  /** Given a confirmed event + the frames used, produce the tactical
   * diagram data. Must mark is_approximate=true and lower confidence
   * whenever exact positions aren't clearly visible — never fabricate. */
  generateTacticalAnalysis(
    event: DetectedEventDraft,
    frames: GameplayFrame[]
  ): Promise<TacticalAnalysisDraft>;

  /** AI Coach chat, grounded in real stored match data. */
  chat(input: CoachChatInput): Promise<CoachChatOutput>;

  /** Batch 6A-3: read an uploaded eFootball player-card image and extract
   * only what's visibly supported by it (name/position/overall/playstyle/
   * attributes). Never infers from outside football knowledge, never
   * fills an unreadable value with 0 — see packages/shared/src/
   * playerCard.ts for the full null/unknown contract and validation. */
  extractPlayerCard(input: ExtractPlayerCardInput): Promise<PlayerCardDraft>;

  /** Batch 6B-3: read an uploaded eFootball manager-card image and
   * extract only what's visibly supported by it (name/possession_rating/
   * quick_counter_rating/long_ball_counter_rating/out_wide_rating/
   * long_ball_rating). Never infers from outside knowledge (e.g.
   * recognizing a named manager and filling in "typical" ratings), never
   * fills an unreadable value with 0 — see packages/shared/src/
   * managerCard.ts for the full null/unknown contract and validation. */
  extractManagerCard(input: ExtractManagerCardInput): Promise<ManagerCardDraft>;
}
