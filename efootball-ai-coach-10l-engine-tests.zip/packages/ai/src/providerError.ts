/**
 * Batch 5.5A: shared, provider-agnostic error classification.
 *
 * No such system existed before this batch — AnthropicProvider currently
 * lets SDK errors propagate unclassified. This is introduced for
 * GeminiProvider only; AnthropicProvider is intentionally left untouched
 * (out of scope for this batch, see BATCH 5.5A section 14).
 *
 * `kind` is what Batch 5.5B's fallback logic is expected to switch on —
 * e.g. retrying or falling back to another provider makes sense for
 * "transient" / "rate_limit" / "timeout", but not for "configuration"
 * (a deployment bug, not a blip) or "authentication" (retrying the same
 * key will never help).
 *
 * IMPORTANT: `message` must always be safe to log or show to a caller —
 * never interpolate an API key, raw request/response body, or other
 * secret into it. Put any sensitive detail only on `cause`, which callers
 * must not surface directly to end users.
 */
export type ProviderErrorKind =
  | "configuration"
  | "authentication"
  | "rate_limit"
  | "timeout"
  | "transient"
  | "malformed_response"
  | "unknown";

export interface ProviderErrorOptions {
  kind: ProviderErrorKind;
  /** Provider name, e.g. "gemini" — matches AiProvider.name. */
  provider: string;
  /** Sanitized, user/log-safe description. Never include secrets. */
  message: string;
  /** Original error, if any. Not guaranteed to be sanitized — callers
   * should not expose this directly to end users. */
  cause?: unknown;
}

export class ProviderError extends Error {
  readonly kind: ProviderErrorKind;
  readonly provider: string;

  constructor(options: ProviderErrorOptions) {
    super(options.message, options.cause !== undefined ? { cause: options.cause } : undefined);
    this.name = "ProviderError";
    this.kind = options.kind;
    this.provider = options.provider;
  }
}

export function isProviderError(err: unknown): err is ProviderError {
  return err instanceof ProviderError;
}
