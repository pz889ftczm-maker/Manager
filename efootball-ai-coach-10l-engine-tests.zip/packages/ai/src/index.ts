import type { AiProvider } from "./provider.js";
import { AnthropicProvider } from "./providers/anthropicProvider.js";
import { GeminiProvider } from "./providers/geminiProvider.js";
import { ProviderRouter } from "./providerRouter.js";

export * from "./provider.js";
export * from "./providerError.js";
export * from "./providerRouter.js";
export { GeminiProvider } from "./providers/geminiProvider.js";
export { AnthropicProvider } from "./providers/anthropicProvider.js";

/**
 * Single entry point for getting an AI provider instance.
 * Reads AI_PROVIDER env var so swapping vendors is a config change,
 * not a code change. Add new `case` branches as providers are added
 * (e.g. OpenAiProvider, GeminiProvider) — calling code never changes.
 *
 * BATCH 5.5B: AI_PROVIDER=gemini now returns a ProviderRouter
 * (./providerRouter.ts) instead of a bare GeminiProvider — Gemini
 * primary, Anthropic fallback, at most one call to each per operation, no
 * recursion, no provider-level retry loop (see that file's header comment
 * for the full design). AI_PROVIDER=anthropic is completely unchanged
 * from Batch 5.5A/before: a bare AnthropicProvider, no router involved, no
 * reverse (Anthropic-primary/Gemini-fallback) behavior — this batch only
 * defines Gemini-primary/Anthropic-fallback. The ProviderRouter is only
 * ever constructed for AI_PROVIDER=gemini, and it only ever constructs the
 * underlying AnthropicProvider lazily, the first time a Gemini operation
 * actually needs to fall back — so an AI_PROVIDER=gemini deployment that
 * never configures ANTHROPIC_API_KEY still works fine as long as Gemini
 * itself never needs to fall back.
 */
export function getAiProvider(): AiProvider {
  const providerName = process.env.AI_PROVIDER ?? "anthropic";
  switch (providerName) {
    case "anthropic":
      return new AnthropicProvider();
    case "gemini":
      return new ProviderRouter({
        primaryName: "gemini",
        fallbackName: "anthropic",
        primary: () => new GeminiProvider(),
        fallback: () => new AnthropicProvider(),
      });
    default:
      throw new Error(`Unknown AI_PROVIDER: ${providerName}`);
  }
}
