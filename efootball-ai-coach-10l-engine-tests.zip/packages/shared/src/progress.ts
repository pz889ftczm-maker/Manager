import { EVENT_TYPES } from "./types.js";
import type { EventCategory } from "./types.js";

/**
 * Batch 3 — real player_progress computation.
 *
 * Everything in this file is a PURE function: given real rows already
 * fetched from Postgres (matches, match_statistics, analysis_events), it
 * derives progress metrics with no I/O of its own. That's deliberate:
 * apps/worker/src/statistics.ts does the fetching/upserting and stays a
 * thin wrapper, while this module is trivially unit-testable and shared
 * by any caller that wants the same math without duplicating it.
 *
 * Hard rule enforced throughout: never invent a metric the data can't
 * support. Every dimension below either derives from a real column/event,
 * or is explicitly marked insufficient_data instead of guessing.
 */

// ============================================================
// Inputs (loosely typed to whatever Supabase actually returns —
// callers pass real rows, not synthesized ones)
// ============================================================

export interface ProgressMatchRow {
  id: string;
  match_date: string | null;
  created_at: string;
  overall_score: number | null;
}

export interface ProgressStatsRow {
  match_id: string;
  passing_score: number | null;
  dribbling_score: number | null;
  attacking_score: number | null;
  defending_score: number | null;
  positioning_score: number | null;
  decision_making_score: number | null;
  good_decisions_count: number | null;
  bad_decisions_count: number | null;
}

export interface ProgressEventRow {
  match_id: string;
  event_type: string;
  category: string;
  severity: string;
  decision_score: number | null;
}

/** One match_player_statistics row for the user's self player, real fields
 * only (is_valid=true rows already merged across sources by the caller —
 * see apps/worker/src/statistics.ts). */
export interface ProgressPlayerStatsRow {
  match_id: string;
  [field: string]: string | number | null;
}

export interface AggregatePlayerProgressInput {
  /** Only real (is_demo=false), status='complete' matches — caller filters before calling. */
  matches: ProgressMatchRow[];
  /** match_statistics rows for those same matches. */
  statsByMatchId: Map<string, ProgressStatsRow>;
  /** All analysis_events rows across those same matches. */
  events: ProgressEventRow[];
  /** Batch 3.5 remaining-work item 4/5/6: the self player's REAL
   * match_player_statistics, one merged row per match (merged across
   * screenshot/structured_data/ai_confirmed sources — see
   * mergeStatRowsForEvidence in playerStatistics.ts), for the same real
   * matches. Optional/empty when the user has no self-player statistics
   * yet — every consumer below degrades to "insufficient data" rather than
   * erroring when this is empty.  */
  playerStatsByMatchId?: Map<string, ProgressPlayerStatsRow>;
}

// ============================================================
// Output — mirrors supabase/migrations/0001_schema.sql player_progress
// plus the evidence columns added in 0004_progress_evidence.sql
// ============================================================

export interface SkillTrendPoint {
  match_id: string;
  score: number;
}

export interface MistakeSummary {
  event_type: string;
  occurrences: number;
  matches_count: number;
}

export interface PositionRecommendation {
  recommended_position: string | null;
  recommended_position_confidence: number | null;
  recommended_position_evidence: string[];
}

export interface PlaystyleResult {
  playstyle_tags: string[];
  playstyle_evidence: Record<string, string>;
}

export interface AggregatedPlayerProgress {
  matches_analyzed: number;
  overall_trend: { match_id: string; match_date: string; overall_score: number }[];
  skill_trends: Record<string, SkillTrendPoint[]>;
  most_improved_skill: string | null;
  biggest_weakness: string | null;
  most_common_mistake: string | null;
  recommended_position: string | null;
  recommended_position_confidence: number | null;
  recommended_position_evidence: string[];
  playstyle_tags: string[];
  playstyle_evidence: Record<string, string>;
  mistake_analysis: { most_common: MistakeSummary | null; repeated: MistakeSummary[] };
  possession_loss_total: number;
  insufficient_data: string[];
  /** Batch 3.5 remaining-work item 4: real per-field trends built from
   * match_player_statistics, keyed by field name. */
  player_stat_trends: Record<string, PlayerStatTrendPoint[]>;
  player_stat_trends_insufficient: string[];
}

// ============================================================
// 0. Real individual-stat trends (Batch 3.5 remaining-work item 4)
// ============================================================

/** The individual match_player_statistics fields tracked for historical
 * trends — mirrors the spec's explicit list (pass completion, successful
 * dribbles, dribble success %, possession losses, duel win %, tackles,
 * interceptions, shots, goals, assists). */
export const PLAYER_STAT_TREND_FIELDS = [
  "pass_completion_percentage",
  "successful_dribbles",
  "dribble_success_percentage",
  "possession_losses",
  "duel_win_percentage",
  "tackles",
  "interceptions",
  "shots",
  "goals",
  "assists",
] as const;

const MIN_POINTS_FOR_STAT_TREND = 2;

/**
 * Builds a { match_id, value } series per tracked field, oldest match
 * first, from the user's real self-player statistics. A field with fewer
 * than MIN_POINTS_FOR_STAT_TREND real values across the user's history is
 * left out of the result and listed in `insufficient` instead — never
 * shown as a one-point "trend".
 */
export interface PlayerStatTrendPoint {
  match_id: string;
  value: number;
}

export function computePlayerStatTrends(
  matchesChrono: ProgressMatchRow[],
  playerStatsByMatchId: Map<string, ProgressPlayerStatsRow>
): { trends: Record<string, PlayerStatTrendPoint[]>; insufficient: string[] } {
  const trends: Record<string, PlayerStatTrendPoint[]> = {};
  const insufficient: string[] = [];

  for (const field of PLAYER_STAT_TREND_FIELDS) {
    const points: PlayerStatTrendPoint[] = [];
    for (const match of matchesChrono) {
      const row = playerStatsByMatchId.get(match.id);
      const value = row?.[field];
      if (typeof value === "number" && Number.isFinite(value)) {
        points.push({ match_id: match.id, value });
      }
    }
    if (points.length >= MIN_POINTS_FOR_STAT_TREND) {
      trends[field] = points;
    } else {
      insufficient.push(field);
    }
  }

  return { trends, insufficient };
}

/** Simple average of a tracked field across whatever real match rows have
 * it — used to blend real individual stats into playstyle/position
 * scoring below. Returns null (never 0) when there's no real data. */
function averageStatField(rows: ProgressPlayerStatsRow[], field: string): number | null {
  const values = rows
    .map((r) => r[field])
    .filter((v): v is number => typeof v === "number" && Number.isFinite(v));
  return values.length > 0 ? average(values) : null;
}

// ============================================================
// 1. Positioning score (fixes positioning_score = avgByCategory("attacking"))
// ============================================================

// EventCategory has no dedicated "positioning" bucket (see types.ts), so a
// positioning score has to be assembled from the event_types that actually
// describe positioning, spanning the two categories that contain them.
export const POSITIONING_EVENT_TYPES: string[] = [
  ...EVENT_TYPES.attacking.filter((t) => t.includes("positioning")), // poor/good_positioning
  ...EVENT_TYPES.defending.filter(
    (t) => t.includes("positioning") || t === "pulled_out_of_position" || t === "left_dangerous_space"
  ),
];

const MIN_POSITIONING_EVENTS = 2;

export function computePositioningScore(
  events: { event_type: string; decision_score: number | null }[]
): { score: number | null; sampleSize: number } {
  const rows = events.filter(
    (e) => POSITIONING_EVENT_TYPES.includes(e.event_type) && e.decision_score != null
  );
  if (rows.length < MIN_POSITIONING_EVENTS) return { score: null, sampleSize: rows.length };
  const score = rows.reduce((sum, r) => sum + Number(r.decision_score), 0) / rows.length;
  return { score: Math.round(score * 100) / 100, sampleSize: rows.length };
}

// ============================================================
// 2. Position recommendation
// ============================================================

const MIN_MATCHES_FOR_POSITION = 3;

const POSSESSION_LOSS_EVENT_TYPES = new Set(["lost_possession"]);
const TRANSITION_CATEGORY: EventCategory = "transition";
const BUILD_UP_CATEGORY: EventCategory = "build_up";

interface CategoryAverages {
  passing: number | null;
  dribbling: number | null;
  attacking: number | null;
  defending: number | null;
  positioning: number | null;
  transition: number | null; // derived from raw events (no match_statistics column)
  buildUp: number | null; // derived from raw events (no match_statistics column)
}

function average(values: number[]): number | null {
  if (values.length === 0) return null;
  return values.reduce((s, v) => s + v, 0) / values.length;
}

function categoryAverageFromEvents(events: ProgressEventRow[], category: string): number | null {
  const scored = events.filter((e) => e.category === category && e.decision_score != null);
  return average(scored.map((e) => Number(e.decision_score)));
}

/** Blends a category's event-derived decision-score average with a real,
 * already-0-100-scale individual statistic average (e.g.
 * pass_completion_percentage, duel_win_percentage). Both inputs are on the
 * same 0-100 scale, so a plain average is a defensible blend — never
 * invents a scale for count fields (tackles, interceptions, etc.), which
 * are surfaced as separate evidence strings instead (see recommendPosition
 * / inferPlaystyle below), not folded into this score. */
function blendWithRealStat(eventAvg: number | null, realStatAvg: number | null): number | null {
  if (eventAvg == null) return realStatAvg;
  if (realStatAvg == null) return eventAvg;
  return (eventAvg + realStatAvg) / 2;
}

function computeCategoryAverages(
  statsRows: ProgressStatsRow[],
  events: ProgressEventRow[],
  playerStatsRows: ProgressPlayerStatsRow[] = []
): CategoryAverages {
  const realPassing = averageStatField(playerStatsRows, "pass_completion_percentage");
  const realDribbling = averageStatField(playerStatsRows, "dribble_success_percentage");
  const realDefending = averageStatField(playerStatsRows, "duel_win_percentage");

  return {
    passing: blendWithRealStat(
      average(statsRows.map((s) => s.passing_score).filter((v): v is number => v != null)),
      realPassing
    ),
    dribbling: blendWithRealStat(
      average(statsRows.map((s) => s.dribbling_score).filter((v): v is number => v != null)),
      realDribbling
    ),
    attacking: average(statsRows.map((s) => s.attacking_score).filter((v): v is number => v != null)),
    defending: blendWithRealStat(
      average(statsRows.map((s) => s.defending_score).filter((v): v is number => v != null)),
      realDefending
    ),
    positioning: average(statsRows.map((s) => s.positioning_score).filter((v): v is number => v != null)),
    transition: categoryAverageFromEvents(events, TRANSITION_CATEGORY),
    buildUp: categoryAverageFromEvents(events, BUILD_UP_CATEGORY),
  };
}

/**
 * Deterministic, explainable position scoring: each candidate position is a
 * weighted combination of category averages that a coach would actually
 * associate with that role. Not a learned model — a defensible heuristic
 * over real aggregated stats, which is the most that eFootball's
 * event-type vocabulary can honestly support today.
 */
function scorePositionCandidates(avgs: CategoryAverages): { position: string; score: number; parts: string[] }[] {
  const z = (v: number | null) => v ?? 0; // treat missing category as 0 contribution, not "good"

  const candidates: { position: string; weights: Partial<Record<keyof CategoryAverages, number>> }[] = [
    { position: "Forward (CF/ST)", weights: { attacking: 0.5, dribbling: 0.3, transition: 0.2 } },
    { position: "Winger (LW/RW)", weights: { dribbling: 0.4, attacking: 0.35, transition: 0.25 } },
    { position: "Attacking Midfielder (CAM)", weights: { passing: 0.4, attacking: 0.3, buildUp: 0.3 } },
    { position: "Central Midfielder (CM)", weights: { passing: 0.4, buildUp: 0.3, defending: 0.3 } },
    { position: "Defensive Midfielder (CDM)", weights: { defending: 0.5, passing: 0.3, buildUp: 0.2 } },
    { position: "Center Back (CB)", weights: { defending: 0.6, positioning: 0.4 } },
    { position: "Full Back (LB/RB)", weights: { defending: 0.35, transition: 0.35, dribbling: 0.3 } },
  ];

  return candidates
    .map(({ position, weights }) => {
      const parts: string[] = [];
      let score = 0;
      for (const [key, weight] of Object.entries(weights) as [keyof CategoryAverages, number][]) {
        const value = z(avgs[key]);
        score += value * weight;
        if (avgs[key] != null) parts.push(`${key}=${avgs[key]!.toFixed(1)}`);
      }
      return { position, score: Math.round(score * 100) / 100, parts };
    })
    .sort((a, b) => b.score - a.score);
}

export function recommendPosition(
  matchesConsidered: number,
  statsRows: ProgressStatsRow[],
  events: ProgressEventRow[],
  playerStatsRows: ProgressPlayerStatsRow[] = []
): PositionRecommendation {
  if (matchesConsidered < MIN_MATCHES_FOR_POSITION) {
    return { recommended_position: null, recommended_position_confidence: null, recommended_position_evidence: [] };
  }

  const avgs = computeCategoryAverages(statsRows, events, playerStatsRows);
  const ranked = scorePositionCandidates(avgs);
  const [best, second] = ranked;

  if (!best || best.score <= 0) {
    return { recommended_position: null, recommended_position_confidence: null, recommended_position_evidence: [] };
  }

  const sampleFactor = Math.min(1, matchesConsidered / 8); // confidence caps out around 8 matches of history
  const gap = second ? best.score - second.score : best.score;
  const marginFactor = Math.min(1, gap / 20); // a 20-point gap between top two candidates = full margin confidence
  const confidence = Math.round(100 * sampleFactor * (0.4 + 0.6 * marginFactor));

  const evidence = [
    `Based on ${matchesConsidered} analyzed real match${matchesConsidered === 1 ? "" : "es"}.`,
    `Top category averages driving this pick: ${best.parts.join(", ")}.`,
  ];
  if (second) {
    evidence.push(`Next-closest fit was ${second.position} (score ${second.score.toFixed(1)} vs ${best.score.toFixed(1)}).`);
  }
  // Batch 3.5 remaining-work item 6: cite the real individual statistics
  // (not just category decision scores) that fed into this pick, when any
  // are actually available.
  const realTackles = averageStatField(playerStatsRows, "tackles");
  const realInterceptions = averageStatField(playerStatsRows, "interceptions");
  const realDuelWin = averageStatField(playerStatsRows, "duel_win_percentage");
  const realPassCompletion = averageStatField(playerStatsRows, "pass_completion_percentage");
  const realDribbleSuccess = averageStatField(playerStatsRows, "dribble_success_percentage");
  const realStatParts: string[] = [];
  if (realPassCompletion != null) realStatParts.push(`pass completion ${realPassCompletion.toFixed(1)}%`);
  if (realDribbleSuccess != null) realStatParts.push(`dribble success ${realDribbleSuccess.toFixed(1)}%`);
  if (realDuelWin != null) realStatParts.push(`duel win ${realDuelWin.toFixed(1)}%`);
  if (realTackles != null) realStatParts.push(`avg ${realTackles.toFixed(1)} tackles/match`);
  if (realInterceptions != null) realStatParts.push(`avg ${realInterceptions.toFixed(1)} interceptions/match`);
  if (realStatParts.length > 0) {
    evidence.push(`Real individual match statistics also considered: ${realStatParts.join(", ")}.`);
  }

  return {
    recommended_position: best.position,
    recommended_position_confidence: confidence,
    recommended_position_evidence: evidence,
  };
}

// ============================================================
// 3. Playstyle inference
// ============================================================

const MIN_MATCHES_FOR_PLAYSTYLE = 3;
const MIN_EVENTS_FOR_PLAYSTYLE = 10;
const MIN_TAG_EVIDENCE = 3;

function countEventTypes(events: ProgressEventRow[], types: string[]): number {
  const set = new Set(types);
  return events.filter((e) => set.has(e.event_type)).length;
}

function countCategory(events: ProgressEventRow[], category: string): number {
  return events.filter((e) => e.category === category).length;
}

export function inferPlaystyle(
  matchesConsidered: number,
  statsRows: ProgressStatsRow[],
  events: ProgressEventRow[],
  playerStatsRows: ProgressPlayerStatsRow[] = []
): PlaystyleResult {
  if (matchesConsidered < MIN_MATCHES_FOR_PLAYSTYLE || events.length < MIN_EVENTS_FOR_PLAYSTYLE) {
    return { playstyle_tags: [], playstyle_evidence: {} };
  }

  const avgs = computeCategoryAverages(statsRows, events, playerStatsRows);
  const tags: string[] = [];
  const evidence: Record<string, string> = {};
  // Batch 3.5 remaining-work item 5: real individual stats, when
  // available, are appended onto the existing event-based evidence
  // strings below (never replacing them — multiple evidence sources per
  // spec section 20) rather than driving separate new tags, since the
  // tag thresholds above are already calibrated to the event-based
  // averages.
  const realDribbleSuccess = averageStatField(playerStatsRows, "dribble_success_percentage");
  const realPossessionLosses = averageStatField(playerStatsRows, "possession_losses");
  const realTackles = averageStatField(playerStatsRows, "tackles");
  const realInterceptions = averageStatField(playerStatsRows, "interceptions");
  const realDuelWin = averageStatField(playerStatsRows, "duel_win_percentage");

  const dribbleEvents = countCategory(events, "dribbling");
  const lostPossession = countEventTypes(events, Array.from(POSSESSION_LOSS_EVENT_TYPES));
  const successfulDribble = countEventTypes(events, ["successful_dribble"]);
  const unnecessaryDribble = countEventTypes(events, ["unnecessary_dribble"]);
  const goodProgression = countEventTypes(events, ["good_progression", "good_switch"]);
  const goodBuildUp = countEventTypes(events, ["good_build_up", "good_escape_from_pressure"]);
  const transitionEvents = countCategory(events, TRANSITION_CATEGORY);
  const buildUpEvents = countCategory(events, BUILD_UP_CATEGORY);
  const goodTransition = countEventTypes(events, ["good_transition"]);
  const attackingEvents = countCategory(events, "attacking");
  const defendingEvents = countCategory(events, "defending");

  // possession_oriented
  if (
    avgs.passing != null &&
    avgs.passing >= 65 &&
    goodBuildUp >= MIN_TAG_EVIDENCE &&
    (dribbleEvents === 0 || lostPossession / dribbleEvents <= 0.35)
  ) {
    tags.push("possession_oriented");
    const lossPct = dribbleEvents > 0 ? Math.round((lostPossession / dribbleEvents) * 100) : 0;
    evidence.possession_oriented = `Average passing score ${avgs.passing.toFixed(1)} with ${goodBuildUp} good build-up events and only ${lossPct}% of ball-carrying events ending in lost possession.`;
    if (realPossessionLosses != null) {
      evidence.possession_oriented += ` Real average possession losses: ${realPossessionLosses.toFixed(1)}/match.`;
    }
  }

  // dribbler
  if (avgs.dribbling != null && avgs.dribbling >= 65 && successfulDribble >= MIN_TAG_EVIDENCE && successfulDribble > unnecessaryDribble) {
    tags.push("dribbler");
    evidence.dribbler = `${successfulDribble} successful dribbles vs ${unnecessaryDribble} unnecessary ones, averaging ${avgs.dribbling.toFixed(1)} in dribbling.`;
    if (realDribbleSuccess != null) {
      evidence.dribbler += ` Real per-match dribble success rate: ${realDribbleSuccess.toFixed(1)}%.`;
    }
  }

  // direct/vertical
  if (transitionEvents >= MIN_TAG_EVIDENCE && transitionEvents > buildUpEvents) {
    tags.push("direct_vertical");
    evidence.direct_vertical = `${transitionEvents} transition-category events vs ${buildUpEvents} build-up events — favors quick vertical play over patient possession.`;
  }

  // passing/playmaker
  if (avgs.passing != null && avgs.passing >= 70 && goodProgression >= MIN_TAG_EVIDENCE) {
    tags.push("passing_playmaker");
    evidence.passing_playmaker = `${goodProgression} good progression/switch passes with a ${avgs.passing.toFixed(1)} average passing score.`;
  }

  // defensive
  if (avgs.defending != null && avgs.defending >= 65 && defendingEvents >= attackingEvents && defendingEvents >= MIN_TAG_EVIDENCE) {
    tags.push("defensive");
    evidence.defensive = `${defendingEvents} defending-category events vs ${attackingEvents} attacking-category events, averaging ${avgs.defending.toFixed(1)} in defending.`;
  }

  // counter-attacking
  if (goodTransition >= MIN_TAG_EVIDENCE && avgs.defending != null && avgs.defending >= 55) {
    tags.push("counter_attacking");
    evidence.counter_attacking = `${goodTransition} good transition events combined with a ${avgs.defending.toFixed(1)} defending average (regains well, then breaks quickly).`;
  }

  return { playstyle_tags: tags, playstyle_evidence: evidence };
}

// ============================================================
// 4. Mistake analysis (most_common_mistake, repeated mistakes, possession losses)
// ============================================================

const MISTAKE_SEVERITIES = new Set(["mistake", "critical_mistake"]);

function computeMistakeAnalysis(events: ProgressEventRow[]): {
  most_common: MistakeSummary | null;
  repeated: MistakeSummary[];
} {
  const mistakes = events.filter((e) => MISTAKE_SEVERITIES.has(e.severity));
  if (mistakes.length === 0) return { most_common: null, repeated: [] };

  const byType = new Map<string, { occurrences: number; matchIds: Set<string> }>();
  for (const m of mistakes) {
    const entry = byType.get(m.event_type) ?? { occurrences: 0, matchIds: new Set<string>() };
    entry.occurrences += 1;
    entry.matchIds.add(m.match_id);
    byType.set(m.event_type, entry);
  }

  const summaries: MistakeSummary[] = Array.from(byType.entries())
    .map(([event_type, v]) => ({ event_type, occurrences: v.occurrences, matches_count: v.matchIds.size }))
    .sort((a, b) => b.occurrences - a.occurrences);

  return {
    most_common: summaries[0] ?? null,
    repeated: summaries.filter((s) => s.matches_count >= 2).slice(0, 5),
  };
}

// ============================================================
// 5. Trend: most_improved_skill / biggest_weakness
// ============================================================

const SKILL_KEYS = ["passing", "dribbling", "attacking", "defending", "positioning"] as const;
type SkillKey = (typeof SKILL_KEYS)[number];

function buildSkillTrends(
  matchesChrono: ProgressMatchRow[],
  statsByMatchId: Map<string, ProgressStatsRow>
): Record<SkillKey, SkillTrendPoint[]> {
  const trends: Record<SkillKey, SkillTrendPoint[]> = {
    passing: [],
    dribbling: [],
    attacking: [],
    defending: [],
    positioning: [],
  };
  const columnFor: Record<SkillKey, keyof ProgressStatsRow> = {
    passing: "passing_score",
    dribbling: "dribbling_score",
    attacking: "attacking_score",
    defending: "defending_score",
    positioning: "positioning_score",
  };

  for (const match of matchesChrono) {
    const stats = statsByMatchId.get(match.id);
    if (!stats) continue;
    for (const skill of SKILL_KEYS) {
      const value = stats[columnFor[skill]];
      if (value != null) trends[skill].push({ match_id: match.id, score: Number(value) });
    }
  }
  return trends;
}

function trendImprovement(points: SkillTrendPoint[]): number | null {
  if (points.length < 2) return null;
  const mid = Math.ceil(points.length / 2);
  const earlier = points.slice(0, mid);
  const recent = points.slice(mid);
  if (recent.length === 0) return null;
  const earlierAvg = average(earlier.map((p) => p.score))!;
  const recentAvg = average(recent.map((p) => p.score))!;
  return recentAvg - earlierAvg;
}

function computeMostImprovedSkill(skillTrends: Record<SkillKey, SkillTrendPoint[]>): string | null {
  let best: { skill: string; improvement: number } | null = null;
  for (const skill of SKILL_KEYS) {
    const improvement = trendImprovement(skillTrends[skill]);
    if (improvement == null || improvement <= 0) continue;
    if (!best || improvement > best.improvement) best = { skill, improvement };
  }
  return best?.skill ?? null;
}

function computeBiggestWeakness(skillTrends: Record<SkillKey, SkillTrendPoint[]>): string | null {
  let worst: { skill: string; avg: number } | null = null;
  for (const skill of SKILL_KEYS) {
    const points = skillTrends[skill];
    if (points.length === 0) continue;
    const avg = average(points.map((p) => p.score))!;
    if (!worst || avg < worst.avg) worst = { skill, avg };
  }
  return worst?.skill ?? null;
}

// ============================================================
// Top-level aggregation — this is what apps/worker/src/statistics.ts calls.
// Deliberately a FULL RECOMPUTE from the real match/stats/event rows every
// time (never an incremental += on the previous player_progress row), so
// re-running it after a retried match is naturally idempotent: the result
// only ever depends on the current state of matches/match_statistics/
// analysis_events, never on how many times this function has run before.
// ============================================================

export function aggregatePlayerProgress(input: AggregatePlayerProgressInput): AggregatedPlayerProgress {
  const { matches, statsByMatchId, events, playerStatsByMatchId } = input;
  const insufficientData: string[] = [];

  const matchesChrono = [...matches].sort((a, b) => {
    const ad = a.match_date ?? a.created_at;
    const bd = b.match_date ?? b.created_at;
    return ad.localeCompare(bd);
  });

  const overallTrend = matchesChrono
    .filter((m) => m.overall_score != null)
    .map((m) => ({ match_id: m.id, match_date: m.match_date ?? m.created_at, overall_score: Number(m.overall_score) }));

  const statsRows = matchesChrono.map((m) => statsByMatchId.get(m.id)).filter((s): s is ProgressStatsRow => !!s);

  // Batch 3.5 remaining-work item 1: the real self-player statistics the
  // worker fetched, aligned to the same chronological match list — empty
  // when the caller didn't pass any (e.g. no self-player identified yet),
  // in which case every consumer below degrades to event-derived-only
  // scoring exactly as it did before this was wired in.
  const playerStatsMap = playerStatsByMatchId ?? new Map<string, ProgressPlayerStatsRow>();
  const playerStatsRows = matchesChrono
    .map((m) => playerStatsMap.get(m.id))
    .filter((s): s is ProgressPlayerStatsRow => !!s);

  const skillTrends = buildSkillTrends(matchesChrono, statsByMatchId);

  const mostImprovedSkill = computeMostImprovedSkill(skillTrends);
  if (mostImprovedSkill == null) insufficientData.push("trend");

  const biggestWeakness = computeBiggestWeakness(skillTrends);
  if (biggestWeakness == null) insufficientData.push("weakness");

  const mistakeAnalysis = computeMistakeAnalysis(events);

  const possessionLossTotal = countEventTypes(events, Array.from(POSSESSION_LOSS_EVENT_TYPES));

  const position = recommendPosition(matches.length, statsRows, events, playerStatsRows);
  if (position.recommended_position == null) insufficientData.push("position");

  const playstyle = inferPlaystyle(matches.length, statsRows, events, playerStatsRows);
  if (playstyle.playstyle_tags.length === 0) insufficientData.push("playstyle");

  const positioningSample = statsRows.filter((s) => s.positioning_score != null).length;
  if (positioningSample === 0) insufficientData.push("positioning");

  // Batch 3.5 remaining-work item 4: real per-field individual-statistic
  // trends, built directly from the self player's match_player_statistics
  // history (never zero-filled/interpolated — see computePlayerStatTrends).
  const { trends: playerStatTrends, insufficient: playerStatTrendsInsufficient } = computePlayerStatTrends(
    matchesChrono,
    playerStatsMap
  );

  return {
    matches_analyzed: matches.length,
    overall_trend: overallTrend,
    skill_trends: skillTrends,
    most_improved_skill: mostImprovedSkill,
    biggest_weakness: biggestWeakness,
    most_common_mistake: mistakeAnalysis.most_common?.event_type ?? null,
    recommended_position: position.recommended_position,
    recommended_position_confidence: position.recommended_position_confidence,
    recommended_position_evidence: position.recommended_position_evidence,
    playstyle_tags: playstyle.playstyle_tags,
    playstyle_evidence: playstyle.playstyle_evidence,
    mistake_analysis: mistakeAnalysis,
    possession_loss_total: possessionLossTotal,
    insufficient_data: insufficientData,
    player_stat_trends: playerStatTrends,
    player_stat_trends_insufficient: playerStatTrendsInsufficient,
  };
}
