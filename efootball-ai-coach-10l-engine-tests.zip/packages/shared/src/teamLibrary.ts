// Batch 7E — Team Library UI: shared validation for the user-authored,
// save-bound Team Library record, plus small pure helpers reused by both
// the web Team Library create/edit UI (client-side early feedback) and
// anything else that needs to validate a team_library row before
// sending it to Supabase.
//
// Unlike PlayerLibraryInput/ManagerLibraryInput, a team_library row is
// never sourced from an AI extraction draft — a team is hand-authored
// by the user directly (spec: "Users must be able to create a team"),
// so there is no separate "Draft" shape to keep this apart from; this
// IS the one and only input shape for a team. Reuses the same
// sanitizeNullableString helper as playerLibrary.ts/managerLibrary.ts
// (identical NULL/UNKNOWN contract: motto/description/stadium stay
// null rather than being defaulted or fabricated) so the three
// validators can't silently drift apart.
//
// This is a client-side early-feedback check only — the actual
// authorization decision (can this user write this row, is
// team_image_path under their own prefix, is manager_id one of their
// own managers) is made by RLS and the ownership triggers in
// migrations 0016/0018/0020, never here. Nothing in this file is ever
// the final word on whether a write is allowed.

import { sanitizeNullableString } from "./playerCard.js";
import { isUniqueViolation } from "./playerLibrary.js";

export { isUniqueViolation };

/** Shape of what a user submits to persist — mirrors the columns
 * public.team_library actually has (migrations 0016_team_library.sql /
 * 0018_team_library_image_path.sql / 0020_team_manager_assignment.sql),
 * minus server-controlled columns (id/user_id/created_at/updated_at).
 * `name` is required (a departure from PlayerLibraryInput/
 * ManagerLibraryInput, matching migration 0016's `not null` column) —
 * every other field stays fully nullable, same NULL/UNKNOWN rule as
 * every other library input in this repo. */
export interface TeamLibraryInput {
  name: string;
  motto: string | null;
  description: string | null;
  founded_year: number | null;
  stadium: string | null;
  /** Storage object path in the private `team-images` bucket, or null
   * for a team saved without a logo/image. Ownership (must sit under
   * the caller's own `{user_id}/` prefix) is NOT checked here — that
   * requires the authenticated user's id, which this pure,
   * dependency-free module deliberately doesn't take; RLS
   * (team_library_insert_own/update_own, 0018) is the actual
   * enforcement. */
  team_image_path: string | null;
  /** One of the caller's own manager_library ids, or null for "no
   * manager assigned" (a normal, valid state — spec section 6). Ownership
   * of the referenced manager is enforced by RLS + the
   * check_team_library_manager_ownership trigger (0020), not here. */
  manager_id: string | null;
}

export interface TeamLibraryValidationResult {
  valid: boolean;
  sanitized: TeamLibraryInput;
  errors: string[];
}

/** name must be a non-empty, non-whitespace-only string — the one
 * required field on team_library (migration 0016's
 * team_library_name_not_blank check). Unlike every other field on this
 * type, there is no valid "null" outcome here: a missing/blank name is
 * always an error, never silently discarded to null and reported as
 * valid, since the DB itself would reject it either way. */
function sanitizeRequiredName(raw: unknown, errors: string[]): string {
  if (typeof raw !== "string" || raw.trim().length === 0) {
    errors.push(`name: expected a non-empty string, got ${JSON.stringify(raw)}`);
    return "";
  }
  return raw.trim();
}

/** founded_year must be a positive integer, or null. No artificial
 * upper bound (spec: "do not invent artificial limits" — mirrors
 * migration 0016's `check (founded_year is null or founded_year > 0)`,
 * which likewise imposes no ceiling). Never coerces an invalid value to
 * a guessed year — always null, with the reason recorded. */
function sanitizeFoundedYear(raw: unknown, errors: string[]): number | null {
  if (raw === undefined || raw === null) return null;
  if (typeof raw !== "number" || !Number.isFinite(raw) || !Number.isInteger(raw) || raw <= 0) {
    errors.push(`founded_year: invalid value ${JSON.stringify(raw)} — discarded to null`);
    return null;
  }
  return raw;
}

/** Same no-path-traversal rule already enforced at the DB layer by
 * team_library_image_path_no_traversal (migration 0018) — checked here
 * too so a malformed path is rejected with a clear, attributable error
 * before it ever reaches Postgres. Ownership-prefix is intentionally
 * NOT checked here — see TeamLibraryInput's doc comment above. */
function sanitizeImagePath(raw: unknown, errors: string[]): string | null {
  if (raw === undefined || raw === null) return null;
  if (typeof raw !== "string") {
    errors.push(`team_image_path: expected string or null, got ${JSON.stringify(raw)} — discarded to null`);
    return null;
  }
  const trimmed = raw.trim();
  if (trimmed.length === 0) return null;
  if (trimmed.includes("..")) {
    errors.push("team_image_path: path traversal sequence rejected — discarded to null");
    return null;
  }
  return trimmed;
}

const UUID_SHAPE = /^[0-9a-f]{8}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{12}$/i;

/** manager_id must be uuid-shaped, or null (clearing/no manager — a
 * normal, valid state, not an error). Same loose "is this even shaped
 * like a uuid" pre-flight as isUuidShaped (teamMembers.ts) — the actual
 * ownership/existence check is RLS + the manager-ownership trigger
 * (0020), not this module. */
function sanitizeManagerId(raw: unknown, errors: string[]): string | null {
  if (raw === undefined || raw === null) return null;
  if (typeof raw !== "string" || raw.trim().length === 0) {
    errors.push(`manager_id: expected a non-empty string or null, got ${JSON.stringify(raw)} — discarded to null`);
    return null;
  }
  const trimmed = raw.trim();
  if (!UUID_SHAPE.test(trimmed)) {
    errors.push("manager_id: does not look like a uuid — discarded to null");
    return null;
  }
  return trimmed;
}

/**
 * Validates a user-submitted TeamLibraryInput-shaped object before it's
 * persisted to public.team_library. Same never-throws,
 * never-coerce-to-a-guess convention as validatePlayerLibraryInput/
 * validateManagerLibraryInput: a failing optional field is dropped to
 * null with the reason recorded in `errors`; a missing/blank `name` is
 * likewise reported as an error rather than silently defaulted (e.g. to
 * "Unnamed team"). Takes `unknown` rather than the strict type so it
 * can validate a raw form/request body before trusting it.
 */
export function validateTeamLibraryInput(input: unknown): TeamLibraryValidationResult {
  const errors: string[] = [];

  if (!input || typeof input !== "object" || Array.isArray(input)) {
    return {
      valid: false,
      errors: ["input is not an object"],
      sanitized: {
        name: "",
        motto: null,
        description: null,
        founded_year: null,
        stadium: null,
        team_image_path: null,
        manager_id: null,
      },
    };
  }

  const d = input as Record<string, unknown>;

  const sanitized: TeamLibraryInput = {
    name: sanitizeRequiredName(d.name, errors),
    motto: sanitizeNullableString(d.motto, "motto", errors),
    description: sanitizeNullableString(d.description, "description", errors),
    founded_year: sanitizeFoundedYear(d.founded_year, errors),
    stadium: sanitizeNullableString(d.stadium, "stadium", errors),
    team_image_path: sanitizeImagePath(d.team_image_path, errors),
    manager_id: sanitizeManagerId(d.manager_id, errors),
  };

  return { valid: errors.length === 0, sanitized, errors };
}

// ============================================================
// Duplicate-save handling
// ============================================================
//
// public.team_library_user_name_uniq (migration 0016) is a plain unique
// index on (user_id, lower(name)) — Postgres enforces it; nothing here
// re-implements that enforcement. This constant lets a caller recognize
// that a failed insert/update failed BECAUSE of this exact constraint
// (spec: "duplicate team name" must fail safely with a clear message,
// not a raw constraint-violation error) rather than some other error.

/** The exact name of the unique index from migration 0016 — kept as one
 * named constant so callers can't drift apart if it's ever renamed. */
export const TEAM_LIBRARY_NAME_UNIQUE_CONSTRAINT = "team_library_user_name_uniq";

/** True when `err` is the "you already have a team with this name"
 * unique violation from team_library_user_name_uniq, as opposed to some
 * other/unexpected error. */
export function isDuplicateTeamName(err: unknown): boolean {
  return isUniqueViolation(err, TEAM_LIBRARY_NAME_UNIQUE_CONSTRAINT);
}
