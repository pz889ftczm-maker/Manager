// Batch 9D — Historical Match Snapshot DISPLAY only. Pure,
// dependency-free helpers that turn an already-fetched MatchSnapshot /
// MatchSnapshotPlayer[] (matchSnapshots.ts, Batch 9A) into a
// render-ready shape for the Match Report UI
// (apps/web/src/components/HistoricalSnapshotPanel.tsx).
//
// SCOPE: this file does not fetch anything, does not check ownership
// (that's RLS on match_snapshots/match_snapshot_players, 0025 — the
// only two tables this file ever reads from), and does not create or
// modify a snapshot in any way. It exists purely so the UI layer has
// one small, tested place to turn already-authorized rows into
// something a component can map over, instead of re-deriving the same
// null-safety/sorting rules inline in JSX.
//
// NULL SAFETY (spec 9D-6 — "NULL values must remain unknown/blank —
// NEVER convert NULL to 0 or fabricate values"): every optional field
// below is copied straight through as null when the source column is
// null. Nothing here ever substitutes 0, "", or a computed default for
// a missing historical value.
//
// HISTORICAL INDEPENDENCE (spec 9D-8/9): this file takes only the
// snapshot's own copied columns as input — it has no code path that
// reads team_library/player_library/manager_library/team_formations at
// all, so a since-edited or since-deleted source Library row cannot
// affect what these functions return.

import type { MatchSnapshot, MatchSnapshotPlayer } from "./matchSnapshots.js";

// ============================================================
// Selecting the right snapshot for the current match
// ============================================================

/**
 * Picks the snapshot to display for `matchId` out of a set of rows
 * already returned by a query scoped to the caller's own data (RLS on
 * match_snapshots, 0025 — `auth.uid() = user_id`). This is a SECOND,
 * independent check on top of that RLS scoping (spec 9D-3 — "never
 * trust a snapshot ID supplied by the client without verifying it
 * belongs to the current match/user"): even though nothing in this
 * codebase ever accepts a client-supplied snapshot id at all (the UI
 * only ever queries by match_id, never by a snapshot's own id), this
 * function still re-filters by match_id itself before choosing one,
 * so a caller that accidentally passed in snapshots for the wrong
 * match (a stale cache, a copy-paste bug in a future call site)
 * cannot silently display another match's historical context.
 *
 * A match may legitimately have more than one snapshot (0025's own
 * design notes — re-analysis under a different team context is
 * allowed); this always returns the most RECENTLY created one for
 * `matchId`, since that is the context the match's current
 * team_id/formation_id columns (migration 0028) were populated from at
 * the time analysis last completed. Returns null when there is no
 * snapshot for this match at all — a normal, non-error state (spec
 * 9D-7).
 */
export function selectMatchSnapshotForMatch(
  snapshots: readonly MatchSnapshot[],
  matchId: string
): MatchSnapshot | null {
  let best: MatchSnapshot | null = null;
  for (const snapshot of snapshots) {
    // Defense-in-depth match-id check — see header comment above.
    if (snapshot.match_id !== matchId) continue;
    if (!best || snapshot.created_at > best.created_at) {
      best = snapshot;
    }
  }
  return best;
}

// ============================================================
// Key/value display entries (attributes / tactical_instructions /
// manager_ratings)
// ============================================================

/** One row of a rendered key/value block. `value` stays exactly what
 * was stored — null when the underlying jsonb value was null, never
 * coerced to 0/"" (spec 9D-6). */
export interface MatchSnapshotKeyValueEntry {
  key: string;
  value: number | string | null;
}

/** Turns a nullable jsonb object into a stable, alphabetically-sorted
 * list of display rows. A null/absent object (never captured, or no
 * manager/formation at snapshot time) returns an empty array — the
 * caller renders nothing for that section rather than a fabricated
 * placeholder (spec 9D-5 — "when present"). Sorting is purely for a
 * stable render order (jsonb key order isn't guaranteed to survive a
 * round trip through Postgres/PostgREST) — it has no bearing on which
 * keys are shown. */
export function toKeyValueEntries(
  obj: Record<string, unknown> | null | undefined
): MatchSnapshotKeyValueEntry[] {
  if (!obj) return [];
  return Object.keys(obj)
    .sort((a, b) => a.localeCompare(b))
    .map((key) => {
      const raw = obj[key];
      const value = typeof raw === "number" || typeof raw === "string" ? raw : raw == null ? null : String(raw);
      return { key, value };
    });
}

// ============================================================
// Player display rows
// ============================================================

export interface MatchSnapshotPlayerDisplay {
  id: string;
  playerName: string | null;
  position: string | null;
  overall: number | null;
  playstyle: string | null;
  positionSlot: string | null;
  attributes: MatchSnapshotKeyValueEntry[];
}

/** position_slot comparator: a slot value sorts before a null one (a
 * captured slot is more useful to group by than "unknown slot"); ties
 * (including both null) fall back to `id` for a stable, deterministic
 * order regardless of the array's original order. Mirrors the same
 * (position_slot, player_id) order create_match_snapshot itself
 * inserts rows in (migrations 0026/0027) — re-applied here rather than
 * assumed, since a caller could hand these rows in any order. */
function comparePlayers(a: MatchSnapshotPlayer, b: MatchSnapshotPlayer): number {
  if (a.position_slot !== b.position_slot) {
    if (a.position_slot === null) return 1;
    if (b.position_slot === null) return -1;
    const cmp = a.position_slot.localeCompare(b.position_slot);
    if (cmp !== 0) return cmp;
  }
  return a.id.localeCompare(b.id);
}

function toPlayerDisplay(player: MatchSnapshotPlayer): MatchSnapshotPlayerDisplay {
  return {
    id: player.id,
    playerName: player.player_name,
    position: player.position,
    overall: player.overall,
    playstyle: player.playstyle,
    positionSlot: player.position_slot,
    attributes: toKeyValueEntries(player.attributes),
  };
}

// ============================================================
// Full display model
// ============================================================

export interface MatchSnapshotDisplay {
  createdAt: string;
  teamName: string | null;
  teamMotto: string | null;
  teamDescription: string | null;
  teamFoundedYear: number | null;
  teamStadium: string | null;
  formationName: string | null;
  formationCode: string | null;
  tacticalInstructions: MatchSnapshotKeyValueEntry[];
  managerName: string | null;
  managerRatings: MatchSnapshotKeyValueEntry[];
  players: MatchSnapshotPlayerDisplay[];
}

/**
 * Builds the full render-ready model for one snapshot + its player
 * rows. Every field here is copied straight from the snapshot's own
 * columns (spec 9D-4 — "historical values captured AT MATCH TIME, not
 * current Player/Manager/Team Library values") — this function never
 * reads, and has no way to reach, team_library/player_library/
 * manager_library/team_formations (spec 9D-8/9).
 */
export function buildMatchSnapshotDisplay(
  snapshot: MatchSnapshot,
  players: readonly MatchSnapshotPlayer[]
): MatchSnapshotDisplay {
  return {
    createdAt: snapshot.created_at,
    teamName: snapshot.team_name,
    teamMotto: snapshot.team_motto,
    teamDescription: snapshot.team_description,
    teamFoundedYear: snapshot.team_founded_year,
    teamStadium: snapshot.team_stadium,
    formationName: snapshot.formation_name,
    formationCode: snapshot.formation_code,
    tacticalInstructions: toKeyValueEntries(snapshot.tactical_instructions),
    managerName: snapshot.manager_name,
    managerRatings: toKeyValueEntries(snapshot.manager_ratings),
    players: [...players].sort(comparePlayers).map(toPlayerDisplay),
  };
}
