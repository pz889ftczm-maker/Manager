// Batch 6A-4 — Player Library: shared validation for the user-reviewed,
// save-bound Player Library record, plus small pure helpers reused by
// both the player-library-save Edge Function (server-side authority) and
// the web Review/Edit UI (client-side early feedback).
//
// Deliberately a SEPARATE shape/module from PlayerCardDraft
// (playerCard.ts) — see that file's design notes and this batch's own
// spec section 11 ("AI DRAFT VS LIBRARY... Never treat the AI draft
// itself as authoritative"). A PlayerCardDraft is unreviewed AI output;
// PlayerLibraryInput is what a human reviewer explicitly confirmed or
// corrected and is asking to persist to public.player_library. Nothing
// in this file runs against a PlayerCardDraft directly, and nothing here
// is invoked automatically after an extraction — only after an explicit
// user Save action (see player-library-save/index.ts's header comment).
//
// Reuses the same per-field sanitizers as playerCard.ts
// (sanitizeNullableString / sanitizeOverall / sanitizeAttributes) because
// the underlying field-level rules are IDENTICAL (same NULL/UNKNOWN
// contract, same "never clamp overall to an assumed max like 99", same
// open attributes shape) — importing them keeps the two validators from
// silently drifting apart instead of duplicating the logic here.

import { sanitizeNullableString, sanitizeOverall, sanitizeAttributes } from "./playerCard.js";

/** Shape of what a reviewer submits to persist — mirrors the columns
 * public.player_library actually has (migration 0011_player_library.sql),
 * minus server-controlled columns (id/user_id/created_at/updated_at) and
 * minus `metadata`, which this batch's Review/Edit UI never sets. */
export interface PlayerLibraryInput {
  name: string | null;
  position: string | null;
  overall: number | null;
  playstyle: string | null;
  attributes: Record<string, number | string | null>;
  /** Storage object path in the private `player-cards` bucket, or null
   * for a library entry saved without a card image. Ownership (must sit
   * under the caller's own `{user_id}/` prefix) is NOT checked here —
   * that requires the authenticated user's id, which this pure,
   * dependency-free module deliberately doesn't take. The caller
   * (player-library-save Edge Function) checks ownership separately via
   * isPathOwnedByUser (uploadValidation.ts), the same way
   * validatePlayerCardDraft's caller (player-card-extract) keeps its own
   * ownership check outside that shared validator too. */
  player_card_image_path: string | null;
}

export interface PlayerLibraryValidationResult {
  valid: boolean;
  sanitized: PlayerLibraryInput;
  errors: string[];
}

/** Same no-path-traversal rule already enforced at the DB layer by
 * player_library_image_path_no_traversal (migration 0011) — checked here
 * too so a malformed path is rejected with a clear, attributable error
 * before it ever reaches Postgres, rather than only surfacing as an
 * opaque CHECK-constraint failure. Ownership-prefix is intentionally NOT
 * checked here — see PlayerLibraryInput's doc comment above. */
function sanitizeImagePath(raw: unknown, errors: string[]): string | null {
  if (raw === undefined || raw === null) return null;
  if (typeof raw !== "string") {
    errors.push(`player_card_image_path: expected string or null, got ${JSON.stringify(raw)} — discarded to null`);
    return null;
  }
  const trimmed = raw.trim();
  if (trimmed.length === 0) return null;
  if (trimmed.includes("..")) {
    errors.push("player_card_image_path: path traversal sequence rejected — discarded to null");
    return null;
  }
  return trimmed;
}

/**
 * Validates a reviewer-submitted PlayerLibraryInput-shaped object before
 * it's persisted to public.player_library (spec section 7). Same
 * never-throws, never-coerce-to-a-guess convention as
 * validatePlayerCardDraft: a failing field is dropped to null (or, for
 * attributes, to an empty object) with the reason recorded in `errors`,
 * never silently replaced with a fabricated value. Takes `unknown`
 * rather than the strict type — this runs server-side, on a raw request
 * body nobody should trust yet (spec section 17: "Never trust...
 * client-only validation").
 */
export function validatePlayerLibraryInput(input: unknown): PlayerLibraryValidationResult {
  const errors: string[] = [];

  if (!input || typeof input !== "object" || Array.isArray(input)) {
    return {
      valid: false,
      errors: ["input is not an object"],
      sanitized: {
        name: null,
        position: null,
        overall: null,
        playstyle: null,
        attributes: {},
        player_card_image_path: null,
      },
    };
  }

  const d = input as Record<string, unknown>;

  const sanitized: PlayerLibraryInput = {
    name: sanitizeNullableString(d.name, "name", errors),
    position: sanitizeNullableString(d.position, "position", errors),
    overall: sanitizeOverall(d.overall, errors),
    playstyle: sanitizeNullableString(d.playstyle, "playstyle", errors),
    attributes: sanitizeAttributes(d.attributes, errors),
    player_card_image_path: sanitizeImagePath(d.player_card_image_path, errors),
  };

  // "no fabricated required fields" (spec section 7) — deliberately no
  // check here requiring name/position/overall/etc. to be non-null. A
  // library entry with only a card image, or only a name, is valid; the
  // NULL/UNKNOWN rule (spec section 2) applies just as much at save time
  // as it does at extraction time.
  //
  // 6A-4 QUICK FIX: an omitted/unknown field (above) and a malformed
  // EXPLICIT value are different cases. Omission is valid. But when a
  // caller explicitly supplies a value and it fails a per-field check
  // (wrong type, negative/non-integer overall, invalid attribute
  // shape/value, invalid image-path syntax), that is malformed input,
  // not "unknown" — the field is still nulled in `sanitized` for safe
  // typing, but the input as a whole must NOT be reported as valid.
  // Server-side persistence (player-library-save) must reject malformed
  // input rather than silently rewriting it to null and saving anyway.
  return { valid: errors.length === 0, sanitized, errors };
}

// ============================================================
// Duplicate-save handling (spec section 9)
// ============================================================
//
// public.player_library_user_variant_uniq (migration 0011) is a PARTIAL,
// EXPRESSION unique index — unique on (user_id, lower(name), position,
// overall) WHERE name IS NOT NULL. Postgres enforces it; nothing here
// re-implements that enforcement. These two small helpers let a caller
// (player-library-save) (a) recognize that a failed insert/update failed
// BECAUSE of this exact constraint rather than some other error, and (b)
// build the same normalized key Postgres's expression index groups on,
// so it can look up and return the pre-existing row instead of
// surfacing a raw constraint-violation error to an accidental
// double-click/retry.

/** True if `err` looks like a Postgres unique_violation (SQLSTATE 23505)
 * — the shape supabase-js/postgrest-js errors actually have (`code` is
 * the Postgres SQLSTATE). Optionally narrowed to a specific constraint
 * name via `constraintName`, matched against the error's `message`/
 * `details` text (postgrest-js doesn't expose a separate structured
 * constraint-name field), so callers can tell "this exact duplicate-
 * variant conflict" apart from an unrelated unique violation. */
export function isUniqueViolation(
  err: unknown,
  constraintName?: string
): err is { code: string; message?: string; details?: string } {
  if (!err || typeof err !== "object") return false;
  const e = err as { code?: unknown; message?: unknown; details?: unknown };
  if (e.code !== "23505") return false;
  if (!constraintName) return true;
  const text = `${typeof e.message === "string" ? e.message : ""} ${typeof e.details === "string" ? e.details : ""}`;
  return text.includes(constraintName);
}

/** The exact name of the partial unique index from migration 0011 —
 * kept as one named constant so the Edge Function and this file can't
 * drift apart if it's ever renamed. */
export const PLAYER_LIBRARY_VARIANT_UNIQUE_CONSTRAINT = "player_library_user_variant_uniq";

export interface PlayerLibraryVariantKey {
  nameLower: string;
  position: string | null;
  overall: number | null;
}

/** Builds the same (lower(name), position, overall) key the DB's partial
 * unique index groups rows by, so a caller that just caught a unique-
 * violation on player_library_user_variant_uniq can look up the exact
 * pre-existing row that conflicted (spec: recover an accidental
 * duplicate save gracefully rather than erroring). Returns null when
 * `name` is null — the constraint itself doesn't apply to null-named
 * entries (see migration 0011's design notes), so there is no variant
 * key to compute. */
export function playerLibraryVariantKey(
  input: Pick<PlayerLibraryInput, "name" | "position" | "overall">
): PlayerLibraryVariantKey | null {
  if (input.name === null) return null;
  return {
    nameLower: input.name.toLowerCase(),
    position: input.position,
    overall: input.overall,
  };
}
