// Batch 4 — shared "context window" math for Watch Moment + clip generation.
//
// The worker already had an implicit default of ±10s when it originally
// extracted context frames around a candidate moment for analysis (see
// apps/worker/src/pipeline/sampleFrames.ts::extractContextWindow's
// `windowSeconds = 10`). That's the "existing default context window" the
// video-experience spec asks to reuse rather than inventing a different
// number — DEFAULT_CONTEXT_SECONDS below mirrors it exactly.
//
// Used by:
//   - apps/web (Watch Moment / Generate Clip button) — real import.
//   - apps/worker (clip generation job) — real import.
//   - supabase/functions/clip-request (Deno) — CANNOT import this package
//     directly (same cross-runtime limitation already documented at the
//     top of supabase/functions/coach-chat/index.ts), so it duplicates
//     just this one small pure function inline. Keep the two in sync if
//     the clamp rule ever changes.

export const DEFAULT_CONTEXT_SECONDS = 10;

export interface ContextWindow {
  start: number;
  end: number;
}

/**
 * Part 19 validation, exactly: clamp [timestamp - before, timestamp + after]
 * to [0, duration], and require start < end. Returns null for anything that
 * can't produce a valid window (missing/negative timestamp, non-positive
 * duration, or a timestamp that's already outside [0, duration]) rather than
 * silently returning a degenerate range — callers must treat null as "can't
 * play/clip this moment" and say so, never fall back to a fabricated range.
 */
export function computeContextWindow(
  timestampSeconds: number | null | undefined,
  durationSeconds: number | null | undefined,
  beforeSeconds: number = DEFAULT_CONTEXT_SECONDS,
  afterSeconds: number = DEFAULT_CONTEXT_SECONDS
): ContextWindow | null {
  if (timestampSeconds == null || !Number.isFinite(timestampSeconds) || timestampSeconds < 0) return null;
  if (durationSeconds == null || !Number.isFinite(durationSeconds) || durationSeconds <= 0) return null;
  if (timestampSeconds > durationSeconds) return null;

  const start = Math.max(0, timestampSeconds - beforeSeconds);
  const end = Math.min(durationSeconds, timestampSeconds + afterSeconds);
  if (!(start < end)) return null;

  return { start, end };
}

/**
 * An analysis_events row already carries its own analysis-time context
 * window (context_start_seconds/context_end_seconds — the exact frames the
 * AI actually looked at for this finding). Prefer that over recomputing a
 * fresh ±10s window, since it's already clamped to real match bounds and
 * may be asymmetric near the start/end of a match. Only falls back to a
 * fresh computeContextWindow() when the event has no stored window (e.g.
 * an older event, or one whose timestamp came from a source other than
 * the video context-detection pass).
 */
export function resolveEventContextWindow(
  event: {
    timestamp_seconds: number | null;
    context_start_seconds: number | null;
    context_end_seconds: number | null;
  },
  durationSeconds: number | null | undefined
): ContextWindow | null {
  if (event.context_start_seconds != null && event.context_end_seconds != null) {
    const start = Math.max(0, event.context_start_seconds);
    const end = durationSeconds != null ? Math.min(durationSeconds, event.context_end_seconds) : event.context_end_seconds;
    if (start < end) return { start, end };
  }
  return computeContextWindow(event.timestamp_seconds, durationSeconds);
}
