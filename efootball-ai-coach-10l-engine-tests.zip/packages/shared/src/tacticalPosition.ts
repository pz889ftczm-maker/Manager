// Batch 10E — Tactical Position Model ONLY. A unified, evidence-based
// representation of "where a player is/should be on the pitch" that
// works identically for an eFootball 11v11 match and a Real Football
// 7v7 match, WITHOUT a new database table, a new event system, or any
// change to 10D's unified event schema.
//
// REUSE, NOT REPLACEMENT (spec section 5 — "reuse existing
// architecture"):
//   * Football-type source of truth: still footballMatchContext.ts's
//     FootballMatchContext — never re-derived here.
//   * eFootball roster/formation context: still
//     efootballMatchContext.ts's EfootballMatchContext (already
//     historical-snapshot-preferring, already never-fabricating).
//   * Real Football roster/formation context: still
//     realFootballMatchContext.ts's RealFootballMatchContext (same
//     guarantees, including its own role-from-formation-only rule).
//   * The one place in this codebase an on-pitch (x, y) coordinate is
//     ever produced with actual reliable evidence behind it: an
//     already-persisted `tactical_analysis` row (types.ts#
//     TacticalAnalysis, migration 0001), 1:1 with one analysis_events
//     row (reuse-listed) — an AI provider's read of that event's own
//     video/screenshot frames, gated by that row's own `is_approximate`
//     flag. This file never calls an AI provider and never touches
//     Supabase — same "pure builder, caller already fetched the row"
//     convention as efootballMatchContext.ts/realFootballMatchContext.ts.
//
// NEVER FABRICATE COORDINATES (spec section 2 — the central rule of
// this batch):
//   * A position built from a roster/formation context (eFootball or
//     Real Football) NEVER carries coordinates — see
//     tacticalPositionFromEfootballContextPlayer/
//     tacticalPositionFromRealFootballContextPlayer below, which
//     hard-code `coordinates: null`. Formation layout `x`/`y`
//     (teamFormations.ts#PositionDefinition) is deliberately never read
//     here — that file's own header comment already documents it as
//     "NOT a real-world tracking coordinate — purely a layout hint for
//     rendering this formation's shape", i.e. every "CB" slot gets
//     roughly the same x/y regardless of which player occupies it. That
//     is exactly the "convert a role into arbitrary x/y" this batch's
//     spec forbids — so it is never surfaced as a tactical position
//     coordinate.
//   * A position built from a tactical_analysis entry
//     (tacticalPositionFromAnalysisEntry below) only ever reports the
//     coordinates that entry itself carries — a missing/malformed
//     `pos.x`/`pos.y` comes back `coordinates: null`, never filled in
//     from `role`/`team`/anything else.
//   * validateTacticalPositionInput (this file's write-path gate, for
//     any future caller that persists/transmits a TacticalPosition
//     built from untrusted input) rejects any draft that sets
//     `coordinates` without a `source.type === "tactical_analysis"`
//     carrying its own `event_id` + `is_approximate` — i.e. rejects a
//     coordinate that claims to be evidence-based but cannot actually
//     point back to the evidence.
//
// FOOTBALL-TYPE GATING (spec section 3): tacticalPositionsFromEfootball
// Context/tacticalPositionsFromRealFootballContext each take the
// already-gated *MatchContextResult those files themselves produce
// (available:false for the wrong football type or an unknown one) —
// this file adds no second gate, it just refuses to build anything from
// an `available: false` result. validateTacticalPositionInput adds a
// defensive re-check for the rare case a caller assembles a draft by
// hand instead of via these builders (same defense-in-depth convention
// as footballEvent.ts's EFOOTBALL_ONLY_EVENT_KEYS gate).
//
// HISTORICAL INTEGRITY (spec section 4): this file introduces no new
// snapshot-vs-live decision of its own — a position's `context_source`
// is copied straight from the EfootballMatchContext/
// RealFootballMatchContext `source` the caller already resolved
// ("historical_snapshot" always wins over "current_data" there; see
// those files' own header comments). A tactical_analysis row is itself
// already an immutable, event-scoped record (nothing here mutates or
// re-derives one), so `context_source` stays null for that source type
// — the historical/current distinction doesn't apply to it the same
// way.
//
// NO ZOD DEPENDENCY, NO I/O (same convention as every other file in
// this package): small hand-written pure functions only.
//
// NO SCOPE CREEP (explicitly out of scope for 10E, left to a later
// phase): no passing lanes, no space model, no decision quality, no
// moment explanation, no full-match context assembly, no analysis
// engine integration (this file never calls an AI provider and is never
// wired into apps/worker's job pipeline), no Coach UI, no player
// progress changes, no tournament features. This file only shapes and
// validates the position itself, as a pure read-side model over
// already-existing, already-persisted data.

import type { FootballType } from "./footballMatchContext.js";
import type { ConfidenceLevel, Point, TacticalAnalysis } from "./types.js";
import type { EfootballContextPlayer, EfootballMatchContextResult } from "./efootballMatchContext.js";
import type { RealFootballContextPlayer, RealFootballMatchContextResult } from "./realFootballMatchContext.js";

// ============================================================
// 1. Shape
// ============================================================

/** A tactical position's on-pitch coordinate — reuses types.ts#Point
 * (0-100 percentage of pitch width/length) exactly; no new coordinate
 * type is introduced. */
export type TacticalPositionCoordinates = Point;

/** A minimal player reference — only ever populated when a player is
 * actually known (spec section 1: "player reference when known"), never
 * guessed from a role/team label alone. */
export interface TacticalPositionPlayerRef {
  player_id: string;
  name: string | null;
}

/** Where a TacticalPosition's data actually came from — every field on
 * TacticalPosition traces back to exactly one of these, and a reader
 * can always tell which. */
export type TacticalPositionSourceType =
  | "tactical_analysis"
  | "efootball_context"
  | "real_football_context";

export interface TacticalPositionSource {
  type: TacticalPositionSourceType;
  /** The analysis_events row a tactical_analysis-sourced position's
   * coordinates were read from — null for every other source type. */
  event_id: string | null;
  /** Mirrors a tactical_analysis row's own `is_approximate` flag,
   * verbatim — never re-derived, never defaulted. Null whenever this
   * position carries no coordinates (the flag only ever qualifies a
   * coordinate). */
  is_approximate: boolean | null;
  /** Mirrors EfootballMatchContext/RealFootballMatchContext's own
   * `source` ("historical_snapshot" | "current_data") for a
   * context-sourced position. Null for a tactical_analysis-sourced
   * position — see file header comment. */
  context_source: "historical_snapshot" | "current_data" | null;
}

/** One tactical position: a player/role at a point in a match, with
 * coordinates present ONLY when explicit, traceable evidence supports
 * them (spec section 2). Every field is independently nullable — a
 * position with a role but no coordinates, or coordinates but no
 * resolved player, is a normal, expected shape, not a partial/invalid
 * one. */
export interface TacticalPosition {
  football_type: FootballType | null;
  match_id: string | null;
  team: "user" | "opponent" | null;
  player: TacticalPositionPlayerRef | null;
  /** Free-text role/position label (e.g. "CB", "ST"), when available. */
  role: string | null;
  /** Formation slot id (team_formation_players.position_slot), when
   * available — kept distinct from `role`, same distinction
   * realFootballMatchContext.ts's own RealFootballContextPlayer makes. */
  position_slot: string | null;
  /** NEVER fabricated — see file header. Null whenever no reliable,
   * explicitly-sourced coordinate evidence exists for this position. */
  coordinates: TacticalPositionCoordinates | null;
  timestamp_seconds: number | null;
  /** Reuses types.ts#ConfidenceLevel (the same closed vocabulary
   * analysis_events already uses) rather than inventing a new numeric
   * scale. Null whenever this position carries no coordinates — a
   * role/roster reference with no coordinate evidence makes no
   * confidence claim about "where" the player is. */
  confidence_level: ConfidenceLevel | null;
  source: TacticalPositionSource;
}

/** A position's actual state, plus its recommended/target alternative
 * when one is supported by the same evidence (spec section 1 — "actual
 * vs recommended/target state when supported"). `recommended` is null
 * whenever no matching alternative exists — never fabricated to fill
 * the field. */
export interface TacticalPositionState {
  actual: TacticalPosition;
  recommended: TacticalPosition | null;
}

// ============================================================
// 2. tactical_analysis -> TacticalPosition (the only coordinate source)
// ============================================================

function isFiniteNumber(value: unknown): value is number {
  return typeof value === "number" && Number.isFinite(value);
}

function isPitchCoordinate(value: unknown): value is number {
  return isFiniteNumber(value) && value >= 0 && value <= 100;
}

function parseRole(value: unknown): string | null {
  return typeof value === "string" && value.trim().length > 0 ? value.trim() : null;
}

function parseTeam(value: unknown): "user" | "opponent" | null {
  return value === "user" || value === "opponent" ? value : null;
}

/** Reads `pos` defensively — a raw tactical_analysis actual_positions/
 * recommended_positions array entry's `pos` field is untrusted JSONB,
 * not a type-checked Point, until this function says so. Any shape
 * other than two finite, in-range numbers comes back null; it is NEVER
 * "corrected" or filled in from another field. */
function parseCoordinates(pos: unknown): TacticalPositionCoordinates | null {
  if (!pos || typeof pos !== "object") return null;
  const p = pos as Record<string, unknown>;
  if (!isPitchCoordinate(p.x) || !isPitchCoordinate(p.y)) return null;
  return { x: p.x, y: p.y };
}

/** is_approximate=true (the AI provider's own default — see
 * geminiProvider.ts/anthropicProvider.ts prompts: "Set is_approximate=
 * true unless positions are unambiguous") maps to "uncertain";
 * is_approximate=false maps to "confirmed". A straight, deterministic
 * re-labeling of a flag this codebase already sets meaningfully — never
 * an invented confidence value. */
function confidenceLevelForApproximation(isApproximate: boolean): ConfidenceLevel {
  return isApproximate ? "uncertain" : "confirmed";
}

export interface TacticalAnalysisPositionContext {
  footballType: FootballType | null;
  matchId: string | null;
  /** The tactical_analysis row's own event_id (analysis_events.id) —
   * required, since a coordinate with no traceable event is exactly the
   * "fabricated" case this batch forbids. */
  eventId: string;
  /** The event's own timestamp_seconds (AnalysisEvent), when known —
   * this file never derives one. */
  timestampSeconds: number | null;
  /** The tactical_analysis row's own is_approximate flag — copied
   * verbatim onto every position built from it. */
  isApproximate: boolean;
}

/**
 * Builds ONE TacticalPosition from ONE raw entry of an already-
 * persisted tactical_analysis row's actual_positions/
 * recommended_positions jsonb array (types.ts#TacticalAnalysis). Pure,
 * defensive parsing of untrusted JSONB — never throws, never
 * fabricates. Returns null only when the entry carries neither a role
 * nor coordinates (nothing meaningful left to represent).
 */
export function tacticalPositionFromAnalysisEntry(
  entry: unknown,
  context: TacticalAnalysisPositionContext
): TacticalPosition | null {
  if (!entry || typeof entry !== "object" || Array.isArray(entry)) return null;
  const e = entry as Record<string, unknown>;

  const role = parseRole(e.role);
  const coordinates = parseCoordinates(e.pos);
  const team = parseTeam(e.team);

  if (role === null && coordinates === null) return null;

  return {
    football_type: context.footballType,
    match_id: context.matchId,
    team,
    // tactical_analysis entries never carry a player reference (spec
    // section 1: a reference is only ever set "when known" — a bare
    // role/team label is not a player identity, so this is never
    // guessed).
    player: null,
    role,
    position_slot: null,
    coordinates,
    timestamp_seconds: context.timestampSeconds,
    confidence_level: coordinates !== null ? confidenceLevelForApproximation(context.isApproximate) : null,
    source: {
      type: "tactical_analysis",
      event_id: context.eventId,
      is_approximate: coordinates !== null ? context.isApproximate : null,
      context_source: null,
    },
  };
}

/**
 * Builds every TacticalPositionState (actual + its matched recommended
 * alternative, when one exists) from one already-persisted
 * tactical_analysis row. `recommended` is paired to `actual` only on an
 * exact (role, team) match between the two arrays — never by array
 * index alone (the arrays are independently generated by the AI
 * provider and are not guaranteed to be parallel/same-length) and never
 * fabricated when no match exists.
 */
export function tacticalPositionStatesFromTacticalAnalysis(
  row: Pick<TacticalAnalysis, "event_id" | "actual_positions" | "recommended_positions" | "is_approximate">,
  context: { footballType: FootballType | null; matchId: string | null; timestampSeconds: number | null }
): TacticalPositionState[] {
  const entryContext: TacticalAnalysisPositionContext = {
    footballType: context.footballType,
    matchId: context.matchId,
    eventId: row.event_id,
    timestampSeconds: context.timestampSeconds,
    isApproximate: row.is_approximate,
  };

  const actualEntries = Array.isArray(row.actual_positions) ? row.actual_positions : [];
  const recommendedEntries = Array.isArray(row.recommended_positions) ? row.recommended_positions : [];

  const actualPositions = actualEntries
    .map((entry) => tacticalPositionFromAnalysisEntry(entry, entryContext))
    .filter((p): p is TacticalPosition => p !== null);
  const recommendedPositions = recommendedEntries
    .map((entry) => tacticalPositionFromAnalysisEntry(entry, entryContext))
    .filter((p): p is TacticalPosition => p !== null);

  return actualPositions.map((actual) => ({
    actual,
    recommended:
      recommendedPositions.find(
        (candidate) => actual.role !== null && candidate.role === actual.role && candidate.team === actual.team
      ) ?? null,
  }));
}

// ============================================================
// 3. Roster/formation context -> TacticalPosition (never coordinates)
// ============================================================

export interface TacticalPositionContextInfo {
  matchId: string | null;
  contextSource: "historical_snapshot" | "current_data";
}

/** Builds a coordinate-free TacticalPosition from one already-resolved
 * EfootballContextPlayer (efootballMatchContext.ts). `role` is that
 * player's own explicit `position` field (e.g. "ST") — free-text data
 * already stored on the player, not a value this function derives. */
export function tacticalPositionFromEfootballContextPlayer(
  player: EfootballContextPlayer,
  context: TacticalPositionContextInfo
): TacticalPosition {
  return {
    football_type: "efootball",
    match_id: context.matchId,
    // eFootball roster context has no per-player user/opponent
    // distinction — never fabricated here.
    team: null,
    player: player.player_id !== null ? { player_id: player.player_id, name: player.name } : null,
    role: player.position,
    position_slot: player.position_slot,
    // Never sourced from formation layout x/y — see file header.
    coordinates: null,
    timestamp_seconds: null,
    confidence_level: null,
    source: {
      type: "efootball_context",
      event_id: null,
      is_approximate: null,
      context_source: context.contextSource,
    },
  };
}

/** Builds a coordinate-free TacticalPosition from one already-resolved
 * RealFootballContextPlayer (realFootballMatchContext.ts). `role` is
 * that file's own `role` field — already sourced ONLY from the
 * formation's stored position-definition data (never derived from
 * `position`), per that file's own header comment; this function simply
 * carries it through unchanged. */
export function tacticalPositionFromRealFootballContextPlayer(
  player: RealFootballContextPlayer,
  context: TacticalPositionContextInfo
): TacticalPosition {
  return {
    football_type: "real_football",
    match_id: context.matchId,
    team: null,
    player: player.player_id !== null ? { player_id: player.player_id, name: player.name } : null,
    role: player.role,
    position_slot: player.position_slot,
    // Never sourced from formation layout x/y — see file header.
    coordinates: null,
    timestamp_seconds: null,
    confidence_level: null,
    source: {
      type: "real_football_context",
      event_id: null,
      is_approximate: null,
      context_source: context.contextSource,
    },
  };
}

/**
 * Every roster-based TacticalPosition for a match's eFootball context —
 * `[]` (never fabricated placeholders) whenever `contextResult.available
 * === false` (wrong/unknown football type, or genuinely no data —
 * efootballMatchContext.ts has already made that call). Historical vs
 * current is inherited entirely from `contextResult.source`, which
 * itself already preferred a snapshot over live data when one existed
 * (spec section 4) — this function adds no second preference of its
 * own.
 */
export function tacticalPositionsFromEfootballContext(
  contextResult: EfootballMatchContextResult,
  matchId: string | null
): TacticalPosition[] {
  if (!contextResult.available) return [];
  return contextResult.players.map((player) =>
    tacticalPositionFromEfootballContextPlayer(player, { matchId, contextSource: contextResult.source })
  );
}

/** Real Football mirror of tacticalPositionsFromEfootballContext
 * immediately above — same reasoning, over
 * realFootballMatchContext.ts's RealFootballMatchContextResult. */
export function tacticalPositionsFromRealFootballContext(
  contextResult: RealFootballMatchContextResult,
  matchId: string | null
): TacticalPosition[] {
  if (!contextResult.available) return [];
  return contextResult.players.map((player) =>
    tacticalPositionFromRealFootballContextPlayer(player, { matchId, contextSource: contextResult.source })
  );
}

// ============================================================
// 4. Write-path validation (untrusted input -> safe to use/persist)
// ============================================================

export interface TacticalPositionValidationInput {
  football_type?: unknown;
  team?: unknown;
  player?: unknown;
  role?: unknown;
  position_slot?: unknown;
  coordinates?: unknown;
  timestamp_seconds?: unknown;
  confidence_level?: unknown;
  source?: unknown;
  [key: string]: unknown;
}

export interface TacticalPositionValidationResult {
  valid: boolean;
  errors: string[];
}

/**
 * The write-path gate for a TacticalPosition-shaped draft — defense in
 * depth for any future caller assembling one by hand instead of via
 * this file's own builders above (which can never produce an invalid
 * shape). Its central job (spec section 2): a draft may only carry
 * `coordinates` when its own `source` positively proves those
 * coordinates came from a tactical_analysis row (an `event_id` +
 * boolean `is_approximate`) — coordinates on any other source, or with
 * no source at all, are rejected as fabricated/inferred, never
 * silently dropped and never guessed-and-accepted.
 */
export function validateTacticalPositionInput(
  input: TacticalPositionValidationInput,
  context: { footballType: FootballType | null }
): TacticalPositionValidationResult {
  const errors: string[] = [];

  if (!input || typeof input !== "object") {
    return { valid: false, errors: ["draft is not an object"] };
  }

  const source = (input.source && typeof input.source === "object" ? input.source : null) as
    | Record<string, unknown>
    | null;

  if (input.coordinates !== undefined && input.coordinates !== null) {
    if (source?.type !== "tactical_analysis") {
      errors.push(
        "coordinates may only be set on a position sourced from tactical_analysis — coordinates can never be derived or inferred from role, position_slot, team, or formation data"
      );
    } else {
      const c = input.coordinates as Record<string, unknown>;
      if (!isPitchCoordinate(c.x) || !isPitchCoordinate(c.y)) {
        errors.push(`coordinates must be finite numbers in [0, 100], got ${JSON.stringify(input.coordinates)}`);
      }
      if (typeof source.event_id !== "string" || source.event_id.trim().length === 0) {
        errors.push("a tactical_analysis-sourced position with coordinates must reference the event_id those coordinates came from");
      }
      if (typeof source.is_approximate !== "boolean") {
        errors.push("a tactical_analysis-sourced position with coordinates must carry that tactical_analysis row's own is_approximate flag");
      }
    }
  }

  // football_type is a match-level attribute, same convention as
  // footballEvent.ts's own gate — never accepted directly on the
  // position draft, always derived from the match's own football
  // context by the caller.
  if (input.football_type !== undefined && input.football_type !== null) {
    errors.push("football_type must not be supplied on the position itself; it is derived from the match's own football context");
  }

  // No eFootball-only data leaking into a Real Football match, and vice
  // versa (spec section 3) — a context-sourced position must agree with
  // the caller's own resolved football_type.
  if (source?.type === "efootball_context" && context.footballType !== "efootball") {
    errors.push(
      `an efootball_context-sourced position is not valid for football_type=${JSON.stringify(context.footballType)}`
    );
  }
  if (source?.type === "real_football_context" && context.footballType !== "real_football") {
    errors.push(
      `a real_football_context-sourced position is not valid for football_type=${JSON.stringify(context.footballType)}`
    );
  }

  if (
    input.timestamp_seconds !== undefined &&
    input.timestamp_seconds !== null &&
    !(isFiniteNumber(input.timestamp_seconds) && input.timestamp_seconds >= 0)
  ) {
    errors.push(`timestamp_seconds must be a non-negative finite number or null, got ${JSON.stringify(input.timestamp_seconds)}`);
  }

  return { valid: errors.length === 0, errors };
}
