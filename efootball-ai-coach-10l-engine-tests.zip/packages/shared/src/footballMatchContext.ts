// Batch 10A — Football Match Context: the foundational model that lets
// the (future, 10B/10C) Football Analysis Engine tell an eFootball
// 11v11 match apart from a Real Football 7v7 match. This file is
// deliberately small and does NOT implement any actual eFootball- or
// 7v7-specific analysis — it only defines the shared type, strict
// validation, and a couple of pure derivation helpers so 10B/10C (and
// the worker/AI packages) have exactly one place to import this from,
// rather than each defining their own football-type string union.
//
// NO ZOD DEPENDENCY: every other validator in this package
// (playerCard.ts, teamFormations.ts, matchSnapshots.ts, ...) is a
// small hand-written pure function with no external dependency — this
// file follows that same established convention rather than
// introducing a new one for a two-value enum.
//
// NEVER FABRICATE / NEVER INFER (spec sections 1/4): there is no
// function anywhere in this file that guesses a football_type from
// anything (player-card presence, formation size, UI state, ...). The
// only two ways a FootballMatchContext value comes into existence are
// (a) validateFootballTypeInput, for an explicit, client-supplied
// football_type string, and (b) readFootballMatchContext, for an
// already-persisted matches row. An absent/NULL value stays exactly
// that — null — through both paths; it is never defaulted to
// "efootball" or any other value.
//
// TEAM SIZE IS DERIVED, NEVER ACCEPTED FROM THE CLIENT (spec section
// 2 — "team_size should be derived/validated consistently with
// football_type"): the safest way to guarantee that consistency is to
// never let a caller supply team_size independently at all. Every
// FootballMatchContext's team_size is computed from its football_type
// via teamSizeForFootballType — there is no code path (client input or
// otherwise) that can produce a mismatched pair.

/** The two football types 10A distinguishes between. Deliberately just
 * these two literal strings — extensible later (spec: "keep the design
 * extensible") simply by adding another literal here and to
 * TEAM_SIZE_BY_FOOTBALL_TYPE below, without touching any of this
 * file's other logic. */
export type FootballType = "efootball" | "real_football";

/** Every valid FootballType value, for validation/UI enumeration. */
export const FOOTBALL_TYPES: readonly FootballType[] = ["efootball", "real_football"];

/** football_type + its consistently-derived team_size — the
 * authoritative context a later Football Analysis Engine phase reads
 * to decide which football-specific data/rules apply. */
export interface FootballMatchContext {
  football_type: FootballType;
  team_size: number;
}

/** eFootball is always 11v11; Real Football (as scoped by 10A) is
 * always 7v7. Kept as one small lookup table so a future additional
 * FootballType only needs one new entry here. */
const TEAM_SIZE_BY_FOOTBALL_TYPE: Record<FootballType, number> = {
  efootball: 11,
  real_football: 7,
};

/** Narrowing type guard — the ONLY definition of "a valid football
 * type" in this codebase. Anything else (a typo, an old/future value,
 * a non-string) is rejected, never coerced. */
export function isFootballType(value: unknown): value is FootballType {
  return value === "efootball" || value === "real_football";
}

/** The team size that is authoritative for a given (already-validated)
 * football type. Never independently settable — see this file's
 * header comment. */
export function teamSizeForFootballType(footballType: FootballType): number {
  return TEAM_SIZE_BY_FOOTBALL_TYPE[footballType];
}

/** Builds a fully consistent FootballMatchContext from a validated
 * FootballType — the only way this package ever constructs one. */
export function buildFootballMatchContext(footballType: FootballType): FootballMatchContext {
  return { football_type: footballType, team_size: teamSizeForFootballType(footballType) };
}

export interface FootballTypeValidationResult {
  valid: boolean;
  /** null both when the input was invalid AND when the input was
   * omitted/null (a legitimate "no context supplied" case, spec
   * section 1 — "Do not silently default an unknown football type").
   * Check `valid` to tell the two apart: `valid: true, footballType:
   * null` means "nothing was supplied, and that's fine"; `valid:
   * false, footballType: null` means "something was supplied and it
   * was rejected". */
  footballType: FootballType | null;
  errors: string[];
}

/**
 * Validates an UNTRUSTED, client-supplied football_type value (e.g. an
 * Edge Function request body field) — never throws, never coerces an
 * unrecognized value into a guess (spec section 1: "Unknown/invalid
 * values must be rejected. Do not silently default an unknown football
 * type."). Omitted/null is accepted as "no context supplied" (backward
 * compatibility, spec section 2/9) — everything else must be exactly
 * one of FOOTBALL_TYPES or the whole input is rejected.
 *
 * Deliberately takes ONLY football_type as input, never team_size —
 * see this file's header comment ("TEAM SIZE IS DERIVED, NEVER
 * ACCEPTED FROM THE CLIENT").
 */
export function validateFootballTypeInput(input: unknown): FootballTypeValidationResult {
  if (input === undefined || input === null) {
    return { valid: true, footballType: null, errors: [] };
  }
  if (!isFootballType(input)) {
    return {
      valid: false,
      footballType: null,
      errors: [`football_type: expected one of ${FOOTBALL_TYPES.join(", ")}, got ${JSON.stringify(input)}`],
    };
  }
  return { valid: true, footballType: input, errors: [] };
}

/**
 * Reads the authoritative football context directly off an
 * already-persisted matches row (spec section 4 — "The pipeline must
 * be able to retrieve the match's football context without
 * guessing"). This is the ONLY function in this package that turns a
 * database row into a FootballMatchContext, and it never infers
 * anything from any other signal — it looks at exactly the two
 * columns migration 0029 adds and nothing else.
 *
 * A legacy match (football_type IS NULL, migration 0029's own
 * backward-compatibility design) returns null here — an explicit,
 * honest "unknown", never defaulted to "efootball" or fabricated any
 * other way (spec sections 2/4/9). The defensive `!isFootballType`
 * branch below is unreachable in practice (migration 0029's own CHECK
 * constraint already rejects any other value at the database level)
 * but follows this package's own "never trust a raw string, always
 * re-validate" convention rather than assuming the constraint can
 * never be bypassed by some future direct-SQL change.
 */
export function readFootballMatchContext(row: {
  football_type: string | null;
  team_size: number | null;
}): FootballMatchContext | null {
  if (row.football_type === null) return null;
  if (!isFootballType(row.football_type)) return null;
  return buildFootballMatchContext(row.football_type);
}

/**
 * Spec section 3 — "Real Football: eFootball-specific fields must NOT
 * be allowed in later analysis context." A later phase (10B/10C) gates
 * any eFootball-specific data/behavior on this rather than
 * re-deriving the same rule inline in multiple places. Returns false
 * for both real_football and null (unknown) context — eFootball-only
 * behavior requires POSITIVE confirmation of football_type =
 * "efootball", never "context is missing, so assume eFootball" (spec
 * section 4 — "Do NOT default everything to eFootball").
 */
export function allowsEfootballContext(context: FootballMatchContext | null): boolean {
  return context?.football_type === "efootball";
}

/**
 * Batch 10C — the Real Football mirror of allowsEfootballContext
 * immediately above, same reasoning: a later phase gates any Real-
 * Football-specific data/behavior on this rather than re-deriving the
 * same rule inline in multiple places. Returns false for both
 * efootball and null (unknown) context — Real-Football-only behavior
 * requires POSITIVE confirmation of football_type = "real_football",
 * never "context is missing, so assume Real Football".
 */
export function allowsRealFootballContext(context: FootballMatchContext | null): boolean {
  return context?.football_type === "real_football";
}
