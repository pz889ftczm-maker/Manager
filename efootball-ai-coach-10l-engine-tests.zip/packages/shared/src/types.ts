// Types mirror supabase/migrations/0001_schema.sql exactly.
// Keep these two in sync manually, or generate this file with
// `supabase gen types typescript` and layer the domain helpers below on top.

export type MatchSourceType = "screenshot" | "video" | "mixed" | "demo";

export type MatchStatus =
  | "uploading"
  // Batch 5 (migration 0009_production_hardening.sql): set atomically by
  // supabase/functions/analysis-enqueue when it hands a match off to the
  // worker, so a duplicate/retried enqueue call can't create a second job
  // for the same match (Part J). Superseded within moments by the
  // worker's own first status write once the job actually starts.
  | "queued"
  | "optimizing"
  | "processing"
  | "detecting_moments"
  | "analyzing"
  | "generating_report"
  | "complete"
  | "error";

export type MediaType = "screenshot" | "video";

export type MediaStatus =
  | "uploaded"
  | "optimizing"
  | "optimized"
  | "processed"
  | "failed"
  | "deleted_temp";

export type EventSeverity =
  | "excellent"
  | "good"
  | "minor_issue"
  | "mistake"
  | "critical_mistake";

export type ConfidenceLevel = "confirmed" | "likely" | "uncertain";

export type EventCategory =
  | "passing"
  | "dribbling"
  | "attacking"
  | "defending"
  | "transition"
  | "build_up";

export interface Profile {
  id: string;
  display_name: string | null;
  avatar_url: string | null;
  preferred_position: string | null;
  created_at: string;
}

export interface Match {
  id: string;
  user_id: string;
  title: string | null;
  match_date: string | null;
  duration_seconds: number | null;
  source_type: MatchSourceType;
  status: MatchStatus;
  overall_score: number | null;
  is_demo: boolean;
  error_message: string | null;
  created_at: string;
}

export interface Media {
  id: string;
  match_id: string;
  user_id: string;
  type: MediaType;
  original_filename: string | null;
  original_size_bytes: number | null;
  processed_size_bytes: number | null;
  status: MediaStatus;
  storage_reference: string | null;
  is_temporary: boolean;
  created_at: string;
  expires_at: string | null;
}

export interface Point {
  x: number; // 0-100, percentage of pitch width
  y: number; // 0-100, percentage of pitch length
}

export interface AnalysisEvent {
  id: string;
  match_id: string;
  timestamp_seconds: number | null;
  event_type: string; // see EVENT_TYPES below
  category: EventCategory;
  severity: EventSeverity;
  decision_score: number | null;
  confidence: number | null;
  confidence_level: ConfidenceLevel;
  description: string;
  better_option: string | null;
  reasoning: string | null;
  before_frame_url: string | null;
  decision_frame_url: string | null;
  after_frame_url: string | null;
  context_start_seconds: number | null;
  context_end_seconds: number | null;
  created_at: string;
  // Batch 3.5 (migration 0006_player_statistics.sql):
  player_id: string | null;
  statistics_evidence: string[] | null;
}

export interface TacticalAnalysis {
  id: string;
  event_id: string;
  actual_positions: { role: string; team: "user" | "opponent"; pos: Point }[] | null;
  recommended_positions: { role: string; team: "user" | "opponent"; pos: Point }[] | null;
  passing_lanes: { from: Point; to: Point; quality: "good" | "risky" | "recommended" }[] | null;
  movement_arrows: { from: Point; to: Point; label?: string }[] | null;
  pressure_zones: { center: Point; radius: number; intensity: number }[] | null;
  open_spaces: { center: Point; radius: number }[] | null;
  is_approximate: boolean;
  explanation: string | null;
  created_at: string;
}

export interface MatchStatistics {
  match_id: string;
  passing_score: number | null;
  dribbling_score: number | null;
  attacking_score: number | null;
  defending_score: number | null;
  positioning_score: number | null;
  decision_making_score: number | null;
  good_decisions_count: number;
  bad_decisions_count: number;
  updated_at: string;
}

export interface PlayerProgress {
  user_id: string;
  matches_analyzed: number;
  overall_trend: { match_id: string; match_date: string; overall_score: number }[] | null;
  skill_trends: Record<string, { match_id: string; score: number }[]> | null;
  most_improved_skill: string | null;
  biggest_weakness: string | null;
  most_common_mistake: string | null;
  recommended_position: string | null;
  playstyle_tags: string[] | null;
  // Added in 0004_progress_evidence.sql — the supporting evidence behind
  // the labels above, produced by packages/shared/src/progress.ts.
  recommended_position_confidence: number | null;
  recommended_position_evidence: string[] | null;
  playstyle_evidence: Record<string, string> | null;
  mistake_analysis: {
    most_common: { event_type: string; occurrences: number; matches_count: number } | null;
    repeated: { event_type: string; occurrences: number; matches_count: number }[];
  } | null;
  possession_loss_total: number;
  insufficient_data: string[] | null;
  // Added in 0007_player_stat_trends.sql — real historical trends built
  // directly from the self player's match_player_statistics (Batch 3.5).
  player_stat_trends: Record<string, { match_id: string; value: number }[]> | null;
  player_stat_trends_insufficient: string[] | null;
  updated_at: string;
}

// Batch 4 (migration 0008_video_experience.sql).
export type VideoClipStatus = "pending" | "processing" | "completed" | "failed";

export interface VideoClip {
  id: string;
  user_id: string;
  match_id: string;
  event_id: string;
  storage_path: string | null;
  start_time: number;
  end_time: number;
  status: VideoClipStatus;
  error_message: string | null;
  created_at: string;
  updated_at: string;
}

// Batch 6A-1/6A-4 (migration 0011_player_library.sql) — a user's own
// reusable player-card library, curated/corrected by the user (see
// packages/shared/src/playerLibrary.ts). Deliberately unconnected to
// Player/AnalysisEvent above — see that migration's design notes.
export interface PlayerLibrary {
  id: string;
  user_id: string;
  name: string | null;
  position: string | null;
  overall: number | null;
  playstyle: string | null;
  player_card_image_path: string | null;
  attributes: Record<string, number | string | null> | null;
  metadata: Record<string, unknown> | null;
  created_at: string;
  updated_at: string;
}

// Batch 6B-1/6B-4 (migration 0014_manager_library.sql) — a user's own
// reusable manager library, curated/corrected by the user (see
// packages/shared/src/managerLibrary.ts). Deliberately unconnected to
// any match/team-preset table — see that migration's design notes.
export interface ManagerLibrary {
  id: string;
  user_id: string;
  name: string | null;
  possession_rating: number | null;
  quick_counter_rating: number | null;
  long_ball_counter_rating: number | null;
  out_wide_rating: number | null;
  long_ball_rating: number | null;
  manager_image_path: string | null;
  metadata: Record<string, unknown> | null;
  created_at: string;
  updated_at: string;
}

// Batch 7C (migration 0019_team_members.sql) — junction row linking one
// of the caller's own player_library entries to one of their own
// team_library entries (the CURRENT roster only). Deliberately minimal:
// no name/position/overall/etc. are duplicated here — a reader joins
// through player_id into PlayerLibrary for that. See that migration's
// design notes for why there is no user_id column on this type either;
// ownership is derived through team_id -> TeamLibrary.user_id and
// player_id -> PlayerLibrary.user_id instead.
export interface TeamMember {
  id: string;
  team_id: string;
  player_id: string;
  created_at: string;
  updated_at: string;
}

// Batch 7A/7B/7D (migrations 0016_team_library.sql /
// 0018_team_library_image_path.sql / 0020_team_manager_assignment.sql)
// — a user's own reusable team library. No prior batch added a shared
// type for this table (7A/7B were schema/RLS/storage-only, with no web
// UI or client type yet needed); this is the first one to need it, so
// it's added here already reflecting the full current column set
// (through 7D) rather than reconstructing it piecemeal.
// `manager_id` (7D) references ManagerLibrary.id directly — the
// canonical manager stays solely in ManagerLibrary; nothing about the
// manager itself (name/ratings/image) is duplicated onto this type. See
// migration 0020's design notes for why this is a single nullable FK
// rather than a junction type like TeamMember above.
export interface TeamLibrary {
  id: string;
  user_id: string;
  name: string;
  motto: string | null;
  description: string | null;
  founded_year: number | null;
  stadium: string | null;
  team_image_path: string | null;
  manager_id: string | null;
  created_at: string;
  updated_at: string;
}

export interface AiCoachMessage {
  id: string;
  user_id: string;
  match_id: string | null;
  role: "user" | "assistant";
  content: string;
  referenced_event_ids: string[] | null;
  created_at: string;
}

// Canonical event-type vocabulary (spec section 12).
// The AI must pick from this closed set — never invent a new event_type string —
// so the timeline/report UI can render consistent icons/labels.
export const EVENT_TYPES: Record<EventCategory, string[]> = {
  passing: [
    "bad_pass", "risky_pass", "delayed_pass", "missed_passing_lane",
    "excellent_pass", "good_switch", "good_progression",
  ],
  dribbling: [
    "unnecessary_dribble", "successful_dribble", "poor_1v1_decision",
    "good_1v1_decision", "lost_possession", "poor_ball_protection",
  ],
  attacking: [
    "missed_scoring_opportunity", "poor_movement", "good_movement",
    "poor_positioning", "good_positioning", "poor_final_pass", "good_final_pass",
  ],
  defending: [
    "poor_defensive_positioning", "good_defensive_positioning", "pressing_too_early",
    "pressing_too_late", "matchup_mistake", "pulled_out_of_position",
    "left_dangerous_space", "good_interception", "good_defensive_cover",
  ],
  transition: [
    "poor_counter_decision", "missed_counter_opportunity", "slow_transition", "good_transition",
  ],
  build_up: [
    "played_into_pressure", "missed_switch", "poor_build_up",
    "good_build_up", "good_escape_from_pressure",
  ],
};
