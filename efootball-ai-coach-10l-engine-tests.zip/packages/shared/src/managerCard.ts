// Batch 6B-3 — AI manager-card extraction: shared type + semantic
// validation for the draft an AiProvider returns after reading an
// uploaded eFootball manager-card image.
//
// Deliberately mirrors packages/shared/src/playerCard.ts's structure and
// conventions (per this batch's spec: "Follow the existing Player Card
// extraction architecture from 6A-3") — same NULL/UNKNOWN contract, same
// field_evidence shape, same "never coerce to a guess" sanitization
// strategy. The one deliberate divergence: extraction_confidence here is
// `number | null` (never defaulted to 0) — this batch's spec explicitly
// lists extraction_confidence as nullable and says "NEVER use 0 as a
// placeholder for unknown data", whereas playerCard.ts's
// extraction_confidence is non-null and defaults to 0 on a missing/
// invalid value. That default-to-0 behavior is exactly what this batch's
// spec forbids, so it is not reused here even though the rest of the
// validation strategy is.
//
// Ratings (possession/quick_counter/long_ball_counter/out_wide/long_ball)
// mirror manager_library's fixed rating columns (see
// supabase/migrations/0014_manager_library.sql's design notes): nullable,
// non-negative, no artificial upper bound — because nothing in this
// repo's existing schema establishes an authoritative max for an
// eFootball manager-style rating, and the spec explicitly says not to
// invent one (same reasoning as playerCard.ts's `overall`).
//
// HARD RULE (same one enforced throughout playerCard.ts /
// playerStatistics.ts): never fabricate a value. Anything not visible/
// legible/certain on the manager card must arrive as null — this file's
// job is to reject or null out anything that doesn't hold up, never to
// invent a plausible-looking replacement.

// Reuses playerCard.ts's exported helpers rather than redeclaring them —
// `name` here has the exact same NULL/UNKNOWN contract as a player
// card's `name`, and isFiniteNumber is a pure numeric-shape check with no
// player-specific meaning. Importing (not duplicating) also avoids a
// duplicate-export collision, since both modules are re-exported via
// packages/shared/src/index.ts's `export *`.
import { sanitizeNullableString, isFiniteNumber } from "./playerCard.js";

/** Evidence for a single extracted field, so a future Review/Edit UI
 * (Batch 6B-4) can explain where a value came from (or why it's null).
 * Identical shape to PlayerCardFieldEvidence (playerCard.ts) — kept as
 * its own named type rather than re-exporting that one, so a manager
 * card's evidence entries can diverge later without an confusing
 * cross-domain rename (same reasoning ManagerCardDraft itself is a
 * distinct type from PlayerCardDraft rather than a reused shape). */
export interface ManagerCardFieldEvidence {
  /** Name of the field this evidence describes, e.g. "name" or
   * "possession_rating". */
  field: string;
  /** Whether the model reports this field as visible on the card at all. */
  visible: boolean;
  /** 0-100 confidence in this specific field, or null if the model didn't
   * provide one. */
  confidence: number | null;
  /** Short free-text note, e.g. "printed under the manager portrait". */
  note?: string | null;
}

/** Structured output of AI manager-card extraction, before any decision
 * about persisting it to manager_library — this batch never writes that
 * table (spec: "DO NOT save the extracted result to manager_library
 * yet"), it only produces and validates this draft. */
export interface ManagerCardDraft {
  name: string | null;
  possession_rating: number | null;
  quick_counter_rating: number | null;
  long_ball_counter_rating: number | null;
  out_wide_rating: number | null;
  long_ball_rating: number | null;
  /** Model's own confidence 0-100 in the extraction as a whole, or null
   * when the model didn't provide one — deliberately NULLABLE, unlike
   * PlayerCardDraft.extraction_confidence. Never defaulted to 0 (spec:
   * "NEVER use 0 as a placeholder for unknown data"). */
  extraction_confidence: number | null;
  field_evidence: ManagerCardFieldEvidence[];
}

// ============================================================
// Semantic validation
// ============================================================
//
// Same strategy as validatePlayerCardDraft: per-field checks, a failing
// field is dropped/nulled (never coerced into a guess) and the reason is
// recorded. Nothing here invents a required field that the raw draft
// didn't include.

export interface ManagerCardValidationResult {
  valid: boolean;
  sanitized: ManagerCardDraft;
  errors: string[];
}

/** A manager style rating must be a non-negative integer, or null. No
 * artificial upper bound — mirrors sanitizeOverall's reasoning in
 * playerCard.ts and manager_library's `check (rating >= 0)` columns
 * (0014_manager_library.sql). Never coerces an invalid/missing value to
 * 0 — always null, per this batch's explicit "NEVER use 0 as a
 * placeholder" rule. */
function sanitizeNullableRating(raw: unknown, field: string, errors: string[]): number | null {
  if (raw === undefined || raw === null) return null;
  if (!isFiniteNumber(raw) || !Number.isInteger(raw) || raw < 0) {
    errors.push(`${field}: invalid value ${JSON.stringify(raw)} — discarded to null`);
    return null;
  }
  return raw;
}

/** Unlike playerCard.ts's sanitizeConfidence (which defaults an invalid/
 * missing extraction_confidence to 0), this batch's spec requires
 * extraction_confidence to stay nullable and forbids ever using 0 as a
 * stand-in for "unknown" — so an invalid/missing value is discarded to
 * null here, exactly like sanitizeNullableConfidence below (which this
 * mirrors) rather than to a numeric default. */
function sanitizeNullableConfidence(raw: unknown, field: string, errors: string[]): number | null {
  if (raw === undefined || raw === null) return null;
  if (!isFiniteNumber(raw) || raw < 0 || raw > 100) {
    errors.push(`${field}: invalid confidence ${JSON.stringify(raw)} — discarded to null`);
    return null;
  }
  return raw;
}

function sanitizeFieldEvidence(raw: unknown, errors: string[]): ManagerCardFieldEvidence[] {
  if (raw === undefined || raw === null) return [];
  if (!Array.isArray(raw)) {
    errors.push(`field_evidence: expected an array, got ${JSON.stringify(raw)} — discarded entirely`);
    return [];
  }

  const sanitized: ManagerCardFieldEvidence[] = [];
  raw.forEach((entry, idx) => {
    if (!entry || typeof entry !== "object" || Array.isArray(entry)) {
      errors.push(`field_evidence[${idx}]: not an object — dropped`);
      return;
    }
    const e = entry as Record<string, unknown>;
    if (typeof e.field !== "string" || e.field.trim().length === 0) {
      errors.push(`field_evidence[${idx}]: missing/invalid "field" — dropped`);
      return;
    }
    if (typeof e.visible !== "boolean") {
      errors.push(`field_evidence[${idx}]: missing/invalid "visible" — dropped`);
      return;
    }
    sanitized.push({
      field: e.field,
      visible: e.visible,
      confidence: sanitizeNullableConfidence(e.confidence, `field_evidence[${idx}].confidence`, errors),
      note: typeof e.note === "string" && e.note.trim().length > 0 ? e.note.trim() : null,
    });
  });

  return sanitized;
}

/**
 * Validates a raw ManagerCardDraft-shaped object returned by an
 * AiProvider. Deliberately takes `Record<string, unknown>` rather than
 * the strict ManagerCardDraft type — nothing coming back from a model
 * can be trusted until after this check runs (same convention as
 * validatePlayerCardDraft / validateDetectedEventDraft).
 *
 * Never throws — malformed input always produces a well-formed, mostly-
 * null ManagerCardDraft plus an `errors` list. `valid` is true only when
 * `errors` is empty — i.e. every field on the raw draft (if present) was
 * structurally/semantically sound. Any discarded/nulled field (an
 * invalid type, an out-of-range confidence, a malformed field_evidence
 * entry, etc.) makes the whole result `valid: false`, even though
 * `sanitized` is still fully populated. This is a deliberate boundary:
 * the caller (the extraction Edge Function) must treat `valid: false` as
 * "the AI response did not hold up — do not return or persist it",
 * never quietly serve a partially-discarded draft as if it were clean.
 */
export function validateManagerCardDraft(draft: unknown): ManagerCardValidationResult {
  const errors: string[] = [];

  if (!draft || typeof draft !== "object" || Array.isArray(draft)) {
    return {
      valid: false,
      errors: ["draft is not an object"],
      sanitized: {
        name: null,
        possession_rating: null,
        quick_counter_rating: null,
        long_ball_counter_rating: null,
        out_wide_rating: null,
        long_ball_rating: null,
        extraction_confidence: null,
        field_evidence: [],
      },
    };
  }

  const d = draft as Record<string, unknown>;

  const sanitized: ManagerCardDraft = {
    name: sanitizeNullableString(d.name, "name", errors),
    possession_rating: sanitizeNullableRating(d.possession_rating, "possession_rating", errors),
    quick_counter_rating: sanitizeNullableRating(d.quick_counter_rating, "quick_counter_rating", errors),
    long_ball_counter_rating: sanitizeNullableRating(
      d.long_ball_counter_rating,
      "long_ball_counter_rating",
      errors
    ),
    out_wide_rating: sanitizeNullableRating(d.out_wide_rating, "out_wide_rating", errors),
    long_ball_rating: sanitizeNullableRating(d.long_ball_rating, "long_ball_rating", errors),
    extraction_confidence: sanitizeNullableConfidence(d.extraction_confidence, "extraction_confidence", errors),
    field_evidence: sanitizeFieldEvidence(d.field_evidence, errors),
  };

  return { valid: errors.length === 0, sanitized, errors };
}
