// Batch 10F — Passing Lane / Space Model ONLY. A unified, evidence-based
// representation of (1) a passing lane between two points on the pitch
// and (2) open/occupied/pressured space, that works identically for an
// eFootball 11v11 match and a Real Football 7v7 match, WITHOUT a new
// database table, a new event system, and WITHOUT touching 10D's
// unified event schema or 10E's tactical position model.
//
// REUSE, NOT REPLACEMENT (spec section 1 — "reuse existing
// architecture"):
//   * Football-type source of truth: still footballMatchContext.ts's
//     FootballMatchContext — never re-derived here.
//   * The one place in this codebase a passing lane or a patch of open/
//     pressured space is ever produced with actual reliable evidence
//     behind it: an already-persisted `tactical_analysis` row
//     (types.ts#TacticalAnalysis, migration 0001), 1:1 with one
//     analysis_events row — an AI provider's read of that event's own
//     video/screenshot frames, gated by that row's own `is_approximate`
//     flag, exactly the same evidence source 10E's tacticalPosition.ts
//     already reads `actual_positions`/`recommended_positions` from.
//     This file reads that SAME row's `passing_lanes`/`open_spaces`/
//     `pressure_zones` jsonb columns — all three already exist on the
//     table (migration 0001), so this batch adds no migration at all
//     (spec section 8).
//   * TacticalPosition (10E) itself is reused directly: a lane
//     endpoint's optional player reference is typed as
//     tacticalPosition.ts's own TacticalPositionPlayerRef, and this
//     file's per-entry context type is tacticalPosition.ts's own
//     exported TacticalAnalysisPositionContext (footballType/matchId/
//     eventId/timestampSeconds/isApproximate) — not a redefined
//     near-duplicate. Neither tacticalPosition.ts nor footballEvent.ts
//     is modified by this batch.
//   * This file never calls an AI provider and never touches Supabase —
//     same "pure builder, caller already fetched the row" convention as
//     efootballMatchContext.ts/realFootballMatchContext.ts/
//     tacticalPosition.ts.
//
// NO ROSTER/FORMATION-DERIVED SOURCE (unlike 10E's TacticalPosition,
// which has a second, coordinate-free source built from
// EfootballMatchContext/RealFootballMatchContext roster data): a
// passing lane or a patch of space is not a roster/formation attribute
// at all — there is no "this player's passing lane" or "this
// formation's open space" the way there is "this player's role". The
// ONLY evidence source for either model is a tactical_analysis row.
// This file therefore has no roster-context builder to mirror 10E's
// tacticalPositionFromEfootballContextPlayer/
// tacticalPositionFromRealFootballContextPlayer — and never imports
// efootballMatchContext.ts/realFootballMatchContext.ts/
// teamFormations.ts at all.
//
// NEVER FABRICATE ENDPOINTS/COORDINATES/QUALITY/STATUS (spec section 2/
// 3/4 — the central rule of this batch):
//   * A PassingLane is represented ONLY when BOTH its `from` and `to`
//     endpoints carry real, well-formed coordinate evidence from the
//     row's own `passing_lanes` entry (passingLaneFromAnalysisEntry
//     below). Unlike a TacticalPosition (which can meaningfully exist
//     with just a role and no coordinates), a lane with only one known
//     endpoint — or neither — is not evidence of a lane at all: the
//     whole entry is dropped, never half-represented and never
//     completed by guessing the missing side.
//   * A Space is represented ONLY when its `center` carries real,
//     well-formed coordinate evidence (spaceFromOpenSpaceEntry/
//     spaceFromPressureZoneEntry below) — "Missing spatial information
//     must remain NULL/unknown" (spec section 3) is honored by
//     dropping an entry with no location evidence entirely, and by
//     leaving `radius`/`intensity`/`team` independently null whenever
//     that specific piece of evidence is absent/malformed on an
//     otherwise-located entry — never clamped, never defaulted, never
//     backfilled from another field.
//   * Neither endpoint of a PassingLane ever carries a player
//     reference from the current evidence source: migration 0001's own
//     column comment for `passing_lanes` — `[{ from: {x,y}, to: {x,y},
//     quality }]` — shows the raw entry never carries a player
//     identity for either side. `from_player`/`to_player` therefore
//     always come back null from passingLaneFromAnalysisEntry — never
//     guessed from proximity to an actual_positions entry, a role, a
//     team label, or anything else. The field stays on the shape
//     (spec section 2 — "support ... when available") purely so a
//     future evidence source that DOES carry endpoint player identity
//     has somewhere to put it, exactly the same "supported vocabulary,
//     not currently producible" convention footballEvent.ts already
//     uses for UnifiedEventType's "receive" (see that file's own
//     header comment) — this file's SpaceStatus "occupied" (see below)
//     follows the identical convention for the same reason: no current
//     evidence source ever reports a patch of pitch as "occupied" (only
//     "open" from `open_spaces` and "pressured" from `pressure_zones`
//     exist today), so `spaceFromOpenSpaceEntry`/
//     `spaceFromPressureZoneEntry` never produce it — it stays in
//     SPACE_STATUSES for schema completeness only.
//   * `quality` (PassingLaneQuality) and `status` (SpaceStatus) are
//     each read from a small closed vocabulary and returned as `null`/
//     dropped respectively for anything outside it — never coerced,
//     never guessed from the entry's coordinates or position on the
//     pitch.
//   * validatePassingLaneInput/validateSpaceInput (this file's
//     write-path gates, for any future caller that persists/transmits
//     a draft built from untrusted input) reject any draft that sets
//     coordinates without a `source.type === "tactical_analysis"`
//     carrying its own `event_id` + `is_approximate` — i.e. reject
//     coordinates that claim to be evidence-based but cannot actually
//     point back to the evidence. They also reject the "half a lane"
//     case (only `from_coordinates` or only `to_coordinates` supplied)
//     and the "space with no location" case (`center` missing) at the
//     write-path level, not just in the read-side builders.
//
// COORDINATE SAFETY (spec section 4 — "formation coordinates are
// rendering hints only, never tracking evidence"): this file never
// imports teamFormations.ts and never reads a PositionDefinition's `x`/
// `y` layout hint for anything. The only coordinates this file ever
// reads are a tactical_analysis row's own `passing_lanes[].from`/`.to`
// and `open_spaces[].center`/`pressure_zones[].center` — never derived
// from a player's role, position name, formation slot, formation
// layout, or a generic "11v11 vs 7v7" assumption about where players
// stand. validatePassingLaneInput/validateSpaceInput additionally
// reject any draft whose `source.type` is anything other than
// "tactical_analysis" (including 10E's own "efootball_context"/
// "real_football_context" — valid TacticalPosition sources, but never
// valid evidence for a lane/space), so a caller can never smuggle a
// roster/formation-derived coordinate in through this file's write
// path either.
//
// FOOTBALL-TYPE GATING (spec section 5): a PassingLane/Space's
// `football_type` is always the caller's own already-resolved
// FootballMatchContext#football_type (from
// footballMatchContext.ts#readFootballMatchContext — never re-derived
// or guessed here), copied straight onto the built value, exactly like
// tacticalPositionFromAnalysisEntry does for a TacticalPosition. Unlike
// 10E's roster-context positions, there is no "efootball_context"/
// "real_football_context"-sourced variant here to gate in the first
// place (see "NO ROSTER/FORMATION-DERIVED SOURCE" above) — the only
// source this file ever produces is "tactical_analysis", which is
// equally valid evidence for either football type (a tactical_analysis
// row's own `event_id` already ties it to one specific match/event, and
// that match's football_type is exactly what the caller passes in as
// `context.footballType`). Neither this file's shape nor its builders
// contain a single eFootball-only field (no playstyle/overall/
// attributes/manager rating/formation instruction of any kind — a
// PassingLane/Space is pure coordinates + quality/status + evidence)
// — validatePassingLaneInput/validateSpaceInput additionally reject the
// same eFootball-only key list footballEvent.ts's own
// EFOOTBALL_ONLY_EVENT_KEYS gates (re-declared locally rather than
// imported, since that file's own list is intentionally private — see
// "NO CROSS-FILE PRIVATE IMPORTS" below), defense-in-depth against a
// caller accidentally attaching one of those keys to a lane/space
// draft.
//
// HISTORICAL INTEGRITY (spec section 6): this file introduces no
// snapshot-vs-live decision of its own, because it never reads Team/
// Formation/Player/Manager Library data — live OR historical — at all.
// A tactical_analysis row is itself already an immutable, event-scoped
// record (nothing here mutates or re-derives one, and nothing here
// re-queries or re-joins it against a match's current roster/
// formation/team). The `context.footballType`/`context.matchId` a
// caller passes into passingLanesFromTacticalAnalysis/
// spacesFromTacticalAnalysis come from the SAME already-resolved,
// already-historical-precedence-respecting FootballMatchContext every
// other 10-series file uses (footballMatchContext.ts) — this file adds
// no second, competing resolution of that context, and has no code
// path that could prefer "current" Team/Formation/Player Library data
// over an existing MatchSnapshot, because it never reads any of those
// three tables in the first place.
//
// NO ZOD DEPENDENCY, NO I/O (same convention as every other file in
// this package): small hand-written pure functions only.
//
// NO CROSS-FILE PRIVATE IMPORTS: isFiniteNumber/isPitchCoordinate/
// parseTeam/confidenceLevelForApproximation below are intentionally
// re-declared locally rather than imported from tacticalPosition.ts —
// that file keeps its own equivalents private (non-exported), the same
// convention playerStatistics.ts already follows for its own private
// `isFiniteNumber` rather than importing playerCard.ts's exported one.
// tacticalPosition.ts is not modified by this batch (spec section 1 —
// "do not create a competing event system", read here as "do not touch
// 10E's own file to make this batch possible").
//
// PERSISTENCE (spec section 8): NO migration is added. `passing_lanes`,
// `open_spaces`, and `pressure_zones` are already columns on
// `tactical_analysis` (migration 0001) — this file only shapes/
// validates data a caller already fetched, using the SAME table and
// the SAME (event_id-based) 1:1 relationship to analysis_events 10E
// already reads `actual_positions`/`recommended_positions` from.
// `analysis_events` itself, its (match_id, dedupe_key) idempotency
// (migration 0005), and 10D's unified event schema (footballEvent.ts)
// are untouched — nothing in this file writes to, upserts into, or
// re-validates against either.
//
// NO SCOPE CREEP (explicitly out of scope for 10F, left to a later
// phase, spec section 10): no decision quality, no moment explanation,
// no full-match context assembly, no analysis engine integration (this
// file never calls an AI provider and is never wired into apps/
// worker's job pipeline), no AI prompt changes, no Coach UI changes, no
// player progress changes, no tournament features. This file only
// shapes and validates the passing lane / space data itself, as a pure
// read-side model over already-existing, already-persisted data.

import type { FootballType } from "./footballMatchContext.js";
import { isFootballType } from "./footballMatchContext.js";
import type { ConfidenceLevel, Point, TacticalAnalysis } from "./types.js";
import type { TacticalAnalysisPositionContext, TacticalPositionPlayerRef } from "./tacticalPosition.js";

// ============================================================
// 1. Shape
// ============================================================

/** A lane endpoint or space center's on-pitch coordinate — reuses
 * types.ts#Point (0-100 percentage of pitch width/length) exactly, same
 * convention as tacticalPosition.ts#TacticalPositionCoordinates; no new
 * coordinate type is introduced. */
export type SpatialCoordinate = Point;

/** The closed quality vocabulary a tactical_analysis row's own
 * `passing_lanes[].quality` already uses (types.ts#TacticalAnalysis,
 * migration 0001) — reused verbatim, never extended or re-labeled. */
export type PassingLaneQuality = "good" | "risky" | "recommended";

export const PASSING_LANE_QUALITIES: readonly PassingLaneQuality[] = ["good", "risky", "recommended"];

/** Narrowing type guard — the ONLY definition of "a valid passing lane
 * quality" in this codebase, same strict-membership contract as
 * footballMatchContext.ts#isFootballType / footballEvent.ts#
 * isUnifiedEventType. */
export function isPassingLaneQuality(value: unknown): value is PassingLaneQuality {
  return typeof value === "string" && (PASSING_LANE_QUALITIES as readonly string[]).includes(value);
}

/** What kind of space a Space value represents. "occupied" has no
 * current evidence source (see file header — same "supported for
 * schema completeness, never currently produced" convention as
 * footballEvent.ts's UnifiedEventType#"receive") — only "open"
 * (from a row's `open_spaces`) and "pressured" (from `pressure_zones`)
 * are ever returned by this file's own builders today. */
export type SpaceStatus = "open" | "occupied" | "pressured";

export const SPACE_STATUSES: readonly SpaceStatus[] = ["open", "occupied", "pressured"];

/** Narrowing type guard — the ONLY definition of "a valid space status"
 * in this codebase. */
export function isSpaceStatus(value: unknown): value is SpaceStatus {
  return typeof value === "string" && (SPACE_STATUSES as readonly string[]).includes(value);
}

/** Where a PassingLane's data actually came from. Deliberately a
 * single-value union (not an inline literal) for parity with
 * tacticalPosition.ts#TacticalPositionSourceType and so a future
 * additional evidence source is a one-line extension — see file header
 * ("NO ROSTER/FORMATION-DERIVED SOURCE") for why "tactical_analysis" is
 * the only value today. */
export type PassingLaneSourceType = "tactical_analysis";

export interface PassingLaneSource {
  type: PassingLaneSourceType;
  /** The analysis_events row this lane's coordinates were read from —
   * always present, since a PassingLane value only ever exists (is
   * non-null) once both endpoints' coordinate evidence has already
   * been confirmed against that row (see passingLaneFromAnalysisEntry
   * below). */
  event_id: string;
  /** Mirrors the owning tactical_analysis row's own `is_approximate`
   * flag, verbatim — never re-derived, never defaulted. */
  is_approximate: boolean;
}

/** One passing lane between two points on the pitch, with both
 * endpoints' coordinates present ONLY when explicit, traceable evidence
 * supports them (spec section 2). `from_player`/`to_player` reuse
 * tacticalPosition.ts's own TacticalPositionPlayerRef and are supported
 * on the shape but never populated by this file's own builder — see
 * file header. */
export interface PassingLane {
  football_type: FootballType | null;
  match_id: string | null;
  /** Player reference for the passing endpoint, when known — see file
   * header ("NEVER FABRICATE ENDPOINTS..."): always null from the
   * current evidence source. */
  from_player: TacticalPositionPlayerRef | null;
  /** Player reference for the receiving endpoint, when known — same
   * "always null today" note as from_player above. */
  to_player: TacticalPositionPlayerRef | null;
  /** NEVER fabricated — see file header. Null only via
   * validatePassingLaneInput's write-path gate (a malformed/half-formed
   * draft); passingLaneFromAnalysisEntry never returns a PassingLane
   * with either coordinate null — an entry missing either side is
   * dropped entirely (returns null) rather than half-represented. */
  from_coordinates: SpatialCoordinate | null;
  to_coordinates: SpatialCoordinate | null;
  quality: PassingLaneQuality | null;
  timestamp_seconds: number | null;
  /** Reuses types.ts#ConfidenceLevel — the same closed vocabulary
   * analysis_events/tacticalPosition.ts already use — rather than
   * inventing a new numeric "confidence" scale not backed by any real
   * evidence (the row only ever carries a boolean is_approximate; see
   * confidenceLevelForApproximation below). */
  confidence_level: ConfidenceLevel | null;
  source: PassingLaneSource;
}

/** Same single-value-union reasoning as PassingLaneSourceType above. */
export type SpaceSourceType = "tactical_analysis";

export interface SpaceSource {
  type: SpaceSourceType;
  event_id: string;
  is_approximate: boolean;
}

/** One patch of open/occupied/pressured pitch space, with spatial data
 * present ONLY when explicit evidence supports it (spec section 3).
 * `status` is the one field always known when a Space value exists at
 * all — it is structurally determined by which of the row's own arrays
 * (`open_spaces` vs `pressure_zones`) an entry came from, exactly the
 * same "defining attribute, never independently missing" role `role`
 * plays for a TacticalPosition built from a roster context — so unlike
 * every other field here, it is not independently nullable. */
export interface Space {
  football_type: FootballType | null;
  match_id: string | null;
  status: SpaceStatus;
  /** NEVER fabricated — see file header. spaceFromOpenSpaceEntry/
   * spaceFromPressureZoneEntry never return a Space with `center: null`
   * — an entry with no location evidence is dropped entirely (returns
   * null) rather than represented with a null center; this field stays
   * nullable on the shape only for a hand-assembled draft that hasn't
   * yet passed validateSpaceInput. */
  center: SpatialCoordinate | null;
  /** "radius/area when actually available" (spec section 3) — null
   * whenever the row's own entry omits/malforms it, even though
   * `center` is known. */
  radius: number | null;
  /** Pressure-specific evidence (`pressure_zones[].intensity`,
   * 0-1) — always null for status "open"/"occupied"; never fabricated
   * for a "pressured" entry that omits it. */
  intensity: number | null;
  /** "team/ownership when known" (spec section 3) — the current
   * evidence source (`open_spaces`/`pressure_zones`) never carries a
   * team label (migration 0001's own column comments show neither
   * array has one), so this is always null today; defensively parsed
   * (never derived) in case a future evidence source adds one. */
  team: "user" | "opponent" | null;
  timestamp_seconds: number | null;
  confidence_level: ConfidenceLevel | null;
  source: SpaceSource;
}

// ============================================================
// 2. tactical_analysis -> PassingLane / Space (the only source)
// ============================================================

// Re-declared locally rather than imported — see file header ("NO
// CROSS-FILE PRIVATE IMPORTS").
function isFiniteNumber(value: unknown): value is number {
  return typeof value === "number" && Number.isFinite(value);
}

function isPitchCoordinate(value: unknown): value is number {
  return isFiniteNumber(value) && value >= 0 && value <= 100;
}

/** Reads a raw `from`/`to`/`center` field defensively — untrusted JSONB,
 * not a type-checked Point, until this function says so. Any shape
 * other than two finite, in-range numbers comes back null; it is NEVER
 * "corrected" or filled in from another field. Same logic as
 * tacticalPosition.ts's own private parseCoordinates. */
function parseCoordinates(pos: unknown): SpatialCoordinate | null {
  if (!pos || typeof pos !== "object") return null;
  const p = pos as Record<string, unknown>;
  if (!isPitchCoordinate(p.x) || !isPitchCoordinate(p.y)) return null;
  return { x: p.x, y: p.y };
}

/** Defensive parse only — see file header on why `team` is always null
 * from the current evidence source. Same logic as tacticalPosition.ts's
 * own private parseTeam. */
function parseTeam(value: unknown): "user" | "opponent" | null {
  return value === "user" || value === "opponent" ? value : null;
}

function parseQuality(value: unknown): PassingLaneQuality | null {
  return isPassingLaneQuality(value) ? value : null;
}

/** Radius is treated as the same 0-100 percentage-of-pitch scale as a
 * Point's own x/y (types.ts#Point doc comment) — never negative, never
 * larger than the pitch itself. Out-of-range/malformed comes back null,
 * never clamped. */
function parseRadius(value: unknown): number | null {
  return isFiniteNumber(value) && value >= 0 && value <= 100 ? value : null;
}

/** Matches the AI providers' own documented range for pressure_zones'
 * intensity (packages/ai's provider prompts: "intensity 0-1"). */
function parseIntensity(value: unknown): number | null {
  return isFiniteNumber(value) && value >= 0 && value <= 1 ? value : null;
}

/** is_approximate=true maps to "uncertain"; is_approximate=false maps
 * to "confirmed" — identical, deterministic re-labeling of a flag this
 * codebase already sets meaningfully, same as tacticalPosition.ts's own
 * private confidenceLevelForApproximation. Never an invented confidence
 * value. */
function confidenceLevelForApproximation(isApproximate: boolean): ConfidenceLevel {
  return isApproximate ? "uncertain" : "confirmed";
}

/**
 * Builds ONE PassingLane from ONE raw entry of an already-persisted
 * tactical_analysis row's `passing_lanes` jsonb array (types.ts#
 * TacticalAnalysis). Pure, defensive parsing of untrusted JSONB — never
 * throws, never fabricates. Returns null whenever either endpoint's
 * coordinate evidence is missing or malformed — see file header ("a
 * lane with only one known endpoint ... is not evidence of a lane").
 */
export function passingLaneFromAnalysisEntry(
  entry: unknown,
  context: TacticalAnalysisPositionContext
): PassingLane | null {
  if (!entry || typeof entry !== "object" || Array.isArray(entry)) return null;
  const e = entry as Record<string, unknown>;

  const from = parseCoordinates(e.from);
  const to = parseCoordinates(e.to);
  if (from === null || to === null) return null;

  return {
    football_type: context.footballType,
    match_id: context.matchId,
    // Raw passing_lanes entries never carry a player identity for
    // either endpoint — see file header. Never guessed.
    from_player: null,
    to_player: null,
    from_coordinates: from,
    to_coordinates: to,
    quality: parseQuality(e.quality),
    timestamp_seconds: context.timestampSeconds,
    confidence_level: confidenceLevelForApproximation(context.isApproximate),
    source: {
      type: "tactical_analysis",
      event_id: context.eventId,
      is_approximate: context.isApproximate,
    },
  };
}

/**
 * Every PassingLane for one already-persisted tactical_analysis row —
 * `[]` (never fabricated placeholders) whenever `row.passing_lanes` is
 * null/not an array, exactly the same defensive-array handling
 * tacticalPositionStatesFromTacticalAnalysis (10E) already uses for
 * `actual_positions`/`recommended_positions`.
 */
export function passingLanesFromTacticalAnalysis(
  row: Pick<TacticalAnalysis, "event_id" | "passing_lanes" | "is_approximate">,
  context: { footballType: FootballType | null; matchId: string | null; timestampSeconds: number | null }
): PassingLane[] {
  const entryContext: TacticalAnalysisPositionContext = {
    footballType: context.footballType,
    matchId: context.matchId,
    eventId: row.event_id,
    timestampSeconds: context.timestampSeconds,
    isApproximate: row.is_approximate,
  };

  const entries = Array.isArray(row.passing_lanes) ? row.passing_lanes : [];
  return entries
    .map((entry) => passingLaneFromAnalysisEntry(entry, entryContext))
    .filter((lane): lane is PassingLane => lane !== null);
}

/**
 * Builds ONE Space (status "open") from ONE raw entry of a
 * tactical_analysis row's `open_spaces` jsonb array. Returns null
 * whenever `center` is missing/malformed — see file header ("a space
 * with no location evidence cannot be represented").
 */
export function spaceFromOpenSpaceEntry(entry: unknown, context: TacticalAnalysisPositionContext): Space | null {
  if (!entry || typeof entry !== "object" || Array.isArray(entry)) return null;
  const e = entry as Record<string, unknown>;

  const center = parseCoordinates(e.center);
  if (center === null) return null;

  return {
    football_type: context.footballType,
    match_id: context.matchId,
    status: "open",
    center,
    radius: parseRadius(e.radius),
    // open_spaces entries never carry an intensity value — that is
    // pressure_zones-only evidence (see spaceFromPressureZoneEntry
    // below). Never fabricated here.
    intensity: null,
    team: parseTeam(e.team),
    timestamp_seconds: context.timestampSeconds,
    confidence_level: confidenceLevelForApproximation(context.isApproximate),
    source: {
      type: "tactical_analysis",
      event_id: context.eventId,
      is_approximate: context.isApproximate,
    },
  };
}

/**
 * Builds ONE Space (status "pressured") from ONE raw entry of a
 * tactical_analysis row's `pressure_zones` jsonb array. Same
 * null-on-missing-center rule as spaceFromOpenSpaceEntry above.
 */
export function spaceFromPressureZoneEntry(entry: unknown, context: TacticalAnalysisPositionContext): Space | null {
  if (!entry || typeof entry !== "object" || Array.isArray(entry)) return null;
  const e = entry as Record<string, unknown>;

  const center = parseCoordinates(e.center);
  if (center === null) return null;

  return {
    football_type: context.footballType,
    match_id: context.matchId,
    status: "pressured",
    center,
    radius: parseRadius(e.radius),
    intensity: parseIntensity(e.intensity),
    team: parseTeam(e.team),
    timestamp_seconds: context.timestampSeconds,
    confidence_level: confidenceLevelForApproximation(context.isApproximate),
    source: {
      type: "tactical_analysis",
      event_id: context.eventId,
      is_approximate: context.isApproximate,
    },
  };
}

/**
 * Every Space for one already-persisted tactical_analysis row —
 * combines `open_spaces` (status "open") and `pressure_zones" (status
 * "pressured") into ONE unified list, since both are the same "patch of
 * pitch space" concept with different evidence behind them (spec
 * section 3 — "a unified... model for... open/occupied space"). `[]`
 * whenever both source arrays are null/not-arrays — never fabricated.
 */
export function spacesFromTacticalAnalysis(
  row: Pick<TacticalAnalysis, "event_id" | "open_spaces" | "pressure_zones" | "is_approximate">,
  context: { footballType: FootballType | null; matchId: string | null; timestampSeconds: number | null }
): Space[] {
  const entryContext: TacticalAnalysisPositionContext = {
    footballType: context.footballType,
    matchId: context.matchId,
    eventId: row.event_id,
    timestampSeconds: context.timestampSeconds,
    isApproximate: row.is_approximate,
  };

  const openEntries = Array.isArray(row.open_spaces) ? row.open_spaces : [];
  const pressureEntries = Array.isArray(row.pressure_zones) ? row.pressure_zones : [];

  const openSpaces = openEntries
    .map((entry) => spaceFromOpenSpaceEntry(entry, entryContext))
    .filter((space): space is Space => space !== null);
  const pressuredSpaces = pressureEntries
    .map((entry) => spaceFromPressureZoneEntry(entry, entryContext))
    .filter((space): space is Space => space !== null);

  return [...openSpaces, ...pressuredSpaces];
}

// ============================================================
// 3. Write-path validation (untrusted input -> safe to use/persist)
// ============================================================

/** Same eFootball-only key list footballEvent.ts's own
 * EFOOTBALL_ONLY_EVENT_KEYS gates, re-declared locally (that file's own
 * list is intentionally private — see file header). None of these are
 * ever legitimate on a PassingLane/Space draft, for either football
 * type — a lane/space is pure coordinates + quality/status + evidence,
 * never a player/manager/formation attribute. */
const EFOOTBALL_ONLY_SPATIAL_KEYS = [
  "playstyle",
  "overall",
  "attributes",
  "manager_ratings",
  "formation_positions",
  "player_card_image_path",
  "tactical_instructions",
] as const;

/** Same closed vocabulary as validation.ts's own private
 * CONFIDENCE_LEVELS, re-declared locally for the same "no cross-file
 * private imports" reason given in the file header. */
const CONFIDENCE_LEVELS: readonly ConfidenceLevel[] = ["confirmed", "likely", "uncertain"];

function isValidPlayerRefShape(ref: unknown): boolean {
  if (typeof ref !== "object" || ref === null) return false;
  const r = ref as Record<string, unknown>;
  return typeof r.player_id === "string" && r.player_id.trim().length > 0;
}

export interface PassingLaneValidationInput {
  football_type?: unknown;
  from_player?: unknown;
  to_player?: unknown;
  from_coordinates?: unknown;
  to_coordinates?: unknown;
  quality?: unknown;
  timestamp_seconds?: unknown;
  confidence_level?: unknown;
  source?: unknown;
  [key: string]: unknown;
}

export interface PassingLaneValidationResult {
  valid: boolean;
  errors: string[];
}

/**
 * The write-path gate for a PassingLane-shaped draft — defense in
 * depth for any future caller assembling one by hand instead of via
 * passingLaneFromAnalysisEntry above (which can never produce an
 * invalid shape). Its central job (spec section 2/4/7): a draft may
 * only carry coordinates when its own `source` positively proves they
 * came from a tactical_analysis row (an `event_id` + boolean
 * `is_approximate`), and BOTH endpoints must be present together — a
 * "half a lane" draft (only `from_coordinates` or only
 * `to_coordinates`) is rejected exactly like a fully coordinate-free
 * one, since neither is evidence of an actual lane.
 */
export function validatePassingLaneInput(
  input: PassingLaneValidationInput,
  context: { footballType: FootballType | null }
): PassingLaneValidationResult {
  const errors: string[] = [];

  if (!input || typeof input !== "object") {
    return { valid: false, errors: ["draft is not an object"] };
  }

  const source = (input.source && typeof input.source === "object" ? input.source : null) as
    | Record<string, unknown>
    | null;

  // A passing lane has exactly one valid evidence source — never a
  // roster/formation context (spec section 4 — "formation coordinates
  // are rendering hints only, never tracking evidence"), and never any
  // other TacticalPositionSourceType value either.
  if (source === null || source.type !== "tactical_analysis") {
    errors.push(
      `source.type must be "tactical_analysis" — a passing lane has no other valid evidence source, got ${JSON.stringify(source?.type ?? null)}`
    );
  } else {
    if (typeof source.event_id !== "string" || source.event_id.trim().length === 0) {
      errors.push("a tactical_analysis-sourced passing lane must reference the event_id its coordinates came from");
    }
    if (typeof source.is_approximate !== "boolean") {
      errors.push("a tactical_analysis-sourced passing lane must carry that tactical_analysis row's own is_approximate flag");
    }
  }

  const fromProvided = input.from_coordinates !== undefined && input.from_coordinates !== null;
  const toProvided = input.to_coordinates !== undefined && input.to_coordinates !== null;

  if (!fromProvided && !toProvided) {
    errors.push(
      "a passing lane requires both from_coordinates and to_coordinates — coordinates can never be derived or inferred from role, position_slot, team, or formation data"
    );
  } else if (fromProvided !== toProvided) {
    errors.push("a passing lane requires both from_coordinates and to_coordinates — a lane with only one known endpoint is not evidence of a lane");
  } else {
    const from = input.from_coordinates as Record<string, unknown>;
    const to = input.to_coordinates as Record<string, unknown>;
    if (!isPitchCoordinate(from.x) || !isPitchCoordinate(from.y)) {
      errors.push(`from_coordinates must be finite numbers in [0, 100], got ${JSON.stringify(input.from_coordinates)}`);
    }
    if (!isPitchCoordinate(to.x) || !isPitchCoordinate(to.y)) {
      errors.push(`to_coordinates must be finite numbers in [0, 100], got ${JSON.stringify(input.to_coordinates)}`);
    }
  }

  if (input.quality !== undefined && input.quality !== null && !isPassingLaneQuality(input.quality)) {
    errors.push(`quality must be one of ${PASSING_LANE_QUALITIES.join(", ")} or null, got ${JSON.stringify(input.quality)}`);
  }

  if (
    input.confidence_level !== undefined &&
    input.confidence_level !== null &&
    !CONFIDENCE_LEVELS.includes(input.confidence_level as ConfidenceLevel)
  ) {
    errors.push(`confidence_level must be one of ${CONFIDENCE_LEVELS.join(", ")} or null, got ${JSON.stringify(input.confidence_level)}`);
  }

  for (const [key, ref] of [
    ["from_player", input.from_player],
    ["to_player", input.to_player],
  ] as const) {
    if (ref !== undefined && ref !== null && !isValidPlayerRefShape(ref)) {
      errors.push(`${key} must be a player reference with a non-empty player_id when supplied, got ${JSON.stringify(ref)}`);
    }
  }

  // football_type is a match-level attribute, same convention as
  // tacticalPosition.ts's own gate — never accepted directly on the
  // lane itself, always derived from the match's own football context.
  if (input.football_type !== undefined && input.football_type !== null) {
    errors.push("football_type must not be supplied on the passing lane itself; it is derived from the match's own football context");
  }

  if (context.footballType !== null && !isFootballType(context.footballType)) {
    errors.push(`invalid football_type in context: ${JSON.stringify(context.footballType)}`);
  }

  for (const key of EFOOTBALL_ONLY_SPATIAL_KEYS) {
    if (input[key] !== undefined && input[key] !== null) {
      errors.push(`${key} is an eFootball-only field and has no place on a passing lane, regardless of football_type`);
    }
  }

  if (
    input.timestamp_seconds !== undefined &&
    input.timestamp_seconds !== null &&
    !(isFiniteNumber(input.timestamp_seconds) && input.timestamp_seconds >= 0)
  ) {
    errors.push(`timestamp_seconds must be a non-negative finite number or null, got ${JSON.stringify(input.timestamp_seconds)}`);
  }

  return { valid: errors.length === 0, errors };
}

export interface SpaceValidationInput {
  football_type?: unknown;
  status?: unknown;
  center?: unknown;
  radius?: unknown;
  intensity?: unknown;
  team?: unknown;
  timestamp_seconds?: unknown;
  confidence_level?: unknown;
  source?: unknown;
  [key: string]: unknown;
}

export interface SpaceValidationResult {
  valid: boolean;
  errors: string[];
}

/**
 * The write-path gate for a Space-shaped draft — same defense-in-depth
 * role as validatePassingLaneInput above. Its central job (spec section
 * 3/4/7): `center` is mandatory (a space with no location evidence
 * cannot be represented — spec section 3's "missing spatial information
 * must remain NULL/unknown" describes radius/team/intensity, not the
 * space's own location), `status` must be one of SPACE_STATUSES, and
 * `intensity` is only ever accepted when `status === "pressured"` (it
 * is pressure_zones-only evidence — see file header).
 */
export function validateSpaceInput(
  input: SpaceValidationInput,
  context: { footballType: FootballType | null }
): SpaceValidationResult {
  const errors: string[] = [];

  if (!input || typeof input !== "object") {
    return { valid: false, errors: ["draft is not an object"] };
  }

  const source = (input.source && typeof input.source === "object" ? input.source : null) as
    | Record<string, unknown>
    | null;

  if (source === null || source.type !== "tactical_analysis") {
    errors.push(
      `source.type must be "tactical_analysis" — a space has no other valid evidence source, got ${JSON.stringify(source?.type ?? null)}`
    );
  } else {
    if (typeof source.event_id !== "string" || source.event_id.trim().length === 0) {
      errors.push("a tactical_analysis-sourced space must reference the event_id its coordinates came from");
    }
    if (typeof source.is_approximate !== "boolean") {
      errors.push("a tactical_analysis-sourced space must carry that tactical_analysis row's own is_approximate flag");
    }
  }

  if (input.center === undefined || input.center === null) {
    errors.push("center is required — a space with no location evidence cannot be represented");
  } else {
    const c = input.center as Record<string, unknown>;
    if (!isPitchCoordinate(c.x) || !isPitchCoordinate(c.y)) {
      errors.push(`center must be finite numbers in [0, 100], got ${JSON.stringify(input.center)}`);
    }
  }

  if (!isSpaceStatus(input.status)) {
    errors.push(`status must be one of ${SPACE_STATUSES.join(", ")}, got ${JSON.stringify(input.status ?? null)}`);
  }

  if (input.radius !== undefined && input.radius !== null) {
    if (!(isFiniteNumber(input.radius) && input.radius >= 0 && input.radius <= 100)) {
      errors.push(`radius must be a finite number in [0, 100] or null, got ${JSON.stringify(input.radius)}`);
    }
  }

  if (input.intensity !== undefined && input.intensity !== null) {
    if (!(isFiniteNumber(input.intensity) && input.intensity >= 0 && input.intensity <= 1)) {
      errors.push(`intensity must be a finite number in [0, 1] or null, got ${JSON.stringify(input.intensity)}`);
    }
    if (input.status !== "pressured") {
      errors.push('intensity is pressure-specific evidence and may only be set when status is "pressured"');
    }
  }

  if (input.team !== undefined && input.team !== null && input.team !== "user" && input.team !== "opponent") {
    errors.push(`team must be "user", "opponent", or null, got ${JSON.stringify(input.team)}`);
  }

  if (
    input.confidence_level !== undefined &&
    input.confidence_level !== null &&
    !CONFIDENCE_LEVELS.includes(input.confidence_level as ConfidenceLevel)
  ) {
    errors.push(`confidence_level must be one of ${CONFIDENCE_LEVELS.join(", ")} or null, got ${JSON.stringify(input.confidence_level)}`);
  }

  if (input.football_type !== undefined && input.football_type !== null) {
    errors.push("football_type must not be supplied on the space itself; it is derived from the match's own football context");
  }

  if (context.footballType !== null && !isFootballType(context.footballType)) {
    errors.push(`invalid football_type in context: ${JSON.stringify(context.footballType)}`);
  }

  for (const key of EFOOTBALL_ONLY_SPATIAL_KEYS) {
    if (input[key] !== undefined && input[key] !== null) {
      errors.push(`${key} is an eFootball-only field and has no place on a space, regardless of football_type`);
    }
  }

  if (
    input.timestamp_seconds !== undefined &&
    input.timestamp_seconds !== null &&
    !(isFiniteNumber(input.timestamp_seconds) && input.timestamp_seconds >= 0)
  ) {
    errors.push(`timestamp_seconds must be a non-negative finite number or null, got ${JSON.stringify(input.timestamp_seconds)}`);
  }

  return { valid: errors.length === 0, errors };
}
