// Batch 9A — Historical Match Snapshot DATA MODEL only. Shared types +
// pure validation for public.match_snapshots / public.match_snapshot_players
// (migration 0025_match_snapshots.sql). No snapshot UI, no snapshot
// creation workflow, no Football Analysis/AI Coach/Progress/Dashboard
// integration — see that migration's design notes for the full scope
// boundary; this file mirrors it at the application layer only for the
// parts that need to exist for typing/validation before a later,
// trusted server-side workflow persists a row.
//
// UNLIKE every *LibraryInput this phase has added (PlayerLibraryInput,
// ManagerLibraryInput, TeamFormationInput, ...), a MatchSnapshotInput is
// NOT something a human reviewer submits through a UI — this batch
// explicitly defers snapshot creation to a later server-side workflow
// (spec section 7). validateMatchSnapshotInput/
// validateMatchSnapshotPlayerInput exist so that future workflow (and
// its tests) has one shared, dependency-free place to check a
// constructed row before it's persisted — same never-throws,
// never-coerce-to-a-guess convention as every other validator in this
// package, and the same NULL-safety rule: an unknown historical value
// must stay null, never be replaced with 0/""/a fabricated default.
//
// Reuses the same per-field sanitizers as playerCard.ts
// (sanitizeNullableString / sanitizeOverall / sanitizeAttributes) and
// teamFormations.ts (validatePositions) — the underlying field-level
// rules are IDENTICAL to their live-Library counterparts (same NULL/
// UNKNOWN contract, same "never invent an upper bound"). Importing them
// keeps this validator from silently drifting apart from the live-data
// validators it mirrors, instead of duplicating the logic here.

import { sanitizeNullableString, sanitizeOverall, sanitizeAttributes, isFiniteNumber } from "./playerCard.js";
import { validatePositions, type PositionsJson } from "./teamFormations.js";
import { isUniqueViolation } from "./playerLibrary.js";

export { isUniqueViolation };

const UUID_SHAPE = /^[0-9a-f]{8}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{12}$/i;

/** Required id field (user_id/match_id) — must be a well-formed uuid
 * string. Unlike an optional provenance id (sanitizeNullableUuid
 * below), a missing/malformed value here is a hard validation failure,
 * not something to null out and move on from — a snapshot with no
 * match_id/user_id isn't a valid snapshot at all. */
export function sanitizeRequiredUuid(raw: unknown, field: string, errors: string[]): string {
  if (typeof raw !== "string" || !UUID_SHAPE.test(raw.trim())) {
    errors.push(`${field}: expected a uuid, got ${JSON.stringify(raw)}`);
    return "";
  }
  return raw.trim();
}

/** Optional provenance id (team_id/formation_id/manager_id/player_id) —
 * a malformed value is discarded to null (same "never fabricate, never
 * throw" convention as every other optional-field sanitizer in this
 * package) rather than failing the whole record, since these columns
 * are reference-only (migration 0025's design notes) and never needed
 * to reconstruct a historical value. */
export function sanitizeNullableUuid(raw: unknown, field: string, errors: string[]): string | null {
  if (raw === undefined || raw === null) return null;
  if (typeof raw !== "string" || !UUID_SHAPE.test(raw.trim())) {
    errors.push(`${field}: expected a uuid or null, got ${JSON.stringify(raw)} — discarded to null`);
    return null;
  }
  return raw.trim();
}

/** team_founded_year must be a positive integer, or null — mirrors
 * team_library_founded_year_valid (0016) / match_snapshots_team_founded_
 * year_valid (0025). No invented upper bound, same reasoning as the
 * live team_library column this mirrors. */
function sanitizeFoundedYear(raw: unknown, errors: string[]): number | null {
  if (raw === undefined || raw === null) return null;
  if (!isFiniteNumber(raw) || !Number.isInteger(raw) || raw <= 0) {
    errors.push(`team_founded_year: invalid value ${JSON.stringify(raw)} — discarded to null`);
    return null;
  }
  return raw;
}

/** positions is nullable here (unlike team_formations.positions, which
 * is required) — a snapshot taken while the analyzed team had no saved
 * formation layout legitimately has no positions to copy. When present,
 * reuses teamFormations.ts's own validatePositions (same object/array
 * shape rule as migration 0025's match_snapshots_positions_shape_valid
 * check) rather than re-implementing it. */
function sanitizeNullablePositions(raw: unknown, errors: string[]): PositionsJson | null {
  if (raw === undefined || raw === null) return null;
  const result = validatePositions(raw);
  if (!result.valid) {
    errors.push(...result.errors.map((e) => `positions: ${e}`));
  }
  return raw as PositionsJson;
}

/** tactical_instructions / manager_ratings must each be a plain JSON
 * object, or null/absent — mirrors migration 0025's own jsonb_typeof
 * checks. Same "don't silently discard a malformed explicit value"
 * convention as teamFormations.ts's own (private) tactical-instructions
 * sanitizer — free-form data is easy to send maliciously/accidentally
 * shaped wrong (e.g. an array), so the error is recorded and returned
 * as null rather than assumed to be equivalent to "not provided". */
function sanitizeNullableJsonObject(
  raw: unknown,
  field: string,
  errors: string[]
): Record<string, unknown> | null {
  if (raw === undefined || raw === null) return null;
  if (typeof raw !== "object" || Array.isArray(raw)) {
    errors.push(`${field}: expected an object or null, got ${JSON.stringify(raw)}`);
    return null;
  }
  return raw as Record<string, unknown>;
}

// ============================================================
// MatchSnapshot
// ============================================================

/** Represents one row of public.match_snapshots (migration
 * 0025_match_snapshots.sql) — an immutable, point-in-time copy of what
 * a user's Team/Formation/Manager configuration looked like when a
 * match was analyzed. team_id/formation_id/manager_id are provenance
 * only (see that migration's design notes) — every other field here is
 * the actual historical value, safe to render without joining back to
 * any live Library table. */
export interface MatchSnapshot {
  id: string;
  user_id: string;
  match_id: string;
  team_id: string | null;
  formation_id: string | null;
  manager_id: string | null;
  formation_code: string | null;
  formation_name: string | null;
  positions: PositionsJson | null;
  tactical_instructions: Record<string, unknown> | null;
  team_name: string | null;
  team_motto: string | null;
  team_description: string | null;
  team_founded_year: number | null;
  team_stadium: string | null;
  manager_name: string | null;
  manager_ratings: Record<string, unknown> | null;
  created_at: string;
}

/** Shape of what a (future, server-side-only — spec section 5/7)
 * creation workflow constructs before persisting a match_snapshots row
 * — mirrors the columns migration 0025_match_snapshots.sql actually
 * has, minus server-controlled columns (id/created_at). Unlike every
 * *LibraryInput in this package, this is never submitted by a browser
 * client — user_id here is the SNAPSHOT'S owner (validated against the
 * referenced match's own owner by RLS + the ownership trigger in
 * migration 0025, never trusted from this validator alone). */
export interface MatchSnapshotInput {
  user_id: string;
  match_id: string;
  team_id: string | null;
  formation_id: string | null;
  manager_id: string | null;
  formation_code: string | null;
  formation_name: string | null;
  positions: PositionsJson | null;
  tactical_instructions: Record<string, unknown> | null;
  team_name: string | null;
  team_motto: string | null;
  team_description: string | null;
  team_founded_year: number | null;
  team_stadium: string | null;
  manager_name: string | null;
  manager_ratings: Record<string, unknown> | null;
}

export interface MatchSnapshotValidationResult {
  valid: boolean;
  sanitized: MatchSnapshotInput;
  errors: string[];
}

const EMPTY_MATCH_SNAPSHOT_INPUT: MatchSnapshotInput = {
  user_id: "",
  match_id: "",
  team_id: null,
  formation_id: null,
  manager_id: null,
  formation_code: null,
  formation_name: null,
  positions: null,
  tactical_instructions: null,
  team_name: null,
  team_motto: null,
  team_description: null,
  team_founded_year: null,
  team_stadium: null,
  manager_name: null,
  manager_ratings: null,
};

/**
 * Validates a constructed MatchSnapshotInput-shaped object before it's
 * persisted to public.match_snapshots. Same never-throws,
 * never-coerce-to-a-guess convention as validatePlayerLibraryInput/
 * validateTeamFormationInput: a failing optional field is dropped to
 * null (with the reason recorded in `errors`), never silently replaced
 * with a fabricated value (spec section 4 — "Never convert unknown
 * values to 0/""/fake names/fake ratings/fabricated attributes").
 * `user_id`/`match_id` are required and a missing/malformed value
 * fails the whole record — everything else may be null, since a
 * snapshot legitimately may not have every historical field available
 * at capture time. Ownership (that `user_id` really is the owner of
 * `match_id`) is NOT checked here — that's RLS + the
 * check_match_snapshots_ownership trigger's job (migration 0025), not
 * this pure, dependency-free module's.
 */
export function validateMatchSnapshotInput(input: unknown): MatchSnapshotValidationResult {
  if (!input || typeof input !== "object" || Array.isArray(input)) {
    return { valid: false, errors: ["input is not an object"], sanitized: EMPTY_MATCH_SNAPSHOT_INPUT };
  }

  const d = input as Record<string, unknown>;
  const errors: string[] = [];

  const sanitized: MatchSnapshotInput = {
    user_id: sanitizeRequiredUuid(d.user_id, "user_id", errors),
    match_id: sanitizeRequiredUuid(d.match_id, "match_id", errors),
    team_id: sanitizeNullableUuid(d.team_id, "team_id", errors),
    formation_id: sanitizeNullableUuid(d.formation_id, "formation_id", errors),
    manager_id: sanitizeNullableUuid(d.manager_id, "manager_id", errors),
    formation_code: sanitizeNullableString(d.formation_code, "formation_code", errors),
    formation_name: sanitizeNullableString(d.formation_name, "formation_name", errors),
    positions: sanitizeNullablePositions(d.positions, errors),
    tactical_instructions: sanitizeNullableJsonObject(d.tactical_instructions, "tactical_instructions", errors),
    team_name: sanitizeNullableString(d.team_name, "team_name", errors),
    team_motto: sanitizeNullableString(d.team_motto, "team_motto", errors),
    team_description: sanitizeNullableString(d.team_description, "team_description", errors),
    team_founded_year: sanitizeFoundedYear(d.team_founded_year, errors),
    team_stadium: sanitizeNullableString(d.team_stadium, "team_stadium", errors),
    manager_name: sanitizeNullableString(d.manager_name, "manager_name", errors),
    manager_ratings: sanitizeNullableJsonObject(d.manager_ratings, "manager_ratings", errors),
  };

  return { valid: errors.length === 0, sanitized, errors };
}

// ============================================================
// MatchSnapshotPlayer
// ============================================================

/** Represents one row of public.match_snapshot_players (migration
 * 0025_match_snapshots.sql) — an immutable, point-in-time copy of one
 * player's Player Library card as it looked when a match was analyzed.
 * player_id is provenance only (see that migration's design notes) —
 * every other field is the actual historical value, safe to render
 * without joining back to player_library. Deliberately has no user_id
 * of its own — ownership derives entirely through
 * snapshot_id -> match_snapshots.user_id. */
export interface MatchSnapshotPlayer {
  id: string;
  snapshot_id: string;
  player_id: string | null;
  player_name: string | null;
  position: string | null;
  overall: number | null;
  playstyle: string | null;
  attributes: Record<string, number | string | null> | null;
  position_slot: string | null;
  created_at: string;
}

/** Shape of what a (future, server-side-only) creation workflow
 * constructs before persisting a match_snapshot_players row — mirrors
 * the columns migration 0025_match_snapshots.sql actually has, minus
 * server-controlled columns (id/created_at). No user_id field exists
 * here at all (spec section 6 — "snapshot player does not require
 * user_id"); ownership is entirely derived through snapshot_id. */
export interface MatchSnapshotPlayerInput {
  snapshot_id: string;
  player_id: string | null;
  player_name: string | null;
  position: string | null;
  overall: number | null;
  playstyle: string | null;
  attributes: Record<string, number | string | null> | null;
  position_slot: string | null;
}

export interface MatchSnapshotPlayerValidationResult {
  valid: boolean;
  sanitized: MatchSnapshotPlayerInput;
  errors: string[];
}

const EMPTY_MATCH_SNAPSHOT_PLAYER_INPUT: MatchSnapshotPlayerInput = {
  snapshot_id: "",
  player_id: null,
  player_name: null,
  position: null,
  overall: null,
  playstyle: null,
  attributes: null,
  position_slot: null,
};

/** attributes here is nullable (unlike player_library.attributes,
 * which always defaults to an empty object when omitted) — a snapshot
 * player row legitimately may have no attributes captured at all,
 * which is a different thing from "attributes were captured and all
 * came back empty". Reuses playerCard.ts's own sanitizeAttributes for
 * the per-key NULL/UNKNOWN rule once a value IS present. */
function sanitizeNullableAttributes(
  raw: unknown,
  errors: string[]
): Record<string, number | string | null> | null {
  if (raw === undefined || raw === null) return null;
  const sanitized = sanitizeAttributes(raw, errors);
  return sanitized;
}

/**
 * Validates a constructed MatchSnapshotPlayerInput-shaped object
 * before it's persisted to public.match_snapshot_players. Same
 * never-throws, never-coerce-to-a-guess convention as
 * validateMatchSnapshotInput above: `snapshot_id` is required and a
 * missing/malformed value fails the whole record; every other field
 * may be null, since an unknown historical player value must stay
 * null rather than be fabricated (spec section 4). Ownership is NOT
 * checked here — that's RLS's job (migration 0025), derived entirely
 * through snapshot_id, not this pure, dependency-free module's.
 */
export function validateMatchSnapshotPlayerInput(input: unknown): MatchSnapshotPlayerValidationResult {
  if (!input || typeof input !== "object" || Array.isArray(input)) {
    return { valid: false, errors: ["input is not an object"], sanitized: EMPTY_MATCH_SNAPSHOT_PLAYER_INPUT };
  }

  const d = input as Record<string, unknown>;
  const errors: string[] = [];

  const sanitized: MatchSnapshotPlayerInput = {
    snapshot_id: sanitizeRequiredUuid(d.snapshot_id, "snapshot_id", errors),
    player_id: sanitizeNullableUuid(d.player_id, "player_id", errors),
    player_name: sanitizeNullableString(d.player_name, "player_name", errors),
    position: sanitizeNullableString(d.position, "position", errors),
    overall: sanitizeOverall(d.overall, errors),
    playstyle: sanitizeNullableString(d.playstyle, "playstyle", errors),
    attributes: sanitizeNullableAttributes(d.attributes, errors),
    position_slot: sanitizeNullableString(d.position_slot, "position_slot", errors),
  };

  return { valid: errors.length === 0, sanitized, errors };
}

// ============================================================
// Duplicate-snapshot handling
// ============================================================
//
// public.match_snapshots_match_team_uniq (migration 0025) is a PARTIAL
// unique index — unique on (match_id, team_id) WHERE team_id IS NOT
// NULL. Postgres enforces it; nothing here re-implements that
// enforcement. This lets a caller (the future creation workflow)
// recognize that a failed insert failed BECAUSE of this exact
// constraint (an accidental repeat snapshot of the same match+team)
// rather than some other error.

/** The exact name of the partial unique index from migration 0025 —
 * kept as one named constant so callers can't drift apart if it's
 * ever renamed. */
export const MATCH_SNAPSHOT_MATCH_TEAM_UNIQUE_CONSTRAINT = "match_snapshots_match_team_uniq";

/** True when `err` is the "this match already has a snapshot for this
 * team" unique violation from match_snapshots_match_team_uniq, as
 * opposed to some other/unexpected error. */
export function isDuplicateMatchSnapshot(err: unknown): boolean {
  return isUniqueViolation(err, MATCH_SNAPSHOT_MATCH_TEAM_UNIQUE_CONSTRAINT);
}
