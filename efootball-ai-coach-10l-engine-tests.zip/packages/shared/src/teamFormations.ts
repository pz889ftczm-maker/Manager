// Batch 8A — Team Formation DATA MODEL only. Shared type + pure
// validation for public.team_formations (migration
// 0021_team_formations.sql). No Formation UI, no player assignment, no
// starting XI/bench, no presets, no historical snapshots — see that
// migration's design notes for the full scope boundary; this file
// mirrors it at the application layer only for the parts that need to
// exist for typing/validation before persisting a row.
//
// Named teamFormations.ts (plural, matching the team_formations table
// and the teamMembers.ts/teamManager.ts convention) to stay distinct
// from the existing formation.ts, which holds unrelated, session-only
// display helpers (FormationPlayerRef/FormationManagerRef) for the
// current (not-yet-persisted) Formation feature — nothing in this file
// depends on or duplicates that.

import { isUniqueViolation } from "./playerLibrary.js";

export { isUniqueViolation };

/**
 * A single formation-layout slot. Deliberately loose/extensible (spec:
 * "keep the schema extensible") — `id` is the only thing every entry
 * must have; everything else is optional and additional unrecognized
 * keys are left alone (never stripped), so a future batch can add
 * fields (e.g. width/height/bench-order) without a shape-breaking
 * migration here.
 *
 * NEVER contains a player_id, player name, or any other Player Library
 * data — see validatePositions below, which rejects an entry carrying
 * one. Player assignment is explicitly Batch 8B's job, not this one's.
 */
export interface PositionDefinition {
  /** Stable slot identifier within this formation (e.g. "gk", "cb1"). */
  id: string;
  /** Football position/role label (e.g. "GK", "CB"), if given. */
  role?: string;
  /** Normalized, formation-relative horizontal coordinate in [0, 1].
   * NOT a real-world tracking coordinate — purely a layout hint for
   * rendering this formation's shape (spec section 3). */
  x?: number;
  /** Normalized, formation-relative vertical coordinate in [0, 1]. */
  y?: number;
  [key: string]: unknown;
}

/** Keys that would smuggle player assignment into a formation-layout
 * entry — explicitly out of scope for this batch (spec sections 3/11:
 * "Do not invent fake player IDs" / "Do NOT create ... player
 * assignments ... this batch"). Checked on every position entry
 * regardless of whether `positions` is a role-keyed object or an array
 * of entries. */
const FORBIDDEN_POSITION_KEYS = ["player_id", "playerId", "player_name", "playerName"] as const;

/** The two shapes `positions` may take, matching migration
 * 0021_team_formations.sql's `jsonb_typeof(positions) in ('object',
 * 'array')` check: a role-keyed map (`{ "GK": { x, y }, ... }`), or a
 * flat array of PositionDefinition-shaped entries. Neither shape is
 * required over the other — the spec's own example shows both, and
 * this stays intentionally permissive at the type level; the actual
 * validation is validatePositions below. */
export type PositionsJson = Record<string, unknown> | unknown[];

export interface PositionsValidationResult {
  valid: boolean;
  errors: string[];
}

/** Checks one position entry (either a `positions[i]` array element, or
 * one value from a role-keyed `positions` object) for the loose,
 * extensible shape this batch requires: no forbidden player-assignment
 * keys, and x/y — if present — are finite numbers roughly in [0, 1].
 * Coordinates outside that range are flagged as a warning-level error
 * rather than silently clamped/dropped, since a wildly out-of-range
 * value likely indicates a real upstream mistake worth surfacing, not
 * a value this function should quietly "fix". */
function validatePositionEntry(entry: unknown, label: string, errors: string[]): void {
  if (!entry || typeof entry !== "object" || Array.isArray(entry)) {
    errors.push(`${label}: expected an object, got ${JSON.stringify(entry)}`);
    return;
  }
  const e = entry as Record<string, unknown>;

  for (const forbidden of FORBIDDEN_POSITION_KEYS) {
    if (Object.prototype.hasOwnProperty.call(e, forbidden)) {
      errors.push(
        `${label}: "${forbidden}" is not allowed on a formation position — player assignment is not part of this data model yet`
      );
    }
  }

  if (e.x !== undefined && e.x !== null) {
    if (typeof e.x !== "number" || !Number.isFinite(e.x) || e.x < 0 || e.x > 1) {
      errors.push(`${label}: x must be a finite number between 0 and 1 (formation-relative), got ${JSON.stringify(e.x)}`);
    }
  }
  if (e.y !== undefined && e.y !== null) {
    if (typeof e.y !== "number" || !Number.isFinite(e.y) || e.y < 0 || e.y > 1) {
      errors.push(`${label}: y must be a finite number between 0 and 1 (formation-relative), got ${JSON.stringify(e.y)}`);
    }
  }
}

/**
 * Validates a `positions` value before it's persisted to
 * team_formations.positions. Mirrors migration
 * 0021_team_formations.sql's DB-level check (must be a jsonb object or
 * array) and adds the one thing a plain jsonb_typeof check can't: that
 * no entry smuggles in a player_id/player_name (Batch 8B's job, not
 * this one's). Deliberately does NOT require specific keys like `role`
 * or coordinates at all — an entry with only an `id` is valid — per
 * spec section 3's "keep the schema extensible".
 */
export function validatePositions(raw: unknown): PositionsValidationResult {
  const errors: string[] = [];

  if (raw === null || raw === undefined) {
    return { valid: false, errors: ["positions is required and cannot be null"] };
  }

  if (Array.isArray(raw)) {
    if (raw.length === 0) {
      errors.push("positions: an empty array is technically valid JSONB but describes no layout — provide at least one position, or omit fields you don't have yet rather than an empty list");
    }
    raw.forEach((entry, i) => {
      if (!entry || typeof entry !== "object" || Array.isArray(entry) || !("id" in entry)) {
        errors.push(`positions[${i}]: expected an object with a stable string "id"`);
        return;
      }
      const id = (entry as Record<string, unknown>).id;
      if (typeof id !== "string" || id.trim().length === 0) {
        errors.push(`positions[${i}].id: expected a non-empty string, got ${JSON.stringify(id)}`);
      }
      validatePositionEntry(entry, `positions[${i}]`, errors);
    });
    return { valid: errors.length === 0, errors };
  }

  if (typeof raw === "object") {
    const entries = Object.entries(raw as Record<string, unknown>);
    if (entries.length === 0) {
      errors.push("positions: an empty object is technically valid JSONB but describes no layout — provide at least one position");
    }
    for (const [key, value] of entries) {
      if (key.trim().length === 0) {
        errors.push("positions: a role key cannot be an empty string");
      }
      validatePositionEntry(value, `positions.${key}`, errors);
    }
    return { valid: errors.length === 0, errors };
  }

  return { valid: false, errors: [`positions: expected an object or array, got ${JSON.stringify(raw)}`] };
}

// ============================================================
// Rendering support (Batch 8C)
// ============================================================
//
// The Formation UI needs to walk a formation's stored `positions`
// value as one flat, order-preserving list of slots — regardless of
// which of the two shapes validatePositions accepts it was actually
// stored in (a role-keyed object map, or an array of entries). This is
// the read-side inverse of that validation, for rendering, not for
// enforcing write-time correctness.

export interface NormalizedPosition {
  /** Stable slot identifier — the array entry's own `id` for
   * array-shaped positions, or the role key itself for role-keyed map
   * positions (e.g. "GK"). This is the same string a
   * team_formation_players.position_slot value is expected to match
   * (see migration 0022's design notes). */
  id: string;
  role: string | null;
  x: number | null;
  y: number | null;
}

function toNormalizedPosition(id: string, entry: Record<string, unknown>): NormalizedPosition {
  const role = typeof entry.role === "string" && entry.role.trim().length > 0 ? entry.role.trim() : null;
  const x = typeof entry.x === "number" && Number.isFinite(entry.x) ? entry.x : null;
  const y = typeof entry.y === "number" && Number.isFinite(entry.y) ? entry.y : null;
  return { id, role, x, y };
}

/**
 * Turns a stored `positions` value (either shape validatePositions
 * accepts) into a flat list of slots ready for rendering. Does NOT
 * re-validate — an entry that wouldn't pass validatePositions (a
 * missing/blank id, an out-of-range x/y) is simply skipped rather than
 * thrown, on the assumption that anything actually being rendered here
 * already passed validateTeamFormationInput at write time; a caller
 * that needs write-time strictness should use validatePositions/
 * validateTeamFormationInput instead of this function. Order is
 * preserved from the input (array order, or Object.entries order for a
 * map) — this function doesn't sort or otherwise reorder slots.
 */
export function normalizePositions(raw: PositionsJson): NormalizedPosition[] {
  const out: NormalizedPosition[] = [];

  if (Array.isArray(raw)) {
    for (const entry of raw) {
      if (!entry || typeof entry !== "object" || Array.isArray(entry)) continue;
      const id = (entry as Record<string, unknown>).id;
      if (typeof id !== "string" || id.trim().length === 0) continue;
      out.push(toNormalizedPosition(id.trim(), entry as Record<string, unknown>));
    }
    return out;
  }

  if (raw && typeof raw === "object") {
    for (const [key, value] of Object.entries(raw as Record<string, unknown>)) {
      if (key.trim().length === 0) continue;
      if (!value || typeof value !== "object" || Array.isArray(value)) continue;
      out.push(toNormalizedPosition(key.trim(), value as Record<string, unknown>));
    }
    return out;
  }

  return out;
}

/** Shape of what a caller submits to persist a team_formations row —
 * mirrors the columns migration 0021_team_formations.sql actually has,
 * minus server-controlled columns (id/created_at/updated_at).
 * `team_id` is required (the row's owning team, checked against
 * team_library.user_id by RLS — never trusted from this validator
 * alone). `tactical_instructions` stays a fully generic, nullable JSON
 * object — no eFootball-specific keys are defined, required, or even
 * suggested here (spec section 4). */
export interface TeamFormationInput {
  team_id: string;
  name: string;
  formation_code: string;
  positions: PositionsJson;
  tactical_instructions: Record<string, unknown> | null;
}

export interface TeamFormationValidationResult {
  valid: boolean;
  sanitized: TeamFormationInput;
  errors: string[];
}

const UUID_SHAPE = /^[0-9a-f]{8}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{12}$/i;

function sanitizeRequiredNonBlank(raw: unknown, field: string, errors: string[]): string {
  if (typeof raw !== "string" || raw.trim().length === 0) {
    errors.push(`${field}: expected a non-empty string, got ${JSON.stringify(raw)}`);
    return "";
  }
  return raw.trim();
}

function sanitizeTeamId(raw: unknown, errors: string[]): string {
  if (typeof raw !== "string" || !UUID_SHAPE.test(raw.trim())) {
    errors.push(`team_id: expected a uuid, got ${JSON.stringify(raw)}`);
    return "";
  }
  return raw.trim();
}

/** tactical_instructions must be a plain JSON object, or null/absent
 * (spec section 4 — nullable, generic, extensible). Unlike the
 * optional string fields elsewhere in this repo, an invalid value here
 * is NOT silently discarded to null — tactical_instructions is
 * free-form enough that a caller could easily send something
 * unintentionally malformed (e.g. an array by mistake), and silently
 * dropping it would lose real user input without telling them. */
function sanitizeTacticalInstructions(raw: unknown, errors: string[]): Record<string, unknown> | null {
  if (raw === undefined || raw === null) return null;
  if (typeof raw !== "object" || Array.isArray(raw)) {
    errors.push(`tactical_instructions: expected an object or null, got ${JSON.stringify(raw)}`);
    return null;
  }
  return raw as Record<string, unknown>;
}

// ============================================================
// Field-only validation (Batch 8C — for updates)
// ============================================================
//
// An update to an existing team_formations row (rename it, redraw its
// layout, change its tactical_instructions) never repoints team_id —
// see teamFormations.ts's client-side updateTeamFormation, which never
// sends that column — so requiring/validating a team_id on every such
// call would force a caller to pass along a value it isn't actually
// changing just to satisfy this function. validateTeamFormationFields
// is validateTeamFormationInput's same field-level checking (name,
// formation_code, positions, tactical_instructions) with the team_id
// requirement lifted out; validateTeamFormationInput itself now
// delegates to it for those four fields rather than duplicating the
// checks.

export interface TeamFormationFieldsInput {
  name: string;
  formation_code: string;
  positions: PositionsJson;
  tactical_instructions: Record<string, unknown> | null;
}

export interface TeamFormationFieldsValidationResult {
  valid: boolean;
  sanitized: TeamFormationFieldsInput;
  errors: string[];
}

/**
 * Validates the team-id-independent fields of a TeamFormationInput —
 * name, formation_code, positions, tactical_instructions — without
 * requiring or touching team_id at all. Same never-throws,
 * never-coerce-to-a-guess convention as validateTeamFormationInput
 * (which this now backs); intended for an UPDATE call site that isn't
 * changing which team a formation belongs to.
 */
export function validateTeamFormationFields(input: unknown): TeamFormationFieldsValidationResult {
  const errors: string[] = [];
  const empty: TeamFormationFieldsInput = {
    name: "",
    formation_code: "",
    positions: {},
    tactical_instructions: null,
  };

  if (!input || typeof input !== "object" || Array.isArray(input)) {
    return { valid: false, errors: ["input is not an object"], sanitized: empty };
  }

  const d = input as Record<string, unknown>;

  const positionsResult = validatePositions(d.positions);
  if (!positionsResult.valid) {
    errors.push(...positionsResult.errors);
  }

  const sanitized: TeamFormationFieldsInput = {
    name: sanitizeRequiredNonBlank(d.name, "name", errors),
    formation_code: sanitizeRequiredNonBlank(d.formation_code, "formation_code", errors),
    // Kept as-submitted (not defaulted to {}) when invalid, so the
    // caller's original — flawed — value is visible in the error
    // rather than replaced by a value that would pass validation.
    positions: (d.positions as PositionsJson) ?? {},
    tactical_instructions: sanitizeTacticalInstructions(d.tactical_instructions, errors),
  };

  return { valid: errors.length === 0, sanitized, errors };
}

/**
 * Validates a user-submitted TeamFormationInput-shaped object before
 * it's persisted to public.team_formations. Delegates name/
 * formation_code/positions/tactical_instructions checking to
 * validateTeamFormationFields above and adds the one thing an update
 * call site doesn't need: a required team_id. Never checks team_id
 * OWNERSHIP — that's RLS's job (migration 0021), not this pure,
 * dependency-free module's.
 */
export function validateTeamFormationInput(input: unknown): TeamFormationValidationResult {
  const empty: TeamFormationInput = {
    team_id: "",
    name: "",
    formation_code: "",
    positions: {},
    tactical_instructions: null,
  };

  if (!input || typeof input !== "object" || Array.isArray(input)) {
    return { valid: false, errors: ["input is not an object"], sanitized: empty };
  }

  const d = input as Record<string, unknown>;
  const errors: string[] = [];

  const team_id = sanitizeTeamId(d.team_id, errors);
  const fieldsResult = validateTeamFormationFields(d);
  errors.push(...fieldsResult.errors);

  const sanitized: TeamFormationInput = { team_id, ...fieldsResult.sanitized };

  return { valid: errors.length === 0, sanitized, errors };
}

// ============================================================
// Duplicate-name handling
// ============================================================
//
// public.team_formations_team_name_uniq (migration 0021) is a plain
// unique index on (team_id, lower(name)) — Postgres enforces it;
// nothing here re-implements that enforcement. This constant lets a
// caller recognize that a failed insert/update failed BECAUSE of this
// exact constraint (spec section 7 — same formation name allowed
// across different teams, never within the same team) rather than some
// other error.

/** The exact name of the unique index from migration 0021 — kept as one
 * named constant so callers can't drift apart if it's ever renamed. */
export const TEAM_FORMATION_NAME_UNIQUE_CONSTRAINT = "team_formations_team_name_uniq";

/** True when `err` is the "this team already has a formation with this
 * name" unique violation from team_formations_team_name_uniq, as
 * opposed to some other/unexpected error. */
export function isDuplicateTeamFormationName(err: unknown): boolean {
  return isUniqueViolation(err, TEAM_FORMATION_NAME_UNIQUE_CONSTRAINT);
}

// ============================================================
// Shared type
// ============================================================

/**
 * Represents one row of public.team_formations (migration
 * 0021_team_formations.sql) — the CURRENT formation/preset-like
 * arrangement for a team, layout only. No player assignment, no
 * starting XI/bench (Batch 8B), no historical snapshot linkage
 * (Phase 9) — see that migration's design notes for the full boundary.
 */
export interface TeamFormation {
  id: string;
  team_id: string;
  name: string;
  formation_code: string;
  positions: PositionsJson;
  tactical_instructions: Record<string, unknown> | null;
  created_at: string;
  updated_at: string;
}
