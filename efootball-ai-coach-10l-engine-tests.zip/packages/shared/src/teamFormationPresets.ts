// Batch 8D — Formation Presets. Shared type + pure validation for
// public.team_formation_presets (migration
// 0024_team_formation_presets.sql). A preset is a REUSABLE, editable
// tactical configuration a user can save from and apply to their
// current Formation — NOT a historical match snapshot. No match_id, no
// snapshot_id, no created-from-match fields anywhere in this file; see
// that migration's design notes for the full scope boundary.
//
// Named teamFormationPresets.ts (plural, matching team_formations.ts's
// own naming convention) to stay distinct from teamFormations.ts, whose
// TeamFormation type represents the CURRENT, single, persisted
// formation for a team — this file's TeamFormationPreset is an
// independent, freely-editable, save-and-load-many configuration.
//
// Reuses teamFormations.ts's existing validatePositions (spec section
// 8 — "reuse existing position validation rather than creating a
// conflicting second implementation") rather than reimplementing the
// positions-shape/forbidden-keys checks a second time — a preset's
// `positions` column has the exact same shape and the exact same
// "never smuggle a player_id/playerId/player_name/playerName into a
// position entry" rule as a team_formations row's.

import { isUniqueViolation } from "./playerLibrary.js";
import { validatePositions, type PositionsJson } from "./teamFormations.js";

export { isUniqueViolation };
// NOTE: PositionsJson is intentionally NOT re-exported from this file —
// it's already exported once via teamFormations.js in index.ts, and a
// second `export type { PositionsJson }` here would make index.ts's
// `export *` from both files ambiguous (TS2308). Import it directly
// from "./teamFormations.js" (as this file does above) if you need the
// type outside teamFormations.ts itself.

const UUID_SHAPE = /^[0-9a-f]{8}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{12}$/i;

function sanitizeRequiredNonBlank(raw: unknown, field: string, errors: string[]): string {
  if (typeof raw !== "string" || raw.trim().length === 0) {
    errors.push(`${field}: expected a non-empty string, got ${JSON.stringify(raw)}`);
    return "";
  }
  return raw.trim();
}

function sanitizeTeamId(raw: unknown, errors: string[]): string {
  if (typeof raw !== "string" || !UUID_SHAPE.test(raw.trim())) {
    errors.push(`team_id: expected a uuid, got ${JSON.stringify(raw)}`);
    return "";
  }
  return raw.trim();
}

/** tactical_instructions must be a plain JSON object, or null/absent —
 * same convention as teamFormations.ts's sanitizeTacticalInstructions,
 * duplicated here (rather than imported) since it's a private,
 * unexported helper in that file; kept identical in behavior. */
function sanitizeTacticalInstructions(raw: unknown, errors: string[]): Record<string, unknown> | null {
  if (raw === undefined || raw === null) return null;
  if (typeof raw !== "object" || Array.isArray(raw)) {
    errors.push(`tactical_instructions: expected an object or null, got ${JSON.stringify(raw)}`);
    return null;
  }
  return raw as Record<string, unknown>;
}

// ============================================================
// Shared type
// ============================================================

/**
 * Represents one row of public.team_formation_presets (migration
 * 0024_team_formation_presets.sql) — a REUSABLE, user-editable
 * tactical configuration for a team. Independent of that team's
 * current team_formations row: saving a preset from a Formation COPIES
 * these fields; applying a preset back COPIES them the other way. No
 * foreign key connects the two tables, and nothing in this type
 * references matches/analysis_events/player_statistics/progress/
 * snapshots/tournament_results/AI Coach — historical formation
 * snapshots are Phase 9's concern, not this one's.
 */
export interface TeamFormationPreset {
  id: string;
  team_id: string;
  name: string;
  formation_code: string;
  positions: PositionsJson;
  tactical_instructions: Record<string, unknown> | null;
  created_at: string;
  updated_at: string;
}

/** Shape of what a caller submits to persist a team_formation_presets
 * row — mirrors the columns migration 0024 actually has, minus
 * server-controlled columns (id/created_at/updated_at). */
export interface TeamFormationPresetInput {
  team_id: string;
  name: string;
  formation_code: string;
  positions: PositionsJson;
  tactical_instructions: Record<string, unknown> | null;
}

export interface TeamFormationPresetValidationResult {
  valid: boolean;
  sanitized: TeamFormationPresetInput;
  errors: string[];
}

// ============================================================
// Field-only validation (for renames/updates that don't touch team_id)
// ============================================================

export interface TeamFormationPresetFieldsInput {
  name: string;
  formation_code: string;
  positions: PositionsJson;
  tactical_instructions: Record<string, unknown> | null;
}

export interface TeamFormationPresetFieldsValidationResult {
  valid: boolean;
  sanitized: TeamFormationPresetFieldsInput;
  errors: string[];
}

/**
 * Validates the team-id-independent fields of a
 * TeamFormationPresetInput — name, formation_code, positions,
 * tactical_instructions — without requiring or touching team_id at
 * all. Intended for an UPDATE/rename call site that isn't changing
 * which team a preset belongs to (renaming a preset, or resaving its
 * layout, never repoints team_id — see apps/web/src/lib/
 * teamFormationPresets.ts's updateTeamFormationPreset, which never
 * sends that column).
 */
export function validateTeamFormationPresetFields(input: unknown): TeamFormationPresetFieldsValidationResult {
  const errors: string[] = [];
  const empty: TeamFormationPresetFieldsInput = {
    name: "",
    formation_code: "",
    positions: {},
    tactical_instructions: null,
  };

  if (!input || typeof input !== "object" || Array.isArray(input)) {
    return { valid: false, errors: ["input is not an object"], sanitized: empty };
  }

  const d = input as Record<string, unknown>;

  const positionsResult = validatePositions(d.positions);
  if (!positionsResult.valid) {
    errors.push(...positionsResult.errors);
  }

  const sanitized: TeamFormationPresetFieldsInput = {
    name: sanitizeRequiredNonBlank(d.name, "name", errors),
    formation_code: sanitizeRequiredNonBlank(d.formation_code, "formation_code", errors),
    // Kept as-submitted (not defaulted to {}) when invalid, so the
    // caller's original — flawed — value is visible in the error
    // rather than replaced by a value that would pass validation.
    positions: (d.positions as PositionsJson) ?? {},
    tactical_instructions: sanitizeTacticalInstructions(d.tactical_instructions, errors),
  };

  return { valid: errors.length === 0, sanitized, errors };
}

/**
 * Validates a user-submitted TeamFormationPresetInput-shaped object
 * before it's persisted to public.team_formation_presets. Delegates
 * name/formation_code/positions/tactical_instructions checking to
 * validateTeamFormationPresetFields above and adds the one thing an
 * update call site doesn't need: a required team_id. Never checks
 * team_id OWNERSHIP — that's RLS's job (migration 0024), not this
 * pure, dependency-free module's.
 */
export function validateTeamFormationPresetInput(input: unknown): TeamFormationPresetValidationResult {
  const empty: TeamFormationPresetInput = {
    team_id: "",
    name: "",
    formation_code: "",
    positions: {},
    tactical_instructions: null,
  };

  if (!input || typeof input !== "object" || Array.isArray(input)) {
    return { valid: false, errors: ["input is not an object"], sanitized: empty };
  }

  const d = input as Record<string, unknown>;
  const errors: string[] = [];

  const team_id = sanitizeTeamId(d.team_id, errors);
  const fieldsResult = validateTeamFormationPresetFields(d);
  errors.push(...fieldsResult.errors);

  const sanitized: TeamFormationPresetInput = { team_id, ...fieldsResult.sanitized };

  return { valid: errors.length === 0, sanitized, errors };
}

// ============================================================
// Duplicate-name handling
// ============================================================
//
// public.team_formation_presets_team_name_uniq (migration 0024) is a
// plain unique index on (team_id, lower(name)) — Postgres enforces it;
// nothing here re-implements that enforcement. Same "same name allowed
// across different teams, never within the same team" semantics as
// TEAM_FORMATION_NAME_UNIQUE_CONSTRAINT (teamFormations.ts).

/** The exact name of the unique index from migration 0024 — kept as one
 * named constant so callers can't drift apart if it's ever renamed. */
export const TEAM_FORMATION_PRESET_NAME_UNIQUE_CONSTRAINT = "team_formation_presets_team_name_uniq";

/** True when `err` is the "this team already has a preset with this
 * name" unique violation from team_formation_presets_team_name_uniq, as
 * opposed to some other/unexpected error. */
export function isDuplicateFormationPresetName(err: unknown): boolean {
  return isUniqueViolation(err, TEAM_FORMATION_PRESET_NAME_UNIQUE_CONSTRAINT);
}

// ============================================================
// Cross-team apply guard (Batch 8D quick fix)
// ============================================================
//
// RLS (team_formation_presets_select_own / team_formations_select_own)
// independently scopes a preset and a Formation to teams the CALLER
// owns — but a caller who owns more than one team can still legally
// read a Team A preset AND a Team B Formation in the same request. RLS
// alone can't stop those two ids from being combined by
// applyFormationPreset (apps/web/src/lib/teamFormationPresets.ts); that
// combination has to be rejected in application code, BEFORE any
// mutation. This is a pure, dependency-free check — same "no live
// Supabase/RLS involved" scope as the rest of this file — so it can be
// unit-tested the same way as validateTeamFormationPresetInput above.

/** Thrown by assertSameTeamForPresetApply when a preset and a Formation
 * belong to different teams. `message` is deliberately generic and
 * fixed — never interpolates a preset id/Formation id/team id or any
 * other value from the caller or the database — so it's always safe to
 * log or (via a UI error mapper) show to the end user as-is. */
export class FormationPresetTeamMismatchError extends Error {
  constructor() {
    super("Formation preset belongs to a different team.");
    this.name = "FormationPresetTeamMismatchError";
  }
}

/** True when `err` is a FormationPresetTeamMismatchError, as opposed to
 * some other/unexpected error — same `instanceof` convention as
 * isProviderError (packages/ai/src/providerError.ts). */
export function isFormationPresetTeamMismatchError(err: unknown): err is FormationPresetTeamMismatchError {
  return err instanceof FormationPresetTeamMismatchError;
}

/**
 * Guards applyFormationPreset against applying a preset belonging to
 * one team onto a Formation belonging to a different team. Call this
 * AFTER loading both the preset and the target Formation and BEFORE
 * writing anything — throwing here must leave the Formation, its
 * player assignments, and the preset completely untouched.
 *
 * Only compares team_id; ownership of either row is already RLS's job
 * (spec section 9 — authorization logic is not duplicated here), not
 * this function's.
 */
export function assertSameTeamForPresetApply(
  preset: Pick<TeamFormationPreset, "team_id">,
  formation: { team_id: string }
): void {
  if (preset.team_id !== formation.team_id) {
    throw new FormationPresetTeamMismatchError();
  }
}
