// Batch 10B — eFootball Context. The shared, server-safe model +
// builder that lets the (future, 10C+) Football Analysis Engine read
// eFootball-specific context for a match — Player Library references/
// attributes/playstyle/position, Manager + manager style ratings, and
// Formation + tactical instructions — WITHOUT reconstructing any of it
// itself and without inventing anything not already stored.
//
// PURE / DEPENDENCY-FREE (same convention as footballMatchContext.ts,
// matchSnapshots.ts, matchSnapshotDisplay.ts): this file makes no
// database call and has no I/O of any kind. It only assembles an
// EfootballMatchContext out of data the caller already fetched —
// either an existing MatchSnapshot(+players) (Batch 9A) or a "live"
// Team/Formation/Manager/Player read (Batches 6A/6B/7/8). This is the
// ONE shared builder spec section 5 asks for: apps/web, apps/worker,
// and packages/ai all import buildEfootballMatchContext from here
// instead of each re-implementing the same assembly/gating logic.
//
// GATING (spec section 3): buildEfootballMatchContext's FIRST job is
// deciding whether eFootball context is even allowed for this match at
// all, using footballMatchContext.ts's own allowsEfootballContext —
// never re-derived here. football_type = "real_football" and
// football_type = null (legacy) both come back { available: false },
// with a distinct `reason` so a caller/test can tell "this is Real
// Football" apart from "this match predates football_type entirely"
// (spec section 3's own separate legacy-match requirement) — neither
// is ever treated as "assume eFootball".
//
// HISTORICAL VS CURRENT (spec section 2): when `sources.snapshot` is
// present, it is used EXCLUSIVELY — every field comes from the
// snapshot's own already-copied columns, never from `sources.live`,
// even to fill in a field the snapshot itself has as null. This is
// deliberate: a snapshot's null means "this value legitimately wasn't
// captured at match time", not "go look it up some other way" — mixing
// in current Player/Manager/Team/Formation data here would silently
// reintroduce exactly the "may have changed since the match" problem
// Batch 9A's snapshot exists to solve. `sources.live` is read only
// when there is NO snapshot at all (e.g. analysis in progress, before
// Batch 9C-1's automatic post-completion snapshot has been created
// yet) — see triggerMatchSnapshotOnCompletion in
// apps/worker/src/matchSnapshot.ts for when that snapshot comes into
// existence.
//
// NEVER FABRICATE (spec section 4): every mapper below is a straight,
// field-for-field copy from the input row(s) it's given. There is no
// branch anywhere in this file that invents a player attribute,
// playstyle, manager rating, formation, or tactical instruction, and
// no branch that converts a null/unknown source value to 0/""/a
// fabricated default — a null column stays null on the built context.
//
// NO DATABASE CALLS, NO OWNERSHIP CHECK HERE (spec sections 5/7): this
// file never touches Supabase and never sees a matchId — ownership
// enforcement and the actual snapshot/live reads live in the caller
// (see apps/worker/src/efootballContext.ts), exactly like every other
// pure builder in this package (matchSnapshotDisplay.ts's own
// buildMatchSnapshotDisplay never checks ownership either — RLS/the
// caller already did).

import type { FootballMatchContext } from "./footballMatchContext.js";
import { allowsEfootballContext } from "./footballMatchContext.js";
import type { MatchSnapshot, MatchSnapshotPlayer } from "./matchSnapshots.js";
import type { PositionsJson, TeamFormation } from "./teamFormations.js";
import type { PlayerLibrary, ManagerLibrary } from "./types.js";

// ============================================================
// Shape
// ============================================================

/** One player relevant to eFootball analysis — a Player Library
 * reference plus its attributes/playstyle/position/formation slot.
 * `player_id` is provenance only (mirrors MatchSnapshotPlayer.player_id
 * / TeamFormationPlayer.player_id) — every other field is the actual
 * value, already resolved by the caller so this type never needs a
 * live join back to player_library. */
export interface EfootballContextPlayer {
  player_id: string | null;
  name: string | null;
  position: string | null;
  position_slot: string | null;
  overall: number | null;
  playstyle: string | null;
  attributes: Record<string, number | string | null> | null;
}

/** Mirrors the five rating columns manager_library/match_snapshots both
 * already have (0014/0025) — no new rating is defined here. */
export interface EfootballContextManagerRatings {
  possession_rating: number | null;
  quick_counter_rating: number | null;
  long_ball_counter_rating: number | null;
  out_wide_rating: number | null;
  long_ball_rating: number | null;
}

export interface EfootballContextManager {
  manager_id: string | null;
  name: string | null;
  ratings: EfootballContextManagerRatings | null;
}

export interface EfootballContextFormation {
  formation_id: string | null;
  formation_code: string | null;
  name: string | null;
  positions: PositionsJson | null;
  tactical_instructions: Record<string, unknown> | null;
}

/** "historical_snapshot" — every field was copied from an existing
 * MatchSnapshot(+players), the authoritative source per spec section 2.
 * "current_data" — no snapshot existed yet, so the caller's live
 * Team/Formation/Manager/Player Library read was used instead. */
export type EfootballContextSource = "historical_snapshot" | "current_data";

export interface EfootballMatchContext {
  available: true;
  source: EfootballContextSource;
  players: EfootballContextPlayer[];
  manager: EfootballContextManager | null;
  formation: EfootballContextFormation | null;
}

/**
 * - "not_efootball": the match's authoritative football_type is
 *   "real_football" (spec section 3 — eFootball context must be
 *   unavailable for Real Football).
 * - "unknown_football_type": football_type is NULL (a legacy match, or
 *   one where no context was ever supplied) — never assumed to be
 *   eFootball (spec section 3/4).
 * - "no_data": football_type IS "efootball", but the caller supplied
 *   neither a snapshot nor any live Team/Formation/Manager/Player data
 *   to build from (e.g. no team_id has ever been attached to this
 *   match) — an honest "nothing to show yet", never fabricated.
 */
export type EfootballContextUnavailableReason = "not_efootball" | "unknown_football_type" | "no_data";

export interface EfootballMatchContextUnavailable {
  available: false;
  reason: EfootballContextUnavailableReason;
}

export type EfootballMatchContextResult = EfootballMatchContext | EfootballMatchContextUnavailable;

// ============================================================
// Inputs — already-fetched data only, never a matchId/query
// ============================================================

/** An existing historical snapshot + its player rows (Batch 9A/9D) —
 * exactly what selectMatchSnapshotForMatch (matchSnapshotDisplay.ts)
 * + a match_snapshot_players query already produce. */
export interface EfootballContextSnapshotSource {
  snapshot: MatchSnapshot;
  players: readonly MatchSnapshotPlayer[];
}

/** One CURRENT formation-slot assignment, already joined by the
 * caller — mirrors team_formation_players.position_slot + the
 * player_library row it points at (exactly what
 * create_match_snapshot's own `tfp join player_library` does
 * server-side, migration 0026/0027). This file never performs that
 * join itself. */
export interface EfootballContextLivePlayer {
  position_slot: string | null;
  player: PlayerLibrary;
}

/** The CURRENT Team's Formation/Manager/roster, already read by the
 * caller — used only when no historical snapshot exists yet (see file
 * header comment). Every field is optional/nullable because a match's
 * team_id (migration 0028) may have no formation and/or no manager
 * assigned. */
export interface EfootballContextLiveSource {
  formation: TeamFormation | null;
  manager: ManagerLibrary | null;
  players: readonly EfootballContextLivePlayer[];
}

export interface EfootballContextSources {
  /** Preferred, exclusive source when present — see file header. */
  snapshot: EfootballContextSnapshotSource | null;
  /** Used only when `snapshot` is null. */
  live: EfootballContextLiveSource | null;
}

// ============================================================
// Snapshot -> EfootballMatchContext
// ============================================================

function snapshotManagerRatings(
  raw: Record<string, unknown> | null
): EfootballContextManagerRatings | null {
  if (!raw) return null;
  const pick = (key: string): number | null => {
    const v = raw[key];
    return typeof v === "number" ? v : null;
  };
  return {
    possession_rating: pick("possession_rating"),
    quick_counter_rating: pick("quick_counter_rating"),
    long_ball_counter_rating: pick("long_ball_counter_rating"),
    out_wide_rating: pick("out_wide_rating"),
    long_ball_rating: pick("long_ball_rating"),
  };
}

/** A snapshot's manager fields are all-or-nothing captured at once by
 * create_match_snapshot (0026) — but stay defensive here rather than
 * assuming that invariant: only report a manager when at least one of
 * manager_id/manager_name/manager_ratings actually carries a value, so
 * a fully-absent manager renders as `null` (spec section 4 — never
 * fabricate a manager object out of nothing) rather than an
 * all-fields-null object indistinguishable from a real one. */
function buildManagerFromSnapshot(snapshot: MatchSnapshot): EfootballContextManager | null {
  if (snapshot.manager_id === null && snapshot.manager_name === null && snapshot.manager_ratings === null) {
    return null;
  }
  return {
    manager_id: snapshot.manager_id,
    name: snapshot.manager_name,
    ratings: snapshotManagerRatings(snapshot.manager_ratings),
  };
}

/** Same "all-or-nothing absence, not an all-null object" reasoning as
 * buildManagerFromSnapshot above, for the formation fields a snapshot
 * copies from team_formations. */
function buildFormationFromSnapshot(snapshot: MatchSnapshot): EfootballContextFormation | null {
  if (
    snapshot.formation_id === null &&
    snapshot.formation_code === null &&
    snapshot.formation_name === null &&
    snapshot.positions === null &&
    snapshot.tactical_instructions === null
  ) {
    return null;
  }
  return {
    formation_id: snapshot.formation_id,
    formation_code: snapshot.formation_code,
    name: snapshot.formation_name,
    positions: snapshot.positions,
    tactical_instructions: snapshot.tactical_instructions,
  };
}

function buildPlayersFromSnapshot(players: readonly MatchSnapshotPlayer[]): EfootballContextPlayer[] {
  return players.map((p) => ({
    player_id: p.player_id,
    name: p.player_name,
    position: p.position,
    position_slot: p.position_slot,
    overall: p.overall,
    playstyle: p.playstyle,
    attributes: p.attributes,
  }));
}

// ============================================================
// Live data -> EfootballMatchContext
// ============================================================

function buildManagerFromLive(manager: ManagerLibrary | null): EfootballContextManager | null {
  if (!manager) return null;
  return {
    manager_id: manager.id,
    name: manager.name,
    ratings: {
      possession_rating: manager.possession_rating,
      quick_counter_rating: manager.quick_counter_rating,
      long_ball_counter_rating: manager.long_ball_counter_rating,
      out_wide_rating: manager.out_wide_rating,
      long_ball_rating: manager.long_ball_rating,
    },
  };
}

function buildFormationFromLive(formation: TeamFormation | null): EfootballContextFormation | null {
  if (!formation) return null;
  return {
    formation_id: formation.id,
    formation_code: formation.formation_code,
    name: formation.name,
    positions: formation.positions,
    tactical_instructions: formation.tactical_instructions,
  };
}

function buildPlayersFromLive(players: readonly EfootballContextLivePlayer[]): EfootballContextPlayer[] {
  return players.map(({ position_slot, player }) => ({
    player_id: player.id,
    name: player.name,
    position: player.position,
    position_slot,
    overall: player.overall,
    playstyle: player.playstyle,
    attributes: player.attributes,
  }));
}

/** True when a live source actually carries at least one piece of
 * eFootball-relevant data — an empty/all-null live source (a match
 * whose team_id has no formation, no manager, and no assigned players
 * at all) is not meaningfully different from having no live source,
 * so buildEfootballMatchContext treats it as `reason: "no_data"`
 * rather than an "available" context with three empty/null sections. */
function liveSourceHasData(live: EfootballContextLiveSource): boolean {
  return live.formation !== null || live.manager !== null || live.players.length > 0;
}

// ============================================================
// The shared builder
// ============================================================

/**
 * The one shared, server-safe builder spec section 5 asks for.
 * `footballContext` must come from
 * footballMatchContext.ts#readFootballMatchContext (never re-derived
 * or guessed by the caller) — see that function's own header comment
 * for why a legacy NULL football_type must never be treated as
 * eFootball. `sources` must be data the caller already fetched and
 * (for `live`) already knows the caller owns — this function performs
 * no ownership check of its own (see file header comment).
 */
export function buildEfootballMatchContext(
  footballContext: FootballMatchContext | null,
  sources: EfootballContextSources
): EfootballMatchContextResult {
  if (!allowsEfootballContext(footballContext)) {
    return { available: false, reason: footballContext === null ? "unknown_football_type" : "not_efootball" };
  }

  if (sources.snapshot) {
    const { snapshot, players } = sources.snapshot;
    return {
      available: true,
      source: "historical_snapshot",
      players: buildPlayersFromSnapshot(players),
      manager: buildManagerFromSnapshot(snapshot),
      formation: buildFormationFromSnapshot(snapshot),
    };
  }

  if (sources.live && liveSourceHasData(sources.live)) {
    return {
      available: true,
      source: "current_data",
      players: buildPlayersFromLive(sources.live.players),
      manager: buildManagerFromLive(sources.live.manager),
      formation: buildFormationFromLive(sources.live.formation),
    };
  }

  return { available: false, reason: "no_data" };
}
