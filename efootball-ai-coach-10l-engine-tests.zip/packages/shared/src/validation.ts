import { EVENT_TYPES } from "./types.js";
import type { EventCategory, EventSeverity, ConfidenceLevel } from "./types.js";

/**
 * Single source of truth for "is this AI-produced event draft safe to
 * persist" — used by both the video pipeline (processMatchVideo.ts) and
 * the screenshot pipeline (processScreenshot.ts) right after calling out
 * to the AI provider. Nothing the model returns should hit the database
 * without passing through here first: the model can hallucinate an
 * event_type outside the closed vocabulary, return an out-of-range score,
 * or omit a required field, and none of that should silently become a
 * row in `analysis_events`.
 */

const SEVERITIES: EventSeverity[] = [
  "excellent",
  "good",
  "minor_issue",
  "mistake",
  "critical_mistake",
];

const CONFIDENCE_LEVELS: ConfidenceLevel[] = ["confirmed", "likely", "uncertain"];

const CATEGORIES = Object.keys(EVENT_TYPES) as EventCategory[];

export interface ValidationResult {
  valid: boolean;
  errors: string[];
}

function isIntInRange(value: unknown, min: number, max: number): boolean {
  return typeof value === "number" && Number.isInteger(value) && value >= min && value <= max;
}

/**
 * Validates a single draft event returned by an AiProvider. Deliberately
 * takes `Record<string, any>` rather than the strict DetectedEventDraft
 * type — the whole point is that we cannot trust the shape coming back
 * from a model until after this check runs.
 */
export function validateDetectedEventDraft(draft: Record<string, any>): ValidationResult {
  const errors: string[] = [];

  if (!draft || typeof draft !== "object") {
    return { valid: false, errors: ["draft is not an object"] };
  }

  if (!CATEGORIES.includes(draft.category)) {
    errors.push(`invalid category: ${JSON.stringify(draft.category)}`);
  } else if (!EVENT_TYPES[draft.category as EventCategory].includes(draft.event_type)) {
    errors.push(
      `event_type ${JSON.stringify(draft.event_type)} is not in the closed vocabulary for category ${draft.category}`
    );
  }

  if (!SEVERITIES.includes(draft.severity)) {
    errors.push(`invalid severity: ${JSON.stringify(draft.severity)}`);
  }

  if (!CONFIDENCE_LEVELS.includes(draft.confidence_level)) {
    errors.push(`invalid confidence_level: ${JSON.stringify(draft.confidence_level)}`);
  }

  if (draft.decision_score != null && !isIntInRange(draft.decision_score, 0, 100)) {
    errors.push(`decision_score out of range: ${JSON.stringify(draft.decision_score)}`);
  }

  if (draft.confidence != null && !isIntInRange(draft.confidence, 0, 100)) {
    errors.push(`confidence out of range: ${JSON.stringify(draft.confidence)}`);
  }

  if (typeof draft.description !== "string" || draft.description.trim().length === 0) {
    errors.push("description is required and must be a non-empty string");
  }

  return { valid: errors.length === 0, errors };
}

/**
 * Filters a batch of drafts, dropping (and logging) anything invalid
 * rather than throwing — one bad element from the model shouldn't sink
 * an entire match's worth of otherwise-good findings.
 */
export function filterValidDetectedEventDrafts<T extends Record<string, any>>(
  drafts: T[],
  onInvalid?: (draft: T, errors: string[]) => void
): T[] {
  return drafts.filter((draft) => {
    const result = validateDetectedEventDraft(draft);
    if (!result.valid) {
      onInvalid?.(draft, result.errors);
    }
    return result.valid;
  });
}
