// Batch 6A-3 — AI player-card extraction: shared type + semantic
// validation for the draft an AiProvider returns after reading an
// uploaded eFootball player-card image.
//
// This is a DELIBERATELY DIFFERENT shape from PlayerAttributes /
// OUTFIELD_ATTRIBUTE_FIELDS / GOALKEEPER_ATTRIBUTE_FIELDS in
// playerStatistics.ts. Those model a fixed, closed set of match-analysis
// attribute columns (a specific schema migrated in 0006). A player-card
// image's visible attributes vary by card layout/rarity/UI version, and
// this batch's spec explicitly prohibits assuming a fixed list — so
// `attributes` here is intentionally an open Record, mirroring
// public.player_library.attributes (jsonb, no fixed shape — see
// migration 0011_player_library.sql's design notes, which anticipated
// exactly this batch).
//
// HARD RULE (same one enforced throughout playerStatistics.ts): never
// fabricate a value. Anything not visible/legible/certain on the card
// must arrive as null — this file's job is to reject or null out
// anything that doesn't hold up, never to invent a plausible-looking
// replacement.

/** Evidence for a single extracted field, so a future Review/Edit UI can
 * explain where a value came from (or why it's null). Deliberately has
 * no coordinate/bounding-box field — the spec forbids fabricating
 * coordinates the provider doesn't actually return. */
export interface PlayerCardFieldEvidence {
  /** Name of the field this evidence describes, e.g. "overall" or
   * "attributes.finishing". */
  field: string;
  /** Whether the model reports this field as visible on the card at all. */
  visible: boolean;
  /** 0-100 confidence in this specific field, or null if the model didn't
   * provide one. */
  confidence: number | null;
  /** Short free-text note, e.g. "printed under the player portrait". */
  note?: string | null;
}

/** Structured output of AI player-card extraction, before any decision
 * about persisting it to player_library — this batch never writes that
 * table, it only produces and validates this draft (see 6A-3 spec). */
export interface PlayerCardDraft {
  name: string | null;
  position: string | null;
  /** Displayed Overall only — never clamped to an assumed maximum such as
   * 99, and never defaulted to 0 when not visible. */
  overall: number | null;
  playstyle: string | null;
  /** Only attributes actually visible on the card. Keys are whatever the
   * model identified (e.g. "offensive_awareness", "ball_control") — this
   * is intentionally not validated against a closed vocabulary, since a
   * real card may show fields not anticipated here. Values are numbers
   * (a rating), strings (e.g. a qualitative label the card shows instead
   * of a number), or null (present as a field on the card but unreadable). */
  attributes: Record<string, number | string | null>;
  /** Model's own confidence 0-100 in the extraction as a whole — reflects
   * extraction/reading confidence, never certainty about football
   * knowledge (spec: "Confidence must represent extraction confidence"). */
  extraction_confidence: number;
  field_evidence: PlayerCardFieldEvidence[];
}

// ============================================================
// Semantic validation
// ============================================================
//
// Same strategy as validatePlayerStatisticsDraft (playerStatistics.ts):
// per-field checks, a failing field is dropped/nulled (never coerced into
// a guess) and the reason is recorded. Nothing here invents a required
// field that the raw draft didn't include.

export interface PlayerCardValidationResult {
  valid: boolean;
  sanitized: PlayerCardDraft;
  errors: string[];
}

export function isFiniteNumber(v: unknown): v is number {
  return typeof v === "number" && Number.isFinite(v);
}

/** Exported (Batch 6A-4) so packages/shared/src/playerLibrary.ts's
 * validatePlayerLibraryInput can reuse the exact same field-level rule
 * instead of duplicating it — a Player Library entry's name/position/
 * playstyle follow the identical NULL/UNKNOWN contract as a card draft's. */
export function sanitizeNullableString(
  raw: unknown,
  field: string,
  errors: string[]
): string | null {
  if (raw === undefined || raw === null) return null;
  if (typeof raw !== "string") {
    errors.push(`${field}: expected string or null, got ${JSON.stringify(raw)} — discarded to null`);
    return null;
  }
  const trimmed = raw.trim();
  return trimmed.length > 0 ? trimmed : null;
}

/** overall must be a non-negative integer, or null. No artificial upper
 * bound (spec: "Do not impose an artificial maximum such as 99") — the
 * displayed Overall is whatever the card actually shows. Exported
 * (Batch 6A-4) — see sanitizeNullableString's note above; Player
 * Library's `overall` column follows this identical rule. */
export function sanitizeOverall(raw: unknown, errors: string[]): number | null {
  if (raw === undefined || raw === null) return null;
  if (!isFiniteNumber(raw) || !Number.isInteger(raw) || raw < 0) {
    errors.push(`overall: invalid value ${JSON.stringify(raw)} — discarded to null`);
    return null;
  }
  return raw;
}

/** Attribute values may be a finite number, a non-empty string, or null.
 * Anything else (NaN, boolean, object, array, empty string) is dropped —
 * the key itself is preserved with a null value rather than silently
 * disappearing, so the caller still knows this field was reported as
 * present-but-unreadable rather than never mentioned at all. Exported
 * (Batch 6A-4) — see sanitizeNullableString's note above; Player
 * Library's `attributes` jsonb column has the identical open shape. */
export function sanitizeAttributes(raw: unknown, errors: string[]): Record<string, number | string | null> {
  const sanitized: Record<string, number | string | null> = {};
  if (raw === undefined || raw === null) return sanitized;
  if (typeof raw !== "object" || Array.isArray(raw)) {
    errors.push(`attributes: expected an object, got ${JSON.stringify(raw)} — discarded entirely`);
    return sanitized;
  }

  for (const [key, value] of Object.entries(raw as Record<string, unknown>)) {
    if (value === null || value === undefined) {
      sanitized[key] = null;
      continue;
    }
    if (typeof value === "number") {
      if (!Number.isFinite(value)) {
        errors.push(`attributes.${key}: NaN/Infinity discarded to null`);
        sanitized[key] = null;
        continue;
      }
      sanitized[key] = value;
      continue;
    }
    if (typeof value === "string") {
      const trimmed = value.trim();
      sanitized[key] = trimmed.length > 0 ? trimmed : null;
      continue;
    }
    errors.push(`attributes.${key}: invalid type ${JSON.stringify(value)} discarded to null`);
    sanitized[key] = null;
  }

  return sanitized;
}

function sanitizeConfidence(raw: unknown, field: string, errors: string[]): number {
  if (!isFiniteNumber(raw) || raw < 0 || raw > 100) {
    errors.push(`${field}: invalid confidence ${JSON.stringify(raw)} — defaulted to 0 (never assumed high)`);
    return 0;
  }
  return raw;
}

function sanitizeNullableConfidence(raw: unknown, field: string, errors: string[]): number | null {
  if (raw === undefined || raw === null) return null;
  if (!isFiniteNumber(raw) || raw < 0 || raw > 100) {
    errors.push(`${field}: invalid confidence ${JSON.stringify(raw)} — discarded to null`);
    return null;
  }
  return raw;
}

function sanitizeFieldEvidence(raw: unknown, errors: string[]): PlayerCardFieldEvidence[] {
  if (raw === undefined || raw === null) return [];
  if (!Array.isArray(raw)) {
    errors.push(`field_evidence: expected an array, got ${JSON.stringify(raw)} — discarded entirely`);
    return [];
  }

  const sanitized: PlayerCardFieldEvidence[] = [];
  raw.forEach((entry, idx) => {
    if (!entry || typeof entry !== "object" || Array.isArray(entry)) {
      errors.push(`field_evidence[${idx}]: not an object — dropped`);
      return;
    }
    const e = entry as Record<string, unknown>;
    if (typeof e.field !== "string" || e.field.trim().length === 0) {
      errors.push(`field_evidence[${idx}]: missing/invalid "field" — dropped`);
      return;
    }
    if (typeof e.visible !== "boolean") {
      errors.push(`field_evidence[${idx}]: missing/invalid "visible" — dropped`);
      return;
    }
    sanitized.push({
      field: e.field,
      visible: e.visible,
      confidence: sanitizeNullableConfidence(e.confidence, `field_evidence[${idx}].confidence`, errors),
      note: typeof e.note === "string" && e.note.trim().length > 0 ? e.note.trim() : null,
    });
  });

  return sanitized;
}

/**
 * Validates a raw PlayerCardDraft-shaped object returned by an AiProvider.
 * Deliberately takes `Record<string, unknown>` rather than the strict
 * PlayerCardDraft type — the whole point is that nothing coming back from
 * a model can be trusted until after this check runs (same convention as
 * validateDetectedEventDraft in validation.ts).
 *
 * Never throws — malformed input always produces a well-formed, mostly-
 * null PlayerCardDraft plus a non-empty `errors` list. `valid` is false
 * only when the draft was not extraction-worthy at all (not an object).
 * Callers (the extraction Edge Function) should still return `sanitized`
 * to the caller either way — a partially-malformed AI response with a
 * few discarded fields is still useful to a human reviewer, just never
 * silently "fixed" into a guess.
 */
export function validatePlayerCardDraft(draft: unknown): PlayerCardValidationResult {
  const errors: string[] = [];

  if (!draft || typeof draft !== "object" || Array.isArray(draft)) {
    return {
      valid: false,
      errors: ["draft is not an object"],
      sanitized: {
        name: null,
        position: null,
        overall: null,
        playstyle: null,
        attributes: {},
        extraction_confidence: 0,
        field_evidence: [],
      },
    };
  }

  const d = draft as Record<string, unknown>;

  const sanitized: PlayerCardDraft = {
    name: sanitizeNullableString(d.name, "name", errors),
    position: sanitizeNullableString(d.position, "position", errors),
    overall: sanitizeOverall(d.overall, errors),
    playstyle: sanitizeNullableString(d.playstyle, "playstyle", errors),
    attributes: sanitizeAttributes(d.attributes, errors),
    extraction_confidence: sanitizeConfidence(d.extraction_confidence, "extraction_confidence", errors),
    field_evidence: sanitizeFieldEvidence(d.field_evidence, errors),
  };

  return { valid: true, sanitized, errors };
}
