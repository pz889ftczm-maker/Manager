// Batch 8D — Formation Presets. Shared type + pure validation for
// public.team_formation_preset_players (migration
// 0024_team_formation_presets.sql). Mirrors
// teamFormationPlayers.ts's TeamFormationPlayer/
// validateTeamFormationPlayerInput almost exactly — "player X occupies
// slot Y" — but scoped to a preset_id instead of a formation_id. No
// player name/stats/attributes/coordinate fields here (those stay on
// player_library and team_formation_presets.positions respectively; a
// reader joins through player_id/preset_id to get them). No starting-
// XI/bench/historical-match fields either.
//
// UNLIKE teamFormationPlayers.ts, this file does NOT export a
// planFormationSlotAssignment-style planner: a preset's player
// assignments are only ever written in bulk, once, when the preset is
// created (spec section 10 — "save current Formation as preset" copies
// a complete, already-non-colliding set of assignments in one go) —
// there is no interactive drag-and-drop re-slotting UI for presets
// (spec section 13 explicitly excludes that), so there is no
// "move player P into slot S, displacing whoever's there" operation to
// plan for on this table the way there is for team_formation_players.

import { isUniqueViolation } from "./playerLibrary.js";

export { isUniqueViolation };

const UUID_SHAPE = /^[0-9a-f]{8}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{12}$/i;

function isUuidShaped(value: unknown): value is string {
  return typeof value === "string" && UUID_SHAPE.test(value.trim());
}

/**
 * Represents one row of public.team_formation_preset_players (migration
 * 0024_team_formation_presets.sql) — "player X is assigned to slot Y in
 * preset Z", and nothing else.
 */
export interface TeamFormationPresetPlayer {
  id: string;
  preset_id: string;
  player_id: string;
  /** Stable slot identifier expected to match one of the `id`s inside
   * the owning preset's team_formation_presets.positions (e.g. "gk",
   * "cb1") — never enforced as a foreign key against that JSONB, same
   * convention as team_formation_players.position_slot. */
  position_slot: string;
  created_at: string;
  updated_at: string;
}

/** Shape of what a caller submits to persist a
 * team_formation_preset_players row — mirrors the columns migration
 * 0024 actually has, minus server-controlled columns (id/created_at/
 * updated_at). Every field is required. */
export interface TeamFormationPresetPlayerInput {
  preset_id: string;
  player_id: string;
  position_slot: string;
}

export interface TeamFormationPresetPlayerValidationResult {
  valid: boolean;
  sanitized: TeamFormationPresetPlayerInput;
  errors: string[];
}

function sanitizeUuid(raw: unknown, field: string, errors: string[]): string {
  if (!isUuidShaped(raw)) {
    errors.push(`${field}: expected a uuid, got ${JSON.stringify(raw)}`);
    return "";
  }
  return (raw as string).trim();
}

function sanitizePositionSlot(raw: unknown, errors: string[]): string {
  if (typeof raw !== "string" || raw.trim().length === 0) {
    errors.push(`position_slot: expected a non-empty string, got ${JSON.stringify(raw)}`);
    return "";
  }
  return raw.trim();
}

/**
 * Validates a user-submitted TeamFormationPresetPlayerInput-shaped
 * object before it's persisted to public.team_formation_preset_players.
 * Same never-throws, never-fabricate-a-value convention as
 * validateTeamFormationPlayerInput: a missing/malformed uuid is
 * reported as an error and left as an empty string — NEVER coerced
 * into a made-up id. Never checks OWNERSHIP (does this preset/player
 * actually belong to the caller) — that's RLS's job (migration 0024),
 * not this pure, dependency-free module's.
 */
export function validateTeamFormationPresetPlayerInput(input: unknown): TeamFormationPresetPlayerValidationResult {
  const errors: string[] = [];
  const empty: TeamFormationPresetPlayerInput = { preset_id: "", player_id: "", position_slot: "" };

  if (!input || typeof input !== "object" || Array.isArray(input)) {
    return { valid: false, errors: ["input is not an object"], sanitized: empty };
  }

  const d = input as Record<string, unknown>;

  const sanitized: TeamFormationPresetPlayerInput = {
    preset_id: sanitizeUuid(d.preset_id, "preset_id", errors),
    player_id: sanitizeUuid(d.player_id, "player_id", errors),
    position_slot: sanitizePositionSlot(d.position_slot, errors),
  };

  return { valid: errors.length === 0, sanitized, errors };
}

// ============================================================
// Duplicate-assignment / duplicate-slot handling
// ============================================================
//
// public.team_formation_preset_players_preset_player_uniq and
// public.team_formation_preset_players_preset_slot_uniq (both from
// migration 0024) are plain unique constraints — Postgres enforces
// them; nothing here re-implements that enforcement. These let a
// caller recognize that a failed insert failed BECAUSE of one of these
// exact constraints rather than some other error — same convention as
// isDuplicateFormationPlayer/isDuplicateFormationSlot
// (teamFormationPlayers.ts).

/** The exact name of the unique constraint from migration 0024 — kept
 * as one named constant so callers can't drift apart if it's ever
 * renamed. */
export const TEAM_FORMATION_PRESET_PLAYER_UNIQUE_CONSTRAINT = "team_formation_preset_players_preset_player_uniq";

/** True when `err` is the "this player is already assigned in this
 * preset" unique violation, as opposed to some other/unexpected
 * error. */
export function isDuplicateFormationPresetPlayer(err: unknown): boolean {
  return isUniqueViolation(err, TEAM_FORMATION_PRESET_PLAYER_UNIQUE_CONSTRAINT);
}

/** The exact name of the unique constraint from migration 0024 — kept
 * as one named constant, same convention as
 * TEAM_FORMATION_PRESET_PLAYER_UNIQUE_CONSTRAINT above. */
export const TEAM_FORMATION_PRESET_PLAYER_SLOT_UNIQUE_CONSTRAINT = "team_formation_preset_players_preset_slot_uniq";

/** True when `err` is the "this slot is already occupied in this
 * preset" unique violation, as opposed to some other/unexpected
 * error. */
export function isDuplicateFormationPresetSlot(err: unknown): boolean {
  return isUniqueViolation(err, TEAM_FORMATION_PRESET_PLAYER_SLOT_UNIQUE_CONSTRAINT);
}
