// Batch 5 (Parts A/C/D) — shared, server-authoritative rules for what an
// uploaded file is allowed to be, and how to turn one into a SAFE storage
// object path. Used by:
//   - apps/web/src/routes/Analyze.tsx for early client-side feedback
//     (never the only enforcement layer — everything here is re-checked
//     server-side)
//   - apps/worker/src/jobs/processMatchVideo.ts / processScreenshot.ts to
//     re-check the actual downloaded bytes before ffmpeg/the AI provider
//     ever touch them
//
// supabase/functions/analysis-enqueue (Deno) duplicates the magic-byte
// signatures and size constants inline instead of importing this file —
// Edge Functions can't import a Node workspace package, the same
// constraint already documented at the top of coach-chat/index.ts and
// clip-request/index.ts. Keep the two in sync if the allowed formats or
// limits ever change.
//
// Deliberately written with no Node-only APIs (no `Buffer`, no
// `process.env`) so this module works unmodified in both the worker
// (Node) and the web app (browser, via Vite).

export type UploadKind = "image" | "video";

export interface DetectedFileType {
  kind: UploadKind;
  mimeType: string;
  extension: string;
}

// ---- Size limits ----
// Defaults only — every real call site should pass the actual configured
// value (MAX_VIDEO_UPLOAD_MB / MAX_IMAGE_UPLOAD_MB env vars) rather than
// relying on these; kept here so there's always a sane, documented
// fallback if a caller doesn't.
export const DEFAULT_MAX_VIDEO_MB = 500;
export const DEFAULT_MAX_IMAGE_MB = 15;
export const MAX_FILENAME_LENGTH = 180; // generous but bounded — Part C

// ---- Magic-byte signatures ----
// Deliberately NOT filename-extension or Content-Type based (Part A: "Do
// not rely only on filename extension" / "Never trust only the
// browser-provided MIME type") — these inspect the actual leading bytes
// of the uploaded object.

function bytesStartWith(bytes: Uint8Array, offset: number, sequence: number[]): boolean {
  if (bytes.length < offset + sequence.length) return false;
  for (let i = 0; i < sequence.length; i++) {
    if (bytes[offset + i] !== sequence[i]) return false;
  }
  return true;
}

function readAscii(bytes: Uint8Array, offset: number, length: number): string {
  if (bytes.length < offset + length) return "";
  let out = "";
  for (let i = 0; i < length; i++) out += String.fromCharCode(bytes[offset + i]);
  return out;
}

/**
 * Sniffs the real file type from its leading bytes. A few KB of prefix is
 * always enough for every signature below — callers should fetch/read
 * only that much rather than the whole file (see analysis-enqueue's
 * Range-request fetch for the Deno-side equivalent).
 */
export function sniffFileType(bytes: Uint8Array): DetectedFileType | null {
  // JPEG: FF D8 FF
  if (bytesStartWith(bytes, 0, [0xff, 0xd8, 0xff])) {
    return { kind: "image", mimeType: "image/jpeg", extension: "jpg" };
  }
  // PNG: 89 50 4E 47 0D 0A 1A 0A
  if (bytesStartWith(bytes, 0, [0x89, 0x50, 0x4e, 0x47, 0x0d, 0x0a, 0x1a, 0x0a])) {
    return { kind: "image", mimeType: "image/png", extension: "png" };
  }
  // WEBP: 'RIFF' .... 'WEBP'
  if (readAscii(bytes, 0, 4) === "RIFF" && readAscii(bytes, 8, 4) === "WEBP") {
    return { kind: "image", mimeType: "image/webp", extension: "webp" };
  }
  // WEBM (and other Matroska containers): EBML header 1A 45 DF A3
  if (bytesStartWith(bytes, 0, [0x1a, 0x45, 0xdf, 0xa3])) {
    return { kind: "video", mimeType: "video/webm", extension: "webm" };
  }
  // MP4 / MOV (ISO base media file format): 'ftyp' box at offset 4. Both
  // share this container; the brand code at offset 8 tells them apart.
  if (readAscii(bytes, 4, 4) === "ftyp") {
    const brand = readAscii(bytes, 8, 4).trim().toLowerCase();
    if (brand === "qt") {
      return { kind: "video", mimeType: "video/quicktime", extension: "mov" };
    }
    return { kind: "video", mimeType: "video/mp4", extension: "mp4" };
  }
  return null;
}

export interface ValidateUploadOptions {
  expectedKind: UploadKind;
  sizeBytes: number;
  maxImageMb?: number;
  maxVideoMb?: number;
  /** Leading bytes of the file — a few KB is enough. */
  headBytes: Uint8Array;
}

export interface ValidateUploadResult {
  valid: boolean;
  errors: string[];
  detected: DetectedFileType | null;
}

/** Single source of truth for "is this upload safe to hand to the worker
 * queue" (Part A/C). Server-side callers (analysis-enqueue,
 * processMatchVideo/processScreenshot) must reject anything that fails
 * this rather than letting it reach ffmpeg or the AI provider. */
export function validateUpload(opts: ValidateUploadOptions): ValidateUploadResult {
  const errors: string[] = [];
  const maxImageMb = opts.maxImageMb ?? DEFAULT_MAX_IMAGE_MB;
  const maxVideoMb = opts.maxVideoMb ?? DEFAULT_MAX_VIDEO_MB;

  const detected = sniffFileType(opts.headBytes);
  if (!detected) {
    errors.push("Unrecognized file type — the file's contents don't match any supported image or video format.");
  } else if (detected.kind !== opts.expectedKind) {
    errors.push(
      `File contents are a ${detected.kind} (${detected.mimeType}), which doesn't match the expected ${opts.expectedKind} upload mode.`
    );
  }

  const maxBytes = (opts.expectedKind === "video" ? maxVideoMb : maxImageMb) * 1024 * 1024;
  if (opts.sizeBytes <= 0) {
    errors.push("File is empty.");
  } else if (opts.sizeBytes > maxBytes) {
    errors.push(
      `File is ${(opts.sizeBytes / (1024 * 1024)).toFixed(1)}MB, which exceeds the ${
        opts.expectedKind === "video" ? maxVideoMb : maxImageMb
      }MB limit for ${opts.expectedKind} uploads.`
    );
  }

  return { valid: errors.length === 0, errors, detected };
}

// ---- Safe filenames / storage paths (Part D) ----

/** Strips anything that isn't a conservative safe character and bounds
 * the length — used only for the human-readable filename kept in
 * media.original_filename (display only, NEVER part of a storage path). */
export function sanitizeDisplayFilename(name: string): string {
  const trimmed = (name || "upload").slice(0, MAX_FILENAME_LENGTH);
  const cleaned = trimmed.replace(/[/\\\u0000-\u001f]/g, "_").trim();
  return cleaned.length > 0 ? cleaned : "upload";
}

/**
 * Builds the actual storage object path. Deliberately does NOT use any
 * part of the user-supplied filename — only a caller-provided random id
 * and an extension drawn from the closed allowlist in sniffFileType/
 * guessExtensionFromMimeOrName — so there is no way for a crafted
 * filename (`../../x`, embedded slashes, absurd length, control
 * characters, etc.) to ever reach a storage key (Part D: "never allow
 * `../`, path traversal, or equivalent manipulation").
 * `{user_id}/{match_id}/{random}.{ext}` matches the existing bucket
 * convention (0002_rls.sql) so storage RLS continues to apply unmodified.
 */
export function buildSafeStoragePath(userId: string, matchId: string, extension: string, randomId: string): string {
  const safeExt = /^[a-z0-9]{1,5}$/i.test(extension) ? extension.toLowerCase() : "bin";
  const safeId = /^[a-z0-9-]{1,64}$/i.test(randomId) ? randomId : "upload";
  return `${userId}/${matchId}/${safeId}.${safeExt}`;
}

/** Extension implied by the browser-reported File.type / File.name — used
 * only for the CLIENT-SIDE pre-upload accept check and to pick a storage
 * extension before the bytes exist to sniff. This is explicitly NOT
 * trusted as the real validation; that's sniffFileType against the
 * uploaded bytes (see validateUpload), re-run server-side by
 * analysis-enqueue and again by the worker. */
export function guessExtensionFromMimeOrName(mimeType: string, filename: string): string {
  const byMime: Record<string, string> = {
    "image/jpeg": "jpg",
    "image/jpg": "jpg",
    "image/png": "png",
    "image/webp": "webp",
    "video/mp4": "mp4",
    "video/quicktime": "mov",
    "video/webm": "webm",
  };
  if (byMime[mimeType]) return byMime[mimeType];
  const match = /\.([a-z0-9]{1,5})$/i.exec(filename);
  return match ? match[1].toLowerCase() : "bin";
}

/**
 * Batch 6A-2 — same safety reasoning as buildSafeStoragePath above (never
 * derived from the user-supplied filename, closed extension allowlist,
 * random id), but for the player-card library: `{user_id}/{random}.{ext}`
 * with no match_id segment, since a library entry isn't scoped to a match
 * (see supabase/migrations/0011_player_library.sql /
 * 0012_player_library_storage.sql). Images only — JPEG/PNG/WEBP, enforced
 * by the caller via sniffFileType/validateUpload before this is called.
 */
export function buildSafePlayerCardStoragePath(userId: string, extension: string, randomId: string): string {
  const safeExt = /^[a-z0-9]{1,5}$/i.test(extension) ? extension.toLowerCase() : "bin";
  const safeId = /^[a-z0-9-]{1,64}$/i.test(randomId) ? randomId : "upload";
  return `${userId}/${safeId}.${safeExt}`;
}

/**
 * Batch 6B-2 — same safety reasoning as buildSafePlayerCardStoragePath
 * above (never derived from the user-supplied filename, closed
 * extension allowlist, random id), but for the manager library:
 * `{user_id}/{random}.{ext}` with no match_id segment, since a library
 * entry isn't scoped to a match (see
 * supabase/migrations/0014_manager_library.sql /
 * 0015_manager_images_storage.sql). Images only — JPEG/PNG/WEBP,
 * enforced by the caller via sniffFileType/validateUpload before this is
 * called. Kept as its own named function (rather than reusing
 * buildSafePlayerCardStoragePath directly) so the manager-images bucket
 * can diverge from the player-cards path shape later without a rename
 * that would be confusing at call sites — same reasoning that already
 * separates buildSafeStoragePath from buildSafePlayerCardStoragePath.
 */
export function buildSafeManagerImageStoragePath(userId: string, extension: string, randomId: string): string {
  const safeExt = /^[a-z0-9]{1,5}$/i.test(extension) ? extension.toLowerCase() : "bin";
  const safeId = /^[a-z0-9-]{1,64}$/i.test(randomId) ? randomId : "upload";
  return `${userId}/${safeId}.${safeExt}`;
}

/**
 * Batch 7B — same safety reasoning as buildSafePlayerCardStoragePath /
 * buildSafeManagerImageStoragePath above (never derived from the
 * user-supplied filename, closed extension allowlist, random id), but
 * for the team library: `{user_id}/{random}.{ext}` with no match_id
 * segment, since a library entry isn't scoped to a match (see
 * supabase/migrations/0016_team_library.sql /
 * 0017_team_images_storage.sql / 0018_team_library_image_path.sql).
 * Images only — JPEG/PNG/WEBP, enforced by the caller via
 * sniffFileType/validateUpload before this is called. Kept as its own
 * named function rather than reusing buildSafeManagerImageStoragePath
 * directly, same reasoning that already separates that function from
 * buildSafePlayerCardStoragePath — each bucket's path shape can diverge
 * later without a confusing rename at call sites.
 */
export function buildSafeTeamImageStoragePath(userId: string, extension: string, randomId: string): string {
  const safeExt = /^[a-z0-9]{1,5}$/i.test(extension) ? extension.toLowerCase() : "bin";
  const safeId = /^[a-z0-9-]{1,64}$/i.test(randomId) ? randomId : "upload";
  return `${userId}/${safeId}.${safeExt}`;
}

/**
 * Batch 6A-4 — whether `path` sits under `userId`'s own storage prefix
 * (`{userId}/...`), the same ownership convention every private bucket
 * in this repo uses (see buildSafeStoragePath / buildSafePlayerCardStoragePath
 * above, and the storage RLS policies in 0002_rls.sql /
 * 0012_player_library_storage.sql). An equivalent inline
 * `path.startsWith(userId + "/")` check already exists at a couple of
 * call sites (player-card-extract/index.ts, playerCardStorage.ts's
 * deletePlayerCardImage) — this is that same check pulled out as one
 * named, unit-testable, reusable function for the player-library-save
 * Edge Function (spec section 8) to use without a further inline copy.
 * Requires an exact `{userId}/` segment match — a merely similar-looking
 * prefix (e.g. a different user id that happens to start with the same
 * characters) is never treated as owned.
 */
export function isPathOwnedByUser(path: string | null | undefined, userId: string): boolean {
  if (!path || !userId) return false;
  return path.startsWith(`${userId}/`);
}
