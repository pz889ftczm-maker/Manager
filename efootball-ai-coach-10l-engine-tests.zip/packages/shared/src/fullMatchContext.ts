// Batch 10I — Full Match Context ONLY. A shared, evidence-first
// aggregate over an ENTIRE match's already-built moments, for moment
// analysis — WITHOUT a new database table, a new event system, an AI
// call, or any change to any of the 10A–10H files it composes.
//
// REUSE, NOT REPLACEMENT / NO DUPLICATE MODELS (spec — "reuse
// UnifiedFootballEvent, TacticalPosition, PassingLane/Space,
// DecisionQuality, MomentExplanation"; "no duplicate model
// definitions"):
//   * Per-event data: still footballEvent.ts's own UnifiedFootballEvent
//     (10D) — this file reads and orders the exact events the caller
//     already built, never re-deriving one from a raw row.
//   * Per-moment explanation (WHAT/WHY/better option/WHY better/
//     actionable improvement/confidence/evidence, plus its own
//     TacticalPosition/PassingLane/Space/DecisionQuality composition):
//     still momentExplanation.ts's own buildMomentExplanationFromUnifiedEvent
//     (10H) — called once per event, exactly the same way 10H's own
//     tests call it. This file does NOT redefine TacticalPosition,
//     PassingLane, Space, or DecisionQuality anywhere — it reaches them
//     only transitively, through MomentExplanation, exactly as 10H
//     already composes them.
//   * Roster/team context: still efootballMatchContext.ts's own
//     EfootballMatchContextResult / realFootballMatchContext.ts's own
//     RealFootballMatchContextResult — attached verbatim, caller-
//     supplied (same "caller already built it" convention as
//     momentExplanation.ts's own tactical/spatial context parameters).
//     This file never re-reads a snapshot or a live Team/Formation/
//     Player row itself.
//   * football_type/team_size: still footballMatchContext.ts's own
//     FootballMatchContext — never supplied independently (same
//     convention as every other 10-series file).
//
// PRESERVES HISTORICAL SNAPSHOT PRECEDENCE (spec): this file never
// reads a MatchSnapshot or a live Team/Formation/Player row itself —
// the EfootballMatchContextResult/RealFootballMatchContextResult it is
// handed were already built by buildEfootballMatchContext/
// buildRealFootballMatchContext (9B/9C+10B/10C), which already apply
// "snapshot wins over live data when a snapshot exists". Nothing here
// re-derives or second-guesses that precedence.
//
// PRESERVES EFOOTBALL / REAL FOOTBALL SEPARATION (spec) — WITHOUT
// cross-type branching in this file's own logic: `efootball`/
// `real_football` below are gated by footballMatchContext.ts's own
// allowsEfootballContext/allowsRealFootballContext guards — the single
// existing source of truth for "which football-type-specific data is
// allowed for this match" (see that file's own doc comments — "a later
// phase gates any [X]-specific data/behavior on this rather than
// re-deriving the same rule inline"). This file calls those guards; it
// does not write its own `football_type === "efootball"` comparison
// anywhere.
//
// CHRONOLOGICAL ORDERING, NEVER FABRICATED (spec — "preserve
// chronological event/timestamp ordering"): moments are sorted by each
// event's own `timestamp_seconds`, ascending. An event with no known
// timestamp is never assigned a guessed position — it sorts after every
// timestamped event (never dropped, never given a fabricated time), and
// ties/unknowns otherwise keep their original relative order (a stable
// sort — no invented tie-breaker).
//
// RELEVANT EVENTS AROUND EACH MOMENT, NEVER FABRICATED (spec —
// "include relevant events around each moment"): a moment's
// `surrounding_events` are exactly the OTHER events in this same match
// whose own `timestamp_seconds` falls inside THIS event's own
// `context_start_seconds`/`context_end_seconds` window — a window
// footballEvent.ts's UnifiedFootballEvent already carries from the
// underlying analysis_events row (Batch 3's own before/decision/after-
// frame windowing), never a separately invented radius. A moment whose
// own window is incomplete (either bound null) gets an empty
// `surrounding_events` array — never a guessed window.
//
// INSUFFICIENT DATA -> NULL/EMPTY (spec): no events -> `moments: []`;
// no footballContext -> `football_type`/`team_size` null; no
// eFootball/Real-Football context supplied (or the guard above
// disallows it) -> that field is null. Never a default/backfilled
// value anywhere in this file.
//
// NO ZOD DEPENDENCY, NO I/O, NO AI CALLS (same convention as every
// other file in this package): small hand-written pure functions only.
//
// NO SCOPE CREEP (explicitly out of scope for 10I, left to a later
// batch): no AI calls, no analysis-pipeline wiring, no new database
// table/migration, no Coach UI. This file only aggregates already-
// existing, already-evidenced per-event data into one match-level read
// shape — no AI call, no new table, no pipeline wiring beyond this
// (see section 3 below, added by Batch 10J-1, for this file's own
// small, additive part of that batch's persistence-reconstruction
// scope); 10J-2+/10K+ are NOT implemented here.

import type { FootballType, FootballMatchContext } from "./footballMatchContext.js";
import { allowsEfootballContext, allowsRealFootballContext } from "./footballMatchContext.js";
import type { UnifiedFootballEvent } from "./footballEvent.js";
import type { EfootballMatchContextResult } from "./efootballMatchContext.js";
import type { RealFootballMatchContextResult } from "./realFootballMatchContext.js";
import type { MomentExplanation, MomentExplanationContext } from "./momentExplanation.js";
import { buildMomentExplanationFromUnifiedEvent } from "./momentExplanation.js";

// ============================================================
// 1. Shape
// ============================================================

/**
 * One moment in chronological context: the event itself (10D), its full
 * evidence-first explanation (10H — itself already composing 10E/10F/
 * 10G), and the other events from this same match that fall inside this
 * event's own context window. No new per-event fields are introduced
 * here — this is purely a grouping of already-reused shapes.
 */
export interface MatchMoment {
  event: UnifiedFootballEvent;
  explanation: MomentExplanation;
  /** Other UnifiedFootballEvent rows (10D, unmodified) whose own
   * `timestamp_seconds` falls inside `event.context_start_seconds`..
   * `event.context_end_seconds` — never `event` itself, never a
   * fabricated/guessed window. Empty when that window is incomplete. */
  surrounding_events: UnifiedFootballEvent[];
}

/**
 * The complete, evidence-first context for one match — every moment
 * (10D+10H, in chronological order) plus the already-built roster/team
 * context (9B/9C+10B/10C) for whichever football type this match
 * actually is. Every field is independently null/empty exactly when the
 * caller did not supply, or the match's own football_type does not
 * allow, the corresponding evidence.
 */
export interface FullMatchContext {
  football_type: FootballType | null;
  match_id: string | null;
  team_size: number | null;
  /** Null whenever `footballContext` does not positively confirm
   * football_type = "efootball" (allowsEfootballContext) — including
   * when it does but the caller supplied nothing. */
  efootball: EfootballMatchContextResult | null;
  /** Real Football mirror of `efootball` above (allowsRealFootballContext) — never both non-null for the same match. */
  real_football: RealFootballMatchContextResult | null;
  /** Every moment for this match, ordered by `event.timestamp_seconds`
   * ascending (nulls last) — see file header, "chronological ordering,
   * never fabricated". Empty when no events were supplied. */
  moments: MatchMoment[];
}

// ============================================================
// 2. Already-built events (+ context) -> FullMatchContext
// ============================================================

/** Ascending by `timestamp_seconds`, nulls sorted last — a stable sort
 * (Array.prototype.sort has been spec-guaranteed stable since ES2019),
 * so events with equal or unknown timestamps keep their original
 * relative order rather than an invented tie-breaker.
 *
 * Exported (Batch 10J-1) so momentExplanationPersistence.ts's own
 * reconstruction path (buildFullMatchContextFromPersistedMoments below)
 * can reuse the exact same ordering rather than duplicating it — no
 * change to this function's own behavior. */
export function sortEventsChronologically(
  events: readonly UnifiedFootballEvent[]
): UnifiedFootballEvent[] {
  return [...events].sort((a, b) => {
    if (a.timestamp_seconds === null && b.timestamp_seconds === null) return 0;
    if (a.timestamp_seconds === null) return 1;
    if (b.timestamp_seconds === null) return -1;
    return a.timestamp_seconds - b.timestamp_seconds;
  });
}

/** The other events (from the SAME already-ordered list) whose own
 * `timestamp_seconds` falls inside `event`'s own context window. Never
 * invents a window: an event with either bound null yields no
 * surrounding events at all.
 *
 * Exported (Batch 10J-1) for the same reuse reason as
 * sortEventsChronologically above — no change to this function's own
 * behavior. */
export function surroundingEventsFor(
  event: UnifiedFootballEvent,
  allEvents: readonly UnifiedFootballEvent[]
): UnifiedFootballEvent[] {
  const start = event.context_start_seconds;
  const end = event.context_end_seconds;
  if (start === null || end === null) return [];

  return allEvents.filter((other) => {
    if (other.id === event.id) return false;
    const t = other.timestamp_seconds;
    return t !== null && t >= start && t <= end;
  });
}

/** Caller-supplied inputs this file composes — every field is
 * already-built data (never a matchId/query for this file to go fetch
 * itself), same "pure builder over already-fetched data" convention as
 * every other 10-series file. */
export interface FullMatchContextInput {
  /** Resolved server-side by the caller — never re-derived from
   * `events`. Null only for a match this file was never told the id
   * of. */
  matchId: string | null;
  /** Still footballMatchContext.ts's own FootballMatchContext — never
   * supplied independently. Null for an unknown/legacy football_type. */
  footballContext: FootballMatchContext | null;
  /** Already built by buildEfootballMatchContext (9B/10B) — attached
   * verbatim. Ignored (see `allowsEfootballContext` in file header)
   * unless `footballContext` positively confirms "efootball". */
  efootball?: EfootballMatchContextResult | null;
  /** Already built by buildRealFootballMatchContext (9C/10C) — Real
   * Football mirror of `efootball` above. */
  realFootball?: RealFootballMatchContextResult | null;
  /** Every UnifiedFootballEvent (10D) for this match, in any order —
   * this function sorts them, never trusts the caller's own order. */
  events: readonly UnifiedFootballEvent[];
  /** Per-event tactical/spatial context (10E/10F), keyed by
   * `UnifiedFootballEvent.id` — passed straight through to
   * buildMomentExplanationFromUnifiedEvent (10H) unchanged; an event
   * with no matching key gets no tactical/spatial context, exactly as
   * calling 10H's own builder with no context would. */
  momentContext?: Readonly<Record<string, MomentExplanationContext>>;
}

/**
 * Builds ONE FullMatchContext from already-built UnifiedFootballEvent
 * rows (10D) plus already-built roster/team context (9B/9C/10B/10C),
 * reusing buildMomentExplanationFromUnifiedEvent (10H) — which itself
 * already reuses 10E/10F/10G-1/10G-2 — for every moment, rather than
 * re-deriving any of that here.
 */
export function buildFullMatchContext(input: FullMatchContextInput): FullMatchContext {
  const orderedEvents = sortEventsChronologically(input.events);

  const moments: MatchMoment[] = orderedEvents.map((event) => ({
    event,
    explanation: buildMomentExplanationFromUnifiedEvent(event, input.momentContext?.[event.id] ?? {}),
    surrounding_events: surroundingEventsFor(event, orderedEvents),
  }));

  return {
    football_type: input.footballContext?.football_type ?? null,
    match_id: input.matchId,
    team_size: input.footballContext?.team_size ?? null,
    efootball: allowsEfootballContext(input.footballContext) ? input.efootball ?? null : null,
    real_football: allowsRealFootballContext(input.footballContext) ? input.realFootball ?? null : null,
    moments,
  };
}

// ============================================================
// 3. Batch 10J-1 — already-persisted MomentExplanation rows ->
//    FullMatchContext (NO new FullMatchContext table; NO re-derivation)
// ============================================================
//
// Spec (10J-1): "Do not create a separate FullMatchContext table;
// reconstruct FullMatchContext from existing persisted match/event/
// context data plus persisted MomentExplanation rows." /
// "never re-derive historical explanations".
//
// buildFullMatchContextFromPersistedMoments below is the read-path
// mirror of buildFullMatchContext above: same FullMatchContext/
// MatchMoment shapes, same sortEventsChronologically/
// surroundingEventsFor ordering — but instead of calling
// buildMomentExplanationFromUnifiedEvent (10H) to build a fresh
// explanation for every event, it looks up an already-persisted one
// (typically via momentExplanationPersistence.ts's own
// momentExplanationsByEventId over that match's public.
// moment_explanations rows, 10J-1) for each event by `event_id`. An
// event with no persisted explanation yet contributes no MatchMoment
// (MatchMoment.explanation is not itself nullable — see that
// interface — so there is nothing valid to build for it) but is still
// eligible to appear inside another moment's own `surrounding_events`,
// exactly as buildFullMatchContext's own surroundingEventsFor already
// treats every supplied event, not just the ones with an explanation.

/** Caller-supplied inputs for the persisted-moments reconstruction —
 * identical to FullMatchContextInput above except `explanations`
 * replaces `momentContext`: already-persisted MomentExplanation values
 * (e.g. from momentExplanationPersistence.ts's own
 * momentExplanationsByEventId), keyed by `UnifiedFootballEvent.id`,
 * NEVER rebuilt by this function. */
export interface FullMatchContextFromPersistedMomentsInput {
  /** Same contract as FullMatchContextInput.matchId above. */
  matchId: string | null;
  /** Same contract as FullMatchContextInput.footballContext above. */
  footballContext: FootballMatchContext | null;
  /** Same contract as FullMatchContextInput.efootball above. */
  efootball?: EfootballMatchContextResult | null;
  /** Same contract as FullMatchContextInput.realFootball above. */
  realFootball?: RealFootballMatchContextResult | null;
  /** Every UnifiedFootballEvent (10D) for this match, in any order —
   * used both to order/window `surrounding_events` (exactly as
   * FullMatchContextInput.events above) and to resolve which event a
   * persisted explanation belongs to. An event with no matching key in
   * `explanations` still participates in ordering/windowing; it simply
   * yields no MatchMoment of its own (see file header above). */
  events: readonly UnifiedFootballEvent[];
  /** Already-persisted MomentExplanation values, keyed by
   * `UnifiedFootballEvent.id` — never rebuilt, never re-derived (see
   * file header above). An event with no entry here gets no
   * MatchMoment. */
  explanations: Readonly<Record<string, MomentExplanation>>;
}

/**
 * Builds ONE FullMatchContext from already-persisted MomentExplanation
 * rows (10J-1) plus already-built UnifiedFootballEvent rows (10D) and
 * roster/team context (9B/9C/10B/10C) — the read-path counterpart to
 * buildFullMatchContext above, for a match whose moments have already
 * been explained and persisted. Reuses sortEventsChronologically/
 * surroundingEventsFor verbatim; never calls
 * buildMomentExplanationFromUnifiedEvent (10H) — see file header,
 * "never re-derive historical explanations".
 */
export function buildFullMatchContextFromPersistedMoments(
  input: FullMatchContextFromPersistedMomentsInput
): FullMatchContext {
  const orderedEvents = sortEventsChronologically(input.events);

  const moments: MatchMoment[] = [];
  for (const event of orderedEvents) {
    const explanation = input.explanations[event.id];
    if (explanation === undefined) continue;
    moments.push({
      event,
      explanation,
      surrounding_events: surroundingEventsFor(event, orderedEvents),
    });
  }

  return {
    football_type: input.footballContext?.football_type ?? null,
    match_id: input.matchId,
    team_size: input.footballContext?.team_size ?? null,
    efootball: allowsEfootballContext(input.footballContext) ? input.efootball ?? null : null,
    real_football: allowsRealFootballContext(input.footballContext) ? input.realFootball ?? null : null,
    moments,
  };
}

// ============================================================
// 4. Batch 10J-3 — connect persisted MomentExplanation rows back into
//    the LIVE reconstruction path (buildFullMatchContext above),
//    with historical precedence (NO new FullMatchContext table; NO
//    re-derivation of any ALREADY-persisted explanation)
// ============================================================
//
// Spec (10J-3): "Connect persisted MomentExplanation records back into
// FullMatchContext reconstruction" / "reconstruct from persisted data;
// never re-run explanation logic" / "historical persisted explanation
// takes precedence over newly computed values".
//
// buildFullMatchContextFromPersistedMoments (10J-1, above) already
// covers the "every moment for this match already has a persisted
// explanation" case, but deliberately drops any event that has none
// yet (see that function's own header comment) — it never falls back
// to a fresh computation. buildFullMatchContextWithPersistedExplanations
// below is the piece 10J-3 adds: the SAME reconstruction, but for a
// match where SOME events already have a persisted (historical)
// explanation and others do not yet — e.g. a match still mid-analysis,
// or an older match analyzed before 10J-2 started persisting rows.
//
// PRECEDENCE, NEVER RE-RUN FOR AN ALREADY-PERSISTED EVENT (the central
// rule of this batch): for any event with an entry in `explanations`,
// that persisted value is used completely verbatim — exactly like
// buildFullMatchContextFromPersistedMoments above,
// buildMomentExplanationFromUnifiedEvent (10H) is NEVER called for
// that event. A historical explanation can therefore never be
// silently recomputed, replaced, or "refreshed" by a newer live
// result, no matter what buildMomentExplanationFromUnifiedEvent would
// produce for that same event today. Only an event with NO persisted
// entry falls back to a freshly computed explanation (10H, same as
// buildFullMatchContext above) — this is the "newly computed value"
// the spec's precedence rule refers to, and it is used only to fill a
// gap, never to override a historical one.
//
// REUSE, NOT REPLACEMENT: this function is a thin composition of
// buildFullMatchContext's own per-event shape and
// buildFullMatchContextFromPersistedMoments's own persisted-lookup
// idea — it duplicates neither's internals: same
// sortEventsChronologically/surroundingEventsFor ordering, same
// football_type/match_id/team_size/efootball/real_football pass-
// through (allowsEfootballContext/allowsRealFootballContext, never a
// new cross-type branch), same MatchMoment/FullMatchContext shapes
// (10I). `explanations` is expected to come from
// momentExplanationPersistence.ts's own momentExplanationsByEventId
// (10J-1) over that match's already-fetched public.moment_explanations
// rows — this file never queries a database itself.
//
// NULL STAYS NULL / NOTHING FABRICATED: a persisted explanation's own
// null fields (e.g. `better_option: null` for insufficient evidence)
// are carried through completely unchanged — this function never
// backfills, defaults, or "fixes up" a persisted row. A freshly
// computed fallback explanation is exactly what buildMomentExplanationFromUnifiedEvent
// (10H) already produces for that event — no different from calling
// buildFullMatchContext directly for that one event.
//
// OWNERSHIP / RLS PRESERVED (spec — "preserve ownership/RLS"): this
// file, like every other 10-series file, never queries Supabase or
// any other datastore itself — it only ever composes already-fetched,
// already-ownership/RLS-checked data the caller supplies (`events` and
// `explanations` both). Whatever query fetched those rows already went
// through moment_explanations' own RLS SELECT policy
// (moment_explanations_select_own, migration 0030) and analysis_events'
// own equivalent — this function adds no new read path and weakens
// neither.
//
// READ-ONLY, NO WRITES (spec): this function (like every function in
// this file) never calls Supabase, never mutates its inputs, and never
// persists anything — it only reads/composes already-fetched values
// into one FullMatchContext read shape.
//
// NO AI CALLS, NO NEW DB TABLE: buildMomentExplanationFromUnifiedEvent
// (10H) is the only "computation" this function can ever trigger, and
// only for a gap event with no persisted row — exactly the same call
// buildFullMatchContext already makes for every event; nothing new is
// added to momentExplanation.ts, and no new table/migration is
// introduced by this batch.

/** Caller-supplied inputs for the persisted-first reconstruction —
 * identical to FullMatchContextInput above (so a caller already using
 * buildFullMatchContext can add persisted-precedence with no other
 * changes), plus an optional `explanations` map of already-persisted
 * MomentExplanation values, keyed by `UnifiedFootballEvent.id` — same
 * contract as FullMatchContextFromPersistedMomentsInput.explanations
 * above. Omitted (or an event with no entry) simply falls back to a
 * freshly computed explanation, same as buildFullMatchContext. */
export interface FullMatchContextWithPersistedExplanationsInput extends FullMatchContextInput {
  /** Already-persisted MomentExplanation values (10J-1), keyed by
   * `UnifiedFootballEvent.id`. When an entry exists for an event, it is
   * used completely verbatim and buildMomentExplanationFromUnifiedEvent
   * (10H) is NEVER called for that event — see file header, "precedence,
   * never re-run for an already-persisted event". */
  explanations?: Readonly<Record<string, MomentExplanation>>;
}

/**
 * Builds ONE FullMatchContext the same way buildFullMatchContext does,
 * except: for any event with an entry in `explanations`, that
 * already-persisted MomentExplanation (10J-1) is used verbatim instead
 * of calling buildMomentExplanationFromUnifiedEvent (10H) again — a
 * historical explanation always takes precedence over a freshly
 * computed one (spec — "historical persisted explanation takes
 * precedence over newly computed values"). An event with no persisted
 * entry still gets a freshly computed explanation, so (unlike
 * buildFullMatchContextFromPersistedMoments above) no event is ever
 * silently dropped from `moments` merely because it hasn't been
 * persisted yet.
 */
export function buildFullMatchContextWithPersistedExplanations(
  input: FullMatchContextWithPersistedExplanationsInput
): FullMatchContext {
  const orderedEvents = sortEventsChronologically(input.events);
  const persisted = input.explanations ?? {};

  const moments: MatchMoment[] = orderedEvents.map((event) => {
    const persistedExplanation = persisted[event.id];
    return {
      event,
      explanation:
        persistedExplanation !== undefined
          ? persistedExplanation
          : buildMomentExplanationFromUnifiedEvent(event, input.momentContext?.[event.id] ?? {}),
      surrounding_events: surroundingEventsFor(event, orderedEvents),
    };
  });

  return {
    football_type: input.footballContext?.football_type ?? null,
    match_id: input.matchId,
    team_size: input.footballContext?.team_size ?? null,
    efootball: allowsEfootballContext(input.footballContext) ? input.efootball ?? null : null,
    real_football: allowsRealFootballContext(input.footballContext) ? input.realFootball ?? null : null,
    moments,
  };
}

