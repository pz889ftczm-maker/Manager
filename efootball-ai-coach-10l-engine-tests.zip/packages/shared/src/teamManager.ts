// Batch 7D — Manager Assignment: small, pure validation helper for
// team_library.manager_id (migration 0020_team_manager_assignment.sql),
// shared between the web team-manager helper
// (apps/web/src/lib/teamManager.ts) and anything else that needs to
// validate a (team_id, manager_id) assignment before sending it to
// Supabase. Same thin-and-pure convention as teamMembers.ts — see that
// file's header comment for why: RLS (0020) is the actual authority on
// whether the caller is allowed to make a given assignment, not this
// module. This file only checks that the ids are even shaped like ids,
// and that a `null` manager_id (clearing the manager) is always treated
// as valid rather than as a malformed field.
import { isUuidShaped } from "./teamMembers.js";

export interface ManagerAssignmentInput {
  team_id: string;
  /** null clears the team's manager (spec section 3 — "valid manager ->
   * NULL" is an explicitly valid state, not an error). */
  manager_id: string | null;
}

export interface ManagerAssignmentValidationResult {
  valid: boolean;
  errors: string[];
}

/**
 * Validates a (team_id, manager_id) assignment before it's sent to
 * Supabase to update public.team_library.manager_id. `manager_id: null`
 * is always valid (clearing the manager); a non-null manager_id must be
 * uuid-shaped. Never throws and never fabricates a value for a
 * malformed field — same never-guess convention as
 * validateTeamMemberInput (teamMembers.ts). This is a client-side
 * early-feedback check only: the actual ownership authorization
 * decision (does this manager belong to the same user as this team) is
 * made by RLS and check_team_library_manager_ownership
 * (0020_team_manager_assignment.sql), never here.
 */
export function validateManagerAssignmentInput(input: unknown): ManagerAssignmentValidationResult {
  const errors: string[] = [];

  if (!input || typeof input !== "object" || Array.isArray(input)) {
    return { valid: false, errors: ["input is not an object"] };
  }

  const d = input as Record<string, unknown>;

  if (typeof d.team_id !== "string" || d.team_id.trim().length === 0) {
    errors.push(`team_id: expected a non-empty string, got ${JSON.stringify(d.team_id)}`);
  } else if (!isUuidShaped(d.team_id.trim())) {
    errors.push("team_id: does not look like a uuid");
  }

  // manager_id is the one field where null is a first-class valid
  // value (clearing) rather than a missing/malformed one — undefined is
  // NOT treated the same as null here, since an omitted field usually
  // means "caller forgot this", whereas an explicit null means "caller
  // wants no manager".
  if (d.manager_id !== null) {
    if (typeof d.manager_id !== "string" || d.manager_id.trim().length === 0) {
      errors.push(`manager_id: expected a non-empty string or null, got ${JSON.stringify(d.manager_id)}`);
    } else if (!isUuidShaped(d.manager_id.trim())) {
      errors.push("manager_id: does not look like a uuid");
    }
  }

  return { valid: errors.length === 0, errors };
}
