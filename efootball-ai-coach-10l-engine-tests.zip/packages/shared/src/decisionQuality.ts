// Batch 10G-1 — Decision Quality Data Model ONLY. A shared, validated
// shape for "how good was this decision" that works identically for an
// eFootball 11v11 match and a Real Football 7v7 match, WITHOUT a new
// database table, a new event system, and WITHOUT touching 10D's
// unified event schema, 10E's tactical position model, or 10F's
// passing-lane/space model.
//
// REUSE, NOT REPLACEMENT (spec — "reuse existing architecture"):
//   * Football-type source of truth: still footballMatchContext.ts's
//     FootballMatchContext — never re-derived here.
//   * Event reference / decision score / confidence / reasoning /
//     better_option / evidence: still footballEvent.ts's own
//     UnifiedFootballEvent (10D) — buildDecisionQualityFromUnifiedEvent
//     below reads those fields straight off an already-built
//     UnifiedFootballEvent rather than re-deriving them from a raw
//     AnalysisEvent row a second time.
//   * Player reference: still tacticalPosition.ts's own
//     TacticalPositionPlayerRef (10E) — not a redefined near-duplicate
//     shape.
//   * Score/confidence range checks: still validation.ts's own
//     0-100 integer range convention (the same one
//     validateDetectedEventDraft already applies to decision_score/
//     confidence on the underlying row) — this file's own
//     isScoreInRange helper mirrors that exact rule rather than
//     inventing a different range or a float scale.
//   * This file never calls an AI provider and never touches
//     Supabase — same "pure builder, caller already fetched the row"
//     convention as efootballMatchContext.ts/realFootballMatchContext.ts/
//     tacticalPosition.ts/passingLaneSpaceModel.ts.
//
// EVIDENCE-SUPPORTED FIELDS ONLY (spec — "include only evidence-
// supported fields"): the eleven fields below are exactly the ones the
// spec lists (player reference, timestamp, event reference, action/
// decision, available options, chosen option, better option, quality
// score, confidence, reasons/evidence, source/evidence references) —
// no outcome/result field, no fabricated "win probability" or
// "expected goals" style derived metric, nothing beyond what an
// already-persisted analysis_events row (plus this batch's own
// caller-supplied option/reason data) can actually evidence.
//
// NEVER FABRICATE (spec — the central rule of this batch):
//   * available_options/chosen_option/better_option are free-form,
//     caller-supplied DecisionOption values — this file's own builder
//     (buildDecisionQualityFromUnifiedEvent) NEVER invents them. The
//     only pre-populated field among the three is better_option, and
//     only when the underlying UnifiedFootballEvent already carries a
//     non-null `better_option` string (i.e. evidence the AI provider
//     itself already produced and that was already validated by
//     validateUnifiedFootballEventInput/validateDetectedEventDraft) —
//     available_options and chosen_option have no existing source
//     anywhere in this codebase today, so the builder always leaves
//     them null rather than guessing at what was "available" or
//     "chosen".
//   * validateDecisionQualityInput (this file's write-path gate)
//     enforces "do not infer a better option without evidence" as a
//     structural rule: a draft may not set `better_option` unless it
//     also carries at least one reason/evidence entry supporting it —
//     a bare, unsupported better_option is rejected, never silently
//     accepted.
//   * Nothing in this file reads or reasons about a match/event
//     *outcome* (final score, win/loss, goals) — "do not judge quality
//     from outcome alone" is honored by there being no outcome field
//     on this shape at all, so no caller of this file can even
//     construct a score that mixes in outcome data through this model.
//   * player/timestamp/options/reasons/evidence that are unknown stay
//     exactly `null` through every builder/validator here — never
//     defaulted, never backfilled from another field (same convention
//     as tacticalPosition.ts's `coordinates: null` / footballEvent.ts's
//     `player_id: null`).
//
// SCORE AND CONFIDENCE ARE SEPARATE (spec): `score` and `confidence`
// are two independent, independently-nullable, independently-range-
// validated fields. Neither this file's builder nor its validator ever
// derives one from the other (no "confidence defaults to score", no
// "score is scaled by confidence") — a caller who wants both must
// supply both from their own evidence.
//
// NO ZOD DEPENDENCY, NO I/O (same convention as every other file in
// this package): small hand-written pure functions only.
//
// NO SCOPE CREEP (explicitly out of scope for 10G-1, left to later
// 10G sub-batches): no AI calls, no AI provider/prompt changes, no
// analysis-pipeline wiring, no new database table/migration, no Coach
// UI, no player progress changes. This file only shapes and validates
// the decision-quality record itself, as a pure model over already-
// existing, already-persisted data plus caller-supplied option/reason
// evidence — 10G-2/10G-3 are NOT implemented here.

import type { FootballType } from "./footballMatchContext.js";
import type { TacticalPositionPlayerRef } from "./tacticalPosition.js";
import type { UnifiedFootballEvent } from "./footballEvent.js";

// ============================================================
// 1. Shape
// ============================================================

/**
 * One decision option — either something that was available to choose
 * from, the option actually chosen, or a proposed better alternative.
 * Deliberately a single small shape reused for all three roles (spec:
 * "available options", "chosen option", "better option") rather than
 * three near-duplicate types — a caller distinguishes them by which
 * field of DecisionQuality they populate, not by a type-level tag.
 */
export interface DecisionOption {
  /** Free-text description of the option (e.g. "pass to right
   * winger", "shoot first time", "hold up play"). Required — an
   * option with no description is not evidence of anything. */
  label: string;
  /** The evidence/reasoning supporting that this option existed or was
   * chosen — e.g. a quote from the AI provider's own analysis, a
   * cited statistic. Null (never an empty-string placeholder) when no
   * such evidence is supplied. */
  evidence: string[] | null;
}

/**
 * One decision-quality record: how good a single decision was, with
 * every supporting fact traceable to real evidence. Every field is
 * independently nullable except `event_id` (a decision-quality record
 * with no event reference has nothing to be "about") — a record with a
 * score but no confidence, or reasons but no better_option, is a
 * normal, expected shape, not a partial/invalid one.
 */
export interface DecisionQuality {
  /** Match-level attribute, sourced only from the match's own
   * FootballMatchContext — never supplied independently (same
   * convention as footballEvent.ts/tacticalPosition.ts's own
   * football_type gates below). */
  football_type: FootballType | null;
  match_id: string | null;
  /** The analysis_events row this decision-quality record is about.
   * Required — see interface doc comment above. */
  event_id: string;
  /** Player reference, when known — reuses tacticalPosition.ts's own
   * shape rather than redefining one. Null whenever the event can't be
   * tied to a specific identified player. */
  player: TacticalPositionPlayerRef | null;
  timestamp_seconds: number | null;
  /** The action/decision itself, in the player's own words/AI's own
   * description of what happened — e.g. "played a risky central pass
   * into a double press". Null when unknown. */
  action: string | null;
  /** Every option that was actually available to the player at this
   * moment, when evidenced. Null (never `[]` used as a "we don't
   * know" placeholder — `[]` means "evidenced as having had zero
   * options", `null` means "not evidenced either way") when no such
   * evidence exists. */
  available_options: DecisionOption[] | null;
  /** The option the player actually chose. Null when unknown. */
  chosen_option: DecisionOption | null;
  /** A proposed better alternative — nullable, and never populated by
   * this file's own builder without the underlying evidence already
   * existing (see file header). */
  better_option: DecisionOption | null;
  /** 0-100 integer quality score. Independent of `confidence` — see
   * file header, "SCORE AND CONFIDENCE ARE SEPARATE". Null when
   * unknown/not evidenced. */
  score: number | null;
  /** 0-100 integer confidence in this record's own assessment.
   * Independent of `score` — see file header. Null when unknown. */
  confidence: number | null;
  /** Reasons/evidence supporting the score/assessment — free-text
   * statements, e.g. the AI provider's own reasoning. Null when none
   * is supplied. */
  reasons: string[] | null;
  /** Source/evidence references distinct from `reasons` — pointers
   * back to the underlying evidence (frame URLs, cited statistics
   * field names, etc.) rather than prose reasoning. Null when none is
   * supplied. */
  source_references: string[] | null;
}

// ============================================================
// 2. UnifiedFootballEvent -> DecisionQuality (the only pre-populating
//    builder in this file)
// ============================================================

function nonEmptyString(value: string | null | undefined): string | null {
  return typeof value === "string" && value.trim().length > 0 ? value : null;
}

/**
 * Builds a DecisionQuality record from an already-built
 * UnifiedFootballEvent (10D) — reusing its event_id/match_id/
 * football_type/player_id/timestamp/decision_score/confidence/
 * reasoning/better_option/evidence fields rather than re-deriving any
 * of them from a raw AnalysisEvent row a second time.
 *
 * `available_options` and `chosen_option` are ALWAYS null from this
 * builder — analysis_events has no column evidencing either today (see
 * file header) — a caller with real evidence for them (a later 10G
 * sub-batch, explicitly out of scope here) supplies them separately,
 * e.g. via `withOptions` below, rather than this function guessing at
 * them.
 *
 * `better_option` is populated ONLY when the underlying event's own
 * `better_option` string is non-empty — i.e. only when the AI
 * provider itself already produced and validated that evidence. Its
 * `evidence` is seeded from the event's own `reasoning`, when present
 * (the same text that already justifies the underlying
 * decision_score/severity) — never fabricated separately.
 */
export function buildDecisionQualityFromUnifiedEvent(
  event: UnifiedFootballEvent
): DecisionQuality {
  const betterOptionLabel = nonEmptyString(event.better_option);
  const reasoning = nonEmptyString(event.reasoning);

  return {
    football_type: event.football_type,
    match_id: event.match_id,
    event_id: event.id,
    player: event.player_id !== null ? { player_id: event.player_id, name: null } : null,
    timestamp_seconds: event.timestamp_seconds,
    action: nonEmptyString(event.description),
    available_options: null,
    chosen_option: null,
    better_option:
      betterOptionLabel !== null
        ? { label: betterOptionLabel, evidence: reasoning !== null ? [reasoning] : null }
        : null,
    score: event.decision_score,
    confidence: event.confidence,
    reasons: reasoning !== null ? [reasoning] : null,
    source_references: event.evidence !== null && event.evidence.length > 0 ? event.evidence : null,
  };
}

/**
 * Attaches caller-supplied `available_options`/`chosen_option`
 * evidence to an already-built DecisionQuality record, without
 * touching any of its other fields. A separate, explicit step (rather
 * than an extra parameter on buildDecisionQualityFromUnifiedEvent)
 * keeps "evidence this file derived from the event itself" and
 * "evidence the caller is separately asserting" visibly distinct at
 * every call site — the caller decides to add this, it is never
 * inferred automatically.
 */
export function withOptions(
  decision: DecisionQuality,
  options: { available_options?: DecisionOption[] | null; chosen_option?: DecisionOption | null }
): DecisionQuality {
  return {
    ...decision,
    available_options:
      options.available_options !== undefined ? options.available_options : decision.available_options,
    chosen_option: options.chosen_option !== undefined ? options.chosen_option : decision.chosen_option,
  };
}

// ============================================================
// 3. Write-path validation (untrusted input -> safe to use/persist)
// ============================================================

function isScoreInRange(value: unknown): value is number {
  return typeof value === "number" && Number.isInteger(value) && value >= 0 && value <= 100;
}

function isNonEmptyStringArray(value: unknown): value is string[] {
  return (
    Array.isArray(value) &&
    value.length > 0 &&
    value.every((entry) => typeof entry === "string" && entry.trim().length > 0)
  );
}

function isValidDecisionOptionShape(value: unknown): value is DecisionOption {
  if (!value || typeof value !== "object") return false;
  const o = value as Record<string, unknown>;
  if (typeof o.label !== "string" || o.label.trim().length === 0) return false;
  if (o.evidence !== undefined && o.evidence !== null) {
    if (!Array.isArray(o.evidence) || !o.evidence.every((e) => typeof e === "string")) return false;
  }
  return true;
}

export interface DecisionQualityValidationInput {
  football_type?: unknown;
  match_id?: unknown;
  event_id?: unknown;
  player?: unknown;
  timestamp_seconds?: unknown;
  action?: unknown;
  available_options?: unknown;
  chosen_option?: unknown;
  better_option?: unknown;
  score?: unknown;
  confidence?: unknown;
  reasons?: unknown;
  source_references?: unknown;
  [key: string]: unknown;
}

export interface DecisionQualityOwnershipContext {
  /** The match this decision-quality record is being written for,
   * resolved server-side (never taken from client input). */
  matchId: string;
  /** The owning user of that match, resolved server-side. */
  userId: string;
  /** The player this record will be linked to, if any, already
   * resolved by the caller — NOT taken from client input (same
   * convention as footballEvent.ts's own
   * UnifiedFootballEventOwnershipContext). */
  player?: { id: string; user_id: string } | null;
}

export interface DecisionQualityValidationResult {
  valid: boolean;
  errors: string[];
}

/**
 * The write-path gate for a DecisionQuality-shaped draft — defense in
 * depth for any future caller assembling/persisting one, mirroring
 * footballEvent.ts's validateUnifiedFootballEventInput and
 * tacticalPosition.ts's validateTacticalPositionInput in structure and
 * conventions:
 *   - event_id is required (a decision-quality record with no event
 *     reference has nothing to be "about").
 *   - score/confidence, independently, must each be a 0-100 integer
 *     when present — never derived from one another.
 *   - available_options/chosen_option/better_option, when present,
 *     must each be a well-formed DecisionOption (non-empty label,
 *     evidence either absent or an array of strings).
 *   - better_option may not be set without at least one supporting
 *     reason/evidence entry — "do not infer a better option without
 *     evidence" (spec), enforced structurally rather than left as an
 *     unchecked convention.
 *   - football_type must never be supplied directly on the record — it
 *     is a match-level attribute, derived from the match's own
 *     football context, same convention as footballEvent.ts/
 *     tacticalPosition.ts's own football_type gates.
 *   - ownership/integrity: a supplied match_id/player must agree with
 *     the caller's own resolved ownership context — no cross-match or
 *     cross-user reference, same convention as footballEvent.ts's own
 *     ownership check.
 */
export function validateDecisionQualityInput(
  input: DecisionQualityValidationInput,
  context: { ownership?: DecisionQualityOwnershipContext } = {}
): DecisionQualityValidationResult {
  const errors: string[] = [];

  if (!input || typeof input !== "object") {
    return { valid: false, errors: ["draft is not an object"] };
  }

  if (typeof input.event_id !== "string" || input.event_id.trim().length === 0) {
    errors.push("event_id is required and must be a non-empty string");
  }

  // football_type is a match-level attribute — never accepted directly
  // on the record itself (spec — "do not infer/fabricate"; same
  // convention as footballEvent.ts/tacticalPosition.ts).
  if (input.football_type !== undefined && input.football_type !== null) {
    errors.push(
      "football_type must not be supplied on the decision-quality record itself; it is derived from the match's own football context"
    );
  }

  if (
    input.timestamp_seconds !== undefined &&
    input.timestamp_seconds !== null &&
    !(typeof input.timestamp_seconds === "number" && Number.isFinite(input.timestamp_seconds) && input.timestamp_seconds >= 0)
  ) {
    errors.push(`timestamp_seconds must be a non-negative finite number or null, got ${JSON.stringify(input.timestamp_seconds)}`);
  }

  // Score and confidence: independent, both 0-100 integer when present
  // (spec — "validate score/confidence ranges", "score and confidence
  // must be separate" — neither check below references the other
  // field).
  if (input.score !== undefined && input.score !== null && !isScoreInRange(input.score)) {
    errors.push(`score must be an integer between 0 and 100 (or null), got ${JSON.stringify(input.score)}`);
  }
  if (input.confidence !== undefined && input.confidence !== null && !isScoreInRange(input.confidence)) {
    errors.push(`confidence must be an integer between 0 and 100 (or null), got ${JSON.stringify(input.confidence)}`);
  }

  if (input.action !== undefined && input.action !== null && typeof input.action !== "string") {
    errors.push(`action must be a string or null, got ${JSON.stringify(input.action)}`);
  }

  if (input.available_options !== undefined && input.available_options !== null) {
    if (!Array.isArray(input.available_options) || !input.available_options.every(isValidDecisionOptionShape)) {
      errors.push("available_options must be an array of {label, evidence} entries or null");
    }
  }

  if (input.chosen_option !== undefined && input.chosen_option !== null && !isValidDecisionOptionShape(input.chosen_option)) {
    errors.push("chosen_option must be a {label, evidence} object or null");
  }

  const hasBetterOption = input.better_option !== undefined && input.better_option !== null;
  if (hasBetterOption && !isValidDecisionOptionShape(input.better_option)) {
    errors.push("better_option must be a {label, evidence} object or null");
  }

  const hasReasons = input.reasons !== undefined && input.reasons !== null;
  if (hasReasons && !isNonEmptyStringArray(input.reasons)) {
    errors.push("reasons must be a non-empty array of non-empty strings, or null");
  }

  if (input.source_references !== undefined && input.source_references !== null && !isNonEmptyStringArray(input.source_references)) {
    errors.push("source_references must be a non-empty array of non-empty strings, or null");
  }

  // "Do not infer a better option without evidence" (spec) — a
  // better_option may only be set alongside supporting reasons/
  // evidence: either the record's own `reasons`, or the option's own
  // `evidence` field.
  if (hasBetterOption && isValidDecisionOptionShape(input.better_option)) {
    const optionHasOwnEvidence = isNonEmptyStringArray((input.better_option as DecisionOption).evidence);
    const recordHasReasons = isNonEmptyStringArray(input.reasons);
    if (!optionHasOwnEvidence && !recordHasReasons) {
      errors.push(
        "better_option cannot be set without supporting evidence — provide better_option.evidence or record-level reasons"
      );
    }
  }

  // Ownership / integrity — never trust client input; a mismatch
  // against the caller's own resolved context is rejected (same
  // convention as footballEvent.ts's own ownership check).
  if (context.ownership) {
    const { matchId, userId, player } = context.ownership;
    if (typeof input.match_id === "string" && input.match_id !== matchId) {
      errors.push("match_id does not match the expected match for this request — cross-match reference rejected");
    }
    if (player && player.user_id !== userId) {
      errors.push("resolved player does not belong to the expected user — cross-user reference rejected");
    }
    const playerRef = input.player as { player_id?: unknown } | null | undefined;
    if (playerRef && typeof playerRef === "object" && playerRef.player_id != null) {
      if (player && playerRef.player_id !== player.id) {
        errors.push("player does not match the resolved player for this decision-quality record");
      }
      if (!player) {
        errors.push("player was supplied but no player was resolved/owned for this request");
      }
    }
  }

  return { valid: errors.length === 0, errors };
}
