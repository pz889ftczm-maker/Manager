// Batch 8B — Formation Player Assignment & Persistence. Shared type +
// pure validation for public.team_formation_players (migration
// 0022_team_formation_players.sql). No Formation UI, no starting XI/
// bench, no presets, no historical snapshots — see that migration's
// design notes for the full scope boundary; this file mirrors it at
// the application layer only for what needs to exist for typing/
// validation before persisting a row.
//
// Named teamFormationPlayers.ts (matching the team_formation_players
// table and the teamMembers.ts/teamFormations.ts naming convention).

import { isUniqueViolation } from "./playerLibrary.js";

export { isUniqueViolation };

const UUID_SHAPE = /^[0-9a-f]{8}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{12}$/i;

function isUuidShaped(value: unknown): value is string {
  return typeof value === "string" && UUID_SHAPE.test(value.trim());
}

/**
 * Represents one row of public.team_formation_players (migration
 * 0022_team_formation_players.sql) — "player X is assigned to slot Y
 * in formation Z", and nothing else. Deliberately has NO player name,
 * stats, attributes, image, or coordinate fields — those stay solely
 * on player_library (name/stats/attributes/image) and
 * team_formations.positions (x/y layout) respectively; a reader joins
 * through player_id/formation_id to get them instead of this type
 * duplicating them. Also has no starting-XI/bench/historical-match
 * fields — that distinction doesn't exist in this data model yet.
 */
export interface TeamFormationPlayer {
  id: string;
  formation_id: string;
  player_id: string;
  /** Stable slot identifier expected to match one of the `id`s inside
   * the owning formation's team_formations.positions (e.g. "gk",
   * "cb1") — never enforced as a foreign key against that JSONB (see
   * migration 0022's design notes), just carried here as plain text. */
  position_slot: string;
  created_at: string;
  updated_at: string;
}

/** Shape of what a caller submits to persist a team_formation_players
 * row — mirrors the columns migration 0022 actually has, minus
 * server-controlled columns (id/created_at/updated_at). Every field is
 * required — there is no valid "partial" assignment (a slot with no
 * player, or a player with no slot, simply isn't a row in this table at
 * all). */
export interface TeamFormationPlayerInput {
  formation_id: string;
  player_id: string;
  position_slot: string;
}

export interface TeamFormationPlayerValidationResult {
  valid: boolean;
  sanitized: TeamFormationPlayerInput;
  errors: string[];
}

function sanitizeUuid(raw: unknown, field: string, errors: string[]): string {
  if (!isUuidShaped(raw)) {
    errors.push(`${field}: expected a uuid, got ${JSON.stringify(raw)}`);
    return "";
  }
  return (raw as string).trim();
}

function sanitizePositionSlot(raw: unknown, errors: string[]): string {
  if (typeof raw !== "string" || raw.trim().length === 0) {
    errors.push(`position_slot: expected a non-empty string, got ${JSON.stringify(raw)}`);
    return "";
  }
  return raw.trim();
}

/**
 * Validates a user-submitted TeamFormationPlayerInput-shaped object
 * before it's persisted to public.team_formation_players. Same
 * never-throws, never-fabricate-a-value convention as
 * validateTeamFormationInput/validateTeamMemberInput: a missing/
 * malformed uuid is reported as an error and left as an empty string —
 * NEVER coerced into a made-up id that would look like a valid
 * assignment. Never checks OWNERSHIP (does this formation/player
 * actually belong to the caller) — that's RLS's job (migration 0022),
 * not this pure, dependency-free module's.
 */
export function validateTeamFormationPlayerInput(input: unknown): TeamFormationPlayerValidationResult {
  const errors: string[] = [];
  const empty: TeamFormationPlayerInput = { formation_id: "", player_id: "", position_slot: "" };

  if (!input || typeof input !== "object" || Array.isArray(input)) {
    return { valid: false, errors: ["input is not an object"], sanitized: empty };
  }

  const d = input as Record<string, unknown>;

  const sanitized: TeamFormationPlayerInput = {
    formation_id: sanitizeUuid(d.formation_id, "formation_id", errors),
    player_id: sanitizeUuid(d.player_id, "player_id", errors),
    position_slot: sanitizePositionSlot(d.position_slot, errors),
  };

  return { valid: errors.length === 0, sanitized, errors };
}

// ============================================================
// Duplicate-assignment handling
// ============================================================
//
// public.team_formation_players_formation_player_uniq (migration 0022)
// is a plain unique index on (formation_id, player_id) — Postgres
// enforces it; nothing here re-implements that enforcement. This
// constant lets a caller recognize that a failed insert failed BECAUSE
// of this exact constraint (spec section 2 — "the same player MUST NOT
// be assigned twice to the same formation") rather than some other
// error. The same player being assigned to a DIFFERENT formation is
// unaffected — this constraint is scoped to one formation_id at a
// time, by design.

/** The exact name of the unique index from migration 0022 — kept as one
 * named constant so callers can't drift apart if it's ever renamed. */
export const TEAM_FORMATION_PLAYER_UNIQUE_CONSTRAINT = "team_formation_players_formation_player_uniq";

/** True when `err` is the "this player is already assigned to this
 * formation" unique violation from
 * team_formation_players_formation_player_uniq, as opposed to some
 * other/unexpected error. */
export function isDuplicateFormationPlayer(err: unknown): boolean {
  return isUniqueViolation(err, TEAM_FORMATION_PLAYER_UNIQUE_CONSTRAINT);
}

// ============================================================
// Duplicate-slot handling (Batch 8C)
// ============================================================
//
// public.team_formation_players_formation_slot_uniq (migration 0023)
// is a plain unique index on (formation_id, position_slot) — a slot is
// one physical position on the pitch, so it can hold at most one
// player. This is a SEPARATE constraint from
// team_formation_players_formation_player_uniq above (that one caps a
// PLAYER at one slot; this one caps a SLOT at one player) — both hold
// at the same time, and a caller can hit either independently.

/** The exact name of the unique index from migration 0023 — kept as one
 * named constant, same convention as
 * TEAM_FORMATION_PLAYER_UNIQUE_CONSTRAINT above. */
export const TEAM_FORMATION_PLAYER_SLOT_UNIQUE_CONSTRAINT = "team_formation_players_formation_slot_uniq";

/** True when `err` is the "this slot is already occupied in this
 * formation" unique violation from
 * team_formation_players_formation_slot_uniq, as opposed to some
 * other/unexpected error. */
export function isDuplicateFormationSlot(err: unknown): boolean {
  return isUniqueViolation(err, TEAM_FORMATION_PLAYER_SLOT_UNIQUE_CONSTRAINT);
}

// ============================================================
// Slot-assignment planning (Batch 8C)
// ============================================================
//
// Two unique constraints (formation_id, player_id) and (formation_id,
// position_slot) both apply to this table at once. That's exactly
// right for the data model, but it means "assign player P to slot S"
// can't always be done as a single blind insert: P might already be
// somewhere else in this formation (in which case inserting a second
// row for them would hit the player constraint — that row needs to be
// MOVED, not duplicated), and/or slot S might already be occupied by a
// different player (in which case inserting into S would hit the slot
// constraint until that occupant is cleared out of the way first).
//
// planFormationSlotAssignment is the pure, dependency-free planner that
// works out which of insert/update/delete operations are needed, IN AN
// ORDER that never transiently re-collides with either constraint, so
// the caller (apps/web/src/lib/teamFormationPlayers.ts's
// assignPlayerToFormationSlot) can just execute the plan step by step
// rather than reason about ordering itself. It never talks to Supabase
// and never decides where a displaced occupant should go next (that's
// a UI/product decision, not this function's) — it only ever removes a
// displaced occupant's assignment row, it never invents a slot for
// them.

/** The minimal shape planFormationSlotAssignment needs for each of a
 * formation's existing assignment rows — a subset of TeamFormationPlayer,
 * so a caller can pass rows straight from listFormationPlayers(). */
export interface ExistingFormationAssignment {
  id: string;
  player_id: string;
  position_slot: string;
}

/** One step of a slot-assignment plan. `insert`/`update_slot` are what
 * actually places the player; `delete` only ever appears as a
 * preceding step to clear a slot's previous occupant out of the way
 * (see planFormationSlotAssignment) — it is never used to remove the
 * player being assigned. */
export type FormationSlotOperation =
  | { type: "insert"; player_id: string; position_slot: string }
  | { type: "update_slot"; id: string; position_slot: string }
  | { type: "delete"; id: string };

export interface FormationSlotAssignmentPlan {
  /** Steps to run, in this exact order, to safely place the player in
   * the requested slot. Empty when they're already exactly there — a
   * no-op plan, not an error. */
  operations: FormationSlotOperation[];
  /** The existing assignment row that this plan removes from the
   * formation entirely because it occupied the requested slot (i.e.
   * belonged to a different player) — null when the slot was free.
   * Exposed so a caller can warn ("this will remove X from the
   * formation") before running the plan, rather than only finding out
   * from the result. This planner never tries to re-home a displaced
   * occupant into the vacated slot or anywhere else. */
  displaced: ExistingFormationAssignment | null;
}

/**
 * Computes the operations needed to assign `playerId` to `positionSlot`
 * within one formation's existing assignments, given as a plain array
 * (e.g. the result of listFormationPlayers) — this function does not
 * fetch anything itself. Handles all four cases:
 *   - slot free, player not yet in the formation -> a single insert.
 *   - slot free, player already elsewhere in the formation -> a single
 *     update_slot on their existing row (a move, not a duplicate).
 *   - slot occupied by a different player, player not yet in the
 *     formation -> delete the occupant, then insert the new row —
 *     deleting first so the insert never collides with the occupant
 *     under team_formation_players_formation_slot_uniq.
 *   - slot occupied by a different player, player already elsewhere in
 *     the formation -> delete the occupant, then update_slot the
 *     player's existing row — same ordering reason.
 * Returns an empty operations list (not an error) when the player is
 * already exactly in that slot. Pure and synchronous — never throws,
 * never talks to Supabase; the caller is responsible for actually
 * running each operation, in order, and for surfacing a duplicate-key
 * error from doing so as a genuine bug in this planner (it shouldn't
 * be possible if `existing` accurately reflects the database).
 */
export function planFormationSlotAssignment(
  existing: ExistingFormationAssignment[],
  playerId: string,
  positionSlot: string
): FormationSlotAssignmentPlan {
  const slot = positionSlot.trim();
  const mover = existing.find((a) => a.player_id === playerId) ?? null;
  const occupant = existing.find((a) => a.position_slot === slot && a.player_id !== playerId) ?? null;

  if (mover && mover.position_slot === slot) {
    // Already exactly there.
    return { operations: [], displaced: null };
  }

  const operations: FormationSlotOperation[] = [];

  // Clear the target slot FIRST when someone else occupies it, so the
  // move/insert below never transiently collides with them under
  // team_formation_players_formation_slot_uniq (migration 0023).
  if (occupant) {
    operations.push({ type: "delete", id: occupant.id });
  }

  if (mover) {
    operations.push({ type: "update_slot", id: mover.id, position_slot: slot });
  } else {
    operations.push({ type: "insert", player_id: playerId, position_slot: slot });
  }

  return { operations, displaced: occupant };
}
