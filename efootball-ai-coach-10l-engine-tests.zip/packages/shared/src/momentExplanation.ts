// Batch 10H — Moment Explanation ONLY. A shared, evidence-first "why did
// this moment matter" explanation that composes 10D's UnifiedFootballEvent,
// 10E's TacticalPosition, 10F's PassingLane/Space, and 10G's DecisionQuality
// (plus its own evidence-gating from decisionQualityEvidence.ts) into ONE
// read shape — WITHOUT a new database table, a new event system, an AI
// call, or any change to any of those four upstream files.
//
// REUSE, NOT REPLACEMENT (spec — "reuse UnifiedFootballEvent +
// TacticalPosition + PassingLane/Space + DecisionQuality"):
//   * Event reference / description / confidence / football_type/
//     match_id/player: still footballEvent.ts's own UnifiedFootballEvent
//     (10D) and decisionQuality.ts's own buildDecisionQualityFromUnifiedEvent
//     (10G-1) — this file calls that builder rather than re-deriving any of
//     action/score/confidence/reasons/source_references/better_option a
//     second time from the raw event.
//   * Evidence gating (whether there is enough evidence to grade at all,
//     and whether better_option is itself evidenced): still
//     decisionQualityEvidence.ts's own hasSufficientEvidence/
//     evaluateDecisionQualityEvidence (10G-2) — this file does not
//     reimplement either check, it calls them.
//   * Tactical/spatial supporting context: tacticalPosition.ts's own
//     TacticalPositionState (10E) and passingLaneSpaceModel.ts's own
//     PassingLane/Space (10F) — attached verbatim, caller-supplied (same
//     "caller already fetched/built it" convention as decisionQuality.ts's
//     withOptions), never re-derived or re-parsed here.
//
// EVIDENCE FIRST / NEVER FABRICATE (spec — the central rule of this
// batch): every field below traces to a real, already-evidenced value on
// one of the four reused models above.
//   * `what_happened` is exactly DecisionQuality's own `action` (itself
//     `UnifiedFootballEvent.description`, never re-worded).
//   * `why_it_happened` is exactly DecisionQuality's own `reasons` — null
//     whenever no such evidence exists, never a guessed explanation.
//   * `better_option` is populated ONLY when
//     evaluateDecisionQualityEvidence's own re-verified `better_option`
//     is non-null (i.e. only when 10G-2's own evidence gate says so) —
//     this file adds no independent judgment of its own.
//   * `why_better` is the SAME evidence that already justified
//     `better_option` (its own `evidence`, or — only when that is empty —
//     the record's own `reasons`, mirroring
//     hasSufficientEvidenceForBetterOption's own OR condition) — never a
//     separately invented justification.
//   * `actionable_improvement` is `better_option.label` verbatim — the AI
//     provider's own already-validated suggested alternative, never a new
//     suggestion synthesized by this file. Null whenever `better_option`
//     is null.
//   * `confidence` is DecisionQuality's own `confidence`, pass-through —
//     independent of evidence-for-grading, same "score and confidence are
//     separate" convention as decisionQuality.ts.
//   * `evidence` is the de-duplicated union of DecisionQuality's own
//     `reasons` and `source_references` — nothing added that either field
//     did not already carry.
//   * `positions`/`passing_lane`/`space` are attached ONLY when the
//     caller-supplied value's own `source.event_id` actually matches this
//     explanation's `event_id` (or, for a context-sourced TacticalPosition,
//     when it carries no event_id at all — see
//     TacticalPositionSourceType/`context_source` in tacticalPosition.ts) —
//     a value sourced from a different event is silently dropped (null),
//     never attached anyway, so nothing here can misattribute evidence
//     from one moment to another.
//
// INSUFFICIENT EVIDENCE -> NULL/UNKNOWN (spec): `has_sufficient_evidence`
// is exactly evaluateDecisionQualityEvidence's own `has_sufficient_evidence`
// (10G-2) — this file's own read of "is there enough evidence to grade
// this moment at all" is never a separate/looser check.
//
// NEVER JUDGE FROM OUTCOME (spec, inherited from decisionQuality.ts): no
// function here takes a match/event outcome (result, goals, win/loss) as
// input, and DecisionQuality itself has no such field — structurally
// impossible for this file's explanation to be outcome-derived.
//
// EFOOTBALL / REAL FOOTBALL SEPARATION PRESERVED (spec): `football_type`
// is passed through unchanged (from the underlying DecisionQuality) and
// never inspected to change explanation behavior — same convention as
// decisionQuality.ts/decisionQualityEvidence.ts, no per-football-type
// branching anywhere in this file.
//
// NO ZOD DEPENDENCY, NO I/O, NO AI CALLS (same convention as every other
// file in this package): small hand-written pure functions only.
//
// NO SCOPE CREEP (explicitly out of scope for 10H, left to a later batch):
// no AI calls, no AI provider/prompt changes, no analysis-pipeline wiring,
// no new database table/migration, no Coach UI. This file only shapes an
// explanation over already-existing, already-evidenced data plus
// caller-supplied tactical/spatial context — 10I+ is NOT implemented here.

import type { FootballType } from "./footballMatchContext.js";
import type { UnifiedFootballEvent } from "./footballEvent.js";
import type { TacticalPositionPlayerRef, TacticalPositionState } from "./tacticalPosition.js";
import type { PassingLane, Space } from "./passingLaneSpaceModel.js";
import type { DecisionOption, DecisionQuality } from "./decisionQuality.js";
import { buildDecisionQualityFromUnifiedEvent } from "./decisionQuality.js";
import { evaluateDecisionQualityEvidence } from "./decisionQualityEvidence.js";

// ============================================================
// 1. Shape
// ============================================================

/**
 * One moment explanation: WHAT happened, WHY it happened, a better option
 * (only when evidenced) and WHY it is better, an actionable improvement,
 * confidence, and the evidence/source references backing all of it — for a
 * single analysis_events row. Every field is independently nullable except
 * `event_id` (an explanation with no event reference has nothing to be
 * "about", same convention as DecisionQuality's own `event_id`) and
 * `has_sufficient_evidence` (always a real boolean, never itself unknown).
 */
export interface MomentExplanation {
  /** Match-level attribute, sourced only from the underlying
   * DecisionQuality (itself sourced only from FootballMatchContext) —
   * never supplied independently. */
  football_type: FootballType | null;
  match_id: string | null;
  /** The analysis_events row this explanation is about. Required — see
   * interface doc comment above. */
  event_id: string;
  /** Reused verbatim from the underlying DecisionQuality — never
   * re-derived. */
  player: TacticalPositionPlayerRef | null;
  timestamp_seconds: number | null;

  /** WHAT happened — DecisionQuality's own `action`
   * (UnifiedFootballEvent.description), verbatim. Null when unknown. */
  what_happened: string | null;
  /** WHY it happened — DecisionQuality's own `reasons`, verbatim. Null
   * when no such evidence exists. */
  why_it_happened: string[] | null;

  /** A better option — populated ONLY when evaluateDecisionQualityEvidence
   * (10G-2) reports one as evidenced. Null otherwise, even if the
   * underlying UnifiedFootballEvent's own `better_option` string was
   * non-empty (see file header — "never fabricate"). */
  better_option: DecisionOption | null;
  /** WHY that option is better — the same evidence that justified
   * `better_option` above (its own `evidence`, or the record's own
   * `reasons`). Always null when `better_option` is null. */
  why_better: string[] | null;
  /** Actionable improvement — `better_option.label`, verbatim. Always
   * null when `better_option` is null. */
  actionable_improvement: string | null;

  /** Confidence in this explanation's own underlying assessment —
   * DecisionQuality's own `confidence`, pass-through. Independent of
   * `has_sufficient_evidence` below (see file header, "confidence...
   * pass-through"). Null when unknown. */
  confidence: number | null;
  /** De-duplicated union of DecisionQuality's own `reasons` and
   * `source_references` — the evidence backing this explanation as a
   * whole. Null when neither exists. */
  evidence: string[] | null;
  /** Exactly evaluateDecisionQualityEvidence's own `has_sufficient_evidence`
   * (10G-2) — whether there was enough real evidence to grade this moment
   * at all. */
  has_sufficient_evidence: boolean;

  /** Caller-supplied tactical/spatial context for this SAME event, reused
   * verbatim from 10E/10F — never re-derived, never re-parsed. Null
   * whenever not supplied, or supplied for a different event (see file
   * header — dropped rather than misattributed). */
  positions: TacticalPositionState | null;
  passing_lane: PassingLane | null;
  space: Space | null;
}

// ============================================================
// 2. UnifiedFootballEvent (+ optional tactical/spatial context) ->
//    MomentExplanation
// ============================================================

function isNonEmptyArray<T>(value: readonly T[] | null | undefined): value is T[] {
  return Array.isArray(value) && value.length > 0;
}

/** De-duplicates while preserving first-seen order — never adds a string
 * that was not already present in `a` or `b`. */
function mergeEvidence(a: string[] | null, b: string[] | null): string[] | null {
  const merged: string[] = [];
  for (const entry of [...(a ?? []), ...(b ?? [])]) {
    if (!merged.includes(entry)) merged.push(entry);
  }
  return merged.length > 0 ? merged : null;
}

/** The same evidence that justified `better_option` per
 * hasSufficientEvidenceForBetterOption's own OR condition
 * (decisionQualityEvidence.ts): the option's own evidence when it has any,
 * else the record's own `reasons` — never a third, separately invented
 * source. Only ever called once `better_option` is already confirmed
 * evidenced (see buildMomentExplanationFromUnifiedEvent below). */
function whyBetterFor(betterOption: DecisionOption, decision: DecisionQuality): string[] | null {
  return isNonEmptyArray(betterOption.evidence) ? betterOption.evidence : decision.reasons;
}

/** Caller-supplied tactical/spatial context to attach to a
 * MomentExplanation, all optional and all reused verbatim — never
 * re-derived, never re-parsed (see file header). */
export interface MomentExplanationContext {
  positions?: TacticalPositionState | null;
  passingLane?: PassingLane | null;
  space?: Space | null;
}

/** True when a TacticalPositionState's own `actual` position is either
 * sourced from THIS event's own tactical_analysis row, or carries no
 * event reference at all (a context-sourced position, which is never
 * event-specific to begin with — see TacticalPositionSourceType). A
 * position sourced from a *different* event's tactical_analysis row is
 * never a match. */
function positionsMatchEvent(positions: TacticalPositionState, eventId: string): boolean {
  const sourceEventId = positions.actual.source.event_id;
  return sourceEventId === null || sourceEventId === eventId;
}

/**
 * Builds ONE MomentExplanation from an already-built UnifiedFootballEvent
 * (10D), reusing buildDecisionQualityFromUnifiedEvent (10G-1) and
 * evaluateDecisionQualityEvidence (10G-2) rather than re-deriving either.
 * `context` is caller-supplied tactical/spatial evidence for this SAME
 * event — see MomentExplanationContext above; omitted entirely, this
 * function still returns a fully evidence-gated explanation with
 * `positions`/`passing_lane`/`space` all null.
 */
export function buildMomentExplanationFromUnifiedEvent(
  event: UnifiedFootballEvent,
  context: MomentExplanationContext = {}
): MomentExplanation {
  const decision = buildDecisionQualityFromUnifiedEvent(event);
  const evidenceResult = evaluateDecisionQualityEvidence(decision);
  const betterOption = evidenceResult.better_option;

  const positions =
    context.positions && positionsMatchEvent(context.positions, event.id) ? context.positions : null;
  const passingLane =
    context.passingLane && context.passingLane.source.event_id === event.id ? context.passingLane : null;
  const space = context.space && context.space.source.event_id === event.id ? context.space : null;

  return {
    football_type: decision.football_type,
    match_id: decision.match_id,
    event_id: decision.event_id,
    player: decision.player,
    timestamp_seconds: decision.timestamp_seconds,

    what_happened: decision.action,
    why_it_happened: decision.reasons,

    better_option: betterOption,
    why_better: betterOption !== null ? whyBetterFor(betterOption, decision) : null,
    actionable_improvement: betterOption !== null ? betterOption.label : null,

    confidence: decision.confidence,
    evidence: mergeEvidence(decision.reasons, decision.source_references),
    has_sufficient_evidence: evidenceResult.has_sufficient_evidence,

    positions,
    passing_lane: passingLane,
    space,
  };
}
