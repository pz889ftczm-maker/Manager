// Batch 7C — Team Members: small, pure, dependency-light helpers for
// public.team_members (migration 0019_team_members.sql), shared between
// the web team-member-management helper (apps/web/src/lib/teamMembers.ts)
// and anything else that needs to validate a (team_id, player_id) pair
// before sending it to Supabase.
//
// Deliberately thin. Unlike PlayerLibraryInput/ManagerLibraryInput, a
// team_members row has no user-editable descriptive fields to sanitize
// (spec section 4 — "Do NOT duplicate player data into team_members");
// the only thing worth validating client-side ahead of the network
// round-trip is "are these two values even syntactically usable as
// ids", since RLS (0019) is the actual authority on whether the caller
// is allowed to use them.
//
// isUniqueViolation is reused as-is from playerLibrary.ts (already a
// pure, domain-agnostic SQLSTATE 23505 check — see that file's doc
// comment) rather than redeclared here, so packages/shared/src/index.ts's
// `export *` doesn't hit a duplicate-export collision on the same name
// (same reasoning managerLibrary.ts already documents for its own
// re-export of this function).
import { isUniqueViolation } from "./playerLibrary.js";

export { isUniqueViolation };

/** The exact name of the unique constraint from migration 0019 —
 * kept as one named constant so callers can recognize "this pair is
 * already a member of this team" (spec section 6 — "duplicate
 * `(team_id, player_id)` must fail safely") apart from any other
 * unique-violation, the same way PLAYER_LIBRARY_VARIANT_UNIQUE_CONSTRAINT
 * (playerLibrary.ts) does for player_library. */
export const TEAM_MEMBERS_UNIQUE_CONSTRAINT = "team_members_team_player_uniq";

export interface TeamMemberInput {
  team_id: string;
  player_id: string;
}

export interface TeamMemberValidationResult {
  valid: boolean;
  errors: string[];
}

// A Postgres uuid, checked loosely (this is a pre-flight client-side
// sanity check, not the source of truth — RLS and the FK constraints in
// 0019 are). Deliberately not stricter than "is this shaped like a
// uuid" — inventing a stricter format here risks rejecting a
// technically-valid uuid variant Postgres itself would accept.
const UUID_SHAPE = /^[0-9a-f]{8}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{12}$/i;

/** Exported so other modules needing the same loose uuid-shape
 * pre-flight check (e.g. teamManager.ts's manager assignment
 * validation) can reuse it instead of redeclaring the pattern —
 * same "don't let two modules' notion of a valid id drift apart"
 * reasoning as isUniqueViolation's reuse across playerLibrary.ts/
 * managerLibrary.ts/teamMembers.ts. */
export function isUuidShaped(raw: unknown): raw is string {
  return typeof raw === "string" && UUID_SHAPE.test(raw.trim());
}

function sanitizeId(raw: unknown, field: string, errors: string[]): string | null {
  if (typeof raw !== "string" || raw.trim().length === 0) {
    errors.push(`${field}: expected a non-empty string, got ${JSON.stringify(raw)}`);
    return null;
  }
  const trimmed = raw.trim();
  if (!isUuidShaped(trimmed)) {
    errors.push(`${field}: does not look like a uuid`);
    return null;
  }
  return trimmed;
}

/**
 * Validates a (team_id, player_id) pair before it's sent to Supabase to
 * insert a public.team_members row. Never throws; a missing/malformed
 * id is reported in `errors` rather than guessed at or silently
 * defaulted — same never-fabricate convention as
 * validatePlayerLibraryInput/validateManagerLibraryInput. This is a
 * client-side early-feedback check only: the actual ownership
 * authorization decision is made by RLS (0019_team_members.sql), never
 * here, and never bypassed by this returning `valid: true`.
 */
export function validateTeamMemberInput(input: unknown): TeamMemberValidationResult {
  const errors: string[] = [];

  if (!input || typeof input !== "object" || Array.isArray(input)) {
    return { valid: false, errors: ["input is not an object"] };
  }

  const d = input as Record<string, unknown>;
  sanitizeId(d.team_id, "team_id", errors);
  sanitizeId(d.player_id, "player_id", errors);

  return { valid: errors.length === 0, errors };
}
