// Batch 6B-4 — Manager Library: shared validation for the user-reviewed,
// save-bound Manager Library record, plus small pure helpers reused by
// both the manager-library-save Edge Function (server-side authority) and
// the web Manager Review/Edit UI (client-side early feedback).
//
// Deliberately a SEPARATE shape/module from ManagerCardDraft
// (managerCard.ts) — same reasoning as playerLibrary.ts's split from
// playerCard.ts (see that file's header comment) and this batch's own
// spec ("The USER is authoritative. AI extraction is only a draft.").
// A ManagerCardDraft is unreviewed AI output; ManagerLibraryInput is what
// a human reviewer explicitly confirmed or corrected and is asking to
// persist to public.manager_library. Nothing in this file runs against a
// ManagerCardDraft directly, and nothing here is invoked automatically
// after an extraction — only after an explicit user Save action (see
// manager-library-save/index.ts's header comment).
//
// Reuses the same per-field sanitizers as playerCard.ts/managerCard.ts
// (sanitizeNullableString, isFiniteNumber) — the underlying field-level
// rules are IDENTICAL (same NULL/UNKNOWN contract, same "never coerce to
// a guess, never default to 0" rule) — importing them keeps the
// validators from silently drifting apart instead of duplicating the
// logic here.

import { sanitizeNullableString, isFiniteNumber } from "./playerCard.js";
// isUniqueViolation is a pure, domain-agnostic SQLSTATE 23505 check (see
// playerLibrary.ts's doc comment) — reused here rather than redeclared,
// so the two modules can't drift apart and packages/shared/src/index.ts's
// `export *` doesn't hit a duplicate-export collision on the same name.
import { isUniqueViolation } from "./playerLibrary.js";

export { isUniqueViolation };

/** Shape of what a reviewer submits to persist — mirrors the columns
 * public.manager_library actually has (migration
 * 0014_manager_library.sql), minus server-controlled columns
 * (id/user_id/created_at/updated_at) and minus `metadata`, which this
 * batch's Review/Edit UI never sets. */
export interface ManagerLibraryInput {
  name: string | null;
  possession_rating: number | null;
  quick_counter_rating: number | null;
  long_ball_counter_rating: number | null;
  out_wide_rating: number | null;
  long_ball_rating: number | null;
  /** Storage object path in the private `manager-images` bucket, or null
   * for a library entry saved without a manager image. Ownership (must
   * sit under the caller's own `{user_id}/` prefix) is NOT checked here —
   * that requires the authenticated user's id, which this pure,
   * dependency-free module deliberately doesn't take. The caller
   * (manager-library-save Edge Function) checks ownership separately via
   * isPathOwnedByUser (uploadValidation.ts), same as
   * validatePlayerLibraryInput's caller. */
  manager_image_path: string | null;
}

export interface ManagerLibraryValidationResult {
  valid: boolean;
  sanitized: ManagerLibraryInput;
  errors: string[];
}

/** A manager style rating must be a non-negative integer, or null. No
 * artificial upper bound — same reasoning as sanitizeNullableRating in
 * managerCard.ts and manager_library's `check (rating >= 0)` columns
 * (0014_manager_library.sql). Never coerces an invalid/missing value to
 * 0 — always null, per the spec's "Do NOT convert NULL to 0" rule. */
function sanitizeNullableRating(raw: unknown, field: string, errors: string[]): number | null {
  if (raw === undefined || raw === null) return null;
  if (!isFiniteNumber(raw) || !Number.isInteger(raw) || raw < 0) {
    errors.push(`${field}: invalid value ${JSON.stringify(raw)} — discarded to null`);
    return null;
  }
  return raw;
}

/** Same no-path-traversal rule already enforced at the DB layer by
 * manager_library_image_path_no_traversal (migration 0014) — checked
 * here too so a malformed path is rejected with a clear, attributable
 * error before it ever reaches Postgres, rather than only surfacing as
 * an opaque CHECK-constraint failure. Ownership-prefix is intentionally
 * NOT checked here — see ManagerLibraryInput's doc comment above. */
function sanitizeImagePath(raw: unknown, errors: string[]): string | null {
  if (raw === undefined || raw === null) return null;
  if (typeof raw !== "string") {
    errors.push(`manager_image_path: expected string or null, got ${JSON.stringify(raw)} — discarded to null`);
    return null;
  }
  const trimmed = raw.trim();
  if (trimmed.length === 0) return null;
  if (trimmed.includes("..")) {
    errors.push("manager_image_path: path traversal sequence rejected — discarded to null");
    return null;
  }
  return trimmed;
}

/**
 * Validates a reviewer-submitted ManagerLibraryInput-shaped object before
 * it's persisted to public.manager_library. Same never-throws,
 * never-coerce-to-a-guess convention as validatePlayerLibraryInput: a
 * failing field is dropped to null with the reason recorded in `errors`,
 * never silently replaced with a fabricated value. Takes `unknown` rather
 * than the strict type — this runs server-side, on a raw request body
 * nobody should trust yet.
 */
export function validateManagerLibraryInput(input: unknown): ManagerLibraryValidationResult {
  const errors: string[] = [];

  if (!input || typeof input !== "object" || Array.isArray(input)) {
    return {
      valid: false,
      errors: ["input is not an object"],
      sanitized: {
        name: null,
        possession_rating: null,
        quick_counter_rating: null,
        long_ball_counter_rating: null,
        out_wide_rating: null,
        long_ball_rating: null,
        manager_image_path: null,
      },
    };
  }

  const d = input as Record<string, unknown>;

  const sanitized: ManagerLibraryInput = {
    name: sanitizeNullableString(d.name, "name", errors),
    possession_rating: sanitizeNullableRating(d.possession_rating, "possession_rating", errors),
    quick_counter_rating: sanitizeNullableRating(d.quick_counter_rating, "quick_counter_rating", errors),
    long_ball_counter_rating: sanitizeNullableRating(
      d.long_ball_counter_rating,
      "long_ball_counter_rating",
      errors
    ),
    out_wide_rating: sanitizeNullableRating(d.out_wide_rating, "out_wide_rating", errors),
    long_ball_rating: sanitizeNullableRating(d.long_ball_rating, "long_ball_rating", errors),
    manager_image_path: sanitizeImagePath(d.manager_image_path, errors),
  };

  // "no fabricated required fields" — deliberately no check here
  // requiring name/ratings to be non-null. A manager entry with only a
  // name, or only an image, is valid; the NULL/UNKNOWN rule applies just
  // as much at save time as it does at extraction time.
  //
  // An omitted/unknown field (above) and a malformed EXPLICIT value are
  // different cases. Omission is valid. But when a caller explicitly
  // supplies a value and it fails a per-field check (wrong type,
  // negative/non-integer rating, invalid image-path syntax), that is
  // malformed input, not "unknown" — the field is still nulled in
  // `sanitized` for safe typing, but the input as a whole must NOT be
  // reported as valid. Server-side persistence (manager-library-save)
  // must reject malformed input rather than silently rewriting it to
  // null and saving anyway.
  return { valid: errors.length === 0, sanitized, errors };
}

// ============================================================
// Duplicate-save handling
// ============================================================
//
// public.manager_library_user_variant_uniq (migration 0014) is a
// PARTIAL, EXPRESSION unique index — unique on (user_id, lower(name),
// possession_rating, quick_counter_rating, long_ball_counter_rating,
// out_wide_rating, long_ball_rating) WHERE name IS NOT NULL. Postgres
// enforces it; nothing here re-implements that enforcement. These two
// small helpers let a caller (manager-library-save) (a) recognize that a
// failed insert/update failed BECAUSE of this exact constraint rather
// than some other error, and (b) build the same normalized key
// Postgres's expression index groups on, so it can look up and return
// the pre-existing row instead of surfacing a raw constraint-violation
// error to an accidental double-click/retry.

/** The exact name of the partial unique index from migration 0014 — kept
 * as one named constant so the Edge Function and this file can't drift
 * apart if it's ever renamed. */
export const MANAGER_LIBRARY_VARIANT_UNIQUE_CONSTRAINT = "manager_library_user_variant_uniq";

export interface ManagerLibraryVariantKey {
  nameLower: string;
  possession_rating: number | null;
  quick_counter_rating: number | null;
  long_ball_counter_rating: number | null;
  out_wide_rating: number | null;
  long_ball_rating: number | null;
}

/** Builds the same (lower(name), ...ratings) key the DB's partial unique
 * index groups rows by, so a caller that just caught a unique-violation
 * on manager_library_user_variant_uniq can look up the exact
 * pre-existing row that conflicted. Returns null when `name` is null —
 * the constraint itself doesn't apply to null-named entries (see
 * migration 0014's design notes), so there is no variant key to
 * compute. */
export function managerLibraryVariantKey(
  input: Pick<
    ManagerLibraryInput,
    | "name"
    | "possession_rating"
    | "quick_counter_rating"
    | "long_ball_counter_rating"
    | "out_wide_rating"
    | "long_ball_rating"
  >
): ManagerLibraryVariantKey | null {
  if (input.name === null) return null;
  return {
    nameLower: input.name.toLowerCase(),
    possession_rating: input.possession_rating,
    quick_counter_rating: input.quick_counter_rating,
    long_ball_counter_rating: input.long_ball_counter_rating,
    out_wide_rating: input.out_wide_rating,
    long_ball_rating: input.long_ball_rating,
  };
}
