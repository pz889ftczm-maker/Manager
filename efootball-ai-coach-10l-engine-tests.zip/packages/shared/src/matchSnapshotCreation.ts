// Batch 9B — Historical Match Snapshot Creation SERVICE. Pure,
// dependency-free helpers shared by supabase/functions/
// match-snapshot-create/index.ts:
//
//   1. validateMatchSnapshotCreateRequest — checks the untrusted
//      request body's shape (spec section 3: "accept only the minimum
//      required identifiers, such as match_id, team_id, formation_id
//      ... Do NOT accept historical player names, stats, manager
//      ratings, team metadata ... from the client"). This is NOT an
//      ownership check (a well-formed uuid the caller doesn't own is
//      still "valid" here) — ownership is entirely public.
//      create_match_snapshot's job (migration
//      0026_match_snapshot_creation.sql), the same "pure syntactic
//      validation only, authorization lives in the database" split
//      matchSnapshots.ts's own validateMatchSnapshotInput/
//      validateMatchSnapshotPlayerInput already use.
//
//   2. mapSnapshotCreationRpcError — translates one of that SQL
//      function's own internal-only `match_snapshot_create: <code>`
//      RAISE EXCEPTION messages into one of spec section 17's literal
//      safe, client-facing strings. The raw Postgres error (message,
//      SQLSTATE, detail, hint, stack) is never returned to the client
//      by either this function or the Edge Function that calls it —
//      only logged server-side (same internalErrorResponse convention
//      every other Edge Function in this repo already follows). An
//      unrecognized message (a genuinely unexpected DB error) maps to
//      the same generic fallback as no-code-at-all, never leaks its
//      own text.
//
// Reuses matchSnapshots.ts's own sanitizeRequiredUuid/
// sanitizeNullableUuid (same uuid-shape regex, same "required fails
// the whole request / optional discards to null" contract) rather
// than re-implementing uuid validation here.

import { sanitizeRequiredUuid, sanitizeNullableUuid } from "./matchSnapshots.js";

/** Shape of the untrusted request body for POST /match-snapshot-create.
 * Deliberately has ONLY these three fields — see this file's header
 * comment ("accept only the minimum required identifiers"). */
export interface MatchSnapshotCreateRequest {
  match_id: string;
  team_id: string;
  formation_id: string | null;
}

export interface MatchSnapshotCreateRequestValidationResult {
  valid: boolean;
  sanitized: MatchSnapshotCreateRequest;
  errors: string[];
}

const EMPTY_REQUEST: MatchSnapshotCreateRequest = {
  match_id: "",
  team_id: "",
  formation_id: null,
};

/**
 * Validates the untrusted POST body before it's ever passed to
 * public.create_match_snapshot: match_id and team_id are required,
 * well-formed uuids (spec section 4 — the service needs both to even
 * attempt an ownership check); formation_id is optional (spec section
 * 9 — a team may legitimately have no formation selected yet) and a
 * malformed value is discarded to null rather than failing the whole
 * request, same convention as every other optional provenance id in
 * matchSnapshots.ts. Never throws; never accepts (or even looks at)
 * any other field the caller might have sent — team/player/manager
 * metadata, historical values, or a client-supplied user_id are all
 * silently ignored here, not merely rejected, since this validator
 * only ever reads the three keys above off the input object.
 */
export function validateMatchSnapshotCreateRequest(input: unknown): MatchSnapshotCreateRequestValidationResult {
  if (!input || typeof input !== "object" || Array.isArray(input)) {
    return { valid: false, errors: ["input is not an object"], sanitized: EMPTY_REQUEST };
  }

  const d = input as Record<string, unknown>;
  const errors: string[] = [];

  const sanitized: MatchSnapshotCreateRequest = {
    match_id: sanitizeRequiredUuid(d.match_id, "match_id", errors),
    team_id: sanitizeRequiredUuid(d.team_id, "team_id", errors),
    formation_id: sanitizeNullableUuid(d.formation_id, "formation_id", errors),
  };

  return { valid: errors.length === 0, sanitized, errors };
}

/** One of the internal-only `match_snapshot_create: <code>` messages
 * public.create_match_snapshot (migration 0026) raises. Exported so
 * the Edge Function and this file's own tests can't drift apart on
 * the exact strings expected from the database. */
export type SnapshotCreationRpcErrorCode =
  | "not_authenticated"
  | "match_not_found"
  | "team_not_found"
  | "formation_not_found"
  | "manager_ownership_invalid"
  | "player_ownership_invalid"
  | "snapshot_missing_after_conflict";

export interface SafeSnapshotCreationError {
  status: number;
  error: string;
}

/** Generic fallback (spec section 17's own literal wording) for any
 * error this table doesn't specifically recognize — including a
 * genuinely unexpected Postgres error, which must never have its own
 * message/detail/hint text forwarded to the client. */
const GENERIC_FALLBACK: SafeSnapshotCreationError = {
  status: 500,
  error: "Unable to create match snapshot.",
};

/** Table-driven mapping from a recognized RPC error code to one of
 * spec section 17's own literal safe strings + an appropriate HTTP
 * status. Kept as a plain lookup table (rather than a chain of
 * if/else on substrings) so every mapped message stays exactly the
 * spec-mandated text and new codes can't be added without an explicit
 * decision about their client-facing wording. */
const KNOWN_ERROR_RESPONSES: Record<SnapshotCreationRpcErrorCode, SafeSnapshotCreationError> = {
  not_authenticated: { status: 401, error: "Unable to create match snapshot." },
  match_not_found: { status: 403, error: "Match does not belong to this user." },
  team_not_found: { status: 403, error: "Team does not belong to this user." },
  formation_not_found: { status: 422, error: "Formation does not belong to this team." },
  manager_ownership_invalid: {
    status: 422,
    error: "Unable to create match snapshot because the selected configuration is invalid.",
  },
  player_ownership_invalid: {
    status: 422,
    error: "Unable to create match snapshot because the selected configuration is invalid.",
  },
  snapshot_missing_after_conflict: GENERIC_FALLBACK,
};

const MESSAGE_PREFIX = "match_snapshot_create: ";

/**
 * Maps a raw Postgres/PostgREST error (as returned by supabase-js's
 * .rpc() call to public.create_match_snapshot) to a safe, client-
 * facing { status, error } pair. Only ever inspects `err.message` —
 * never returns any part of `err` itself (spec section 17: "Never
 * expose SQL errors, Postgres errors, Supabase internals, ... stack
 * traces"). Any message that isn't exactly one of this function's own
 * known `match_snapshot_create: <code>` strings (including a message
 * that doesn't have that prefix at all, or has an unrecognized code
 * after it) falls back to the same generic response spec section 17
 * itself gives as an example — the caller is expected to still log
 * the original `err` server-side (this function does not log
 * anything itself; that stays the Edge Function's job, same
 * convention as internalErrorResponse in supabase/functions/_shared/
 * helpers.ts).
 */
export function mapSnapshotCreationRpcError(err: unknown): SafeSnapshotCreationError {
  if (!err || typeof err !== "object") return GENERIC_FALLBACK;
  const message = (err as { message?: unknown }).message;
  if (typeof message !== "string" || !message.startsWith(MESSAGE_PREFIX)) return GENERIC_FALLBACK;

  const code = message.slice(MESSAGE_PREFIX.length).trim() as SnapshotCreationRpcErrorCode;
  return KNOWN_ERROR_RESPONSES[code] ?? GENERIC_FALLBACK;
}
