// Batch 10G-2 — Decision Quality EVIDENCE LOGIC only. Pure functions
// that decide whether a 10G-1 DecisionQuality record has enough real
// evidence to be graded at all, and — only when it does — what that
// grade is. No AI calls, no database access, no new fields on
// DecisionQuality, no changes to 10D (footballEvent.ts)/10E
// (tacticalPosition.ts)/10F (passingLaneSpaceModel.ts), and no
// scope creep into 10G-3+.
//
// EVIDENCE FIRST (spec — the one rule this whole file exists to
// enforce): a DecisionQuality record's `score` alone is never treated
// as sufficient to grade a decision. Grading requires the record to
// also carry at least one real, caller/AI-supplied evidence source —
// `reasons`, `source_references`, `chosen_option.evidence`, or an
// `available_options[].evidence` entry. A record with a score but no
// evidence anywhere is graded `null`, not defaulted to a middling
// grade.
//
// NEVER JUDGE FROM OUTCOME ALONE (spec): this file never accepts a
// match/event outcome (result, goals, win/loss) as input — there is no
// such field on DecisionQuality (see decisionQuality.ts's file header)
// and no function below takes one as a parameter, so it is structurally
// impossible for this file's grading to be outcome-derived.
//
// BETTER_OPTION REQUIRES EVIDENCE, ELSE NULL (spec): 10G-1's
// validateDecisionQualityInput already rejects an unevidenced
// better_option at the write path, but this file does not assume every
// DecisionQuality it is handed went through that gate (e.g. a record
// built directly by buildDecisionQualityFromUnifiedEvent, or
// reconstructed from a persisted row). evaluateDecisionQualityEvidence
// below re-checks that evidence at read time and reports `null`
// instead of `better_option` whenever it is missing — evidence is
// re-verified here, never re-trusted.
//
// INSUFFICIENT EVIDENCE -> QUALITY NULL (spec): see
// hasSufficientEvidence/evaluateDecisionQualityEvidence below — this is
// the central branch of this file.
//
// NEVER FABRICATE OR INFER MISSING DATA (spec): every function here is
// a pure read of fields the caller already populated. Nothing is
// counted, averaged, guessed, or backfilled from a related record —
// only the DecisionQuality object passed in is consulted.
//
// EFOOTBALL / REAL FOOTBALL SEPARATION PRESERVED (spec): `football_type`
// is passed through unchanged on the result and never inspected to
// change grading behavior — same convention as decisionQuality.ts, no
// per-football-type branching anywhere in this file.
//
// HISTORICAL SNAPSHOT PRECEDENCE PRESERVED (spec): this file never
// reads match/formation/roster data itself — it only grades the
// DecisionQuality record it is handed, which (via
// buildDecisionQualityFromUnifiedEvent) already reflects whatever
// snapshot-vs-live precedence efootballMatchContext.ts/
// realFootballMatchContext.ts already applied upstream. Nothing here
// re-derives or second-guesses that.

import type { DecisionQuality, DecisionOption } from "./decisionQuality.js";

// ============================================================
// 1. Grade vocabulary
// ============================================================

/**
 * A coarse, evidence-gated quality grade — deliberately small and
 * ordinal, mirroring the closed-vocabulary convention of
 * types.ts#EventSeverity/ConfidenceLevel rather than exposing the raw
 * 0-100 `score` as a label. Only ever produced when
 * hasSufficientEvidence(decision) is true (see below) — never present
 * without it.
 */
export type DecisionQualityRating = "good" | "average" | "poor";

// ============================================================
// 2. Evidence detection — never fabricated, only observed
// ============================================================

function isNonEmptyArray<T>(value: readonly T[] | null | undefined): boolean {
  return Array.isArray(value) && value.length > 0;
}

function optionHasEvidence(option: DecisionOption | null | undefined): boolean {
  return !!option && isNonEmptyArray(option.evidence);
}

/**
 * True when at least one option in the list itself carries evidence.
 * An option with a label but no `evidence` is not, on its own, proof
 * of anything (see decisionQuality.ts's own DecisionOption doc
 * comment) — it does not count here.
 */
function anyOptionHasEvidence(options: readonly DecisionOption[] | null | undefined): boolean {
  return Array.isArray(options) && options.some((o) => optionHasEvidence(o));
}

/**
 * Does this DecisionQuality record carry ANY real evidence at all —
 * record-level `reasons`/`source_references`, the chosen option's own
 * evidence, or any available option's own evidence? `better_option`'s
 * own evidence is deliberately NOT one of the sources checked here:
 * evidence for a *proposed alternative* is not, by itself, evidence
 * that the *actual* decision can be graded — see
 * hasSufficientEvidenceForBetterOption below for that separate check.
 */
export function hasSufficientEvidence(decision: DecisionQuality): boolean {
  if (decision.score === null) return false;
  return (
    isNonEmptyArray(decision.reasons) ||
    isNonEmptyArray(decision.source_references) ||
    optionHasEvidence(decision.chosen_option) ||
    anyOptionHasEvidence(decision.available_options)
  );
}

/**
 * Mirrors validateDecisionQualityInput's own write-path rule for
 * `better_option` (decisionQuality.ts): a better_option may be
 * reported only when it has its own evidence, or the record carries
 * record-level `reasons`. Checked independently of
 * hasSufficientEvidence above — a decision can be gradable with no
 * evidenced better_option, and (in principle, from a hand-built
 * record that skipped validation) a better_option could carry
 * evidence the record's `score`/`reasons` otherwise lack.
 */
export function hasSufficientEvidenceForBetterOption(decision: DecisionQuality): boolean {
  if (!decision.better_option) return false;
  return optionHasEvidence(decision.better_option) || isNonEmptyArray(decision.reasons);
}

// ============================================================
// 3. Grading — evidence-gated, score-derived, never outcome-derived
// ============================================================

/** Pure 0-100 -> rating mapping. Never called unless the caller has
 * already confirmed evidence exists (see evaluateDecisionQualityEvidence)
 * — this function has no evidence-awareness of its own, by design, so
 * it can never accidentally be used to grade an unevidenced score. */
function ratingFromScore(score: number): DecisionQualityRating {
  if (score >= 70) return "good";
  if (score >= 40) return "average";
  return "poor";
}

export interface DecisionQualityEvidenceResult {
  /** Pass-through, unchanged — see file header, "separation preserved". */
  football_type: DecisionQuality["football_type"];
  event_id: string;
  /** True only when hasSufficientEvidence(decision) is true. */
  has_sufficient_evidence: boolean;
  /** Null whenever has_sufficient_evidence is false — "insufficient
   * evidence -> quality null" (spec). Never a default/guessed grade. */
  quality: DecisionQualityRating | null;
  /** decision.better_option, re-verified against
   * hasSufficientEvidenceForBetterOption — null when that check
   * fails, even if decision.better_option was non-null going in. */
  better_option: DecisionOption | null;
}

/**
 * The single entry point for 10G-2: evidence-gates and grades one
 * already-built DecisionQuality record. Read-only — never mutates
 * `decision`, never persists anything, never calls an AI provider.
 */
export function evaluateDecisionQualityEvidence(
  decision: DecisionQuality
): DecisionQualityEvidenceResult {
  const sufficient = hasSufficientEvidence(decision);
  const quality = sufficient && decision.score !== null ? ratingFromScore(decision.score) : null;
  const betterOption = hasSufficientEvidenceForBetterOption(decision) ? decision.better_option : null;

  return {
    football_type: decision.football_type,
    event_id: decision.event_id,
    has_sufficient_evidence: sufficient,
    quality,
    better_option: betterOption,
  };
}
