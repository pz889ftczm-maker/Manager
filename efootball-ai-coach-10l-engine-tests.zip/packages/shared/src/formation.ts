// Batch 6A-5 — Player Library -> Formation display connection ONLY.
//
// No Formation Library / Manager Library / Team Presets table exists yet
// (spec sections 9 explicitly forbids creating them in this batch) — the
// formation itself is client-side, ephemeral UI state in
// apps/web/src/routes/Formation.tsx. What lives here is just the small,
// pure, dependency-free shape/helpers that state is built from, kept
// separate (and unit-testable without React/Supabase) the same way
// playerLibrary.ts and playerCard.ts keep their own pure validators
// separate from the Edge Functions/UI that call them.
//
// FormationPlayerRef is deliberately NOT the full PlayerLibrary row (spec
// section 2: "do not duplicate the entire player record into the
// formation UI state unless needed for rendering") — just the fields a
// formation slot actually renders, plus the id needed to re-fetch or
// re-associate later. This shape is also what a future Team Presets
// table would persist per slot (spec section 9's "future compatibility"),
// so it's kept as a plain, storage-agnostic value type now rather than
// something React-only.

import type { ManagerLibrary, PlayerLibrary } from "./types.js";
import { isPathOwnedByUser } from "./uploadValidation.js";

export interface FormationPlayerRef {
  player_library_id: string;
  name: string | null;
  position: string | null;
  overall: number | null;
  playstyle: string | null;
  player_card_image_path: string | null;
}

/** Projects a full player_library row down to just what a formation slot
 * needs to render (spec section 2). Pure — no ownership/auth decisions
 * here, those stay in isFormationCardImageOwned below. */
export function toFormationPlayerRef(entry: PlayerLibrary): FormationPlayerRef {
  return {
    player_library_id: entry.id,
    name: entry.name,
    position: entry.position,
    overall: entry.overall,
    playstyle: entry.playstyle,
    player_card_image_path: entry.player_card_image_path,
  };
}

export interface FormationCardDisplay {
  /** Never blank — a player with no saved name still needs a label. */
  displayName: string;
  /** Null (not shown) when the position wasn't recorded — never rendered
   * as an empty string or a fake default position. */
  positionLabel: string | null;
  /** Null (not shown) when overall wasn't recorded — never coerced to 0
   * (same NULL/UNKNOWN convention as player_library itself). */
  overallLabel: string | null;
  /** Whether a card image is expected for this slot at all. False for an
   * empty slot AND for a player saved without a card image — both cases
   * render the same clean placeholder (spec section 3), never a fake or
   * generated image. */
  hasImage: boolean;
}

/** Pure mapping from an (optional) formation slot occupant to what the UI
 * should show, independent of whether the actual image bytes/signed URL
 * loaded successfully. `player == null` means an empty slot. */
export function getFormationCardDisplay(player: FormationPlayerRef | null): FormationCardDisplay {
  if (!player) {
    return { displayName: "Empty slot", positionLabel: null, overallLabel: null, hasImage: false };
  }
  const name = player.name?.trim();
  const position = player.position?.trim();
  return {
    displayName: name ? name : "Unnamed player",
    positionLabel: position ? position : null,
    overallLabel: player.overall != null ? `OVR ${player.overall}` : null,
    hasImage: Boolean(player.player_card_image_path),
  };
}

/** Whether it's safe to even attempt minting a signed URL for this
 * player's card image (spec section 6: "Never generate a signed URL for
 * another user's object"). Reuses the same isPathOwnedByUser check every
 * other private-bucket path in this repo uses — no separate ownership
 * rule invented for formation slots. Returns false (not an error) for an
 * empty slot or a player saved without an image path, same as
 * getFormationCardDisplay's hasImage. */
export function isFormationCardImageOwned(player: FormationPlayerRef | null, userId: string): boolean {
  if (!player?.player_card_image_path) return false;
  return isPathOwnedByUser(player.player_card_image_path, userId);
}

// ============================================================
// Batch 6B-5 — Manager -> Formation/Team-context connection ONLY.
// ============================================================
//
// Same reasoning as the player-side helpers above, applied to a saved
// Manager Library entry instead of a saved Player Library entry: the
// Formation page's manager selection is current-session/page React
// state (spec: "Manager selection can remain current-session/page state
// for now... A later Formation Persistence / Team Preset batch will
// handle permanent persistence" — no Team Library/Team Profile/Team
// Preset table is added here). FormationManagerRef is kept as a plain
// value type for the same future-compatibility reason
// FormationPlayerRef is: so a later persistence batch can store this
// exact shape without reshaping the UI built on it now.

export interface FormationManagerRef {
  manager_library_id: string;
  name: string | null;
  possession_rating: number | null;
  quick_counter_rating: number | null;
  long_ball_counter_rating: number | null;
  out_wide_rating: number | null;
  long_ball_rating: number | null;
  manager_image_path: string | null;
}

/** Projects a full manager_library row down to just what the Formation
 * page's Manager section needs to render — same "don't duplicate the
 * entire row into UI state" reasoning as toFormationPlayerRef. Pure — no
 * ownership/auth decisions here, those stay in
 * isFormationManagerImageOwned below. */
export function toFormationManagerRef(entry: ManagerLibrary): FormationManagerRef {
  return {
    manager_library_id: entry.id,
    name: entry.name,
    possession_rating: entry.possession_rating,
    quick_counter_rating: entry.quick_counter_rating,
    long_ball_counter_rating: entry.long_ball_counter_rating,
    out_wide_rating: entry.out_wide_rating,
    long_ball_rating: entry.long_ball_rating,
    manager_image_path: entry.manager_image_path,
  };
}

export interface FormationManagerDisplay {
  /** Never blank — a manager with no saved name still needs a label. */
  displayName: string;
  /** Every rating is always a renderable "<Label>: <value or Unknown>"
   * line (spec: "NULL values must remain NULL. Do NOT display NULL as
   * fake 0.") — a rating of 0 renders as "...: 0", distinct from an
   * unknown rating rendering as "...: Unknown"; never the reverse. Same
   * NULL/UNKNOWN convention ManagerLibrary.tsx's own list view already
   * uses for these exact fields — reused here as one pure, testable
   * helper rather than re-implemented inline a third time. */
  possessionLabel: string;
  quickCounterLabel: string;
  longBallCounterLabel: string;
  outWideLabel: string;
  longBallLabel: string;
  /** Whether a manager image is expected at all. False when no manager
   * is selected AND for a manager saved without an image — both render
   * the same clean placeholder (never a generated/fake image), same
   * convention as FormationCardDisplay.hasImage. */
  hasImage: boolean;
}

function managerRatingLine(label: string, value: number | null): string {
  return value != null ? `${label}: ${value}` : `${label}: Unknown`;
}

/** Pure mapping from an (optional) selected manager to what the
 * Formation page's Manager section should show, independent of whether
 * the actual image bytes/signed URL loaded successfully.
 * `manager == null` means no manager is currently selected. */
export function getFormationManagerDisplay(manager: FormationManagerRef | null): FormationManagerDisplay {
  if (!manager) {
    return {
      displayName: "No manager selected",
      possessionLabel: managerRatingLine("Possession", null),
      quickCounterLabel: managerRatingLine("Quick Counter", null),
      longBallCounterLabel: managerRatingLine("Long Ball Counter", null),
      outWideLabel: managerRatingLine("Out Wide", null),
      longBallLabel: managerRatingLine("Long Ball", null),
      hasImage: false,
    };
  }
  const name = manager.name?.trim();
  return {
    displayName: name ? name : "Unnamed manager",
    possessionLabel: managerRatingLine("Possession", manager.possession_rating),
    quickCounterLabel: managerRatingLine("Quick Counter", manager.quick_counter_rating),
    longBallCounterLabel: managerRatingLine("Long Ball Counter", manager.long_ball_counter_rating),
    outWideLabel: managerRatingLine("Out Wide", manager.out_wide_rating),
    longBallLabel: managerRatingLine("Long Ball", manager.long_ball_rating),
    hasImage: Boolean(manager.manager_image_path),
  };
}

/** Whether it's safe to even attempt minting a signed URL for this
 * manager's image (same "Never generate a signed URL for another user's
 * object" rule as isFormationCardImageOwned, applied to the private
 * `manager-images` bucket). Reuses the same isPathOwnedByUser check —
 * no separate ownership rule invented for the Manager section. Returns
 * false (not an error) when no manager is selected or the selected
 * manager has no saved image, same as isFormationCardImageOwned. */
export function isFormationManagerImageOwned(manager: FormationManagerRef | null, userId: string): boolean {
  if (!manager?.manager_image_path) return false;
  return isPathOwnedByUser(manager.manager_image_path, userId);
}
