// Batch 3.5 — individual player statistics.
//
// Single source of truth for:
//   - which stat fields exist, grouped by category (mirrors migration
//     0006_player_statistics.sql exactly — keep the two in sync manually)
//   - the TypeScript shape of a match_player_statistics / player_attributes row
//   - semantic validation (spec section 7), shared by the worker (before
//     insert) and re-usable anywhere else that needs to sanity-check a draft.
//
// Hard rule enforced throughout this file: never fabricate a value. Every
// function here either passes a real provided number through (after range/
// consistency checks) or nulls it out with a recorded reason — nothing is
// invented, estimated, or inferred from an unrelated field.

export type StatisticsSource = "screenshot" | "structured_data" | "ai_confirmed" | "unavailable";

// ============================================================
// Field catalog (spec section 3), grouped for the AI prompt + UI.
// ============================================================

export const PASSING_STAT_FIELDS = [
  "passes_attempted",
  "passes_completed",
  "pass_completion_percentage",
  "key_passes",
  "through_passes",
  "crosses",
  "progressive_passes",
  "forward_passes",
  "backward_passes",
  "long_passes",
  "short_passes",
] as const;

export const DRIBBLING_STAT_FIELDS = [
  "dribbles_attempted",
  "successful_dribbles",
  "dribble_success_percentage",
  "ball_control",
  "tight_possession",
  "ball_retention",
  "possession_losses",
  "progressive_carries",
] as const;

export const DEFENDING_STAT_FIELDS = [
  "tackles",
  "successful_tackles",
  "interceptions",
  "clearances",
  "blocks",
  "defensive_recoveries",
  "defensive_actions",
  "pressures",
] as const;

export const DUEL_STAT_FIELDS = [
  "total_duels",
  "ground_duels",
  "ground_duels_won",
  "aerial_duels",
  "aerial_duels_won",
  "physical_challenges",
  "duel_win_percentage",
] as const;

export const ATTACK_STAT_FIELDS = [
  "shots",
  "shots_on_target",
  "goals",
  "assists",
  "chances_created",
  "touches_attacking_third",
  "progressive_actions",
] as const;

export const GOALKEEPING_STAT_FIELDS = [
  "saves",
  "save_percentage",
  "claims",
  "punches",
  "sweeper_actions",
  "goalkeeper_distribution",
] as const;

export const DISCIPLINE_STAT_FIELDS = [
  "fouls",
  "yellow_cards",
  "red_cards",
  "offsides",
] as const;

export const PLAYER_STAT_CATEGORIES = {
  passing: PASSING_STAT_FIELDS,
  dribbling: DRIBBLING_STAT_FIELDS,
  defending: DEFENDING_STAT_FIELDS,
  duels: DUEL_STAT_FIELDS,
  attack: ATTACK_STAT_FIELDS,
  goalkeeping: GOALKEEPING_STAT_FIELDS,
  discipline: DISCIPLINE_STAT_FIELDS,
} as const;

export type PlayerStatCategory = keyof typeof PLAYER_STAT_CATEGORIES;

export const ALL_STAT_FIELDS: string[] = Object.values(PLAYER_STAT_CATEGORIES).flat();

// Fields that are percentages (0-100, may be fractional) vs. counts
// (non-negative integers). Used for range validation.
export const PERCENTAGE_FIELDS = new Set([
  "pass_completion_percentage",
  "dribble_success_percentage",
  "duel_win_percentage",
  "save_percentage",
]);

export type MatchPlayerStatisticsFields = {
  [K in (typeof ALL_STAT_FIELDS)[number]]?: number | null;
};

export interface MatchPlayerStatistics extends MatchPlayerStatisticsFields {
  id: string;
  user_id: string;
  match_id: string;
  player_id: string;
  media_id: string | null;
  source: StatisticsSource;
  confidence: number | null;
  extraction_metadata: Record<string, unknown> | null;
  is_valid: boolean;
  validation_errors: string[];
  created_at: string;
  updated_at: string;
}

// ============================================================
// Player attributes (spec section 4) — a SEPARATE concept from performance.
// ============================================================

export const OUTFIELD_ATTRIBUTE_FIELDS = [
  "speed",
  "acceleration",
  "ball_control",
  "dribbling",
  "tight_possession",
  "low_pass",
  "lofted_pass",
  "defensive_awareness",
  "tackling",
  "aggression",
  "physical_contact",
  "balance",
  "jump",
  "heading",
  "finishing",
  "kicking_power",
] as const;

export const GOALKEEPER_ATTRIBUTE_FIELDS = [
  "gk_awareness",
  "gk_catching",
  "gk_parrying",
  "gk_reflexes",
  "gk_coverage",
] as const;

export const ALL_ATTRIBUTE_FIELDS: string[] = [...OUTFIELD_ATTRIBUTE_FIELDS, ...GOALKEEPER_ATTRIBUTE_FIELDS];

export type PlayerAttributeFields = {
  [K in (typeof ALL_ATTRIBUTE_FIELDS)[number]]?: number | null;
};

export interface PlayerAttributes extends PlayerAttributeFields {
  id: string;
  user_id: string;
  player_id: string;
  media_id: string | null;
  source: StatisticsSource;
  confidence: number | null;
  created_at: string;
  updated_at: string;
}

export interface Player {
  id: string;
  user_id: string;
  name: string | null;
  is_self: boolean;
  position: string | null;
  created_at: string;
  updated_at: string;
}

// ============================================================
// Draft shapes returned by the AI provider, before validation/persistence.
// ============================================================

export interface PlayerStatisticsDraft extends MatchPlayerStatisticsFields {
  /** Player name as it appeared on screen, or null if not shown/legible. */
  playerName: string | null;
  /** Whether this row represents the human user's own controlled player. */
  isSelf: boolean;
  /** Model's own confidence 0-100 in the extraction as a whole. */
  confidence: number;
  /** Short notes on what was actually visible — not persisted verbatim,
   * folded into extraction_metadata. */
  notes?: string;
}

// ============================================================
// Semantic validation (spec section 7)
// ============================================================
//
// Strategy: field-level range checks first, then cross-field consistency
// checks. A failing field (or failing pair) is set to null and the reason
// is recorded — the rest of the record is preserved. Nothing is "fixed"
// into a plausible-looking number.

export interface StatisticsValidationResult {
  sanitized: MatchPlayerStatisticsFields;
  errors: string[];
}

function isFiniteNumber(v: unknown): v is number {
  return typeof v === "number" && Number.isFinite(v);
}

/**
 * Range-checks every present field, dropping (nulling) anything outside
 * its valid domain: percentages must be 0-100, counts must be non-negative.
 * Non-numeric junk is dropped rather than coerced.
 */
function sanitizeRanges(draft: Record<string, unknown>): StatisticsValidationResult {
  const sanitized: MatchPlayerStatisticsFields = {};
  const errors: string[] = [];

  for (const field of ALL_STAT_FIELDS) {
    const raw = draft[field];
    if (raw === undefined || raw === null) continue; // absent — stays null, never fabricated

    if (!isFiniteNumber(raw)) {
      errors.push(`${field}: non-numeric value ${JSON.stringify(raw)} discarded`);
      continue;
    }

    if (PERCENTAGE_FIELDS.has(field)) {
      if (raw < 0 || raw > 100) {
        errors.push(`${field}: ${raw} out of 0-100 range, discarded`);
        continue;
      }
    } else {
      if (raw < 0) {
        errors.push(`${field}: negative count ${raw} discarded`);
        continue;
      }
      if (!Number.isInteger(raw)) {
        errors.push(`${field}: non-integer count ${raw} discarded`);
        continue;
      }
    }

    sanitized[field as keyof MatchPlayerStatisticsFields] = raw;
  }

  return { sanitized, errors };
}

/** Cross-field pairs where the first must be <= the second. Both sides are
 * nulled on violation, since we can't tell which one is actually wrong. */
const ORDER_CONSTRAINTS: [string, string][] = [
  ["passes_completed", "passes_attempted"],
  ["successful_dribbles", "dribbles_attempted"],
  ["shots_on_target", "shots"],
  ["ground_duels_won", "ground_duels"],
  ["aerial_duels_won", "aerial_duels"],
  ["successful_tackles", "tackles"],
  ["goals", "shots_on_target"],
];

function applyOrderConstraints(fields: MatchPlayerStatisticsFields, errors: string[]): void {
  for (const [smaller, larger] of ORDER_CONSTRAINTS) {
    const a = fields[smaller as keyof MatchPlayerStatisticsFields];
    const b = fields[larger as keyof MatchPlayerStatisticsFields];
    if (a != null && b != null && a > b) {
      errors.push(`${smaller} (${a}) exceeds ${larger} (${b}) — both discarded, source data inconsistent`);
      fields[smaller as keyof MatchPlayerStatisticsFields] = null;
      fields[larger as keyof MatchPlayerStatisticsFields] = null;
    }
  }
}

/**
 * Fills a percentage field from its two underlying counts ONLY when the
 * percentage itself wasn't provided and both counts survived validation —
 * this is arithmetic on values the source actually showed (spec section 6's
 * own example: "Passes: 25/30" -> pass_completion_percentage = 83.33),
 * never an invented number.
 */
function deriveMissingPercentages(fields: MatchPlayerStatisticsFields): void {
  const derive = (pctField: string, numField: string, denField: string) => {
    if (fields[pctField as keyof MatchPlayerStatisticsFields] != null) return;
    const num = fields[numField as keyof MatchPlayerStatisticsFields];
    const den = fields[denField as keyof MatchPlayerStatisticsFields];
    if (num != null && den != null && den > 0) {
      fields[pctField as keyof MatchPlayerStatisticsFields] = Math.round((num / den) * 10000) / 100;
    }
  };

  derive("pass_completion_percentage", "passes_completed", "passes_attempted");
  derive("dribble_success_percentage", "successful_dribbles", "dribbles_attempted");
  derive("duel_win_percentage", "ground_duels_won", "ground_duels"); // ground-duel-based approximation when no combined total is given
  derive("save_percentage", "saves", "shots_on_target");
}

export function validatePlayerStatisticsDraft(draft: Record<string, unknown>): StatisticsValidationResult {
  const { sanitized, errors } = sanitizeRanges(draft);
  applyOrderConstraints(sanitized, errors);
  deriveMissingPercentages(sanitized);
  return { sanitized, errors };
}

/** True if the sanitized record has at least one real (non-null) stat —
 * an all-null row isn't worth persisting as evidence. */
export function hasAnyStatistic(fields: MatchPlayerStatisticsFields): boolean {
  return ALL_STAT_FIELDS.some((f) => fields[f as keyof MatchPlayerStatisticsFields] != null);
}

// ============================================================
// Player attribute validation — simpler: attributes are 0-99 int ratings.
// ============================================================

export function validatePlayerAttributesDraft(draft: Record<string, unknown>): StatisticsValidationResult {
  const sanitized: PlayerAttributeFields = {};
  const errors: string[] = [];

  for (const field of ALL_ATTRIBUTE_FIELDS) {
    const raw = (draft as Record<string, unknown>)[field];
    if (raw === undefined || raw === null) continue;
    if (!isFiniteNumber(raw) || !Number.isInteger(raw) || raw < 0 || raw > 99) {
      errors.push(`${field}: invalid attribute value ${JSON.stringify(raw)} discarded`);
      continue;
    }
    (sanitized as Record<string, number>)[field] = raw;
  }

  return { sanitized: sanitized as MatchPlayerStatisticsFields, errors };
}

// ============================================================
// Statistics evidence linking (Batch 3.5 remaining-work item 2).
//
// Given a decision event's category/event_type and the REAL, already-
// validated match_player_statistics fields for the player it belongs to,
// pick the 1-3 most relevant fields (if any are actually present) and
// format them as short citation strings, e.g.
// "pass_completion_percentage: 87.0%". Pure/deterministic: never invents a
// number, never cites a field that's null on the row, and returns []
// (never a fabricated placeholder) when nothing relevant is available.
// ============================================================

const EVENT_TYPE_STAT_HINTS: Record<string, string[]> = {
  bad_pass: ["pass_completion_percentage", "passes_completed", "passes_attempted"],
  risky_pass: ["pass_completion_percentage", "passes_attempted"],
  delayed_pass: ["pass_completion_percentage", "passes_attempted"],
  missed_passing_lane: ["key_passes", "pass_completion_percentage"],
  excellent_pass: ["pass_completion_percentage", "key_passes"],
  good_switch: ["progressive_passes", "pass_completion_percentage"],
  good_progression: ["progressive_passes", "pass_completion_percentage"],
  unnecessary_dribble: ["dribble_success_percentage", "possession_losses"],
  successful_dribble: ["successful_dribbles", "dribble_success_percentage"],
  poor_1v1_decision: ["dribble_success_percentage", "dribbles_attempted"],
  good_1v1_decision: ["successful_dribbles", "dribble_success_percentage"],
  lost_possession: ["possession_losses", "dribble_success_percentage"],
  poor_ball_protection: ["possession_losses", "ball_retention"],
  missed_scoring_opportunity: ["shots", "shots_on_target", "goals"],
  poor_movement: ["touches_attacking_third"],
  good_movement: ["touches_attacking_third", "chances_created"],
  poor_positioning: ["touches_attacking_third"],
  good_positioning: ["touches_attacking_third"],
  poor_final_pass: ["chances_created", "assists"],
  good_final_pass: ["assists", "chances_created", "key_passes"],
  poor_defensive_positioning: ["defensive_actions", "tackles"],
  good_defensive_positioning: ["tackles", "defensive_actions"],
  pressing_too_early: ["duel_win_percentage", "pressures"],
  pressing_too_late: ["duel_win_percentage", "pressures"],
  matchup_mistake: ["duel_win_percentage", "tackles"],
  pulled_out_of_position: ["defensive_actions"],
  left_dangerous_space: ["defensive_actions", "clearances"],
  good_interception: ["interceptions"],
  good_defensive_cover: ["tackles", "successful_tackles", "clearances"],
  poor_counter_decision: ["progressive_carries", "progressive_actions"],
  missed_counter_opportunity: ["progressive_actions"],
  slow_transition: ["progressive_carries"],
  good_transition: ["progressive_carries", "progressive_actions"],
  played_into_pressure: ["possession_losses", "pass_completion_percentage"],
  missed_switch: ["progressive_passes"],
  poor_build_up: ["pass_completion_percentage", "possession_losses"],
  good_build_up: ["pass_completion_percentage", "progressive_passes"],
  good_escape_from_pressure: ["dribble_success_percentage", "ball_retention"],
};

const CATEGORY_STAT_FALLBACK: Record<string, string[]> = {
  passing: ["pass_completion_percentage", "passes_completed", "passes_attempted", "key_passes"],
  dribbling: ["dribble_success_percentage", "successful_dribbles", "possession_losses"],
  attacking: ["shots", "shots_on_target", "goals", "assists"],
  defending: ["tackles", "interceptions", "duel_win_percentage", "defensive_actions"],
  transition: ["progressive_carries", "progressive_actions"],
  build_up: ["forward_passes", "progressive_passes", "pass_completion_percentage"],
};

function formatStatValue(field: string, value: number): string {
  return PERCENTAGE_FIELDS.has(field) ? `${value.toFixed(1)}%` : `${value}`;
}

const MAX_EVIDENCE_FIELDS = 3;

/**
 * Never fabricated: only fields that are non-null on `stats` (i.e. real,
 * validated numbers already persisted from a screenshot/video/structured
 * source) can appear in the result.
 */
export function buildStatisticsEvidence(
  category: string,
  eventType: string,
  stats: MatchPlayerStatisticsFields | null | undefined
): string[] {
  if (!stats) return [];

  const preferredFields = EVENT_TYPE_STAT_HINTS[eventType] ?? [];
  const fallbackFields = CATEGORY_STAT_FALLBACK[category] ?? [];
  const candidateFields = [...preferredFields, ...fallbackFields];

  const evidence: string[] = [];
  const seen = new Set<string>();
  for (const field of candidateFields) {
    if (seen.has(field)) continue;
    seen.add(field);
    const value = stats[field as keyof MatchPlayerStatisticsFields];
    if (value == null) continue;
    evidence.push(`${field}: ${formatStatValue(field, Number(value))}`);
    if (evidence.length >= MAX_EVIDENCE_FIELDS) break;
  }
  return evidence;
}

/**
 * Merges however many match_player_statistics rows exist for one player in
 * one match (one row per `source` — screenshot/structured_data/ai_confirmed)
 * into a single field set for evidence-citation purposes: for each field,
 * the highest-confidence row that actually has a non-null value for it
 * wins. Never invents a value neither row provided.
 */
export function mergeStatRowsForEvidence(
  rows: (MatchPlayerStatisticsFields & { confidence: number | null })[]
): MatchPlayerStatisticsFields {
  const sorted = [...rows].sort((a, b) => (b.confidence ?? 0) - (a.confidence ?? 0));
  const merged: MatchPlayerStatisticsFields = {};
  for (const row of sorted) {
    for (const field of ALL_STAT_FIELDS) {
      const key = field as keyof MatchPlayerStatisticsFields;
      if (merged[key] == null && row[key] != null) merged[key] = row[key];
    }
  }
  return merged;
}
