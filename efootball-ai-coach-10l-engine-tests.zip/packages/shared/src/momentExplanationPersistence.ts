// Batch 10J-1 — Persistence layer for the existing 10H MomentExplanation
// and 10I FullMatchContext. Pure row<->model builders ONLY — no
// worker/pipeline wiring, no AI calls, no new FullMatchContext table
// (see fullMatchContext.ts's own buildFullMatchContextFromPersistedMoments,
// added alongside this file, for the "reconstruct FullMatchContext from
// persisted MomentExplanation rows" half of this batch's spec).
//
// REUSE, NOT REPLACEMENT (spec — "reuse existing 10H/10I models... do
// not duplicate logic"): every field below is a direct 1:1 copy of one
// field on momentExplanation.ts's own MomentExplanation (10H) — this
// file does not redefine TacticalPositionPlayerRef, DecisionOption,
// TacticalPositionState, PassingLane, or Space anywhere; it only types
// the public.moment_explanations row shape (migration
// 0030_moment_explanations.sql) that already-built values are copied
// into/out of.
//
// PRESERVE FIELDS EXACTLY, NEVER RE-DERIVE (spec — "Preserve
// football_type, explanation fields, confidence, and evidence/source
// references exactly"; "never re-derive historical explanations"):
// toMomentExplanationInsertRow/momentExplanationFromRow are pure 1:1
// field copies in each direction — neither function recomputes
// what_happened/why_it_happened/better_option/why_better/
// actionable_improvement/confidence/evidence/has_sufficient_evidence
// from the underlying event. A MomentExplanation must already be fully
// built (via buildMomentExplanationFromUnifiedEvent, 10H) before either
// function ever sees it.
//
// NULLABLE/UNKNOWN STAYS NULL (spec): neither function substitutes a
// default for a null field — a row built from a MomentExplanation with
// (e.g.) `confidence: null` persists `confidence: null`, never 0.
//
// IDENTITY REQUIRED TO PERSIST (spec — "Persist one MomentExplanation
// per (match_id, event_id)"): toMomentExplanationInsertRow returns null
// (never a row with a fabricated match_id) when the MomentExplanation's
// own `match_id` is null — migration 0030's `match_id not null`
// constraint means there is structurally no valid row to build for a
// moment with no known match. `event_id` is never null on
// MomentExplanation itself (see momentExplanation.ts's own interface
// doc comment), so no equivalent guard is needed for it.
//
// NO ZOD DEPENDENCY, NO I/O, NO AI CALLS (same convention as every
// other file in this package): small hand-written pure functions only.
//
// NO SCOPE CREEP (explicitly out of scope for 10J-1, left to a later
// batch): no worker/pipeline write path (no code here ever calls
// Supabase), no AI calls, no 10J-2+/10K+ features, no unrelated
// refactor of momentExplanation.ts/fullMatchContext.ts beyond exporting
// the two chronological/context helpers fullMatchContext.ts's own
// buildFullMatchContextFromPersistedMoments needs to reuse rather than
// duplicate.

import type { FootballType } from "./footballMatchContext.js";
import type { TacticalPositionPlayerRef, TacticalPositionState } from "./tacticalPosition.js";
import type { PassingLane, Space } from "./passingLaneSpaceModel.js";
import type { DecisionOption } from "./decisionQuality.js";
import type { MomentExplanation } from "./momentExplanation.js";

// ============================================================
// 1. Row shape (public.moment_explanations, migration 0030)
// ============================================================

/**
 * One row of public.moment_explanations — an immutable, persisted copy
 * of a 10H MomentExplanation for a single (match_id, event_id) pair.
 * Every field is a direct copy of the identically-named MomentExplanation
 * field (see momentExplanation.ts) except `id`/`created_at`, which are
 * server-assigned and have no MomentExplanation counterpart.
 */
export interface MomentExplanationRow {
  id: string;
  match_id: string;
  event_id: string;
  football_type: FootballType | null;
  timestamp_seconds: number | null;
  player: TacticalPositionPlayerRef | null;
  what_happened: string | null;
  why_it_happened: string[] | null;
  better_option: DecisionOption | null;
  why_better: string[] | null;
  actionable_improvement: string | null;
  confidence: number | null;
  evidence: string[] | null;
  has_sufficient_evidence: boolean;
  positions: TacticalPositionState | null;
  passing_lane: PassingLane | null;
  space: Space | null;
  created_at: string;
}

/** Shape of what a (future, out-of-scope-for-10J-1) server-side write
 * path inserts into public.moment_explanations — every MomentExplanationRow
 * column except the server-assigned `id`/`created_at`. */
export type MomentExplanationInsertRow = Omit<MomentExplanationRow, "id" | "created_at">;

// ============================================================
// 2. MomentExplanation (10H) -> row
// ============================================================

/**
 * Builds the row a (future) write path would insert into
 * public.moment_explanations from an already-built MomentExplanation
 * (10H) — a pure 1:1 field copy, never a re-derivation of any
 * evidence/explanation field. Returns null when `explanation.match_id`
 * is null (see file header, "IDENTITY REQUIRED TO PERSIST") — there is
 * no valid moment_explanations row for a moment with no known match.
 */
export function toMomentExplanationInsertRow(
  explanation: MomentExplanation
): MomentExplanationInsertRow | null {
  if (explanation.match_id === null) return null;

  return {
    match_id: explanation.match_id,
    event_id: explanation.event_id,
    football_type: explanation.football_type,
    timestamp_seconds: explanation.timestamp_seconds,
    player: explanation.player,
    what_happened: explanation.what_happened,
    why_it_happened: explanation.why_it_happened,
    better_option: explanation.better_option,
    why_better: explanation.why_better,
    actionable_improvement: explanation.actionable_improvement,
    confidence: explanation.confidence,
    evidence: explanation.evidence,
    has_sufficient_evidence: explanation.has_sufficient_evidence,
    positions: explanation.positions,
    passing_lane: explanation.passing_lane,
    space: explanation.space,
  };
}

// ============================================================
// 3. row -> MomentExplanation (10H)
// ============================================================

/**
 * Reconstructs a MomentExplanation (10H) from a persisted
 * public.moment_explanations row — a pure 1:1 field copy, never a
 * re-derivation. This is the ONLY supported way to read back a
 * historical explanation once persisted (see file header, "never
 * re-derive historical explanations") — a caller must not call
 * buildMomentExplanationFromUnifiedEvent again for an event that
 * already has a persisted row.
 */
export function momentExplanationFromRow(row: MomentExplanationRow): MomentExplanation {
  return {
    football_type: row.football_type,
    match_id: row.match_id,
    event_id: row.event_id,
    player: row.player,
    timestamp_seconds: row.timestamp_seconds,
    what_happened: row.what_happened,
    why_it_happened: row.why_it_happened,
    better_option: row.better_option,
    why_better: row.why_better,
    actionable_improvement: row.actionable_improvement,
    confidence: row.confidence,
    evidence: row.evidence,
    has_sufficient_evidence: row.has_sufficient_evidence,
    positions: row.positions,
    passing_lane: row.passing_lane,
    space: row.space,
  };
}

/**
 * Reconstructs every persisted MomentExplanation for a match, keyed by
 * `event_id`, from its moment_explanations rows — for
 * fullMatchContext.ts's own buildFullMatchContextFromPersistedMoments
 * to consume (see that function; not called from here, to keep this
 * file's own dependency direction one-way: momentExplanationPersistence.ts
 * never imports fullMatchContext.ts). A row is skipped only if the
 * caller supplies more than one row for the same event_id, in which
 * case the LAST one wins — moment_explanations_match_event_uniq (0030)
 * already prevents this from occurring for real persisted data.
 */
export function momentExplanationsByEventId(
  rows: readonly MomentExplanationRow[]
): Record<string, MomentExplanation> {
  const byEventId: Record<string, MomentExplanation> = {};
  for (const row of rows) {
    byEventId[row.event_id] = momentExplanationFromRow(row);
  }
  return byEventId;
}
