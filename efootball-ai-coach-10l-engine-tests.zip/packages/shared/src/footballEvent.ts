// Batch 10D — Unified Football Event Schema. The smallest layer needed
// to represent an `analysis_events` row (or a not-yet-persisted draft
// of one) as ONE validated shape that works identically for an
// eFootball (11v11) match and a Real Football (7v7) match, WITHOUT
// introducing a second event table, a second validation pipeline, or a
// second idempotency mechanism.
//
// REUSE, NOT REPLACEMENT (spec section — "reuse the existing
// analysis_events database model, validation, idempotency and
// persistence wherever possible"):
//   * Storage: still `public.analysis_events` (0001_schema.sql). No
//     migration is added by this file — every column this schema reads
//     from/writes to already exists.
//   * Vocabulary/range validation: still `validateDetectedEventDraft`
//     (validation.ts). This file's own `validateUnifiedFootballEventInput`
//     CALLS that function rather than re-implementing event_type/
//     category/severity/confidence_level/score-range checks a second
//     time — see that function below.
//   * Idempotency: still migration 0005's (match_id, dedupe_key) upsert
//     in apps/worker/src/jobs/processMatchVideo.ts /
//     processScreenshot.ts. Nothing here touches dedupe_key or changes
//     how events are upserted.
//   * Football-type source of truth: still footballMatchContext.ts's
//     FootballMatchContext / readFootballMatchContext /
//     isFootballType. This file never re-derives or re-validates a raw
//     football_type string itself.
//
// WHAT THIS FILE ADDS:
//   1. UnifiedEventType — a small closed vocabulary (pass, receive,
//      dribble, shot, turnover, pressure, defensive_action,
//      positioning) that both football types share, plus a pure
//      mapping from the existing closed event_type vocabulary
//      (types.ts#EVENT_TYPES) onto it. This is a CATEGORIZATION of
//      already-validated strings, not a new fact — no event is ever
//      given a unified type the underlying event_type doesn't already
//      imply.
//   2. UnifiedFootballEvent — a read-shape combining an AnalysisEvent
//      row with the match's (already-validated, already-persisted)
//      FootballMatchContext, via the pure `toUnifiedFootballEvent`
//      mapper. Never fabricates a field the row doesn't have.
//   3. validateUnifiedFootballEventInput — the write-path gate a caller
//      runs (in addition to, not instead of, validateDetectedEventDraft)
//      before persisting a draft, so an event can never be constructed
//      with: a client-supplied football_type override, a fabricated
//      eFootball-only field on a non-eFootball match, a malformed
//      timestamp/context-window, an event_type with no unified mapping,
//      or a match_id/player reference that doesn't match the caller's
//      own ownership context.
//
// NO ZOD DEPENDENCY (same reasoning as footballMatchContext.ts's own
// header comment): every other validator in this package
// (validation.ts, footballMatchContext.ts, uploadValidation.ts, ...) is
// a small hand-written pure function with zero external dependencies,
// and this repo has never taken a `zod` dependency (not in any
// package.json, not in bun.lock). This file follows that same
// established convention rather than introducing a new validation
// library for one schema.
//
// NO SCOPE CREEP (explicitly out of scope for 10D, left to a later
// phase): no tactical position model, no passing-lane/space model, no
// decision-quality model, no moment explanation, no full-match context
// assembly, no new AI prompts/providers, no Coach UI, no player
// progress changes, no tournament features. This file only shapes and
// validates the event itself.

import { EVENT_TYPES } from "./types.js";
import type { AnalysisEvent, EventCategory, EventSeverity, ConfidenceLevel } from "./types.js";
import { validateDetectedEventDraft } from "./validation.js";
import type { FootballMatchContext, FootballType } from "./footballMatchContext.js";
import { isFootballType } from "./footballMatchContext.js";

// ============================================================
// 1. Unified event-type vocabulary + mapping from the existing
//    (category, event_type) vocabulary
// ============================================================

/** The common football concepts spec section 1 asks for. Deliberately
 * flat (no category nesting) — unlike EventCategory, this vocabulary is
 * meant to read the same whether the underlying match was 11v11 or
 * 7v7. */
export type UnifiedEventType =
  | "pass"
  | "receive"
  | "dribble"
  | "shot"
  | "turnover"
  | "pressure"
  | "defensive_action"
  | "positioning";

export const UNIFIED_EVENT_TYPES: readonly UnifiedEventType[] = [
  "pass",
  "receive",
  "dribble",
  "shot",
  "turnover",
  "pressure",
  "defensive_action",
  "positioning",
];

/** Narrowing type guard — the ONLY definition of "a valid unified event
 * type" in this codebase, mirroring isFootballType's own contract
 * (strict membership, never fuzzy/case-insensitive matching). */
export function isUnifiedEventType(value: unknown): value is UnifiedEventType {
  return typeof value === "string" && (UNIFIED_EVENT_TYPES as readonly string[]).includes(value);
}

/**
 * Maps every existing leaf event_type string (types.ts#EVENT_TYPES) onto
 * exactly one UnifiedEventType. This is a categorization of an
 * already-closed, already-validated vocabulary — it never invents a new
 * event_type and never changes what analysis_events stores; it only
 * groups the strings the AI provider already produces into the smaller
 * shared vocabulary both football types use.
 *
 * "receive" has no current source event_type (this codebase's AI
 * provider does not yet detect a bare "received the ball" moment) — it
 * stays in UNIFIED_EVENT_TYPES for schema completeness (spec section 1
 * lists it as a common concept) but is never produced by this mapping,
 * consistent with "do not fabricate" — no leaf event_type is force-fit
 * into it just to populate the bucket.
 */
const UNIFIED_EVENT_TYPE_BY_LEGACY_EVENT_TYPE: Record<string, UnifiedEventType> = {
  // passing
  bad_pass: "pass",
  risky_pass: "pass",
  delayed_pass: "pass",
  missed_passing_lane: "pass",
  excellent_pass: "pass",
  good_switch: "pass",
  good_progression: "pass",
  // dribbling
  unnecessary_dribble: "dribble",
  successful_dribble: "dribble",
  poor_1v1_decision: "dribble",
  good_1v1_decision: "dribble",
  lost_possession: "turnover",
  poor_ball_protection: "dribble",
  // attacking
  missed_scoring_opportunity: "shot",
  poor_movement: "positioning",
  good_movement: "positioning",
  poor_positioning: "positioning",
  good_positioning: "positioning",
  poor_final_pass: "pass",
  good_final_pass: "pass",
  // defending
  poor_defensive_positioning: "defensive_action",
  good_defensive_positioning: "defensive_action",
  pressing_too_early: "pressure",
  pressing_too_late: "pressure",
  matchup_mistake: "defensive_action",
  pulled_out_of_position: "positioning",
  left_dangerous_space: "positioning",
  good_interception: "defensive_action",
  good_defensive_cover: "defensive_action",
  // transition
  poor_counter_decision: "turnover",
  missed_counter_opportunity: "turnover",
  slow_transition: "positioning",
  good_transition: "positioning",
  // build_up
  played_into_pressure: "pressure",
  missed_switch: "pass",
  poor_build_up: "positioning",
  good_build_up: "positioning",
  good_escape_from_pressure: "pressure",
};

/** Returns null (never a guess) for any event_type outside the closed
 * vocabulary above — including one that hasn't passed
 * validateDetectedEventDraft yet. Callers that need a hard guarantee
 * should validate the draft first. */
export function unifiedEventTypeForLegacyEvent(eventType: string): UnifiedEventType | null {
  return UNIFIED_EVENT_TYPE_BY_LEGACY_EVENT_TYPE[eventType] ?? null;
}

// ============================================================
// 2. eFootball-only field gate (spec section 2)
// ============================================================

/**
 * Keys that only make sense in an eFootball context (player-card
 * attributes/playstyle/overall, manager style ratings, formation
 * tactical instructions — see efootballMatchContext.ts). NONE of these
 * are columns on `analysis_events` today — this list exists purely as
 * a defensive allowlist-complement so that IF a caller's raw event
 * input ever included one of these keys (e.g. a copy-paste from an
 * eFootball-context object), validateUnifiedFootballEventInput rejects
 * it for a real_football or unknown-football-type match instead of
 * silently persisting fabricated eFootball-shaped data next to a Real
 * Football event.
 */
const EFOOTBALL_ONLY_EVENT_KEYS = [
  "playstyle",
  "overall",
  "attributes",
  "manager_ratings",
  "formation_positions",
  "player_card_image_path",
  "tactical_instructions",
] as const;

// ============================================================
// 3. The unified read-shape + pure mapper (analysis_events row ->
//    UnifiedFootballEvent)
// ============================================================

/** One analysis_events row, represented uniformly for either football
 * type. Every field below already exists on AnalysisEvent (types.ts) —
 * this is a re-shaping/renaming for a shared read API, not a new set of
 * facts. `football_type` is the ONLY addition, and it is sourced
 * exclusively from the match's own already-validated
 * FootballMatchContext (never from the event row itself, never
 * inferred from event_type/category/description). */
export interface UnifiedFootballEvent {
  id: string;
  match_id: string;
  /** null = legacy match (football_type was never recorded) or truly
   * unknown — never defaulted to "efootball". */
  football_type: FootballType | null;
  timestamp_seconds: number | null;
  /** The shared, cross-football-type categorization — see
   * unifiedEventTypeForLegacyEvent above. */
  event_type: UnifiedEventType;
  /** The original, more specific event_type/category this codebase's AI
   * provider actually produced — preserved so nothing is lost by
   * unifying. */
  legacy_event_type: string;
  legacy_category: EventCategory;
  severity: EventSeverity;
  confidence: number | null;
  confidence_level: ConfidenceLevel;
  decision_score: number | null;
  description: string;
  better_option: string | null;
  reasoning: string | null;
  /** Player reference when known (Batch 3.5) — null whenever the event
   * can't be tied to a specific identified player. */
  player_id: string | null;
  /** Evidence/source references already supported by analysis_events:
   * the cited match_player_statistics fields (Batch 3.5) plus the
   * persisted frame URLs a report/clip can point back to. Never
   * populated with anything not already stored on the row. */
  evidence: string[] | null;
  before_frame_url: string | null;
  decision_frame_url: string | null;
  after_frame_url: string | null;
  context_start_seconds: number | null;
  context_end_seconds: number | null;
  created_at: string;
}

/**
 * Builds a UnifiedFootballEvent from an ALREADY-PERSISTED,
 * already-validated analysis_events row plus the match's
 * FootballMatchContext (from
 * footballMatchContext.ts#readFootballMatchContext — never re-derived
 * here). Returns null only in the defensive case where the row's own
 * event_type has no unified mapping (should be unreachable given
 * validateDetectedEventDraft's closed vocabulary already gates what
 * reaches the table — kept defensive rather than throwing, same
 * convention as readFootballMatchContext's own defensive branch).
 */
export function toUnifiedFootballEvent(
  row: AnalysisEvent,
  footballContext: FootballMatchContext | null
): UnifiedFootballEvent | null {
  const unifiedType = unifiedEventTypeForLegacyEvent(row.event_type);
  if (unifiedType === null) return null;

  return {
    id: row.id,
    match_id: row.match_id,
    football_type: footballContext?.football_type ?? null,
    timestamp_seconds: row.timestamp_seconds,
    event_type: unifiedType,
    legacy_event_type: row.event_type,
    legacy_category: row.category,
    severity: row.severity,
    confidence: row.confidence,
    confidence_level: row.confidence_level,
    decision_score: row.decision_score,
    description: row.description,
    better_option: row.better_option,
    reasoning: row.reasoning,
    player_id: row.player_id,
    evidence: row.statistics_evidence,
    before_frame_url: row.before_frame_url,
    decision_frame_url: row.decision_frame_url,
    after_frame_url: row.after_frame_url,
    context_start_seconds: row.context_start_seconds,
    context_end_seconds: row.context_end_seconds,
    created_at: row.created_at,
  };
}

// ============================================================
// 4. Write-path validation (untrusted input -> safe to persist)
// ============================================================

export interface UnifiedFootballEventOwnershipContext {
  /** The match this event is being written for, resolved server-side
   * (never taken from client input) — e.g. the matchId a worker job
   * was enqueued for. */
  matchId: string;
  /** The owning user of that match, resolved server-side. */
  userId: string;
  /** The player this event will be linked to, if any, already resolved
   * by the caller (e.g. resolveEventSelfPlayerId in
   * apps/worker/src/eventLinking.ts) — NOT taken from client input. */
  player?: { id: string; user_id: string } | null;
}

export interface UnifiedFootballEventValidationInput {
  /** Must equal ownership.matchId when ownership is supplied — see
   * "cross-match event reference rejected" below. */
  match_id?: string;
  /** Must equal ownership.player.id when both are supplied — see
   * "player_id does not match" below. */
  player_id?: string | null;
  [key: string]: unknown;
}

export interface UnifiedFootballEventValidationResult {
  valid: boolean;
  errors: string[];
}

/**
 * The write-path gate for a unified football event draft. Deliberately
 * does NOT re-implement validateDetectedEventDraft's own event_type/
 * category/severity/confidence_level/score-range checks — it calls that
 * function first and merges its errors, then adds exactly the checks
 * that function does not cover:
 *   - malformed timestamp/context-window values (spec section 4)
 *   - football_type must never be supplied ON the event itself (it is a
 *     match-level attribute — spec section 2/"do not infer from
 *     unrelated fields")
 *   - the context's own football_type (if present) must itself be valid
 *   - eFootball-only fields are rejected unless football_type is
 *     positively "efootball" (spec section 2)
 *   - the event_type must have a unified mapping
 *   - ownership/integrity: a supplied match_id/player_id must agree with
 *     the caller's own resolved ownership context — no cross-match or
 *     cross-user reference (spec section 5)
 *
 * Never trusts `input` for ownership — `context.ownership`, when
 * supplied, always wins; a mismatching input value is an error, not
 * silently overwritten.
 */
export function validateUnifiedFootballEventInput(
  input: UnifiedFootballEventValidationInput,
  context: {
    footballContext: FootballMatchContext | null;
    ownership?: UnifiedFootballEventOwnershipContext;
  }
): UnifiedFootballEventValidationResult {
  const errors: string[] = [];

  if (!input || typeof input !== "object") {
    return { valid: false, errors: ["draft is not an object"] };
  }

  // Reuse, never re-derive: closed event_type/category/severity/
  // confidence_level vocabulary + score ranges + description.
  const base = validateDetectedEventDraft(input);
  errors.push(...base.errors);

  // Malformed timestamp / context window (spec section 4).
  const isNonNegativeFiniteNumber = (v: unknown): v is number =>
    typeof v === "number" && Number.isFinite(v) && v >= 0;

  if (input.timestamp_seconds != null && !isNonNegativeFiniteNumber(input.timestamp_seconds)) {
    errors.push(`timestamp_seconds must be a non-negative finite number or null, got ${JSON.stringify(input.timestamp_seconds)}`);
  }
  if (input.context_start_seconds != null && !isNonNegativeFiniteNumber(input.context_start_seconds)) {
    errors.push(`context_start_seconds must be a non-negative finite number or null, got ${JSON.stringify(input.context_start_seconds)}`);
  }
  if (input.context_end_seconds != null && !isNonNegativeFiniteNumber(input.context_end_seconds)) {
    errors.push(`context_end_seconds must be a non-negative finite number or null, got ${JSON.stringify(input.context_end_seconds)}`);
  }
  if (
    isNonNegativeFiniteNumber(input.context_start_seconds) &&
    isNonNegativeFiniteNumber(input.context_end_seconds) &&
    (input.context_end_seconds as number) < (input.context_start_seconds as number)
  ) {
    errors.push("context_end_seconds must not be before context_start_seconds");
  }

  // football_type is a match-level attribute — never accepted on the
  // event itself, and never inferred from event_type/category/
  // description (spec section 2 — "do not infer missing information
  // from unrelated fields").
  if (input.football_type !== undefined && input.football_type !== null) {
    errors.push("football_type must not be supplied on the event itself; it is derived from the match's own football context");
  }

  // The supplied context's own football_type (if any) must itself be a
  // recognized value — defensive re-check, same convention as
  // readFootballMatchContext's own defensive branch.
  if (context.footballContext !== null && !isFootballType(context.footballContext.football_type)) {
    errors.push(`invalid football_type in context: ${JSON.stringify(context.footballContext?.football_type)}`);
  }

  // eFootball-only fields require POSITIVE confirmation of
  // football_type === "efootball" — real_football and unknown/null
  // contexts both reject them (never "context missing, so allow it").
  const allowsEfootballFields = context.footballContext?.football_type === "efootball";
  if (!allowsEfootballFields) {
    for (const key of EFOOTBALL_ONLY_EVENT_KEYS) {
      if (input[key] !== undefined && input[key] !== null) {
        errors.push(
          `${key} is an eFootball-only field and cannot be set for football_type=${JSON.stringify(context.footballContext?.football_type ?? null)}`
        );
      }
    }
  }

  // Unified event_type must be derivable (only meaningful once the base
  // event_type/category check above has already passed).
  if (
    typeof input.event_type === "string" &&
    base.errors.length === 0 &&
    unifiedEventTypeForLegacyEvent(input.event_type) === null
  ) {
    errors.push(`event_type ${JSON.stringify(input.event_type)} has no unified-event-type mapping`);
  }

  // Ownership / integrity (spec section 5) — never trust client input;
  // a mismatch against the caller's own resolved context is rejected.
  if (context.ownership) {
    const { matchId, userId, player } = context.ownership;
    if (typeof input.match_id === "string" && input.match_id !== matchId) {
      errors.push("match_id does not match the expected match for this request — cross-match event reference rejected");
    }
    if (player && player.user_id !== userId) {
      errors.push("resolved player does not belong to the expected user — cross-user event reference rejected");
    }
    if (input.player_id != null && player && input.player_id !== player.id) {
      errors.push("player_id does not match the resolved player for this event");
    }
    if (input.player_id != null && !player) {
      errors.push("player_id was supplied but no player was resolved/owned for this request");
    }
  }

  return { valid: errors.length === 0, errors };
}

/** Every leaf event_type across every category in types.ts#EVENT_TYPES
 * — used by this file's own test to assert the unified mapping table
 * above stays exhaustive as EVENT_TYPES evolves. Exported so a future
 * addition to EVENT_TYPES that's missing a unified mapping fails a test
 * immediately rather than silently returning null from
 * unifiedEventTypeForLegacyEvent at runtime. */
export function allLegacyEventTypes(): string[] {
  return Object.values(EVENT_TYPES).flat();
}
