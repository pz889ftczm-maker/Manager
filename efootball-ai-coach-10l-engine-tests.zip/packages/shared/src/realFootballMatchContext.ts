// Batch 10C — Real Football 7v7 Context. The shared, server-safe model
// + builder that lets the Football Analysis Engine read Real-Football-
// specific context for a match — formation, player positions/roles,
// and tactical instructions — WITHOUT reconstructing any of it itself,
// without inventing anything not already stored, and WITHOUT importing
// or depending on any eFootball-specific concept (playstyle, player-
// card attributes, overall rating, manager style ratings).
//
// PURE / DEPENDENCY-FREE (same convention as footballMatchContext.ts,
// efootballMatchContext.ts, matchSnapshots.ts): this file makes no
// database call and has no I/O of any kind. It only assembles a
// RealFootballMatchContext out of data the caller already fetched —
// either an existing MatchSnapshot(+players) (Batch 9A) or a "live"
// Team/Formation/Player read. This is the ONE shared builder spec
// section 7 asks for: apps/web, apps/worker, and packages/ai all
// import buildRealFootballMatchContext from here instead of each
// re-implementing the same assembly/gating logic.
//
// GATING (spec section 4): buildRealFootballMatchContext's FIRST job
// is deciding whether Real Football context is even allowed for this
// match at all, using footballMatchContext.ts's own
// allowsRealFootballContext — never re-derived here. football_type =
// "efootball" and football_type = null (legacy) both come back
// { available: false }, with a distinct `reason` so a caller/test can
// tell "this is eFootball" apart from "this match predates
// football_type entirely" — neither is ever treated as "assume Real
// Football".
//
// HISTORICAL VS CURRENT (spec section 2): when `sources.snapshot` is
// present, it is used EXCLUSIVELY — every field comes from the
// snapshot's own already-copied columns, never from `sources.live`,
// even to fill in a field the snapshot itself has as null. `sources.
// live` is read only when there is NO snapshot at all — see
// efootballMatchContext.ts's own header comment for the fuller
// rationale, identical here.
//
// NEVER FABRICATE (spec sections 3/4/6): every mapper below is a
// straight, field-for-field copy from the input row(s) it's given.
// There is no branch anywhere in this file that invents a formation,
// tactical instruction, or player role, and no branch that converts a
// null/unknown source value to 0/""/a fabricated default — a null
// column stays null on the built context.
//
// NO eFootball CONCEPTS (spec sections 1/5): this file imports
// PlayerLibrary/TeamFormation/MatchSnapshot types (the same underlying
// tables both football types share — there is no separate "Real
// Football player" table in this schema) but its OWN
// RealFootballContextPlayer/RealFootballContextFormation types below
// deliberately omit every eFootball-only column those source types
// carry (overall, playstyle, attributes, player_card_image_path,
// manager/manager ratings entirely). This file never imports
// EfootballMatchContext or any eFootball-specific model, and
// EfootballMatchContext is never reused here with fields nulled out —
// see this package's efootballMatchContext.ts for the fully separate
// eFootball type family.
//
// PLAYER ROLES (spec section 6): a RealFootballContextPlayer's `role`
// is sourced ONLY from the formation's own stored position-definition
// data (`positions[slot].role` — teamFormations.ts's
// PositionDefinition.role, already a free-text field on the persisted
// formation layout, e.g. "GK"/"CB"). This file deliberately does NOT
// map a player's `position` string (e.g. "ST") onto a generic bucket
// like "forward" — doing so would be exactly the kind of invented
// categorization spec section 6 forbids ("keep it nullable rather than
// inventing it"). If the formation has no positions data, or the
// player's position_slot isn't found in it, or that slot has no `role`
// set, `role` stays null. No new role database system is introduced.
//
// NO DATABASE CALLS, NO OWNERSHIP CHECK HERE (spec sections 7/9): this
// file never touches Supabase and never sees a matchId — ownership
// enforcement and the actual snapshot/live reads live in the caller
// (see apps/worker/src/realFootballContext.ts), exactly like
// efootballMatchContext.ts's own buildEfootballMatchContext.

import type { FootballMatchContext } from "./footballMatchContext.js";
import { allowsRealFootballContext } from "./footballMatchContext.js";
import type { MatchSnapshot, MatchSnapshotPlayer } from "./matchSnapshots.js";
import { normalizePositions, type PositionsJson, type TeamFormation } from "./teamFormations.js";
import type { PlayerLibrary } from "./types.js";

// ============================================================
// Shape
// ============================================================

/** One player relevant to Real Football analysis. Deliberately has NO
 * overall/playstyle/attributes/player_card_image_path — those are
 * eFootball-only concepts (see file header comment). `player_id` is
 * provenance only, mirroring MatchSnapshotPlayer.player_id/
 * TeamFormationPlayer.player_id — every other field is the actual
 * value, already resolved by the caller. */
export interface RealFootballContextPlayer {
  player_id: string | null;
  name: string | null;
  position: string | null;
  position_slot: string | null;
  /** Generic role label (e.g. "goalkeeper", "defender", "midfielder",
   * "forward", "other") — see file header comment on PLAYER ROLES for
   * why this is sourced only from the formation's own stored
   * position-definition data, never derived/guessed from `position`,
   * and stays null when that data isn't present. */
  role: string | null;
}

export interface RealFootballContextFormation {
  formation_id: string | null;
  formation_code: string | null;
  name: string | null;
  positions: PositionsJson | null;
  tactical_instructions: Record<string, unknown> | null;
}

/** "historical_snapshot" — every field was copied from an existing
 * MatchSnapshot(+players), the authoritative source per spec section
 * 2. "current_data" — no snapshot existed yet, so the caller's live
 * Team/Formation/Player Library read was used instead. */
export type RealFootballContextSource = "historical_snapshot" | "current_data";

export interface RealFootballMatchContext {
  available: true;
  football_type: "real_football";
  team_size: 7;
  source: RealFootballContextSource;
  formation: RealFootballContextFormation | null;
  players: RealFootballContextPlayer[];
}

/**
 * - "not_real_football": the match's authoritative football_type is
 *   "efootball" (spec section 4 — Real Football context must be
 *   unavailable for eFootball).
 * - "unknown_football_type": football_type is NULL (a legacy match, or
 *   one where no context was ever supplied) — never assumed to be
 *   Real Football (spec section 4).
 * - "no_data": football_type IS "real_football", but the caller
 *   supplied neither a snapshot nor any live Team/Formation/Player
 *   data to build from (e.g. no team_id has ever been attached to this
 *   match) — an honest "nothing to show yet", never fabricated.
 */
export type RealFootballContextUnavailableReason = "not_real_football" | "unknown_football_type" | "no_data";

export interface RealFootballMatchContextUnavailable {
  available: false;
  reason: RealFootballContextUnavailableReason;
}

export type RealFootballMatchContextResult = RealFootballMatchContext | RealFootballMatchContextUnavailable;

// ============================================================
// Inputs — already-fetched data only, never a matchId/query
// ============================================================

/** An existing historical snapshot + its player rows (Batch 9A/9D) —
 * exactly what selectMatchSnapshotForMatch (matchSnapshotDisplay.ts) +
 * a match_snapshot_players query already produce. Same source rows
 * efootballMatchContext.ts's EfootballContextSnapshotSource reads —
 * this file simply never copies that source's eFootball-only columns
 * onto its own output type. */
export interface RealFootballContextSnapshotSource {
  snapshot: MatchSnapshot;
  players: readonly MatchSnapshotPlayer[];
}

/** One CURRENT formation-slot assignment, already joined by the
 * caller — mirrors team_formation_players.position_slot + the
 * player_library row it points at. This file never performs that join
 * itself. */
export interface RealFootballContextLivePlayer {
  position_slot: string | null;
  player: PlayerLibrary;
}

/** The CURRENT Formation/roster, already read by the caller — used
 * only when no historical snapshot exists yet. No manager here at all
 * (spec section 1's minimum list has no manager concept for Real
 * Football, and manager style ratings are explicitly an eFootball-only
 * concept — see file header comment). */
export interface RealFootballContextLiveSource {
  formation: TeamFormation | null;
  players: readonly RealFootballContextLivePlayer[];
}

export interface RealFootballContextSources {
  /** Preferred, exclusive source when present — see file header. */
  snapshot: RealFootballContextSnapshotSource | null;
  /** Used only when `snapshot` is null. */
  live: RealFootballContextLiveSource | null;
}

// ============================================================
// Role lookup (spec section 6 — see file header comment)
// ============================================================

/** Looks up `positionSlot`'s own stored `role` value in `positions`
 * (a formation's persisted position-definition layout), via
 * teamFormations.ts's own normalizePositions rather than re-walking
 * either of the two shapes `positions` may take here. Returns null
 * whenever `positions` is absent, `positionSlot` is null, no entry's
 * `id` matches it, or the matching entry has no `role` set — never
 * invents a role from any other signal (e.g. the player's own
 * `position` string). */
function roleForPositionSlot(positions: PositionsJson | null, positionSlot: string | null): string | null {
  if (!positions || positionSlot === null) return null;
  const match = normalizePositions(positions).find((p) => p.id === positionSlot);
  return match?.role ?? null;
}

// ============================================================
// Snapshot -> RealFootballMatchContext
// ============================================================

/** Same "all-or-nothing absence, not an all-null object" reasoning as
 * efootballMatchContext.ts's buildFormationFromSnapshot, for the
 * formation fields a snapshot copies from team_formations. */
function buildFormationFromSnapshot(snapshot: MatchSnapshot): RealFootballContextFormation | null {
  if (
    snapshot.formation_id === null &&
    snapshot.formation_code === null &&
    snapshot.formation_name === null &&
    snapshot.positions === null &&
    snapshot.tactical_instructions === null
  ) {
    return null;
  }
  return {
    formation_id: snapshot.formation_id,
    formation_code: snapshot.formation_code,
    name: snapshot.formation_name,
    positions: snapshot.positions,
    tactical_instructions: snapshot.tactical_instructions,
  };
}

function buildPlayersFromSnapshot(
  players: readonly MatchSnapshotPlayer[],
  positions: PositionsJson | null
): RealFootballContextPlayer[] {
  return players.map((p) => ({
    player_id: p.player_id,
    name: p.player_name,
    position: p.position,
    position_slot: p.position_slot,
    role: roleForPositionSlot(positions, p.position_slot),
  }));
}

// ============================================================
// Live data -> RealFootballMatchContext
// ============================================================

function buildFormationFromLive(formation: TeamFormation | null): RealFootballContextFormation | null {
  if (!formation) return null;
  return {
    formation_id: formation.id,
    formation_code: formation.formation_code,
    name: formation.name,
    positions: formation.positions,
    tactical_instructions: formation.tactical_instructions,
  };
}

function buildPlayersFromLive(
  players: readonly RealFootballContextLivePlayer[],
  positions: PositionsJson | null
): RealFootballContextPlayer[] {
  return players.map(({ position_slot, player }) => ({
    player_id: player.id,
    name: player.name,
    position: player.position,
    position_slot,
    role: roleForPositionSlot(positions, position_slot),
  }));
}

/** True when a live source actually carries at least one piece of
 * Real-Football-relevant data — an empty/all-null live source (a match
 * whose team_id has no formation and no assigned players at all) is
 * not meaningfully different from having no live source, so
 * buildRealFootballMatchContext treats it as `reason: "no_data"`
 * rather than an "available" context with two empty/null sections. */
function liveSourceHasData(live: RealFootballContextLiveSource): boolean {
  return live.formation !== null || live.players.length > 0;
}

// ============================================================
// The shared builder
// ============================================================

/**
 * The one shared, server-safe builder spec section 7 asks for.
 * `footballContext` must come from
 * footballMatchContext.ts#readFootballMatchContext (never re-derived
 * or guessed by the caller). `sources` must be data the caller already
 * fetched and (for `live`) already knows the caller owns — this
 * function performs no ownership check of its own (see file header
 * comment).
 */
export function buildRealFootballMatchContext(
  footballContext: FootballMatchContext | null,
  sources: RealFootballContextSources
): RealFootballMatchContextResult {
  if (!allowsRealFootballContext(footballContext)) {
    return { available: false, reason: footballContext === null ? "unknown_football_type" : "not_real_football" };
  }

  if (sources.snapshot) {
    const { snapshot, players } = sources.snapshot;
    return {
      available: true,
      football_type: "real_football",
      team_size: 7,
      source: "historical_snapshot",
      formation: buildFormationFromSnapshot(snapshot),
      players: buildPlayersFromSnapshot(players, snapshot.positions),
    };
  }

  if (sources.live && liveSourceHasData(sources.live)) {
    return {
      available: true,
      football_type: "real_football",
      team_size: 7,
      source: "current_data",
      formation: buildFormationFromLive(sources.live.formation),
      players: buildPlayersFromLive(sources.live.players, sources.live.formation?.positions ?? null),
    };
  }

  return { available: false, reason: "no_data" };
}
