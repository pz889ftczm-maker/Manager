// Batch 7E — lightweight, framework-free tests for teamLibrary.ts's pure
// validation/helper functions. Same convention as playerLibrary.test.ts/
// managerLibrary.test.ts — no test runner/framework, uses Node's
// built-in `assert` module, runs via `tsx`.
//
// Run with:  npx tsx packages/shared/test/teamLibrary.test.ts
//        or: npm test --workspace=packages/shared
//
// SCOPE NOTE: these are pure, in-process unit tests of validation/
// duplicate-detection logic only — nothing here talks to a real
// Supabase/Postgres instance. The actual authorization boundary
// (ownership of team_image_path/manager_id, the name-uniqueness
// constraint itself) lives entirely in migrations
// 0016/0018/0020_*.sql's RLS policies and triggers, reviewed by hand,
// not exercised by a live integration test here. No live Supabase
// testing was performed for this batch.

import assert from "node:assert/strict";
import {
  validateTeamLibraryInput,
  isDuplicateTeamName,
  TEAM_LIBRARY_NAME_UNIQUE_CONSTRAINT,
} from "../src/teamLibrary.js";

let passed = 0;

function check(name: string, fn: () => void): void {
  try {
    fn();
    passed += 1;
    console.log(`  ok — ${name}`);
  } catch (err) {
    process.exitCode = 1;
    console.error(`  FAIL — ${name}`);
    console.error(err);
  }
}

console.log("validateTeamLibraryInput — required name");

check("a non-empty name is valid", () => {
  const { valid, sanitized, errors } = validateTeamLibraryInput({
    name: "Manchester Blue",
    motto: null,
    description: null,
    founded_year: null,
    stadium: null,
    team_image_path: null,
    manager_id: null,
  });
  assert.equal(valid, true);
  assert.equal(sanitized.name, "Manchester Blue");
  assert.deepEqual(errors, []);
});

check("a name is trimmed", () => {
  const { sanitized } = validateTeamLibraryInput({ name: "  Red Devils  " });
  assert.equal(sanitized.name, "Red Devils");
});

check("an empty string name is rejected, never silently defaulted", () => {
  const { valid, errors } = validateTeamLibraryInput({ name: "" });
  assert.equal(valid, false);
  assert.ok(errors.some((e) => e.startsWith("name:")));
});

check("a whitespace-only name is rejected", () => {
  const { valid, errors } = validateTeamLibraryInput({ name: "   " });
  assert.equal(valid, false);
  assert.ok(errors.some((e) => e.startsWith("name:")));
});

check("a missing name is rejected, not defaulted to 'Unnamed team'", () => {
  const { valid, sanitized, errors } = validateTeamLibraryInput({});
  assert.equal(valid, false);
  assert.equal(sanitized.name, "");
  assert.ok(errors.some((e) => e.startsWith("name:")));
});

check("a non-string name is rejected", () => {
  const { valid, errors } = validateTeamLibraryInput({ name: 42 });
  assert.equal(valid, false);
  assert.ok(errors.some((e) => e.startsWith("name:")));
});

console.log("validateTeamLibraryInput — optional fields stay NULL, never fabricated");

check("all optional fields explicitly null stay null and the input is valid", () => {
  const { valid, sanitized, errors } = validateTeamLibraryInput({
    name: "Riverside FC",
    motto: null,
    description: null,
    founded_year: null,
    stadium: null,
    team_image_path: null,
    manager_id: null,
  });
  assert.equal(valid, true);
  assert.equal(sanitized.motto, null);
  assert.equal(sanitized.description, null);
  assert.equal(sanitized.founded_year, null);
  assert.equal(sanitized.stadium, null);
  assert.equal(sanitized.team_image_path, null);
  assert.equal(sanitized.manager_id, null);
  assert.deepEqual(errors, []);
});

check("all optional fields omitted entirely also stay null and valid", () => {
  const { valid, sanitized, errors } = validateTeamLibraryInput({ name: "Riverside FC" });
  assert.equal(valid, true);
  assert.equal(sanitized.motto, null);
  assert.equal(sanitized.description, null);
  assert.equal(sanitized.founded_year, null);
  assert.equal(sanitized.stadium, null);
  assert.deepEqual(errors, []);
});

check("optional string fields are trimmed and empty strings become null", () => {
  const { sanitized } = validateTeamLibraryInput({
    name: "Riverside FC",
    motto: "  Never say die  ",
    description: "",
    stadium: "   ",
  });
  assert.equal(sanitized.motto, "Never say die");
  assert.equal(sanitized.description, null);
  assert.equal(sanitized.stadium, null);
});

console.log("validateTeamLibraryInput — founded_year (no artificial limits)");

check("a positive integer founded_year is accepted", () => {
  const { valid, sanitized, errors } = validateTeamLibraryInput({ name: "X", founded_year: 1889 });
  assert.equal(valid, true);
  assert.equal(sanitized.founded_year, 1889);
  assert.deepEqual(errors, []);
});

check("a far-future founded_year is accepted — no invented upper bound", () => {
  const { valid, sanitized } = validateTeamLibraryInput({ name: "X", founded_year: 2999 });
  assert.equal(valid, true);
  assert.equal(sanitized.founded_year, 2999);
});

check("a zero/negative founded_year is rejected to null, not silently accepted", () => {
  const { valid, sanitized, errors } = validateTeamLibraryInput({ name: "X", founded_year: 0 });
  assert.equal(valid, false);
  assert.equal(sanitized.founded_year, null);
  assert.ok(errors.some((e) => e.startsWith("founded_year:")));
});

check("a non-integer founded_year is rejected to null", () => {
  const { valid, sanitized } = validateTeamLibraryInput({ name: "X", founded_year: 1990.5 });
  assert.equal(valid, false);
  assert.equal(sanitized.founded_year, null);
});

console.log("validateTeamLibraryInput — team_image_path / manager_id");

check("a well-formed team_image_path is accepted", () => {
  const { valid, sanitized } = validateTeamLibraryInput({
    name: "X",
    team_image_path: "user-a/abc123.png",
  });
  assert.equal(valid, true);
  assert.equal(sanitized.team_image_path, "user-a/abc123.png");
});

check("a team_image_path with a path-traversal sequence is rejected to null", () => {
  const { valid, sanitized, errors } = validateTeamLibraryInput({
    name: "X",
    team_image_path: "user-a/../user-b/logo.png",
  });
  assert.equal(valid, false);
  assert.equal(sanitized.team_image_path, null);
  assert.ok(errors.some((e) => e.startsWith("team_image_path:")));
});

check("a uuid-shaped manager_id is accepted", () => {
  const { valid, sanitized } = validateTeamLibraryInput({
    name: "X",
    manager_id: "11111111-1111-1111-1111-111111111111",
  });
  assert.equal(valid, true);
  assert.equal(sanitized.manager_id, "11111111-1111-1111-1111-111111111111");
});

check("a non-uuid-shaped manager_id is rejected to null — clearing (null) itself stays valid", () => {
  const { valid, sanitized, errors } = validateTeamLibraryInput({ name: "X", manager_id: "not-a-uuid" });
  assert.equal(valid, false);
  assert.equal(sanitized.manager_id, null);
  assert.ok(errors.some((e) => e.startsWith("manager_id:")));
});

check("a null manager_id (clearing) is always valid", () => {
  const { valid, sanitized } = validateTeamLibraryInput({ name: "X", manager_id: null });
  assert.equal(valid, true);
  assert.equal(sanitized.manager_id, null);
});

console.log("validateTeamLibraryInput — malformed input never fabricated into something valid");

check("non-object input is rejected outright", () => {
  const { valid, errors } = validateTeamLibraryInput("not-an-object");
  assert.equal(valid, false);
  assert.ok(errors.length > 0);
});

check("array input is rejected outright (not treated as an object)", () => {
  const { valid, errors } = validateTeamLibraryInput(["name"]);
  assert.equal(valid, false);
  assert.ok(errors.length > 0);
});

console.log("duplicate team-name handling");

check("isDuplicateTeamName recognizes the team_library constraint by name", () => {
  const pgError = {
    code: "23505",
    message: `duplicate key value violates unique constraint "${TEAM_LIBRARY_NAME_UNIQUE_CONSTRAINT}"`,
  };
  assert.equal(isDuplicateTeamName(pgError), true);
});

check("isDuplicateTeamName does not misattribute an unrelated unique violation", () => {
  const pgError = { code: "23505", message: 'duplicate key value violates unique constraint "some_other_constraint"' };
  assert.equal(isDuplicateTeamName(pgError), false);
});

check("isDuplicateTeamName rejects a non-23505 error even with a matching message", () => {
  assert.equal(
    isDuplicateTeamName({ code: "23502", message: `violates "${TEAM_LIBRARY_NAME_UNIQUE_CONSTRAINT}"` }),
    false
  );
});

console.log("");
if (process.exitCode === 1) {
  console.error(`${passed} check(s) passed, at least one FAILED.`);
} else {
  console.log(`All ${passed} checks passed.`);
}
