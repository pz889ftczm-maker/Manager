// Batch 6A-5 — lightweight, framework-free tests for formation.ts's pure
// helpers, following the same convention as playerLibrary.test.ts (no
// jest/vitest in this repo; run via tsx). Pure, in-process unit tests
// only — nothing here talks to a real Supabase/Postgres/Storage
// instance. No live Supabase Storage testing was performed for this
// batch.
//
// Run with:  npx tsx packages/shared/test/formation.test.ts
//        or: npm test --workspace=packages/shared

import assert from "node:assert/strict";
import {
  toFormationPlayerRef,
  getFormationCardDisplay,
  isFormationCardImageOwned,
  toFormationManagerRef,
  getFormationManagerDisplay,
  isFormationManagerImageOwned,
} from "../src/formation.js";
import type { PlayerLibrary, ManagerLibrary } from "../src/types.js";

let passed = 0;

function check(name: string, fn: () => void): void {
  try {
    fn();
    passed += 1;
    console.log(`  ok — ${name}`);
  } catch (err) {
    process.exitCode = 1;
    console.error(`  FAIL — ${name}`);
    console.error(err);
  }
}

function makeEntry(overrides: Partial<PlayerLibrary> = {}): PlayerLibrary {
  return {
    id: "row-1",
    user_id: "user-a",
    name: "Kevin De Bruyne",
    position: "CM",
    overall: 91,
    playstyle: "Creative Playmaker",
    player_card_image_path: "user-a/card-1.png",
    attributes: null,
    metadata: null,
    created_at: "2026-01-01T00:00:00.000Z",
    updated_at: "2026-01-01T00:00:00.000Z",
    ...overrides,
  };
}

console.log("toFormationPlayerRef — player rendering data (spec section 2)");

check("projects only the fields a formation slot renders", () => {
  const ref = toFormationPlayerRef(makeEntry());
  assert.deepEqual(ref, {
    player_library_id: "row-1",
    name: "Kevin De Bruyne",
    position: "CM",
    overall: 91,
    playstyle: "Creative Playmaker",
    player_card_image_path: "user-a/card-1.png",
  });
});

check("never leaks the full row's server-only columns onto the ref", () => {
  const ref = toFormationPlayerRef(makeEntry()) as unknown as Record<string, unknown>;
  assert.equal("user_id" in ref, false);
  assert.equal("created_at" in ref, false);
  assert.equal("updated_at" in ref, false);
  assert.equal("metadata" in ref, false);
});

console.log("getFormationCardDisplay — rendering + missing-card fallback (spec sections 3/4)");

check("empty slot renders a clean placeholder, not a fake player", () => {
  const display = getFormationCardDisplay(null);
  assert.equal(display.displayName, "Empty slot");
  assert.equal(display.positionLabel, null);
  assert.equal(display.overallLabel, null);
  assert.equal(display.hasImage, false);
});

check("a saved player with no name falls back to a label, never blank", () => {
  const ref = toFormationPlayerRef(makeEntry({ name: null }));
  const display = getFormationCardDisplay(ref);
  assert.equal(display.displayName, "Unnamed player");
});

check("a saved player with an image path reports hasImage true", () => {
  const ref = toFormationPlayerRef(makeEntry());
  assert.equal(getFormationCardDisplay(ref).hasImage, true);
});

check("a saved player with no image path reports hasImage false (fallback, not a generated image)", () => {
  const ref = toFormationPlayerRef(makeEntry({ player_card_image_path: null }));
  assert.equal(getFormationCardDisplay(ref).hasImage, false);
});

check("unknown position/overall render as null, never 0 or an empty string", () => {
  const ref = toFormationPlayerRef(makeEntry({ position: null, overall: null }));
  const display = getFormationCardDisplay(ref);
  assert.equal(display.positionLabel, null);
  assert.equal(display.overallLabel, null);
});

console.log("isFormationCardImageOwned — signed URL path ownership (spec section 6)");

check("owned path (same user prefix) is allowed", () => {
  const ref = toFormationPlayerRef(makeEntry({ player_card_image_path: "user-a/card-1.png" }));
  assert.equal(isFormationCardImageOwned(ref, "user-a"), true);
});

check("another user's path is never treated as owned", () => {
  const ref = toFormationPlayerRef(makeEntry({ player_card_image_path: "user-b/card-1.png" }));
  assert.equal(isFormationCardImageOwned(ref, "user-a"), false);
});

check("a similar-looking prefix (user-a2) is not treated as owned by user-a", () => {
  const ref = toFormationPlayerRef(makeEntry({ player_card_image_path: "user-a2/card-1.png" }));
  assert.equal(isFormationCardImageOwned(ref, "user-a"), false);
});

check("an empty slot never attempts a signed URL", () => {
  assert.equal(isFormationCardImageOwned(null, "user-a"), false);
});

check("a player saved without a card image never attempts a signed URL", () => {
  const ref = toFormationPlayerRef(makeEntry({ player_card_image_path: null }));
  assert.equal(isFormationCardImageOwned(ref, "user-a"), false);
});

// ============================================================
// Batch 6B-5 — Manager -> Formation/Team-context connection ONLY.
// ============================================================
//
// Same framework-free convention as above. Covers the pure/testable
// surface this batch adds: projecting a manager_library row, the
// NULL-safe display mapping, and signed-image ownership. Everything
// that depends on React state (selecting/changing/clearing a manager,
// the ManagerPicker's loading/error/empty rendering, Formation.tsx's
// independent manager-load effect never blocking player/formation
// behavior) was reviewed by hand against this file's helpers — same
// convention managerLibrary.test.ts's own SCOPE NOTE already documents
// for this repo (no React/DOM test harness exists here). The unchanged
// player-side checks above passing after this batch's edits IS the
// regression check for "existing Player/Formation behavior is not
// broken" (formation.ts's player helpers were not modified by 6B-5).

function makeManagerEntry(overrides: Partial<ManagerLibrary> = {}): ManagerLibrary {
  return {
    id: "mgr-1",
    user_id: "user-a",
    name: "Pep Guardiola",
    possession_rating: 95,
    quick_counter_rating: 60,
    long_ball_counter_rating: 55,
    out_wide_rating: 70,
    long_ball_rating: 40,
    manager_image_path: "user-a/manager-1.png",
    metadata: null,
    created_at: "2026-01-01T00:00:00.000Z",
    updated_at: "2026-01-01T00:00:00.000Z",
    ...overrides,
  };
}

console.log("\ntoFormationManagerRef — manager rendering data");

check("projects only the fields the Manager section renders", () => {
  const ref = toFormationManagerRef(makeManagerEntry());
  assert.deepEqual(ref, {
    manager_library_id: "mgr-1",
    name: "Pep Guardiola",
    possession_rating: 95,
    quick_counter_rating: 60,
    long_ball_counter_rating: 55,
    out_wide_rating: 70,
    long_ball_rating: 40,
    manager_image_path: "user-a/manager-1.png",
  });
});

check("never leaks the full row's server-only columns onto the ref", () => {
  const ref = toFormationManagerRef(makeManagerEntry()) as unknown as Record<string, unknown>;
  assert.equal("user_id" in ref, false);
  assert.equal("created_at" in ref, false);
  assert.equal("updated_at" in ref, false);
  assert.equal("metadata" in ref, false);
});

console.log("getFormationManagerDisplay — NULL/UNKNOWN handling (spec's explicit NULL rule)");

check("no manager selected renders a clean 'no selection' state, never a fake manager", () => {
  const display = getFormationManagerDisplay(null);
  assert.equal(display.displayName, "No manager selected");
  assert.equal(display.possessionLabel, "Possession: Unknown");
  assert.equal(display.hasImage, false);
});

check("a selected manager with no name falls back to a label, never blank", () => {
  const ref = toFormationManagerRef(makeManagerEntry({ name: null }));
  assert.equal(getFormationManagerDisplay(ref).displayName, "Unnamed manager");
});

check("unknown (null) ratings render as 'Unknown', never as fake 0", () => {
  const ref = toFormationManagerRef(
    makeManagerEntry({
      possession_rating: null,
      quick_counter_rating: null,
      long_ball_counter_rating: null,
      out_wide_rating: null,
      long_ball_rating: null,
    })
  );
  const display = getFormationManagerDisplay(ref);
  assert.equal(display.possessionLabel, "Possession: Unknown");
  assert.equal(display.quickCounterLabel, "Quick Counter: Unknown");
  assert.equal(display.longBallCounterLabel, "Long Ball Counter: Unknown");
  assert.equal(display.outWideLabel, "Out Wide: Unknown");
  assert.equal(display.longBallLabel, "Long Ball: Unknown");
});

check("a legitimately-reported rating of 0 is preserved, distinct from unknown", () => {
  const ref = toFormationManagerRef(makeManagerEntry({ possession_rating: 0 }));
  assert.equal(getFormationManagerDisplay(ref).possessionLabel, "Possession: 0");
});

check("a manager with an image path reports hasImage true", () => {
  const ref = toFormationManagerRef(makeManagerEntry());
  assert.equal(getFormationManagerDisplay(ref).hasImage, true);
});

check("a manager saved without an image path reports hasImage false (fallback, not a generated image)", () => {
  const ref = toFormationManagerRef(makeManagerEntry({ manager_image_path: null }));
  assert.equal(getFormationManagerDisplay(ref).hasImage, false);
});

console.log("isFormationManagerImageOwned — signed URL path ownership");

check("owned path (same user prefix) is allowed", () => {
  const ref = toFormationManagerRef(makeManagerEntry({ manager_image_path: "user-a/manager-1.png" }));
  assert.equal(isFormationManagerImageOwned(ref, "user-a"), true);
});

check("another user's path is never treated as owned", () => {
  const ref = toFormationManagerRef(makeManagerEntry({ manager_image_path: "user-b/manager-1.png" }));
  assert.equal(isFormationManagerImageOwned(ref, "user-a"), false);
});

check("a similar-looking prefix (user-a2) is not treated as owned by user-a", () => {
  const ref = toFormationManagerRef(makeManagerEntry({ manager_image_path: "user-a2/manager-1.png" }));
  assert.equal(isFormationManagerImageOwned(ref, "user-a"), false);
});

check("no manager selected never attempts a signed URL", () => {
  assert.equal(isFormationManagerImageOwned(null, "user-a"), false);
});

check("a manager saved without an image never attempts a signed URL", () => {
  const ref = toFormationManagerRef(makeManagerEntry({ manager_image_path: null }));
  assert.equal(isFormationManagerImageOwned(ref, "user-a"), false);
});

console.log(`\n${passed} checks passed`);
