// Batch 7C — lightweight, framework-free tests for teamMembers.ts's
// pure validation/helper functions. Same convention as
// playerLibrary.test.ts/managerLibrary.test.ts — no test runner/
// framework, uses Node's built-in `assert` module, runs via `tsx`.
//
// Run with:  npx tsx packages/shared/test/teamMembers.test.ts
//        or: npm test --workspace=packages/shared
//
// SCOPE NOTE: these are pure, in-process unit tests of validation/
// duplicate-detection logic only — nothing here talks to a real
// Supabase/Postgres instance. The actual authorization boundary for
// this batch — team ownership, player ownership, and cross-user
// rejection (spec section 3's four cases: A-team+A-player allowed,
// A-team+B-player rejected, B-team+A-player rejected, B-team+B-player
// inaccessible to A) — lives entirely in migration
// 0019_team_members.sql's RLS policies and its
// check_team_members_ownership trigger, reviewed by hand, not exercised
// by a live integration test here. Cascade-delete behavior (team/player
// deletion removing team_members rows) is likewise enforced by the
// `on delete cascade` foreign keys declared in that same migration and
// was not verified against a live database. No live Supabase testing
// was performed for this batch.

import assert from "node:assert/strict";
import {
  validateTeamMemberInput,
  isUniqueViolation,
  TEAM_MEMBERS_UNIQUE_CONSTRAINT,
} from "../src/teamMembers.js";

let passed = 0;

function check(name: string, fn: () => void): void {
  try {
    fn();
    passed += 1;
    console.log(`  ok — ${name}`);
  } catch (err) {
    process.exitCode = 1;
    console.error(`  FAIL — ${name}`);
    console.error(err);
  }
}

console.log("validateTeamMemberInput — valid relationship (spec section 10)");

const TEAM_A = "11111111-1111-4111-8111-111111111111";
const PLAYER_A = "22222222-2222-4222-8222-222222222222";

check("a well-formed (team_id, player_id) uuid pair is valid", () => {
  const { valid, errors } = validateTeamMemberInput({ team_id: TEAM_A, player_id: PLAYER_A });
  assert.equal(valid, true);
  assert.deepEqual(errors, []);
});

console.log("validateTeamMemberInput — malformed input never fabricated into something valid");

check("missing team_id is rejected, not silently defaulted", () => {
  const { valid, errors } = validateTeamMemberInput({ player_id: PLAYER_A });
  assert.equal(valid, false);
  assert.ok(errors.some((e) => e.includes("team_id")));
});

check("missing player_id is rejected, not silently defaulted", () => {
  const { valid, errors } = validateTeamMemberInput({ team_id: TEAM_A });
  assert.equal(valid, false);
  assert.ok(errors.some((e) => e.includes("player_id")));
});

check("empty-string ids are rejected", () => {
  const { valid, errors } = validateTeamMemberInput({ team_id: "", player_id: "" });
  assert.equal(valid, false);
  assert.equal(errors.length, 2);
});

check("non-uuid-shaped strings are rejected", () => {
  const { valid, errors } = validateTeamMemberInput({ team_id: "not-a-uuid", player_id: PLAYER_A });
  assert.equal(valid, false);
  assert.ok(errors.some((e) => e.includes("team_id") && e.includes("uuid")));
});

check("non-object input is rejected outright", () => {
  const { valid, errors } = validateTeamMemberInput(null);
  assert.equal(valid, false);
  assert.equal(errors.length, 1);
});

check("array input is rejected outright (not treated as an object)", () => {
  const { valid } = validateTeamMemberInput([TEAM_A, PLAYER_A]);
  assert.equal(valid, false);
});

console.log("duplicate relationship detection (spec section 6 — 'must fail safely')");

check("isUniqueViolation recognizes the team_members constraint by name", () => {
  const err = {
    code: "23505",
    message: `duplicate key value violates unique constraint "${TEAM_MEMBERS_UNIQUE_CONSTRAINT}"`,
  };
  assert.equal(isUniqueViolation(err, TEAM_MEMBERS_UNIQUE_CONSTRAINT), true);
});

check("isUniqueViolation does not misattribute an unrelated unique violation", () => {
  const err = {
    code: "23505",
    message: 'duplicate key value violates unique constraint "team_library_user_name_uniq"',
  };
  assert.equal(isUniqueViolation(err, TEAM_MEMBERS_UNIQUE_CONSTRAINT), false);
});

check("isUniqueViolation rejects a non-23505 error even with a matching message", () => {
  const err = { code: "23503", message: TEAM_MEMBERS_UNIQUE_CONSTRAINT };
  assert.equal(isUniqueViolation(err, TEAM_MEMBERS_UNIQUE_CONSTRAINT), false);
});

console.log(`\n${passed} check(s) passed.`);
