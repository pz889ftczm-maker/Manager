// Batch 8B — lightweight, framework-free tests for
// teamFormationPlayers.ts's pure validation helpers. Same convention as
// teamMembers.test.ts/teamFormations.test.ts — no test runner/
// framework, uses Node's built-in `assert` module, runs via `tsx`.
//
// Run with:  npx tsx packages/shared/test/teamFormationPlayers.test.ts
//        or: npm test --workspace=packages/shared
//
// SCOPE NOTE: these are pure, in-process unit tests of validation/
// duplicate-detection logic only — nothing here talks to a real
// Supabase/Postgres instance. The actual authorization boundary
// (formation -> team_library.user_id and player -> player_library.
// user_id ownership, the RLS policies themselves, the
// ownership-consistency trigger, and ON DELETE CASCADE behavior) lives
// entirely in migration 0022_team_formation_players.sql, reviewed by
// hand, not exercised by a live integration test here. No live
// Supabase/RLS/cascade verification was performed for this batch.

import assert from "node:assert/strict";
import type { TeamFormationPlayer } from "../src/teamFormationPlayers.js";
import {
  validateTeamFormationPlayerInput,
  isDuplicateFormationPlayer,
  TEAM_FORMATION_PLAYER_UNIQUE_CONSTRAINT,
  isDuplicateFormationSlot,
  TEAM_FORMATION_PLAYER_SLOT_UNIQUE_CONSTRAINT,
  planFormationSlotAssignment,
} from "../src/teamFormationPlayers.js";

let passed = 0;

function check(name: string, fn: () => void): void {
  try {
    fn();
    passed += 1;
    console.log(`  ok — ${name}`);
  } catch (err) {
    process.exitCode = 1;
    console.error(`  FAIL — ${name}`);
    console.error(err);
  }
}

const FORMATION_A = "11111111-1111-1111-1111-111111111111";
const FORMATION_B = "22222222-2222-2222-2222-222222222222";
const PLAYER_A = "33333333-3333-3333-3333-333333333333";

console.log("validateTeamFormationPlayerInput — a valid assignment");

check("a well-formed (formation_id, player_id, position_slot) triple is valid", () => {
  const { valid, sanitized, errors } = validateTeamFormationPlayerInput({
    formation_id: FORMATION_A,
    player_id: PLAYER_A,
    position_slot: "GK",
  });
  assert.equal(valid, true);
  assert.equal(sanitized.formation_id, FORMATION_A);
  assert.equal(sanitized.player_id, PLAYER_A);
  assert.equal(sanitized.position_slot, "GK");
  assert.deepEqual(errors, []);
});

check("position_slot is trimmed", () => {
  const { sanitized } = validateTeamFormationPlayerInput({
    formation_id: FORMATION_A,
    player_id: PLAYER_A,
    position_slot: "  CB1  ",
  });
  assert.equal(sanitized.position_slot, "CB1");
});

console.log("validateTeamFormationPlayerInput — malformed input never fabricated into something valid");

check("missing formation_id is rejected, not silently defaulted", () => {
  const { valid, errors } = validateTeamFormationPlayerInput({ player_id: PLAYER_A, position_slot: "GK" });
  assert.equal(valid, false);
  assert.ok(errors.some((e) => e.startsWith("formation_id:")));
});

check("missing player_id is rejected, not silently defaulted", () => {
  const { valid, errors } = validateTeamFormationPlayerInput({ formation_id: FORMATION_A, position_slot: "GK" });
  assert.equal(valid, false);
  assert.ok(errors.some((e) => e.startsWith("player_id:")));
});

check("missing position_slot is rejected, not silently defaulted", () => {
  const { valid, errors } = validateTeamFormationPlayerInput({ formation_id: FORMATION_A, player_id: PLAYER_A });
  assert.equal(valid, false);
  assert.ok(errors.some((e) => e.startsWith("position_slot:")));
});

check("an empty-string position_slot is rejected", () => {
  const { valid, errors } = validateTeamFormationPlayerInput({
    formation_id: FORMATION_A,
    player_id: PLAYER_A,
    position_slot: "",
  });
  assert.equal(valid, false);
  assert.ok(errors.some((e) => e.startsWith("position_slot:")));
});

check("a whitespace-only position_slot is rejected", () => {
  const { valid, errors } = validateTeamFormationPlayerInput({
    formation_id: FORMATION_A,
    player_id: PLAYER_A,
    position_slot: "   ",
  });
  assert.equal(valid, false);
  assert.ok(errors.some((e) => e.startsWith("position_slot:")));
});

check("a non-uuid-shaped formation_id is rejected, never coerced into a fake id", () => {
  const { valid, sanitized, errors } = validateTeamFormationPlayerInput({
    formation_id: "not-a-uuid",
    player_id: PLAYER_A,
    position_slot: "GK",
  });
  assert.equal(valid, false);
  assert.equal(sanitized.formation_id, "");
  assert.ok(errors.some((e) => e.includes("formation_id") && e.includes("uuid")));
});

check("a non-uuid-shaped player_id is rejected, never coerced into a fake id", () => {
  const { valid, sanitized, errors } = validateTeamFormationPlayerInput({
    formation_id: FORMATION_A,
    player_id: "not-a-uuid",
    position_slot: "GK",
  });
  assert.equal(valid, false);
  assert.equal(sanitized.player_id, "");
  assert.ok(errors.some((e) => e.includes("player_id") && e.includes("uuid")));
});

check("empty-string ids are rejected", () => {
  const { valid, errors } = validateTeamFormationPlayerInput({
    formation_id: "",
    player_id: "",
    position_slot: "GK",
  });
  assert.equal(valid, false);
  assert.equal(errors.length, 2);
});

check("non-object input is rejected outright", () => {
  const { valid, errors } = validateTeamFormationPlayerInput(null);
  assert.equal(valid, false);
  assert.equal(errors.length, 1);
});

check("array input is rejected outright (not treated as an object)", () => {
  const { valid } = validateTeamFormationPlayerInput([FORMATION_A, PLAYER_A, "GK"]);
  assert.equal(valid, false);
});

console.log("TeamFormationPlayer — no coordinates, no player data duplication (spec section 3/8)");

check("a TeamFormationPlayer value only ever needs formation_id/player_id/position_slot/timestamps", () => {
  // Compile-time/structural check: this is exactly the full field set —
  // no x/y, no player name/stats, no starting-XI/bench flag. Assigning
  // a value missing any of these six keys, or adding an extra one,
  // would be a type error at compile time; at runtime we just confirm
  // the six expected keys round-trip untouched.
  const row: TeamFormationPlayer = {
    id: FORMATION_A,
    formation_id: FORMATION_A,
    player_id: PLAYER_A,
    position_slot: "ST",
    created_at: "2026-01-01T00:00:00.000Z",
    updated_at: "2026-01-01T00:00:00.000Z",
  };
  assert.deepEqual(Object.keys(row).sort(), [
    "created_at",
    "formation_id",
    "id",
    "player_id",
    "position_slot",
    "updated_at",
  ]);
});

console.log("duplicate assignment handling (spec section 2 — 'must fail safely')");

check("isDuplicateFormationPlayer recognizes the team_formation_players constraint by name", () => {
  const err = {
    code: "23505",
    message: `duplicate key value violates unique constraint "${TEAM_FORMATION_PLAYER_UNIQUE_CONSTRAINT}"`,
  };
  assert.equal(isDuplicateFormationPlayer(err), true);
});

check("isDuplicateFormationPlayer does not misattribute an unrelated unique violation", () => {
  const err = {
    code: "23505",
    message: 'duplicate key value violates unique constraint "team_formations_team_name_uniq"',
  };
  assert.equal(isDuplicateFormationPlayer(err), false);
});

check("isDuplicateFormationPlayer rejects a non-23505 error even with a matching message", () => {
  const err = { code: "23503", message: TEAM_FORMATION_PLAYER_UNIQUE_CONSTRAINT };
  assert.equal(isDuplicateFormationPlayer(err), false);
});

console.log("");
console.log("duplicate slot handling (Batch 8C — migration 0023)");

check("isDuplicateFormationSlot recognizes the team_formation_players slot constraint by name", () => {
  const err = {
    code: "23505",
    message: `duplicate key value violates unique constraint "${TEAM_FORMATION_PLAYER_SLOT_UNIQUE_CONSTRAINT}"`,
  };
  assert.equal(isDuplicateFormationSlot(err), true);
});

check("isDuplicateFormationSlot does not misattribute the player-uniq violation", () => {
  const err = {
    code: "23505",
    message: `duplicate key value violates unique constraint "${TEAM_FORMATION_PLAYER_UNIQUE_CONSTRAINT}"`,
  };
  assert.equal(isDuplicateFormationSlot(err), false);
});

console.log("");
console.log("planFormationSlotAssignment — pure slot-assignment planning (Batch 8C)");

const F_ID = "22222222-2222-2222-2222-222222222222";
const P1 = "33333333-3333-3333-3333-333333333333";
const P2 = "44444444-4444-4444-4444-444444444444";

check("empty formation, new player -> a single insert", () => {
  const plan = planFormationSlotAssignment([], P1, "gk");
  assert.deepEqual(plan.operations, [{ type: "insert", player_id: P1, position_slot: "gk" }]);
  assert.equal(plan.displaced, null);
});

check("player already exactly in that slot -> no-op plan", () => {
  const existing = [{ id: "row-1", player_id: P1, position_slot: "gk" }];
  const plan = planFormationSlotAssignment(existing, P1, "gk");
  assert.deepEqual(plan.operations, []);
  assert.equal(plan.displaced, null);
});

check("player elsewhere in the formation, target slot free -> a single move (update_slot)", () => {
  const existing = [{ id: "row-1", player_id: P1, position_slot: "cb1" }];
  const plan = planFormationSlotAssignment(existing, P1, "gk");
  assert.deepEqual(plan.operations, [{ type: "update_slot", id: "row-1", position_slot: "gk" }]);
  assert.equal(plan.displaced, null);
});

check("target slot occupied by a different player, mover not yet in formation -> delete occupant then insert", () => {
  const existing = [{ id: "row-1", player_id: P2, position_slot: "gk" }];
  const plan = planFormationSlotAssignment(existing, P1, "gk");
  assert.deepEqual(plan.operations, [
    { type: "delete", id: "row-1" },
    { type: "insert", player_id: P1, position_slot: "gk" },
  ]);
  assert.deepEqual(plan.displaced, { id: "row-1", player_id: P2, position_slot: "gk" });
});

check("target slot occupied by a different player, mover already elsewhere -> delete occupant then move mover", () => {
  const existing = [
    { id: "row-1", player_id: P2, position_slot: "gk" },
    { id: "row-2", player_id: P1, position_slot: "cb1" },
  ];
  const plan = planFormationSlotAssignment(existing, P1, "gk");
  assert.deepEqual(plan.operations, [
    { type: "delete", id: "row-1" },
    { type: "update_slot", id: "row-2", position_slot: "gk" },
  ]);
  assert.deepEqual(plan.displaced, { id: "row-1", player_id: P2, position_slot: "gk" });
});

check("delete step always precedes the move/insert step, so a caller executing in order never transiently collides", () => {
  const existing = [{ id: "row-1", player_id: P2, position_slot: "gk" }];
  const plan = planFormationSlotAssignment(existing, P1, "gk");
  assert.equal(plan.operations[0].type, "delete");
});

console.log("");
console.log(
  "NOTE: 'same player allowed in different formations' and 'ON DELETE CASCADE' are properties of the unique index"
);
console.log(
  "scope — (formation_id, player_id), not (player_id) alone — and of the two foreign keys' ON DELETE CASCADE"
);
console.log(
  "clauses in migration 0022_team_formation_players.sql. Both were reviewed by hand in that migration; neither"
);
console.log("is something a pure-function unit test here can exercise without a live Postgres instance.");

console.log("");
if (process.exitCode === 1) {
  console.error(`${passed} check(s) passed, at least one FAILED.`);
} else {
  console.log(`All ${passed} checks passed.`);
}
