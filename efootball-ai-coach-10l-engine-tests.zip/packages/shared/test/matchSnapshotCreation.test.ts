// Batch 9B — lightweight, framework-free tests for
// matchSnapshotCreation.ts's pure helpers. Same convention as
// matchSnapshots.test.ts/playerLibrary.test.ts — no test
// runner/framework, uses Node's built-in `assert` module, runs via
// `tsx`.
//
// Run with:  npx tsx packages/shared/test/matchSnapshotCreation.test.ts
//        or: npm test --workspace=packages/shared
//
// SCOPE NOTE: these are pure, in-process unit tests of request-shape
// validation and error-message mapping only — nothing here talks to a
// real Supabase/Postgres instance. The actual authorization boundary
// (match/team/formation/manager/player ownership, atomic creation,
// idempotency under concurrency) lives entirely in
// public.create_match_snapshot (migration
// 0026_match_snapshot_creation.sql), reviewed by hand, not exercised
// by a live integration test here. No live Supabase/Postgres
// verification was performed for this batch (spec section 22).

import assert from "node:assert/strict";
import {
  validateMatchSnapshotCreateRequest,
  mapSnapshotCreationRpcError,
} from "../src/matchSnapshotCreation.js";

let passed = 0;

function check(name: string, fn: () => void): void {
  try {
    fn();
    passed += 1;
    console.log(`  ok — ${name}`);
  } catch (err) {
    process.exitCode = 1;
    console.error(`  FAIL — ${name}`);
    console.error(err);
  }
}

const VALID_MATCH_ID = "22222222-2222-2222-2222-222222222222";
const VALID_TEAM_ID = "33333333-3333-3333-3333-333333333333";
const VALID_FORMATION_ID = "66666666-6666-6666-6666-666666666666";

console.log("validateMatchSnapshotCreateRequest — valid requests");

check("match_id + team_id, no formation_id, is valid", () => {
  const { valid, sanitized, errors } = validateMatchSnapshotCreateRequest({
    match_id: VALID_MATCH_ID,
    team_id: VALID_TEAM_ID,
  });
  assert.equal(valid, true);
  assert.deepEqual(errors, []);
  assert.equal(sanitized.match_id, VALID_MATCH_ID);
  assert.equal(sanitized.team_id, VALID_TEAM_ID);
  assert.equal(sanitized.formation_id, null);
});

check("match_id + team_id + formation_id, all valid", () => {
  const { valid, sanitized } = validateMatchSnapshotCreateRequest({
    match_id: VALID_MATCH_ID,
    team_id: VALID_TEAM_ID,
    formation_id: VALID_FORMATION_ID,
  });
  assert.equal(valid, true);
  assert.equal(sanitized.formation_id, VALID_FORMATION_ID);
});

check("explicit formation_id: null is valid and stays null", () => {
  const { valid, sanitized } = validateMatchSnapshotCreateRequest({
    match_id: VALID_MATCH_ID,
    team_id: VALID_TEAM_ID,
    formation_id: null,
  });
  assert.equal(valid, true);
  assert.equal(sanitized.formation_id, null);
});

console.log("\nvalidateMatchSnapshotCreateRequest — required fields");

check("missing match_id is invalid", () => {
  const { valid, errors } = validateMatchSnapshotCreateRequest({ team_id: VALID_TEAM_ID });
  assert.equal(valid, false);
  assert.ok(errors.some((e) => e.startsWith("match_id:")));
});

check("missing team_id is invalid", () => {
  const { valid, errors } = validateMatchSnapshotCreateRequest({ match_id: VALID_MATCH_ID });
  assert.equal(valid, false);
  assert.ok(errors.some((e) => e.startsWith("team_id:")));
});

check("non-uuid match_id is invalid", () => {
  const { valid, errors } = validateMatchSnapshotCreateRequest({
    match_id: "not-a-uuid",
    team_id: VALID_TEAM_ID,
  });
  assert.equal(valid, false);
  assert.ok(errors.some((e) => e.startsWith("match_id:")));
});

check("malformed formation_id is discarded to null, not a hard failure", () => {
  const { valid, sanitized, errors } = validateMatchSnapshotCreateRequest({
    match_id: VALID_MATCH_ID,
    team_id: VALID_TEAM_ID,
    formation_id: "not-a-uuid",
  });
  // A malformed OPTIONAL id is recorded as an error (so the caller
  // knows the value was dropped) — same "discard, don't silently
  // accept" contract as matchSnapshots.ts's own sanitizeNullableUuid.
  assert.equal(valid, false);
  assert.equal(sanitized.formation_id, null);
  assert.ok(errors.some((e) => e.startsWith("formation_id:")));
});

console.log("\nvalidateMatchSnapshotCreateRequest — no other field is accepted");

check("client-supplied historical fields (team_name, user_id, ...) are ignored, not surfaced", () => {
  const { valid, sanitized } = validateMatchSnapshotCreateRequest({
    match_id: VALID_MATCH_ID,
    team_id: VALID_TEAM_ID,
    user_id: "77777777-7777-7777-7777-777777777777",
    team_name: "Fabricated FC",
    manager_ratings: { possession_rating: 99 },
  });
  assert.equal(valid, true);
  // Only the three known keys ever exist on the sanitized result.
  assert.deepEqual(Object.keys(sanitized).sort(), ["formation_id", "match_id", "team_id"]);
});

check("non-object input is rejected", () => {
  assert.equal(validateMatchSnapshotCreateRequest(null).valid, false);
  assert.equal(validateMatchSnapshotCreateRequest("nope").valid, false);
  assert.equal(validateMatchSnapshotCreateRequest([1, 2]).valid, false);
});

console.log("\nmapSnapshotCreationRpcError — known codes map to spec-mandated safe strings");

check("match_not_found -> 'Match does not belong to this user.'", () => {
  const result = mapSnapshotCreationRpcError({ message: "match_snapshot_create: match_not_found" });
  assert.equal(result.error, "Match does not belong to this user.");
  assert.equal(result.status, 403);
});

check("team_not_found -> 'Team does not belong to this user.'", () => {
  const result = mapSnapshotCreationRpcError({ message: "match_snapshot_create: team_not_found" });
  assert.equal(result.error, "Team does not belong to this user.");
});

check("formation_not_found -> 'Formation does not belong to this team.'", () => {
  const result = mapSnapshotCreationRpcError({ message: "match_snapshot_create: formation_not_found" });
  assert.equal(result.error, "Formation does not belong to this team.");
  assert.equal(result.status, 422);
});

check("manager_ownership_invalid -> the generic invalid-configuration message", () => {
  const result = mapSnapshotCreationRpcError({ message: "match_snapshot_create: manager_ownership_invalid" });
  assert.equal(result.error, "Unable to create match snapshot because the selected configuration is invalid.");
});

check("player_ownership_invalid -> the generic invalid-configuration message", () => {
  const result = mapSnapshotCreationRpcError({ message: "match_snapshot_create: player_ownership_invalid" });
  assert.equal(result.error, "Unable to create match snapshot because the selected configuration is invalid.");
});

console.log("\nmapSnapshotCreationRpcError — never leaks raw Postgres detail");

check("an unrecognized match_snapshot_create code falls back to the generic message", () => {
  const result = mapSnapshotCreationRpcError({ message: "match_snapshot_create: some_future_code" });
  assert.equal(result.error, "Unable to create match snapshot.");
  assert.equal(result.status, 500);
});

check("a raw Postgres error with no known prefix never has its own text surfaced", () => {
  const result = mapSnapshotCreationRpcError({
    message: 'insert or update on table "match_snapshots" violates foreign key constraint "..."',
    details: "Key (team_id)=(...) is not present in table \"team_library\".",
    code: "23503",
  });
  assert.equal(result.error, "Unable to create match snapshot.");
  assert.equal(/foreign key|constraint|team_library/.test(result.error), false);
});

check("non-object / missing-message errors fall back to the generic message", () => {
  assert.equal(mapSnapshotCreationRpcError(null).error, "Unable to create match snapshot.");
  assert.equal(mapSnapshotCreationRpcError(new Error()).error, "Unable to create match snapshot.");
  assert.equal(mapSnapshotCreationRpcError("plain string").error, "Unable to create match snapshot.");
});

console.log(`\n${passed} check(s) passed.`);
if (process.exitCode) {
  console.error("\nSome checks FAILED.");
} else {
  console.log("All checks passed.");
}
