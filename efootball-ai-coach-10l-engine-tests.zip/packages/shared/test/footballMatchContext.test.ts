// Batch 10A — lightweight, framework-free tests for
// footballMatchContext.ts's pure validation/derivation helpers. Same
// convention as matchSnapshots.test.ts/matchSnapshotDisplay.test.ts —
// no test runner/framework, Node's built-in `assert`, run via `tsx`.
//
// Run with:  npx tsx packages/shared/test/footballMatchContext.test.ts
//        or: npm test --workspace=packages/shared
//
// SCOPE NOTE: these are pure, in-process unit tests of validation and
// derivation logic only — nothing here talks to a real Supabase/
// Postgres instance. The actual persistence guarantee (NULL allowed
// for legacy rows, football_type/team_size can never be mismatched)
// lives in migration 0029_football_match_context.sql's own CHECK
// constraint, reviewed by hand, not exercised by a live integration
// test here.

import assert from "node:assert/strict";
import {
  FOOTBALL_TYPES,
  isFootballType,
  teamSizeForFootballType,
  buildFootballMatchContext,
  validateFootballTypeInput,
  readFootballMatchContext,
  allowsEfootballContext,
} from "../src/footballMatchContext.js";

let passed = 0;

function check(name: string, fn: () => void): void {
  try {
    fn();
    passed += 1;
    console.log(`  ok — ${name}`);
  } catch (err) {
    process.exitCode = 1;
    console.error(`  FAIL — ${name}`);
    console.error(err);
  }
}

console.log("buildFootballMatchContext / teamSizeForFootballType — valid contexts");

check("valid eFootball context: football_type=efootball, team_size=11", () => {
  const context = buildFootballMatchContext("efootball");
  assert.deepEqual(context, { football_type: "efootball", team_size: 11 });
  assert.equal(teamSizeForFootballType("efootball"), 11);
});

check("valid real-football context: football_type=real_football, team_size=7", () => {
  const context = buildFootballMatchContext("real_football");
  assert.deepEqual(context, { football_type: "real_football", team_size: 7 });
  assert.equal(teamSizeForFootballType("real_football"), 7);
});

console.log("\nisFootballType — strict, no coercion");

check("recognizes exactly the two known values", () => {
  assert.equal(isFootballType("efootball"), true);
  assert.equal(isFootballType("real_football"), true);
});

check("rejects an unknown/invalid football type outright — never coerced to a guess", () => {
  assert.equal(isFootballType("football"), false);
  assert.equal(isFootballType("eFootball"), false); // case-sensitive — no fuzzy matching
  assert.equal(isFootballType("7v7"), false);
  assert.equal(isFootballType(""), false);
  assert.equal(isFootballType(11), false);
  assert.equal(isFootballType(null), false);
  assert.equal(isFootballType(undefined), false);
});

check("FOOTBALL_TYPES enumerates exactly the two supported values", () => {
  assert.deepEqual([...FOOTBALL_TYPES].sort(), ["efootball", "real_football"]);
});

console.log("\nvalidateFootballTypeInput — client input validation");

check("valid eFootball input is accepted", () => {
  const result = validateFootballTypeInput("efootball");
  assert.equal(result.valid, true);
  assert.equal(result.footballType, "efootball");
  assert.deepEqual(result.errors, []);
});

check("valid real_football input is accepted", () => {
  const result = validateFootballTypeInput("real_football");
  assert.equal(result.valid, true);
  assert.equal(result.footballType, "real_football");
});

check("an invalid football type is rejected, never silently defaulted", () => {
  const result = validateFootballTypeInput("esports");
  assert.equal(result.valid, false);
  assert.equal(result.footballType, null);
  assert.ok(result.errors[0].includes("football_type"));
});

check("a non-string value (number/object/array) is rejected", () => {
  assert.equal(validateFootballTypeInput(11).valid, false);
  assert.equal(validateFootballTypeInput({}).valid, false);
  assert.equal(validateFootballTypeInput([]).valid, false);
});

check("omitted/null input is VALID (backward compatibility) — not an error, and stays null", () => {
  const omitted = validateFootballTypeInput(undefined);
  assert.equal(omitted.valid, true);
  assert.equal(omitted.footballType, null);

  const explicitNull = validateFootballTypeInput(null);
  assert.equal(explicitNull.valid, true);
  assert.equal(explicitNull.footballType, null);
});

console.log("\nreadFootballMatchContext — authoritative, never-guessed context from a persisted row");

check("a row with football_type='efootball' round-trips to a full eFootball context", () => {
  const context = readFootballMatchContext({ football_type: "efootball", team_size: 11 });
  assert.deepEqual(context, { football_type: "efootball", team_size: 11 });
});

check("a row with football_type='real_football' round-trips to a full real-football context", () => {
  const context = readFootballMatchContext({ football_type: "real_football", team_size: 7 });
  assert.deepEqual(context, { football_type: "real_football", team_size: 7 });
});

check("NULL legacy context (both columns NULL) reads back as null — never fabricated as eFootball", () => {
  const context = readFootballMatchContext({ football_type: null, team_size: null });
  assert.equal(context, null);
});

check("an unrecognized/corrupt football_type string reads back as null rather than a guess (defensive)", () => {
  const context = readFootballMatchContext({ football_type: "not_a_real_type", team_size: null });
  assert.equal(context, null);
});

check("readFootballMatchContext derives team_size itself — it never trusts the row's own team_size column", () => {
  // Even if some future direct-SQL change or bug left an inconsistent
  // team_size on the row, this function must still return the DERIVED
  // value for the football_type — never echo back a stored value that
  // could have drifted out of sync.
  const context = readFootballMatchContext({ football_type: "efootball", team_size: 999 });
  assert.equal(context?.team_size, 11);
});

console.log("\nallowsEfootballContext — eFootball-specific data is gated on POSITIVE confirmation only");

check("eFootball context allows eFootball-specific data", () => {
  assert.equal(allowsEfootballContext({ football_type: "efootball", team_size: 11 }), true);
});

check("real-football context does NOT allow eFootball-specific data", () => {
  assert.equal(allowsEfootballContext({ football_type: "real_football", team_size: 7 }), false);
});

check("null (unknown/legacy) context does NOT allow eFootball-specific data — never defaults to eFootball", () => {
  assert.equal(allowsEfootballContext(null), false);
});

console.log("\n10A — eFootball context is identifiable without any player-card signal");

check("an eFootball context is fully determined by football_type alone — no player-card/formation data is read anywhere in this file", () => {
  // There is no parameter for player cards, formation size, or any
  // other signal anywhere in this file's functions — this test simply
  // documents/locks that contract at the type level: every function
  // here takes only a football_type/context value, never a players or
  // cards argument.
  assert.equal(buildFootballMatchContext.length, 1);
  assert.equal(readFootballMatchContext.length, 1);
  assert.equal(allowsEfootballContext.length, 1);
});

console.log(`\n${passed} check(s) passed.`);
if (process.exitCode) {
  console.error("\nSome checks FAILED.");
} else {
  console.log("All checks passed.");
}
