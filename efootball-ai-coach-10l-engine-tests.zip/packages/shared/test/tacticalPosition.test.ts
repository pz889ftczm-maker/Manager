// Batch 10E — lightweight, framework-free tests for tacticalPosition.ts's
// unified tactical position model. Same convention as
// footballEvent.test.ts/realFootballMatchContext.test.ts — no test
// runner/framework, Node's built-in `assert`, run via `tsx`.
//
// Run with:  npx tsx packages/shared/test/tacticalPosition.test.ts
//        or: npm test --workspace=packages/shared
//
// SCOPE NOTE: pure, in-process tests of the shared model/builders/
// validation only — no database, no RLS, no worker integration.

import assert from "node:assert/strict";
import {
  tacticalPositionFromAnalysisEntry,
  tacticalPositionStatesFromTacticalAnalysis,
  tacticalPositionFromEfootballContextPlayer,
  tacticalPositionFromRealFootballContextPlayer,
  tacticalPositionsFromEfootballContext,
  tacticalPositionsFromRealFootballContext,
  validateTacticalPositionInput,
  type TacticalPositionValidationInput,
} from "../src/tacticalPosition.js";
import type { EfootballContextPlayer, EfootballMatchContextResult } from "../src/efootballMatchContext.js";
import type { RealFootballContextPlayer, RealFootballMatchContextResult } from "../src/realFootballMatchContext.js";
// 10D regression — this batch must not break the existing unified event
// schema/validation it sits alongside.
import { isUnifiedEventType, unifiedEventTypeForLegacyEvent, UNIFIED_EVENT_TYPES } from "../src/footballEvent.js";

let passed = 0;

function check(name: string, fn: () => void): void {
  try {
    fn();
    passed += 1;
    console.log(`  ok — ${name}`);
  } catch (err) {
    process.exitCode = 1;
    console.error(`  FAIL — ${name}`);
    console.error(err);
  }
}

function efootballPlayer(overrides: Partial<EfootballContextPlayer> = {}): EfootballContextPlayer {
  return {
    player_id: "p1",
    name: "Alex Striker",
    position: "ST",
    position_slot: "st",
    overall: 88,
    playstyle: "Goal Poacher",
    attributes: { pace: 90 },
    ...overrides,
  };
}

function realFootballPlayer(overrides: Partial<RealFootballContextPlayer> = {}): RealFootballContextPlayer {
  return {
    player_id: "p2",
    name: "Sam Wing",
    position: "LW",
    position_slot: "lw",
    role: "forward",
    ...overrides,
  };
}

// ============================================================
// 1. tactical_analysis entry -> TacticalPosition (the coordinate path)
// ============================================================

console.log("tacticalPositionFromAnalysisEntry — eFootball, reliable coordinates");

check("builds a position with coordinates from a well-formed entry (efootball)", () => {
  const pos = tacticalPositionFromAnalysisEntry(
    { role: "CB", team: "user", pos: { x: 40, y: 25 } },
    { footballType: "efootball", matchId: "m1", eventId: "e1", timestampSeconds: 305, isApproximate: false }
  );
  assert.ok(pos);
  assert.equal(pos!.football_type, "efootball");
  assert.equal(pos!.match_id, "m1");
  assert.equal(pos!.role, "CB");
  assert.equal(pos!.team, "user");
  assert.deepEqual(pos!.coordinates, { x: 40, y: 25 });
  assert.equal(pos!.timestamp_seconds, 305);
  assert.equal(pos!.confidence_level, "confirmed");
  assert.deepEqual(pos!.source, {
    type: "tactical_analysis",
    event_id: "e1",
    is_approximate: false,
    context_source: null,
  });
  // Never fabricated — a bare role/team label is not a player identity.
  assert.equal(pos!.player, null);
});

check("is_approximate=true maps to confidence_level=uncertain (efootball)", () => {
  const pos = tacticalPositionFromAnalysisEntry(
    { role: "GK", team: "opponent", pos: { x: 5, y: 50 } },
    { footballType: "efootball", matchId: "m1", eventId: "e1", timestampSeconds: null, isApproximate: true }
  );
  assert.equal(pos!.confidence_level, "uncertain");
  assert.equal(pos!.source.is_approximate, true);
});

console.log("tacticalPositionFromAnalysisEntry — Real Football, reliable coordinates");

check("builds a position with coordinates from a well-formed entry (real_football)", () => {
  const pos = tacticalPositionFromAnalysisEntry(
    { role: "forward", team: "user", pos: { x: 82, y: 60 } },
    { footballType: "real_football", matchId: "m2", eventId: "e2", timestampSeconds: 12, isApproximate: false }
  );
  assert.ok(pos);
  assert.equal(pos!.football_type, "real_football");
  assert.equal(pos!.match_id, "m2");
  assert.deepEqual(pos!.coordinates, { x: 82, y: 60 });
  assert.equal(pos!.confidence_level, "confirmed");
  assert.equal(pos!.source.event_id, "e2");
});

console.log("tacticalPositionFromAnalysisEntry — NULL coordinates");

check("missing pos -> coordinates null, role preserved", () => {
  const pos = tacticalPositionFromAnalysisEntry(
    { role: "CM", team: "user" },
    { footballType: "efootball", matchId: "m1", eventId: "e1", timestampSeconds: 10, isApproximate: false }
  );
  assert.ok(pos);
  assert.equal(pos!.coordinates, null);
  assert.equal(pos!.role, "CM");
  // No coordinate evidence -> no confidence claim, and is_approximate is
  // not reported either (it only ever qualifies a coordinate).
  assert.equal(pos!.confidence_level, null);
  assert.equal(pos!.source.is_approximate, null);
});

check("malformed pos (non-numeric) -> coordinates null, never coerced", () => {
  const pos = tacticalPositionFromAnalysisEntry(
    { role: "RB", team: "user", pos: { x: "wide", y: null } },
    { footballType: "real_football", matchId: "m2", eventId: "e2", timestampSeconds: null, isApproximate: false }
  );
  assert.ok(pos);
  assert.equal(pos!.coordinates, null);
});

check("out-of-range pos -> coordinates null, never clamped", () => {
  const pos = tacticalPositionFromAnalysisEntry(
    { role: "LB", team: "user", pos: { x: 140, y: -5 } },
    { footballType: "efootball", matchId: "m1", eventId: "e1", timestampSeconds: null, isApproximate: false }
  );
  assert.equal(pos!.coordinates, null);
});

check("entry with neither role nor coordinates returns null", () => {
  const pos = tacticalPositionFromAnalysisEntry(
    { team: "user" },
    { footballType: "efootball", matchId: "m1", eventId: "e1", timestampSeconds: null, isApproximate: false }
  );
  assert.equal(pos, null);
});

check("non-object entry returns null defensively", () => {
  const pos = tacticalPositionFromAnalysisEntry("not an object", {
    footballType: "efootball",
    matchId: "m1",
    eventId: "e1",
    timestampSeconds: null,
    isApproximate: false,
  });
  assert.equal(pos, null);
});

// ============================================================
// 2. actual/recommended pairing + ownership/integrity of the evidence chain
// ============================================================

console.log("tacticalPositionStatesFromTacticalAnalysis — actual/recommended + integrity");

check("pairs actual with recommended only on exact (role, team) match", () => {
  const states = tacticalPositionStatesFromTacticalAnalysis(
    {
      event_id: "e9",
      actual_positions: [
        { role: "CB", team: "user", pos: { x: 40, y: 20 } },
        { role: "ST", team: "user", pos: { x: 70, y: 50 } },
      ],
      recommended_positions: [{ role: "CB", team: "user", pos: { x: 45, y: 22 } }],
      is_approximate: false,
    },
    { footballType: "efootball", matchId: "m1", timestampSeconds: 100 }
  );
  assert.equal(states.length, 2);
  const cb = states.find((s) => s.actual.role === "CB")!;
  assert.ok(cb.recommended);
  assert.deepEqual(cb.recommended!.coordinates, { x: 45, y: 22 });
  const st = states.find((s) => s.actual.role === "ST")!;
  assert.equal(st.recommended, null);
});

check("every position traces back to the exact match_id/event_id/timestamp requested — never mixed across matches", () => {
  const states = tacticalPositionStatesFromTacticalAnalysis(
    {
      event_id: "e-integrity",
      actual_positions: [{ role: "GK", team: "user", pos: { x: 5, y: 50 } }],
      recommended_positions: null,
      is_approximate: true,
    },
    { footballType: "real_football", matchId: "m-integrity", timestampSeconds: 42 }
  );
  assert.equal(states.length, 1);
  const { actual } = states[0];
  assert.equal(actual.match_id, "m-integrity");
  assert.equal(actual.source.event_id, "e-integrity");
  assert.equal(actual.timestamp_seconds, 42);
  assert.equal(actual.football_type, "real_football");
});

check("null/non-array actual_positions or recommended_positions yields no fabricated entries", () => {
  const states = tacticalPositionStatesFromTacticalAnalysis(
    { event_id: "e10", actual_positions: null, recommended_positions: null, is_approximate: true },
    { footballType: "efootball", matchId: "m1", timestampSeconds: null }
  );
  assert.deepEqual(states, []);
});

// ============================================================
// 3. Roster/formation context -> TacticalPosition (never coordinates)
// ============================================================

console.log("tacticalPositionFromEfootballContextPlayer / tacticalPositionFromRealFootballContextPlayer — role without coordinates");

check("eFootball roster position carries role/player but never coordinates", () => {
  const pos = tacticalPositionFromEfootballContextPlayer(efootballPlayer(), {
    matchId: "m1",
    contextSource: "current_data",
  });
  assert.equal(pos.coordinates, null);
  assert.equal(pos.role, "ST");
  assert.equal(pos.position_slot, "st");
  assert.deepEqual(pos.player, { player_id: "p1", name: "Alex Striker" });
  assert.equal(pos.source.type, "efootball_context");
  assert.equal(pos.source.context_source, "current_data");
  assert.equal(pos.confidence_level, null);
});

check("Real Football roster position carries role/player but never coordinates", () => {
  const pos = tacticalPositionFromRealFootballContextPlayer(realFootballPlayer(), {
    matchId: "m2",
    contextSource: "current_data",
  });
  assert.equal(pos.coordinates, null);
  assert.equal(pos.role, "forward");
  assert.equal(pos.source.type, "real_football_context");
});

check("player_id null -> player reference null (never fabricated)", () => {
  const pos = tacticalPositionFromEfootballContextPlayer(efootballPlayer({ player_id: null, name: null }), {
    matchId: "m1",
    contextSource: "current_data",
  });
  assert.equal(pos.player, null);
});

// ============================================================
// 4. Historical snapshot preference (inherited, not re-decided here)
// ============================================================

console.log("tacticalPositionsFromEfootballContext / tacticalPositionsFromRealFootballContext — historical snapshot preference");

check("context_source = historical_snapshot is carried through on every position when the resolved context used a snapshot", () => {
  const contextResult: EfootballMatchContextResult = {
    available: true,
    source: "historical_snapshot",
    players: [efootballPlayer(), efootballPlayer({ player_id: "p3", position_slot: "cb1", position: "CB" })],
    manager: null,
    formation: null,
  };
  const positions = tacticalPositionsFromEfootballContext(contextResult, "m1");
  assert.equal(positions.length, 2);
  assert.ok(positions.every((p) => p.source.context_source === "historical_snapshot"));
});

check("unavailable context (e.g. no snapshot/live data yet) yields no positions — never fabricated placeholders", () => {
  const contextResult: EfootballMatchContextResult = { available: false, reason: "no_data" };
  assert.deepEqual(tacticalPositionsFromEfootballContext(contextResult, "m1"), []);
});

// ============================================================
// 5. No eFootball-only data leaking into Real Football
// ============================================================

console.log("football-type isolation");

check("a real_football match's context result never yields efootball positions (structural — wrong-type context is already unavailable)", () => {
  const wrongTypeResult: RealFootballMatchContextResult = { available: false, reason: "not_real_football" };
  assert.deepEqual(tacticalPositionsFromRealFootballContext(wrongTypeResult, "m1"), []);
});

check("validateTacticalPositionInput rejects an efootball_context-sourced position on a real_football match", () => {
  const draft: TacticalPositionValidationInput = {
    role: "ST",
    source: { type: "efootball_context", context_source: "current_data" },
  };
  const result = validateTacticalPositionInput(draft, { footballType: "real_football" });
  assert.equal(result.valid, false);
  assert.ok(result.errors.some((e) => e.includes("efootball_context")));
});

check("validateTacticalPositionInput rejects a real_football_context-sourced position on an efootball match", () => {
  const draft: TacticalPositionValidationInput = {
    role: "forward",
    source: { type: "real_football_context", context_source: "current_data" },
  };
  const result = validateTacticalPositionInput(draft, { footballType: "efootball" });
  assert.equal(result.valid, false);
  assert.ok(result.errors.some((e) => e.includes("real_football_context")));
});

// ============================================================
// 6. Rejection of fabricated/inferred coordinates (write-path gate)
// ============================================================

console.log("validateTacticalPositionInput — rejection of fabricated/inferred coordinates");

check("accepts a well-formed tactical_analysis-sourced position with coordinates", () => {
  const draft: TacticalPositionValidationInput = {
    coordinates: { x: 40, y: 25 },
    source: { type: "tactical_analysis", event_id: "e1", is_approximate: false },
  };
  const result = validateTacticalPositionInput(draft, { footballType: "efootball" });
  assert.equal(result.valid, true);
  assert.deepEqual(result.errors, []);
});

check("rejects coordinates with no source at all", () => {
  const draft: TacticalPositionValidationInput = { coordinates: { x: 40, y: 25 } };
  const result = validateTacticalPositionInput(draft, { footballType: "efootball" });
  assert.equal(result.valid, false);
  assert.ok(result.errors.some((e) => e.includes("tactical_analysis")));
});

check("rejects coordinates sourced from a roster/formation context (role-derived coordinates)", () => {
  const draft: TacticalPositionValidationInput = {
    coordinates: { x: 40, y: 25 },
    source: { type: "efootball_context", context_source: "current_data" },
  };
  const result = validateTacticalPositionInput(draft, { footballType: "efootball" });
  assert.equal(result.valid, false);
  assert.ok(result.errors.some((e) => e.includes("never be derived or inferred")));
});

check("rejects tactical_analysis-sourced coordinates missing event_id (broken evidence chain)", () => {
  const draft: TacticalPositionValidationInput = {
    coordinates: { x: 40, y: 25 },
    source: { type: "tactical_analysis", is_approximate: false },
  };
  const result = validateTacticalPositionInput(draft, { footballType: "efootball" });
  assert.equal(result.valid, false);
  assert.ok(result.errors.some((e) => e.includes("event_id")));
});

check("rejects tactical_analysis-sourced coordinates missing is_approximate", () => {
  const draft: TacticalPositionValidationInput = {
    coordinates: { x: 40, y: 25 },
    source: { type: "tactical_analysis", event_id: "e1" },
  };
  const result = validateTacticalPositionInput(draft, { footballType: "efootball" });
  assert.equal(result.valid, false);
  assert.ok(result.errors.some((e) => e.includes("is_approximate")));
});

check("rejects out-of-range coordinates even with a valid tactical_analysis source", () => {
  const draft: TacticalPositionValidationInput = {
    coordinates: { x: 400, y: 25 },
    source: { type: "tactical_analysis", event_id: "e1", is_approximate: false },
  };
  const result = validateTacticalPositionInput(draft, { footballType: "efootball" });
  assert.equal(result.valid, false);
});

check("rejects football_type supplied directly on the position draft", () => {
  const draft: TacticalPositionValidationInput = { football_type: "efootball" };
  const result = validateTacticalPositionInput(draft, { footballType: "efootball" });
  assert.equal(result.valid, false);
  assert.ok(result.errors.some((e) => e.includes("football_type")));
});

check("rejects a negative timestamp_seconds", () => {
  const draft: TacticalPositionValidationInput = { timestamp_seconds: -5 };
  const result = validateTacticalPositionInput(draft, { footballType: "efootball" });
  assert.equal(result.valid, false);
});

check("null draft is rejected, not thrown", () => {
  const result = validateTacticalPositionInput(null as unknown as TacticalPositionValidationInput, {
    footballType: null,
  });
  assert.equal(result.valid, false);
});

// ============================================================
// 7. Existing 10D unified event behavior remains intact
// ============================================================

console.log("10D regression — unified event schema untouched by 10E");

check("UNIFIED_EVENT_TYPES / isUnifiedEventType / unifiedEventTypeForLegacyEvent still behave as before", () => {
  assert.ok(UNIFIED_EVENT_TYPES.includes("pass"));
  assert.equal(isUnifiedEventType("shot"), true);
  assert.equal(isUnifiedEventType("not_a_type"), false);
  assert.equal(unifiedEventTypeForLegacyEvent("bad_pass"), "pass");
  assert.equal(unifiedEventTypeForLegacyEvent("good_interception"), "defensive_action");
});

console.log(`\n${passed} check(s) passed.`);
