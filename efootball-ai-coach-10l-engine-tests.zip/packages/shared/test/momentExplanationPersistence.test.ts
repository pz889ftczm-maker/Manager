// Batch 10J-1 — lightweight, framework-free tests for
// momentExplanationPersistence.ts. Same convention as
// momentExplanation.test.ts/fullMatchContext.test.ts — no test
// runner/framework, Node's built-in `assert`, run via `tsx`.
//
// Run with:  npx tsx packages/shared/test/momentExplanationPersistence.test.ts
//        or: npm test --workspace=packages/shared
//
// SCOPE NOTE: pure, in-process tests of the shared row<->model builders
// only — no database, no RLS, no worker integration, no AI calls (10J-1
// makes none of the latter three). Proves the 1:1 field-copy contract
// (never re-derived, nulls preserved, no valid row without a match_id),
// not migration 0030's own SQL (which has no TypeScript-testable
// behavior of its own beyond what these builders assume).

import assert from "node:assert/strict";
import {
  toMomentExplanationInsertRow,
  momentExplanationFromRow,
  momentExplanationsByEventId,
  type MomentExplanationRow,
} from "../src/momentExplanationPersistence.js";
import type { MomentExplanation } from "../src/momentExplanation.js";

let passed = 0;

function check(name: string, fn: () => void): void {
  try {
    fn();
    passed += 1;
    console.log(`  ok — ${name}`);
  } catch (err) {
    process.exitCode = 1;
    console.error(`  FAIL — ${name}`);
    console.error(err);
  }
}

/** A fully-populated MomentExplanation (10H) — every field non-null so
 * round-trip tests can assert nothing is dropped/altered. */
function fullExplanation(overrides: Partial<MomentExplanation> = {}): MomentExplanation {
  return {
    football_type: "efootball",
    match_id: "match-1",
    event_id: "event-1",
    player: { player_id: "player-1", name: "Test Player" },
    timestamp_seconds: 123.5,
    what_happened: "Played a risky central pass into a double press.",
    why_it_happened: ["Two defenders were already converging on the receiver."],
    better_option: { label: "Switch play to the far side", evidence: ["The far side was 2v1 in attack."] },
    why_better: ["The far side was 2v1 in attack."],
    actionable_improvement: "Switch play to the far side",
    confidence: 82,
    evidence: ["Two defenders were already converging on the receiver.", "The far side was 2v1 in attack."],
    has_sufficient_evidence: true,
    positions: {
      actual: {
        football_type: "efootball",
        match_id: "match-1",
        team: "user",
        player: { player_id: "player-1", name: "Test Player" },
        role: "CM",
        position_slot: null,
        coordinates: { x: 50, y: 50 },
        timestamp_seconds: 123.5,
        confidence_level: "likely",
        source: { type: "tactical_analysis", event_id: "event-1", is_approximate: false, context_source: null },
      },
      recommended: null,
    },
    passing_lane: {
      football_type: "efootball",
      match_id: "match-1",
      from_player: null,
      to_player: null,
      from_coordinates: { x: 50, y: 50 },
      to_coordinates: { x: 80, y: 60 },
      quality: "recommended",
      timestamp_seconds: 123.5,
      confidence_level: "likely",
      source: { type: "tactical_analysis", event_id: "event-1", is_approximate: false },
    },
    space: {
      football_type: "efootball",
      match_id: "match-1",
      status: "open",
      center: { x: 80, y: 60 },
      radius: 8,
      intensity: null,
      source: { type: "tactical_analysis", event_id: "event-1", is_approximate: false },
    },
    ...overrides,
  };
}

/** A MomentExplanationRow with every field populated — the row-shape
 * mirror of fullExplanation() above, for row -> model round-trip
 * tests. */
function fullRow(overrides: Partial<MomentExplanationRow> = {}): MomentExplanationRow {
  const explanation = fullExplanation();
  return {
    id: "row-1",
    match_id: explanation.match_id as string,
    event_id: explanation.event_id,
    football_type: explanation.football_type,
    timestamp_seconds: explanation.timestamp_seconds,
    player: explanation.player,
    what_happened: explanation.what_happened,
    why_it_happened: explanation.why_it_happened,
    better_option: explanation.better_option,
    why_better: explanation.why_better,
    actionable_improvement: explanation.actionable_improvement,
    confidence: explanation.confidence,
    evidence: explanation.evidence,
    has_sufficient_evidence: explanation.has_sufficient_evidence,
    positions: explanation.positions,
    passing_lane: explanation.passing_lane,
    space: explanation.space,
    created_at: "2026-01-01T00:00:00Z",
    ...overrides,
  };
}

console.log("toMomentExplanationInsertRow — preserves every field exactly, never re-derives");

check("every MomentExplanation field is copied verbatim onto the insert row", () => {
  const explanation = fullExplanation();
  const row = toMomentExplanationInsertRow(explanation);
  assert.notEqual(row, null);
  assert.equal(row!.match_id, explanation.match_id);
  assert.equal(row!.event_id, explanation.event_id);
  assert.equal(row!.football_type, explanation.football_type);
  assert.equal(row!.timestamp_seconds, explanation.timestamp_seconds);
  assert.deepEqual(row!.player, explanation.player);
  assert.equal(row!.what_happened, explanation.what_happened);
  assert.deepEqual(row!.why_it_happened, explanation.why_it_happened);
  assert.deepEqual(row!.better_option, explanation.better_option);
  assert.deepEqual(row!.why_better, explanation.why_better);
  assert.equal(row!.actionable_improvement, explanation.actionable_improvement);
  assert.equal(row!.confidence, explanation.confidence);
  assert.deepEqual(row!.evidence, explanation.evidence);
  assert.equal(row!.has_sufficient_evidence, explanation.has_sufficient_evidence);
  assert.deepEqual(row!.positions, explanation.positions);
  assert.deepEqual(row!.passing_lane, explanation.passing_lane);
  assert.deepEqual(row!.space, explanation.space);
});

check("null fields on MomentExplanation stay null on the row, never defaulted/fabricated", () => {
  const explanation = fullExplanation({
    player: null,
    timestamp_seconds: null,
    what_happened: null,
    why_it_happened: null,
    better_option: null,
    why_better: null,
    actionable_improvement: null,
    confidence: null,
    evidence: null,
    positions: null,
    passing_lane: null,
    space: null,
    has_sufficient_evidence: false,
  });
  const row = toMomentExplanationInsertRow(explanation);
  assert.notEqual(row, null);
  assert.equal(row!.player, null);
  assert.equal(row!.timestamp_seconds, null);
  assert.equal(row!.what_happened, null);
  assert.equal(row!.why_it_happened, null);
  assert.equal(row!.better_option, null);
  assert.equal(row!.why_better, null);
  assert.equal(row!.actionable_improvement, null);
  assert.equal(row!.confidence, null);
  assert.equal(row!.evidence, null);
  assert.equal(row!.positions, null);
  assert.equal(row!.passing_lane, null);
  assert.equal(row!.space, null);
  assert.equal(row!.has_sufficient_evidence, false);
});

check("a null match_id yields no row at all — never a fabricated match_id", () => {
  const explanation = fullExplanation({ match_id: null });
  assert.equal(toMomentExplanationInsertRow(explanation), null);
});

console.log("\nmomentExplanationFromRow — reconstructs the exact MomentExplanation, never re-derives");

check("every row field is copied verbatim onto the reconstructed MomentExplanation", () => {
  const row = fullRow();
  const explanation = momentExplanationFromRow(row);
  assert.equal(explanation.football_type, row.football_type);
  assert.equal(explanation.match_id, row.match_id);
  assert.equal(explanation.event_id, row.event_id);
  assert.deepEqual(explanation.player, row.player);
  assert.equal(explanation.timestamp_seconds, row.timestamp_seconds);
  assert.equal(explanation.what_happened, row.what_happened);
  assert.deepEqual(explanation.why_it_happened, row.why_it_happened);
  assert.deepEqual(explanation.better_option, row.better_option);
  assert.deepEqual(explanation.why_better, row.why_better);
  assert.equal(explanation.actionable_improvement, row.actionable_improvement);
  assert.equal(explanation.confidence, row.confidence);
  assert.deepEqual(explanation.evidence, row.evidence);
  assert.equal(explanation.has_sufficient_evidence, row.has_sufficient_evidence);
  assert.deepEqual(explanation.positions, row.positions);
  assert.deepEqual(explanation.passing_lane, row.passing_lane);
  assert.deepEqual(explanation.space, row.space);
});

check("round-trip: toMomentExplanationInsertRow then momentExplanationFromRow yields an equivalent MomentExplanation", () => {
  const original = fullExplanation();
  const insertRow = toMomentExplanationInsertRow(original)!;
  const row: MomentExplanationRow = { id: "row-1", created_at: "2026-01-01T00:00:00Z", ...insertRow };
  const roundTripped = momentExplanationFromRow(row);
  assert.deepEqual(roundTripped, original);
});

console.log("\nmomentExplanationsByEventId — keys reconstructed explanations by event_id, never re-derives");

check("returns one reconstructed MomentExplanation per row, keyed by event_id", () => {
  const rowA = fullRow({ id: "row-a", event_id: "event-a" });
  const rowB = fullRow({ id: "row-b", event_id: "event-b", what_happened: "A different moment entirely." });
  const byEventId = momentExplanationsByEventId([rowA, rowB]);
  assert.deepEqual(Object.keys(byEventId).sort(), ["event-a", "event-b"]);
  assert.equal(byEventId["event-a"].what_happened, rowA.what_happened);
  assert.equal(byEventId["event-b"].what_happened, "A different moment entirely.");
});

check("no rows -> an empty record, never fabricated", () => {
  assert.deepEqual(momentExplanationsByEventId([]), {});
});

console.log(`\n${passed} check(s) passed`);
if (process.exitCode) {
  console.error("\nSome checks FAILED — see above.");
} else {
  console.log("All checks passed.");
}
