// Batch 6B-4 — lightweight, framework-free tests for managerLibrary.ts's
// pure validation/helper functions. Same convention as
// playerLibrary.test.ts — no test runner/framework, uses Node's built-in
// `assert` module, runs via `tsx`.
//
// Run with:  npx tsx packages/shared/test/managerLibrary.test.ts
//        or: npm test --workspace=packages/shared
//
// SCOPE NOTE: these are pure, in-process unit tests of validation/helper
// logic only — nothing here talks to a real Supabase/Postgres instance.
// RLS enforcement and the manager_library_user_variant_uniq constraint's
// actual database-level behavior are exercised by migration
// 0014_manager_library.sql and the manager-library-save Edge Function's
// own logic, reviewed by hand, not by a live integration test.

import assert from "node:assert/strict";
import {
  validateManagerLibraryInput,
  isUniqueViolation,
  managerLibraryVariantKey,
  MANAGER_LIBRARY_VARIANT_UNIQUE_CONSTRAINT,
} from "../src/managerLibrary.js";
import { isPathOwnedByUser } from "../src/uploadValidation.js";

let passed = 0;

function check(name: string, fn: () => void): void {
  try {
    fn();
    passed += 1;
    console.log(`  ok — ${name}`);
  } catch (err) {
    process.exitCode = 1;
    console.error(`  FAIL — ${name}`);
    console.error(err);
  }
}

console.log("validateManagerLibraryInput — NULL/UNKNOWN handling");

check("explicit nulls stay null — never guessed, never zeroed — and the input is valid", () => {
  const { valid, sanitized, errors } = validateManagerLibraryInput({
    name: null,
    possession_rating: null,
    quick_counter_rating: null,
    long_ball_counter_rating: null,
    out_wide_rating: null,
    long_ball_rating: null,
    manager_image_path: null,
  });
  assert.equal(sanitized.name, null);
  assert.equal(sanitized.possession_rating, null);
  assert.equal(sanitized.quick_counter_rating, null);
  assert.equal(sanitized.long_ball_counter_rating, null);
  assert.equal(sanitized.out_wide_rating, null);
  assert.equal(sanitized.long_ball_rating, null);
  assert.deepEqual(errors, []);
  assert.equal(valid, true);
});

check("a known rating of 0 is preserved, distinct from unknown", () => {
  const { sanitized } = validateManagerLibraryInput({
    name: "Test Manager",
    possession_rating: 0,
    quick_counter_rating: null,
    long_ball_counter_rating: null,
    out_wide_rating: null,
    long_ball_rating: null,
    manager_image_path: null,
  });
  assert.equal(sanitized.possession_rating, 0);
});

console.log("validateManagerLibraryInput — rating validation");

check("a negative rating is rejected to null AND fails the whole input", () => {
  const { valid, sanitized, errors } = validateManagerLibraryInput({
    name: null,
    possession_rating: -5,
    quick_counter_rating: null,
    long_ball_counter_rating: null,
    out_wide_rating: null,
    long_ball_rating: null,
    manager_image_path: null,
  });
  assert.equal(sanitized.possession_rating, null);
  assert.ok(errors.some((e) => e.startsWith("possession_rating:")));
  assert.equal(valid, false);
});

check("a non-integer (decimal) rating is rejected to null AND fails the whole input", () => {
  const { valid, sanitized, errors } = validateManagerLibraryInput({
    name: null,
    possession_rating: null,
    quick_counter_rating: 82.5,
    long_ball_counter_rating: null,
    out_wide_rating: null,
    long_ball_rating: null,
    manager_image_path: null,
  });
  assert.equal(sanitized.quick_counter_rating, null);
  assert.ok(errors.length > 0);
  assert.equal(valid, false);
});

check("a string rating is rejected to null (must be a real number) AND fails the whole input", () => {
  const { valid, sanitized, errors } = validateManagerLibraryInput({
    name: null,
    possession_rating: "82" as unknown,
    quick_counter_rating: null,
    long_ball_counter_rating: null,
    out_wide_rating: null,
    long_ball_rating: null,
    manager_image_path: null,
  });
  assert.equal(sanitized.possession_rating, null);
  assert.ok(errors.length > 0);
  assert.equal(valid, false);
});

check("an explicit NaN rating is rejected to null AND fails the whole input", () => {
  const { valid, sanitized, errors } = validateManagerLibraryInput({
    name: null,
    possession_rating: Number.NaN,
    quick_counter_rating: null,
    long_ball_counter_rating: null,
    out_wide_rating: null,
    long_ball_rating: null,
    manager_image_path: null,
  });
  assert.equal(sanitized.possession_rating, null);
  assert.ok(errors.length > 0);
  assert.equal(valid, false);
});

check("ratings are never clamped to an assumed max, and a large value remains valid", () => {
  const { valid, sanitized, errors } = validateManagerLibraryInput({
    name: null,
    possession_rating: 150,
    quick_counter_rating: null,
    long_ball_counter_rating: null,
    out_wide_rating: null,
    long_ball_rating: null,
    manager_image_path: null,
  });
  assert.equal(sanitized.possession_rating, 150);
  assert.deepEqual(errors, []);
  assert.equal(valid, true);
});

console.log("validateManagerLibraryInput — malformed input must fail validation, not be silently nulled");

check("a wrong-typed field (e.g. name as a number) fails the whole input", () => {
  const { valid, sanitized, errors } = validateManagerLibraryInput({
    name: 12345 as unknown,
    possession_rating: null,
    quick_counter_rating: null,
    long_ball_counter_rating: null,
    out_wide_rating: null,
    long_ball_rating: null,
    manager_image_path: null,
  });
  assert.equal(sanitized.name, null);
  assert.ok(errors.some((e) => e.startsWith("name:")));
  assert.equal(valid, false);
});

check("a normal, fully valid entry passes with no errors", () => {
  const { valid, errors, sanitized } = validateManagerLibraryInput({
    name: "Pep Guardiola",
    possession_rating: 95,
    quick_counter_rating: 60,
    long_ball_counter_rating: 55,
    out_wide_rating: 70,
    long_ball_rating: 40,
    manager_image_path: "user-a/manager.png",
  });
  assert.equal(valid, true);
  assert.deepEqual(errors, []);
  assert.equal(sanitized.name, "Pep Guardiola");
  assert.equal(sanitized.possession_rating, 95);
  assert.equal(sanitized.manager_image_path, "user-a/manager.png");
});

console.log("validateManagerLibraryInput — no fabricated required fields");

check("a fully-empty entry is still `valid` — nothing is force-required", () => {
  const { valid, errors } = validateManagerLibraryInput({
    name: null,
    possession_rating: null,
    quick_counter_rating: null,
    long_ball_counter_rating: null,
    out_wide_rating: null,
    long_ball_rating: null,
    manager_image_path: null,
  });
  assert.equal(valid, true);
  assert.deepEqual(errors, []);
});

console.log("validateManagerLibraryInput — image path safety");

check("a path traversal sequence is rejected to null AND fails the whole input", () => {
  const { valid, sanitized, errors } = validateManagerLibraryInput({
    name: null,
    possession_rating: null,
    quick_counter_rating: null,
    long_ball_counter_rating: null,
    out_wide_rating: null,
    long_ball_rating: null,
    manager_image_path: "user-a/../user-b/manager.png",
  });
  assert.equal(sanitized.manager_image_path, null);
  assert.ok(errors.length > 0);
  assert.equal(valid, false);
});

check("input that is not an object fails entirely", () => {
  const { valid, errors } = validateManagerLibraryInput("not-an-object");
  assert.equal(valid, false);
  assert.ok(errors.length > 0);
});

console.log("isPathOwnedByUser — ownership (reused from playerLibrary — sanity check here too)");

check("a path under the caller's own prefix is owned", () => {
  assert.equal(isPathOwnedByUser("user-a/manager.png", "user-a"), true);
});

check("a path under a different user's prefix is NOT owned", () => {
  assert.equal(isPathOwnedByUser("user-b/manager.png", "user-a"), false);
});

console.log("duplicate-save handling");

check("isUniqueViolation recognizes Postgres SQLSTATE 23505 for the right constraint", () => {
  const pgError = {
    code: "23505",
    message: `duplicate key value violates unique constraint "${MANAGER_LIBRARY_VARIANT_UNIQUE_CONSTRAINT}"`,
  };
  assert.equal(isUniqueViolation(pgError, MANAGER_LIBRARY_VARIANT_UNIQUE_CONSTRAINT), true);
});

check("isUniqueViolation rejects a unique violation on an unrelated constraint", () => {
  const pgError = { code: "23505", message: 'duplicate key value violates unique constraint "some_other_constraint"' };
  assert.equal(isUniqueViolation(pgError, MANAGER_LIBRARY_VARIANT_UNIQUE_CONSTRAINT), false);
});

check("isUniqueViolation rejects a non-unique-violation error entirely", () => {
  assert.equal(isUniqueViolation({ code: "23502", message: "null value in column" }), false);
});

check("managerLibraryVariantKey normalizes name case the same way the DB's expression index does", () => {
  const key = managerLibraryVariantKey({
    name: "Pep Guardiola",
    possession_rating: 95,
    quick_counter_rating: 60,
    long_ball_counter_rating: 55,
    out_wide_rating: 70,
    long_ball_rating: 40,
  });
  assert.deepEqual(key, {
    nameLower: "pep guardiola",
    possession_rating: 95,
    quick_counter_rating: 60,
    long_ball_counter_rating: 55,
    out_wide_rating: 70,
    long_ball_rating: 40,
  });
});

check("managerLibraryVariantKey returns null when name is null — the partial index doesn't apply", () => {
  assert.equal(
    managerLibraryVariantKey({
      name: null,
      possession_rating: 95,
      quick_counter_rating: 60,
      long_ball_counter_rating: 55,
      out_wide_rating: 70,
      long_ball_rating: 40,
    }),
    null
  );
});

console.log("");
if (process.exitCode === 1) {
  console.error(`${passed} check(s) passed, at least one FAILED.`);
} else {
  console.log(`All ${passed} checks passed.`);
}
