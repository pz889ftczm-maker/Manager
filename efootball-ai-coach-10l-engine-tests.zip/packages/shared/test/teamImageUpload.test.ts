// Batch 7B — lightweight, framework-free tests for the Team Library
// image upload validation/path helpers, following the same convention as
// managerImageUpload.test.ts / playerLibrary.test.ts (no jest/vitest in
// this repo; run via tsx). Pure, in-process unit tests only — nothing
// here talks to a real Supabase/Postgres/Storage instance. No live
// Supabase Storage testing was performed for this batch.
//
// Run with:  npx tsx packages/shared/test/teamImageUpload.test.ts
//        or: npm test --workspace=packages/shared
//
// These exercise the SAME validateUpload/sniffFileType/isPathOwnedByUser
// functions player-card and manager-image uploads already rely on
// (uploadValidation.ts) — team images reuse that logic rather than a
// parallel copy, so these tests are scoped to what's actually new for
// this batch: buildSafeTeamImageStoragePath, plus team-image-shaped
// exercises of the shared validators to cover the spec's required cases
// end to end.

import assert from "node:assert/strict";
import {
  validateUpload,
  buildSafeTeamImageStoragePath,
  isPathOwnedByUser,
  DEFAULT_MAX_IMAGE_MB,
} from "../src/uploadValidation.js";

let passed = 0;

function check(name: string, fn: () => void): void {
  try {
    fn();
    passed += 1;
    console.log(`  ok — ${name}`);
  } catch (err) {
    process.exitCode = 1;
    console.error(`  FAIL — ${name}`);
    console.error(err);
  }
}

// ---- Real magic-byte prefixes (a few bytes is enough for sniffFileType) ----
const JPEG_HEAD = new Uint8Array([0xff, 0xd8, 0xff, 0xe0, 0x00, 0x10]);
const PNG_HEAD = new Uint8Array([0x89, 0x50, 0x4e, 0x47, 0x0d, 0x0a, 0x1a, 0x0a]);
const WEBP_HEAD = new Uint8Array([
  0x52, 0x49, 0x46, 0x46, 0x00, 0x00, 0x00, 0x00, 0x57, 0x45, 0x42, 0x50,
]); // 'RIFF'....'WEBP'
const GIF_HEAD = new Uint8Array([0x47, 0x49, 0x46, 0x38, 0x39, 0x61]); // 'GIF89a' — not in the allowed set
const MP4_HEAD = new Uint8Array([0x00, 0x00, 0x00, 0x18, 0x66, 0x74, 0x79, 0x70]); // video, wrong kind for an image upload
const GARBAGE_HEAD = new Uint8Array([0x00, 0x01, 0x02, 0x03, 0x04, 0x05]); // fake/garbage bytes — no MIME can rescue this

console.log("validateUpload (team image shape) — valid formats accepted (spec section 9)");

check("valid JPEG is accepted", () => {
  const result = validateUpload({ expectedKind: "image", sizeBytes: 1024, headBytes: JPEG_HEAD });
  assert.equal(result.valid, true);
  assert.equal(result.detected?.mimeType, "image/jpeg");
});

check("valid PNG is accepted", () => {
  const result = validateUpload({ expectedKind: "image", sizeBytes: 1024, headBytes: PNG_HEAD });
  assert.equal(result.valid, true);
  assert.equal(result.detected?.mimeType, "image/png");
});

check("valid WEBP is accepted", () => {
  const result = validateUpload({ expectedKind: "image", sizeBytes: 1024, headBytes: WEBP_HEAD });
  assert.equal(result.valid, true);
  assert.equal(result.detected?.mimeType, "image/webp");
});

console.log("validateUpload (team image shape) — fake MIME / invalid bytes / unsupported format rejected (spec section 9)");

check("fake MIME type with invalid (garbage) magic bytes is rejected", () => {
  // Mirrors "fake MIME type with invalid bytes rejected" — validateUpload
  // never consults a claimed MIME type at all, only the real bytes, so a
  // caller claiming image/jpeg over bytes that aren't a real JPEG is
  // rejected the same as any other unrecognized content.
  const result = validateUpload({ expectedKind: "image", sizeBytes: 1024, headBytes: GARBAGE_HEAD });
  assert.equal(result.valid, false);
  assert.equal(result.detected, null);
});

check("a format outside the allowed set (GIF) is rejected, not silently accepted", () => {
  const result = validateUpload({ expectedKind: "image", sizeBytes: 1024, headBytes: GIF_HEAD });
  assert.equal(result.valid, false);
});

check("wrong content kind (video bytes claimed as an image upload) is rejected", () => {
  const result = validateUpload({ expectedKind: "image", sizeBytes: 1024, headBytes: MP4_HEAD });
  assert.equal(result.valid, false);
  assert.ok(result.errors.some((e) => e.includes("video")));
});

console.log("validateUpload (team image shape) — size limit (spec section 9)");

check("oversized file (>15MB) is rejected at the team-image limit", () => {
  const oneByteOverLimit = DEFAULT_MAX_IMAGE_MB * 1024 * 1024 + 1;
  const result = validateUpload({ expectedKind: "image", sizeBytes: oneByteOverLimit, headBytes: JPEG_HEAD });
  assert.equal(result.valid, false);
  assert.ok(result.errors.some((e) => e.includes("15MB") || e.includes(`${DEFAULT_MAX_IMAGE_MB}MB`)));
});

check("empty file is rejected", () => {
  const result = validateUpload({ expectedKind: "image", sizeBytes: 0, headBytes: JPEG_HEAD });
  assert.equal(result.valid, false);
});

console.log("buildSafeTeamImageStoragePath — safe path generation (spec sections 2/6)");

check("builds the {user_id}/{random}.{ext} shape, no match segment", () => {
  const path = buildSafeTeamImageStoragePath("user-a", "png", "abc-123");
  assert.equal(path, "user-a/abc-123.png");
});

check("never derives the path from user-supplied filename content — malicious extension falls back to bin", () => {
  const path = buildSafeTeamImageStoragePath("user-a", "png/../../etc", "abc-123");
  assert.equal(path, "user-a/abc-123.bin");
});

check("a crafted random id (path traversal attempt) falls back to a safe default", () => {
  const path = buildSafeTeamImageStoragePath("user-a", "png", "../../etc/passwd");
  assert.equal(path, "user-a/upload.png");
  assert.ok(!path.includes(".."));
});

check("the userId segment is used verbatim as the ownership prefix (RLS/DB CHECK rely on this)", () => {
  const path = buildSafeTeamImageStoragePath("user-a", "jpg", "rand1");
  assert.ok(path.startsWith("user-a/"));
});

console.log("isPathOwnedByUser (team image paths) — user-owned accepted, cross-user/unsafe rejected (spec sections 2/8/9)");

check("a team image path owned by the caller is recognized as owned", () => {
  const path = buildSafeTeamImageStoragePath("user-a", "png", "rand1");
  assert.equal(isPathOwnedByUser(path, "user-a"), true);
});

check("another user's team image path is never treated as owned (cross-user path rejected)", () => {
  const path = buildSafeTeamImageStoragePath("user-b", "png", "rand1");
  assert.equal(isPathOwnedByUser(path, "user-a"), false);
});

check("a path-traversal-shaped string is never treated as owned (unsafe path rejected)", () => {
  assert.equal(isPathOwnedByUser("../user-a/rand1.png", "user-a"), false);
});

check("an absolute path is never treated as owned (unsafe path rejected)", () => {
  assert.equal(isPathOwnedByUser("/user-a/rand1.png", "user-a"), false);
});

console.log(`\n${passed} checks passed`);
