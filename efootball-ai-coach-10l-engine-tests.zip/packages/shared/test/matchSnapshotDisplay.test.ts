// Batch 9D — lightweight, framework-free tests for
// matchSnapshotDisplay.ts's pure selection + display-model helpers.
// Same convention as matchSnapshots.test.ts/matchSnapshotCreation.test.ts
// — no test runner/framework, Node's built-in `assert`, run via `tsx`.
//
// Run with:  npx tsx packages/shared/test/matchSnapshotDisplay.test.ts
//        or: npm test --workspace=packages/shared
//
// SCOPE NOTE: these are pure, in-process unit tests of display logic
// only — nothing here talks to a real Supabase/Postgres instance. The
// actual ownership boundary (RLS on match_snapshots/match_snapshot_players,
// 0025) is unchanged by 9D and not re-exercised here — what IS
// exercised below is selectMatchSnapshotForMatch's own defense-in-depth
// match-id re-check, which is what apps/web/src/hooks/useMatchSnapshot.ts
// relies on for the "never trust a client-supplied snapshot id" contract
// (spec 9D-3).

import assert from "node:assert/strict";
import {
  selectMatchSnapshotForMatch,
  toKeyValueEntries,
  buildMatchSnapshotDisplay,
} from "../src/matchSnapshotDisplay.js";
import type { MatchSnapshot, MatchSnapshotPlayer } from "../src/matchSnapshots.js";

let passed = 0;

function check(name: string, fn: () => void): void {
  try {
    fn();
    passed += 1;
    console.log(`  ok — ${name}`);
  } catch (err) {
    process.exitCode = 1;
    console.error(`  FAIL — ${name}`);
    console.error(err);
  }
}

const MATCH_A = "11111111-1111-1111-1111-111111111111";
const MATCH_B = "22222222-2222-2222-2222-222222222222";
const USER_ID = "33333333-3333-3333-3333-333333333333";

function makeSnapshot(overrides: Partial<MatchSnapshot> = {}): MatchSnapshot {
  return {
    id: "44444444-4444-4444-4444-444444444444",
    user_id: USER_ID,
    match_id: MATCH_A,
    team_id: null,
    formation_id: null,
    manager_id: null,
    formation_code: null,
    formation_name: null,
    positions: null,
    tactical_instructions: null,
    team_name: null,
    team_motto: null,
    team_description: null,
    team_founded_year: null,
    team_stadium: null,
    manager_name: null,
    manager_ratings: null,
    created_at: "2026-01-01T00:00:00.000Z",
    ...overrides,
  };
}

function makePlayer(overrides: Partial<MatchSnapshotPlayer> = {}): MatchSnapshotPlayer {
  return {
    id: "55555555-5555-5555-5555-555555555555",
    snapshot_id: "44444444-4444-4444-4444-444444444444",
    player_id: null,
    player_name: null,
    position: null,
    overall: null,
    playstyle: null,
    attributes: null,
    position_slot: null,
    created_at: "2026-01-01T00:00:00.000Z",
    ...overrides,
  };
}

console.log("selectMatchSnapshotForMatch — correct snapshot for the current match");

check("returns the (only) snapshot for this match_id", () => {
  const snap = makeSnapshot({ match_id: MATCH_A });
  assert.equal(selectMatchSnapshotForMatch([snap], MATCH_A), snap);
});

check("returns null when there is no snapshot at all (clean 'unavailable' case)", () => {
  assert.equal(selectMatchSnapshotForMatch([], MATCH_A), null);
});

console.log("\nselectMatchSnapshotForMatch — ownership/match-scoping protection");

check("never returns a snapshot belonging to a different match_id, even if it's the only row given", () => {
  const otherMatchSnapshot = makeSnapshot({ match_id: MATCH_B });
  assert.equal(selectMatchSnapshotForMatch([otherMatchSnapshot], MATCH_A), null);
});

check("filters out cross-match rows and still finds the correct one among a mixed set", () => {
  const wrong1 = makeSnapshot({ id: "a", match_id: MATCH_B, created_at: "2026-01-05T00:00:00.000Z" });
  const right = makeSnapshot({ id: "b", match_id: MATCH_A, created_at: "2026-01-02T00:00:00.000Z" });
  const wrong2 = makeSnapshot({ id: "c", match_id: MATCH_B, created_at: "2026-01-06T00:00:00.000Z" });
  const result = selectMatchSnapshotForMatch([wrong1, right, wrong2], MATCH_A);
  assert.equal(result?.id, "b");
});

check("of several genuine snapshots for the same match, picks the most recently created one", () => {
  const older = makeSnapshot({ id: "older", match_id: MATCH_A, created_at: "2026-01-01T00:00:00.000Z" });
  const newer = makeSnapshot({ id: "newer", match_id: MATCH_A, created_at: "2026-02-01T00:00:00.000Z" });
  const result = selectMatchSnapshotForMatch([older, newer], MATCH_A);
  assert.equal(result?.id, "newer");
});

console.log("\ntoKeyValueEntries — NULL-safe rendering");

check("null/undefined object returns an empty list, never a fabricated row", () => {
  assert.deepEqual(toKeyValueEntries(null), []);
  assert.deepEqual(toKeyValueEntries(undefined), []);
});

check("a null value inside the object stays null — never coerced to 0 or ''", () => {
  const entries = toKeyValueEntries({ possession_rating: null, long_ball_rating: 70 });
  assert.deepEqual(entries, [
    { key: "long_ball_rating", value: 70 },
    { key: "possession_rating", value: null },
  ]);
});

check("entries are sorted alphabetically by key for a stable render order", () => {
  const entries = toKeyValueEntries({ zeta: 1, alpha: 2, mid: 3 });
  assert.deepEqual(
    entries.map((e) => e.key),
    ["alpha", "mid", "zeta"]
  );
});

console.log("\nbuildMatchSnapshotDisplay — historical values, captured at match time");

check("full snapshot: every field is copied through as-is, no fabrication", () => {
  const snapshot = makeSnapshot({
    team_name: "Riverside FC",
    team_motto: "Never Say Die",
    team_description: "A scrappy underdog side.",
    team_founded_year: 1998,
    team_stadium: "Riverside Park",
    formation_name: "4-3-3 Attack",
    formation_code: "433A",
    tactical_instructions: { build_up_play: "possession" },
    manager_name: "A. Wenger",
    manager_ratings: { possession_rating: 88, long_ball_rating: null },
  });
  const player = makePlayer({
    player_name: "J. Smith",
    position: "ST",
    overall: 82,
    playstyle: "Poacher",
    position_slot: "FW1",
    attributes: { pace: 84, finishing: null },
  });

  const display = buildMatchSnapshotDisplay(snapshot, [player]);

  assert.equal(display.teamName, "Riverside FC");
  assert.equal(display.teamMotto, "Never Say Die");
  assert.equal(display.teamFoundedYear, 1998);
  assert.equal(display.formationCode, "433A");
  assert.deepEqual(display.tacticalInstructions, [{ key: "build_up_play", value: "possession" }]);
  assert.equal(display.managerName, "A. Wenger");
  assert.deepEqual(display.managerRatings, [
    { key: "long_ball_rating", value: null },
    { key: "possession_rating", value: 88 },
  ]);
  assert.equal(display.players.length, 1);
  assert.equal(display.players[0].playerName, "J. Smith");
  assert.deepEqual(display.players[0].attributes, [
    { key: "finishing", value: null },
    { key: "pace", value: 84 },
  ]);
});

check("sparse snapshot (no manager, no formation): absent sections render as empty, not fabricated", () => {
  const snapshot = makeSnapshot({ team_name: "Solo FC" });
  const display = buildMatchSnapshotDisplay(snapshot, []);

  assert.equal(display.teamName, "Solo FC");
  assert.equal(display.teamMotto, null);
  assert.equal(display.formationName, null);
  assert.deepEqual(display.tacticalInstructions, []);
  assert.equal(display.managerName, null);
  assert.deepEqual(display.managerRatings, []);
  assert.deepEqual(display.players, []);
});

check("a field that is NULL on the snapshot stays NULL in the display model (never 0/'')", () => {
  const snapshot = makeSnapshot({ team_founded_year: null, team_stadium: null });
  const display = buildMatchSnapshotDisplay(snapshot, []);
  assert.equal(display.teamFoundedYear, null);
  assert.equal(display.teamStadium, null);
});

console.log("\nbuildMatchSnapshotDisplay — player ordering");

check("players are ordered by position_slot, with a missing slot sorted last", () => {
  const p1 = makePlayer({ id: "p1", position_slot: "MF2" });
  const p2 = makePlayer({ id: "p2", position_slot: "GK" });
  const p3 = makePlayer({ id: "p3", position_slot: null });
  const display = buildMatchSnapshotDisplay(makeSnapshot(), [p1, p2, p3]);
  assert.deepEqual(
    display.players.map((p) => p.id),
    ["p2", "p1", "p3"]
  );
});

console.log("\nbuildMatchSnapshotDisplay — historical independence from the current Library");

check(
  "renders fully from the snapshot's own copied columns even when provenance ids are null (source since deleted)",
  () => {
    // team_id/formation_id/manager_id null, player_id null on the
    // player row — exactly what migration 0025's `on delete set null`
    // FKs produce once the original Team/Formation/Manager/Player
    // Library row has been deleted. The historical columns themselves
    // are untouched by that deletion, so the display model must still
    // be fully populated from them.
    const snapshot = makeSnapshot({
      team_id: null,
      formation_id: null,
      manager_id: null,
      team_name: "Deleted-Source FC",
      manager_name: "Former Manager",
    });
    const player = makePlayer({ player_id: null, player_name: "Departed Player", overall: 75 });

    const display = buildMatchSnapshotDisplay(snapshot, [player]);

    assert.equal(display.teamName, "Deleted-Source FC");
    assert.equal(display.managerName, "Former Manager");
    assert.equal(display.players[0].playerName, "Departed Player");
    assert.equal(display.players[0].overall, 75);
  }
);

console.log("\nbuildMatchSnapshotDisplay — 9F: Player Library edits/deletes never reach an existing snapshot");

check("player_name/overall/position/playstyle/attributes edits made to the Player Library AFTER a snapshot was captured are invisible to that snapshot's display", () => {
  // The whole point of 9F: buildMatchSnapshotDisplay has no parameter
  // for "the current Player Library row" at all — there is no plumbing
  // by which an edit made later could reach an already-built display.
  // `snapshot`/`player` below represent exactly what was persisted at
  // capture time; a caller editing the *live* player_library row
  // afterward (renaming them, changing overall/playstyle/attributes,
  // reassigning their position) has no code path back into this data.
  const capturedAtMatchTime = makePlayer({
    player_id: "aaaaaaaa-aaaa-aaaa-aaaa-aaaaaaaaaaaa",
    player_name: "J. Smith",
    position: "ST",
    overall: 82,
    playstyle: "Poacher",
    position_slot: "FW1",
    attributes: { pace: 84 },
  });

  const display = buildMatchSnapshotDisplay(makeSnapshot(), [capturedAtMatchTime]);

  // Simulate the live row being edited to something completely
  // different AFTER the snapshot above was built — this object is
  // never passed to buildMatchSnapshotDisplay, which is exactly the
  // guarantee under test: there is nothing for it to be passed to.
  const editedLiveRow = { player_name: "R. Jones", overall: 99, playstyle: "Target Man" };
  assert.notEqual(display.players[0].playerName, editedLiveRow.player_name);
  assert.equal(display.players[0].playerName, "J. Smith");
  assert.equal(display.players[0].overall, 82);
  assert.equal(display.players[0].playstyle, "Poacher");
});

check("player deletion (player_id -> null via ON DELETE SET NULL) leaves every historical player field intact", () => {
  const player = makePlayer({
    player_id: null, // migration 0025: player_library(id) on delete set null
    player_name: "Departed Player",
    position: "CB",
    overall: 78,
    playstyle: "Aerial Threat",
    position_slot: "DF2",
    attributes: { heading: 88 },
  });
  const display = buildMatchSnapshotDisplay(makeSnapshot(), [player]);
  assert.equal(display.players[0].playerName, "Departed Player");
  assert.equal(display.players[0].position, "CB");
  assert.equal(display.players[0].overall, 78);
  assert.equal(display.players[0].playstyle, "Aerial Threat");
  assert.equal(display.players[0].positionSlot, "DF2");
  assert.deepEqual(display.players[0].attributes, [{ key: "heading", value: 88 }]);
});

console.log("\nbuildMatchSnapshotDisplay — 9F: Manager Library edits/deletes never reach an existing snapshot");

check("manager_name/ratings edits made to the Manager Library after capture are invisible to the snapshot", () => {
  const snapshot = makeSnapshot({
    manager_id: "bbbbbbbb-bbbb-bbbb-bbbb-bbbbbbbbbbbb",
    manager_name: "A. Wenger",
    manager_ratings: {
      possession_rating: 88,
      quick_counter_rating: 70,
      long_ball_counter_rating: 60,
      out_wide_rating: 75,
      long_ball_rating: 50,
    },
  });
  const display = buildMatchSnapshotDisplay(snapshot, []);
  const editedLiveManager = { name: "J. Mourinho", possession_rating: 40 };
  assert.notEqual(display.managerName, editedLiveManager.name);
  assert.equal(display.managerName, "A. Wenger");
  assert.deepEqual(display.managerRatings, [
    { key: "long_ball_counter_rating", value: 60 },
    { key: "long_ball_rating", value: 50 },
    { key: "out_wide_rating", value: 75 },
    { key: "possession_rating", value: 88 },
    { key: "quick_counter_rating", value: 70 },
  ]);
});

check("manager deletion (manager_id -> null) leaves manager_name/manager_ratings intact — NULL ratings stay NULL, never 0", () => {
  const snapshot = makeSnapshot({
    manager_id: null, // migration 0025: manager_library(id) on delete set null
    manager_name: "Former Manager",
    manager_ratings: { possession_rating: 65, long_ball_rating: null },
  });
  const display = buildMatchSnapshotDisplay(snapshot, []);
  assert.equal(display.managerName, "Former Manager");
  assert.deepEqual(display.managerRatings, [
    { key: "long_ball_rating", value: null },
    { key: "possession_rating", value: 65 },
  ]);
});

console.log("\nbuildMatchSnapshotDisplay — 9F: Team Library edits/deletes never reach an existing snapshot");

check("team_name/motto/description/founded_year/stadium edits made after capture are invisible to the snapshot", () => {
  const snapshot = makeSnapshot({
    team_id: "cccccccc-cccc-cccc-cccc-cccccccccccc",
    team_name: "Riverside FC",
    team_motto: "Never Say Die",
    team_description: "A scrappy underdog side.",
    team_founded_year: 1998,
    team_stadium: "Riverside Park",
  });
  const display = buildMatchSnapshotDisplay(snapshot, []);
  const editedLiveTeam = { name: "Riverside United", stadium: "New Arena" };
  assert.notEqual(display.teamName, editedLiveTeam.name);
  assert.notEqual(display.teamStadium, editedLiveTeam.stadium);
  assert.equal(display.teamName, "Riverside FC");
  assert.equal(display.teamMotto, "Never Say Die");
  assert.equal(display.teamDescription, "A scrappy underdog side.");
  assert.equal(display.teamFoundedYear, 1998);
  assert.equal(display.teamStadium, "Riverside Park");
});

check("team deletion (team_id -> null) leaves every historical team field intact", () => {
  const snapshot = makeSnapshot({
    team_id: null, // migration 0025: team_library(id) on delete set null
    team_name: "Deleted-Source FC",
    team_motto: "Still Here",
    team_founded_year: 2005,
    team_stadium: "Old Ground",
  });
  const display = buildMatchSnapshotDisplay(snapshot, []);
  assert.equal(display.teamName, "Deleted-Source FC");
  assert.equal(display.teamMotto, "Still Here");
  assert.equal(display.teamFoundedYear, 2005);
  assert.equal(display.teamStadium, "Old Ground");
});

console.log("\nbuildMatchSnapshotDisplay — 9F: Formation/tactics edits/deletes never reach an existing snapshot");

check("formation_code/formation_name/tactical_instructions edits made after capture are invisible to the snapshot", () => {
  const snapshot = makeSnapshot({
    formation_id: "dddddddd-dddd-dddd-dddd-dddddddddddd",
    formation_code: "433A",
    formation_name: "4-3-3 Attack",
    tactical_instructions: { build_up_play: "possession" },
  });
  const display = buildMatchSnapshotDisplay(snapshot, []);
  const editedLiveFormation = { code: "442", name: "4-4-2 Flat" };
  assert.notEqual(display.formationCode, editedLiveFormation.code);
  assert.equal(display.formationCode, "433A");
  assert.equal(display.formationName, "4-3-3 Attack");
  assert.deepEqual(display.tacticalInstructions, [{ key: "build_up_play", value: "possession" }]);
});

check("formation deletion (formation_id -> null) leaves formation_code/name/tactical_instructions intact", () => {
  const snapshot = makeSnapshot({
    formation_id: null, // migration 0025: team_formations(id) on delete set null
    formation_code: "352",
    formation_name: "3-5-2",
    tactical_instructions: { pressing: "high" },
  });
  const display = buildMatchSnapshotDisplay(snapshot, []);
  assert.equal(display.formationCode, "352");
  assert.equal(display.formationName, "3-5-2");
  assert.deepEqual(display.tacticalInstructions, [{ key: "pressing", value: "high" }]);
});

console.log("\nselectMatchSnapshotForMatch / buildMatchSnapshotDisplay — 9F: no path back to current Library data");

check(
  "buildMatchSnapshotDisplay's own signature has no 'current library' input — there is nothing for the UI to substitute even by mistake",
  () => {
    // Documents/enforces the actual 9F guarantee at the type level: the
    // function accepts exactly (snapshot, players) — two args. A caller
    // cannot pass a third "fall back to current data" argument because
    // none exists. If a future change ever added one, this length
    // assertion (and every other check in this file, which never
    // passes such a value) would need to be revisited deliberately.
    assert.equal(buildMatchSnapshotDisplay.length, 2);
  }
);

console.log("\nselectMatchSnapshotForMatch — 9F: isolation between different snapshots is preserved under a mixed, multi-owner-shaped input");

check(
  "given rows as if returned unfiltered across users (never how RLS actually returns them — see match_snapshots_select_own, 0025), " +
    "match-id scoping alone still never lets a wrong-match row through",
  () => {
    // RLS (auth.uid() = user_id on match_snapshots; the derived
    // snapshot_id -> match_snapshots.user_id join on
    // match_snapshot_players) is the actual, sole enforcement boundary
    // for cross-user access (0025) and is unchanged by 9F — nothing
    // here re-implements it. This test only proves the pure
    // match-id defense-in-depth check inside selectMatchSnapshotForMatch
    // itself holds even in a worst-case input shape (rows tagged with
    // two different user_ids mixed together), so a hypothetical RLS
    // bypass/bug wouldn't be silently compounded by this function too.
    const mine = makeSnapshot({ id: "mine", match_id: MATCH_A, user_id: USER_ID, created_at: "2026-01-01T00:00:00.000Z" });
    const someoneElses = makeSnapshot({
      id: "theirs",
      match_id: MATCH_B,
      user_id: "ffffffff-ffff-ffff-ffff-ffffffffffff",
      created_at: "2026-01-02T00:00:00.000Z",
    });
    const result = selectMatchSnapshotForMatch([mine, someoneElses], MATCH_A);
    assert.equal(result?.id, "mine");
  }
);

console.log(`\n${passed} check(s) passed.`);
if (process.exitCode) {
  console.error("\nSome checks FAILED.");
} else {
  console.log("All checks passed.");
}
