// Batch 10I — lightweight, framework-free tests for fullMatchContext.ts.
// Same convention as momentExplanation.test.ts — no test runner/
// framework, Node's built-in `assert`, run via `tsx`.
//
// Run with:  npx tsx packages/shared/test/fullMatchContext.test.ts
//        or: npm test --workspace=packages/shared
//
// SCOPE NOTE: pure, in-process tests of the shared aggregate/builder
// only — no database, no RLS, no worker integration, no AI calls (10I
// makes none). Proves ordering/windowing/separation/composition, not
// the internal rules of 10D–10H (already covered by their own test
// files).

import assert from "node:assert/strict";
import {
  buildFullMatchContext,
  buildFullMatchContextFromPersistedMoments,
  buildFullMatchContextWithPersistedExplanations,
  type FullMatchContextInput,
} from "../src/fullMatchContext.js";
import type { FootballMatchContext } from "../src/footballMatchContext.js";
import type { UnifiedFootballEvent } from "../src/footballEvent.js";
import type { EfootballMatchContextResult } from "../src/efootballMatchContext.js";
import type { RealFootballMatchContextResult } from "../src/realFootballMatchContext.js";
import { buildMomentExplanationFromUnifiedEvent } from "../src/momentExplanation.js";

let passed = 0;

function check(name: string, fn: () => void): void {
  try {
    fn();
    passed += 1;
    console.log(`  ok — ${name}`);
  } catch (err) {
    process.exitCode = 1;
    console.error(`  FAIL — ${name}`);
    console.error(err);
  }
}

const EFOOTBALL: FootballMatchContext = { football_type: "efootball", team_size: 11 };
const REAL_FOOTBALL: FootballMatchContext = { football_type: "real_football", team_size: 7 };

function event(overrides: Partial<UnifiedFootballEvent> = {}): UnifiedFootballEvent {
  return {
    id: "event-1",
    match_id: "match-1",
    football_type: "efootball",
    timestamp_seconds: 100,
    event_type: "pass",
    legacy_event_type: "bad_pass",
    legacy_category: "passing",
    severity: "mistake",
    confidence: 80,
    confidence_level: "likely",
    decision_score: 20,
    description: "Played a risky central pass into a double press.",
    better_option: null,
    reasoning: null,
    player_id: null,
    evidence: null,
    before_frame_url: null,
    decision_frame_url: null,
    after_frame_url: null,
    context_start_seconds: null,
    context_end_seconds: null,
    created_at: "2026-01-01T00:00:00Z",
    ...overrides,
  };
}

const AVAILABLE_EFOOTBALL: EfootballMatchContextResult = {
  available: true,
  source: "current_data",
  players: [],
  manager: null,
  formation: null,
};

const AVAILABLE_REAL_FOOTBALL: RealFootballMatchContextResult = {
  available: true,
  source: "current_data",
  players: [],
  formation: null,
};

console.log("buildFullMatchContext — football_type/match_id/team_size pass through, never re-derived");

check("football_type/team_size come from footballContext, match_id from input — never from the events themselves", () => {
  const result = buildFullMatchContext({
    matchId: "match-1",
    footballContext: EFOOTBALL,
    events: [event()],
  });
  assert.equal(result.football_type, "efootball");
  assert.equal(result.team_size, 11);
  assert.equal(result.match_id, "match-1");
});

check("no footballContext -> football_type/team_size are null, never defaulted", () => {
  const result = buildFullMatchContext({ matchId: "match-1", footballContext: null, events: [] });
  assert.equal(result.football_type, null);
  assert.equal(result.team_size, null);
});

console.log("\nbuildFullMatchContext — chronological ordering, nulls last, never fabricated");

check("moments are ordered ascending by timestamp_seconds regardless of input order", () => {
  const result = buildFullMatchContext({
    matchId: "match-1",
    footballContext: EFOOTBALL,
    events: [
      event({ id: "e3", timestamp_seconds: 300 }),
      event({ id: "e1", timestamp_seconds: 100 }),
      event({ id: "e2", timestamp_seconds: 200 }),
    ],
  });
  assert.deepEqual(
    result.moments.map((m) => m.event.id),
    ["e1", "e2", "e3"]
  );
});

check("events with an unknown timestamp sort after every timestamped event, never given a guessed position", () => {
  const result = buildFullMatchContext({
    matchId: "match-1",
    footballContext: EFOOTBALL,
    events: [
      event({ id: "e-null", timestamp_seconds: null }),
      event({ id: "e2", timestamp_seconds: 200 }),
      event({ id: "e1", timestamp_seconds: 100 }),
    ],
  });
  assert.deepEqual(
    result.moments.map((m) => m.event.id),
    ["e1", "e2", "e-null"]
  );
});

check("no events supplied -> moments is an empty array, never fabricated", () => {
  const result = buildFullMatchContext({ matchId: "match-1", footballContext: EFOOTBALL, events: [] });
  assert.deepEqual(result.moments, []);
});

console.log("\nbuildFullMatchContext — surrounding_events reuse each event's own context window, never a guessed radius");

check("an event whose window covers another event's timestamp includes it in surrounding_events", () => {
  const result = buildFullMatchContext({
    matchId: "match-1",
    footballContext: EFOOTBALL,
    events: [
      event({ id: "e1", timestamp_seconds: 100, context_start_seconds: 95, context_end_seconds: 105 }),
      event({ id: "e2", timestamp_seconds: 102, context_start_seconds: null, context_end_seconds: null }),
      event({ id: "e3", timestamp_seconds: 500, context_start_seconds: null, context_end_seconds: null }),
    ],
  });
  const e1 = result.moments.find((m) => m.event.id === "e1")!;
  assert.deepEqual(
    e1.surrounding_events.map((e) => e.id),
    ["e2"]
  );
});

check("an event never includes itself in its own surrounding_events", () => {
  const result = buildFullMatchContext({
    matchId: "match-1",
    footballContext: EFOOTBALL,
    events: [event({ id: "e1", timestamp_seconds: 100, context_start_seconds: 90, context_end_seconds: 110 })],
  });
  assert.deepEqual(result.moments[0].surrounding_events, []);
});

check("an incomplete context window (either bound null) yields no surrounding_events, never a guessed window", () => {
  const result = buildFullMatchContext({
    matchId: "match-1",
    footballContext: EFOOTBALL,
    events: [
      event({ id: "e1", timestamp_seconds: 100, context_start_seconds: 95, context_end_seconds: null }),
      event({ id: "e2", timestamp_seconds: 102 }),
    ],
  });
  const e1 = result.moments.find((m) => m.event.id === "e1")!;
  assert.deepEqual(e1.surrounding_events, []);
});

check("an event with an unknown timestamp is never included as someone else's surrounding_event", () => {
  const result = buildFullMatchContext({
    matchId: "match-1",
    footballContext: EFOOTBALL,
    events: [
      event({ id: "e1", timestamp_seconds: 100, context_start_seconds: 0, context_end_seconds: 1000 }),
      event({ id: "e-null", timestamp_seconds: null }),
    ],
  });
  const e1 = result.moments.find((m) => m.event.id === "e1")!;
  assert.deepEqual(e1.surrounding_events, []);
});

console.log("\nbuildFullMatchContext — each moment reuses buildMomentExplanationFromUnifiedEvent (10H), never re-derived");

check("each moment's explanation matches calling 10H's own builder directly for that event", () => {
  const e = event({ reasoning: "Clear evidence the pass was risky." });
  const result = buildFullMatchContext({ matchId: "match-1", footballContext: EFOOTBALL, events: [e] });
  assert.equal(result.moments[0].explanation.what_happened, e.description);
  assert.deepEqual(result.moments[0].explanation.why_it_happened, ["Clear evidence the pass was risky."]);
});

console.log("\nbuildFullMatchContext — eFootball/Real Football separation preserved, never both populated");

check("efootball context is attached only when footballContext positively confirms efootball", () => {
  const result = buildFullMatchContext({
    matchId: "match-1",
    footballContext: EFOOTBALL,
    efootball: AVAILABLE_EFOOTBALL,
    realFootball: AVAILABLE_REAL_FOOTBALL,
    events: [],
  });
  assert.deepEqual(result.efootball, AVAILABLE_EFOOTBALL);
  assert.equal(result.real_football, null);
});

check("real_football context is attached only when footballContext positively confirms real_football", () => {
  const result = buildFullMatchContext({
    matchId: "match-1",
    footballContext: REAL_FOOTBALL,
    efootball: AVAILABLE_EFOOTBALL,
    realFootball: AVAILABLE_REAL_FOOTBALL,
    events: [],
  });
  assert.equal(result.efootball, null);
  assert.deepEqual(result.real_football, AVAILABLE_REAL_FOOTBALL);
});

check("unknown/null footballContext -> neither efootball nor real_football is attached, even if both were supplied", () => {
  const result = buildFullMatchContext({
    matchId: "match-1",
    footballContext: null,
    efootball: AVAILABLE_EFOOTBALL,
    realFootball: AVAILABLE_REAL_FOOTBALL,
    events: [],
  });
  assert.equal(result.efootball, null);
  assert.equal(result.real_football, null);
});

console.log(
  "\nbuildFullMatchContextFromPersistedMoments (10J-1) — uses persisted explanations verbatim, never re-derives"
);

check("a persisted explanation is used verbatim, never rebuilt from the event", () => {
  const e = event({ id: "e1", reasoning: "Clear evidence the pass was risky." });
  // A persisted explanation deliberately DIFFERENT from what 10H's own
  // builder would produce for `e` — proves this function reads the
  // persisted value rather than silently recomputing it.
  const persisted = {
    ...buildMomentExplanationFromUnifiedEvent(e),
    what_happened: "PERSISTED — historical value, not recomputed",
  };
  const result = buildFullMatchContextFromPersistedMoments({
    matchId: "match-1",
    footballContext: EFOOTBALL,
    events: [e],
    explanations: { e1: persisted },
  });
  assert.equal(result.moments.length, 1);
  assert.equal(result.moments[0].explanation.what_happened, "PERSISTED — historical value, not recomputed");
});

check("an event with no persisted explanation yields no MatchMoment of its own", () => {
  const e1 = event({ id: "e1", timestamp_seconds: 100 });
  const e2 = event({ id: "e2", timestamp_seconds: 200 });
  const result = buildFullMatchContextFromPersistedMoments({
    matchId: "match-1",
    footballContext: EFOOTBALL,
    events: [e1, e2],
    explanations: { e1: buildMomentExplanationFromUnifiedEvent(e1) },
  });
  assert.deepEqual(
    result.moments.map((m) => m.event.id),
    ["e1"]
  );
});

check("an event with no persisted explanation is still eligible as another moment's surrounding_event", () => {
  const e1 = event({ id: "e1", timestamp_seconds: 100, context_start_seconds: 95, context_end_seconds: 105 });
  const e2 = event({ id: "e2", timestamp_seconds: 102, context_start_seconds: null, context_end_seconds: null });
  const result = buildFullMatchContextFromPersistedMoments({
    matchId: "match-1",
    footballContext: EFOOTBALL,
    events: [e1, e2],
    explanations: { e1: buildMomentExplanationFromUnifiedEvent(e1) },
  });
  assert.deepEqual(
    result.moments[0].surrounding_events.map((e) => e.id),
    ["e2"]
  );
});

check("moments stay chronologically ordered, same rules as buildFullMatchContext", () => {
  const e1 = event({ id: "e1", timestamp_seconds: 300 });
  const e2 = event({ id: "e2", timestamp_seconds: 100 });
  const result = buildFullMatchContextFromPersistedMoments({
    matchId: "match-1",
    footballContext: EFOOTBALL,
    events: [e1, e2],
    explanations: {
      e1: buildMomentExplanationFromUnifiedEvent(e1),
      e2: buildMomentExplanationFromUnifiedEvent(e2),
    },
  });
  assert.deepEqual(
    result.moments.map((m) => m.event.id),
    ["e2", "e1"]
  );
});

check("no persisted explanations supplied -> moments is an empty array, never fabricated", () => {
  const result = buildFullMatchContextFromPersistedMoments({
    matchId: "match-1",
    footballContext: EFOOTBALL,
    events: [event()],
    explanations: {},
  });
  assert.deepEqual(result.moments, []);
});

check("football_type/team_size/efootball/real_football separation is preserved, same as buildFullMatchContext", () => {
  const result = buildFullMatchContextFromPersistedMoments({
    matchId: "match-1",
    footballContext: REAL_FOOTBALL,
    efootball: AVAILABLE_EFOOTBALL,
    realFootball: AVAILABLE_REAL_FOOTBALL,
    events: [],
    explanations: {},
  });
  assert.equal(result.football_type, "real_football");
  assert.equal(result.team_size, 7);
  assert.equal(result.efootball, null);
  assert.deepEqual(result.real_football, AVAILABLE_REAL_FOOTBALL);
});

console.log(
  "\nbuildFullMatchContextWithPersistedExplanations (10J-3) — persisted historical explanations take precedence, gaps still get a fresh one"
);

check(
  "an event with a persisted explanation uses it verbatim — never recomputed, even though it differs from what 10H's own builder would produce",
  () => {
    const e = event({ id: "e1", reasoning: "Clear evidence the pass was risky." });
    const persisted = {
      ...buildMomentExplanationFromUnifiedEvent(e),
      what_happened: "PERSISTED — historical value, not recomputed",
    };
    const result = buildFullMatchContextWithPersistedExplanations({
      matchId: "match-1",
      footballContext: EFOOTBALL,
      events: [e],
      explanations: { e1: persisted },
    });
    assert.equal(result.moments.length, 1);
    assert.equal(result.moments[0].explanation.what_happened, "PERSISTED — historical value, not recomputed");
  }
);

check(
  "an event with NO persisted explanation still gets a freshly computed one (unlike buildFullMatchContextFromPersistedMoments, nothing is dropped)",
  () => {
    const e1 = event({ id: "e1", timestamp_seconds: 100 });
    const e2 = event({ id: "e2", timestamp_seconds: 200, reasoning: "Live evidence for e2." });
    const result = buildFullMatchContextWithPersistedExplanations({
      matchId: "match-1",
      footballContext: EFOOTBALL,
      events: [e1, e2],
      explanations: { e1: buildMomentExplanationFromUnifiedEvent(e1) },
    });
    assert.deepEqual(
      result.moments.map((m) => m.event.id),
      ["e1", "e2"]
    );
    const e2Moment = result.moments.find((m) => m.event.id === "e2")!;
    assert.deepEqual(e2Moment.explanation.why_it_happened, ["Live evidence for e2."]);
  }
);

check("omitting `explanations` entirely falls back to a freshly computed explanation for every event", () => {
  const e = event({ id: "e1", reasoning: "Live evidence only." });
  const result = buildFullMatchContextWithPersistedExplanations({
    matchId: "match-1",
    footballContext: EFOOTBALL,
    events: [e],
  });
  assert.equal(result.moments.length, 1);
  assert.deepEqual(result.moments[0].explanation.why_it_happened, ["Live evidence only."]);
});

check(
  "a persisted explanation's own null fields (insufficient evidence) are preserved exactly, never backfilled",
  () => {
    const e = event({ id: "e1" });
    const persisted = buildMomentExplanationFromUnifiedEvent(e); // no reasoning/better_option -> null fields
    assert.equal(persisted.has_sufficient_evidence, false);
    assert.equal(persisted.better_option, null);
    const result = buildFullMatchContextWithPersistedExplanations({
      matchId: "match-1",
      footballContext: EFOOTBALL,
      events: [e],
      explanations: { e1: persisted },
    });
    assert.equal(result.moments[0].explanation.has_sufficient_evidence, false);
    assert.equal(result.moments[0].explanation.better_option, null);
  }
);

check("moments stay chronologically ordered, mixing persisted and freshly computed explanations", () => {
  const e1 = event({ id: "e1", timestamp_seconds: 300 });
  const e2 = event({ id: "e2", timestamp_seconds: 100 });
  const result = buildFullMatchContextWithPersistedExplanations({
    matchId: "match-1",
    footballContext: EFOOTBALL,
    events: [e1, e2],
    explanations: { e1: buildMomentExplanationFromUnifiedEvent(e1) },
  });
  assert.deepEqual(
    result.moments.map((m) => m.event.id),
    ["e2", "e1"]
  );
});

check("surrounding_events still reuse each event's own context window regardless of which explanation source was used", () => {
  const e1 = event({ id: "e1", timestamp_seconds: 100, context_start_seconds: 95, context_end_seconds: 105 });
  const e2 = event({ id: "e2", timestamp_seconds: 102, context_start_seconds: null, context_end_seconds: null });
  const result = buildFullMatchContextWithPersistedExplanations({
    matchId: "match-1",
    footballContext: EFOOTBALL,
    events: [e1, e2],
    explanations: { e1: buildMomentExplanationFromUnifiedEvent(e1) },
  });
  const e1Moment = result.moments.find((m) => m.event.id === "e1")!;
  assert.deepEqual(
    e1Moment.surrounding_events.map((e) => e.id),
    ["e2"]
  );
});

check(
  "football_type/team_size/efootball/real_football separation is preserved, same as buildFullMatchContext/buildFullMatchContextFromPersistedMoments",
  () => {
    const result = buildFullMatchContextWithPersistedExplanations({
      matchId: "match-1",
      footballContext: REAL_FOOTBALL,
      efootball: AVAILABLE_EFOOTBALL,
      realFootball: AVAILABLE_REAL_FOOTBALL,
      events: [],
      explanations: {},
    });
    assert.equal(result.football_type, "real_football");
    assert.equal(result.team_size, 7);
    assert.equal(result.efootball, null);
    assert.deepEqual(result.real_football, AVAILABLE_REAL_FOOTBALL);
  }
);

console.log(`\n${passed} check(s) passed`);
if (process.exitCode) {
  console.error("\nSome checks FAILED — see above.");
} else {
  console.log("All checks passed.");
}
