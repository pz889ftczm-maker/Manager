// Batch 10D — lightweight, framework-free tests for footballEvent.ts's
// unified event schema, mapping, and validation. Same convention as
// footballMatchContext.test.ts / realFootballMatchContext.test.ts — no
// test runner/framework, Node's built-in `assert`, run via `tsx`.
//
// Run with:  npx tsx packages/shared/test/footballEvent.test.ts
//        or: npm test --workspace=packages/shared
//
// SCOPE NOTE: pure, in-process tests of the shared schema/validation
// only — no database, no RLS, no worker integration (those are
// unchanged by 10D and covered by their own existing tests).

import assert from "node:assert/strict";
import {
  UNIFIED_EVENT_TYPES,
  isUnifiedEventType,
  unifiedEventTypeForLegacyEvent,
  allLegacyEventTypes,
  toUnifiedFootballEvent,
  validateUnifiedFootballEventInput,
  type UnifiedFootballEventValidationInput,
} from "../src/footballEvent.js";
import type { FootballMatchContext } from "../src/footballMatchContext.js";
import type { AnalysisEvent } from "../src/types.js";

let passed = 0;

function check(name: string, fn: () => void): void {
  try {
    fn();
    passed += 1;
    console.log(`  ok — ${name}`);
  } catch (err) {
    process.exitCode = 1;
    console.error(`  FAIL — ${name}`);
    console.error(err);
  }
}

const EFOOTBALL: FootballMatchContext = { football_type: "efootball", team_size: 11 };
const REAL_FOOTBALL: FootballMatchContext = { football_type: "real_football", team_size: 7 };

function baseDraft(overrides: UnifiedFootballEventValidationInput = {}): UnifiedFootballEventValidationInput {
  return {
    match_id: "match-1",
    timestamp_seconds: 120.5,
    event_type: "bad_pass",
    category: "passing",
    severity: "mistake",
    confidence: 80,
    confidence_level: "likely",
    description: "Played a risky central pass into a double press.",
    context_start_seconds: 118,
    context_end_seconds: 123,
    ...overrides,
  };
}

function baseRow(overrides: Partial<AnalysisEvent> = {}): AnalysisEvent {
  return {
    id: "event-1",
    match_id: "match-1",
    timestamp_seconds: 120.5,
    event_type: "bad_pass",
    category: "passing",
    severity: "mistake",
    decision_score: 20,
    confidence: 80,
    confidence_level: "likely",
    description: "Played a risky central pass into a double press.",
    better_option: null,
    reasoning: null,
    before_frame_url: null,
    decision_frame_url: null,
    after_frame_url: null,
    context_start_seconds: 118,
    context_end_seconds: 123,
    created_at: "2026-01-01T00:00:00Z",
    player_id: null,
    statistics_evidence: null,
    ...overrides,
  };
}

console.log("UNIFIED_EVENT_TYPES / isUnifiedEventType");

check("enumerates exactly the 8 common football concepts", () => {
  assert.deepEqual(
    [...UNIFIED_EVENT_TYPES].sort(),
    ["defensive_action", "dribble", "pass", "positioning", "pressure", "receive", "shot", "turnover"].sort()
  );
});

check("rejects unknown/invalid unified event types outright", () => {
  assert.equal(isUnifiedEventType("goal"), false);
  assert.equal(isUnifiedEventType("Pass"), false);
  assert.equal(isUnifiedEventType(1), false);
  assert.equal(isUnifiedEventType(null), false);
});

console.log("\nunifiedEventTypeForLegacyEvent — exhaustive mapping");

check("every leaf event_type in EVENT_TYPES has a unified mapping", () => {
  for (const eventType of allLegacyEventTypes()) {
    const mapped = unifiedEventTypeForLegacyEvent(eventType);
    assert.ok(isUnifiedEventType(mapped), `${eventType} has no unified mapping`);
  }
});

check("an unrecognized event_type maps to null, never a guess", () => {
  assert.equal(unifiedEventTypeForLegacyEvent("not_a_real_event_type"), null);
});

check("common event types map as expected", () => {
  assert.equal(unifiedEventTypeForLegacyEvent("bad_pass"), "pass");
  assert.equal(unifiedEventTypeForLegacyEvent("unnecessary_dribble"), "dribble");
  assert.equal(unifiedEventTypeForLegacyEvent("missed_scoring_opportunity"), "shot");
  assert.equal(unifiedEventTypeForLegacyEvent("lost_possession"), "turnover");
  assert.equal(unifiedEventTypeForLegacyEvent("pressing_too_early"), "pressure");
  assert.equal(unifiedEventTypeForLegacyEvent("good_interception"), "defensive_action");
  assert.equal(unifiedEventTypeForLegacyEvent("good_positioning"), "positioning");
});

console.log("\ntoUnifiedFootballEvent — pure read-mapper, no fabrication");

check("valid eFootball event round-trips with football_type='efootball'", () => {
  const unified = toUnifiedFootballEvent(baseRow(), EFOOTBALL);
  assert.ok(unified);
  assert.equal(unified!.football_type, "efootball");
  assert.equal(unified!.event_type, "pass");
  assert.equal(unified!.legacy_event_type, "bad_pass");
  assert.equal(unified!.match_id, "match-1");
});

check("valid real-football event round-trips with football_type='real_football'", () => {
  const unified = toUnifiedFootballEvent(
    baseRow({ event_type: "good_interception", category: "defending", severity: "good" }),
    REAL_FOOTBALL
  );
  assert.ok(unified);
  assert.equal(unified!.football_type, "real_football");
  assert.equal(unified!.event_type, "defensive_action");
});

check("null (legacy/unknown) football context stays null — never defaulted to eFootball", () => {
  const unified = toUnifiedFootballEvent(baseRow(), null);
  assert.ok(unified);
  assert.equal(unified!.football_type, null);
});

check("NULL/unknown fields (timestamp, player_id, evidence, frame urls) remain null, not fabricated", () => {
  const unified = toUnifiedFootballEvent(
    baseRow({ timestamp_seconds: null, player_id: null, statistics_evidence: null }),
    EFOOTBALL
  );
  assert.ok(unified);
  assert.equal(unified!.timestamp_seconds, null);
  assert.equal(unified!.player_id, null);
  assert.equal(unified!.evidence, null);
  assert.equal(unified!.before_frame_url, null);
});

check("no coordinate field exists anywhere on the unified shape (nothing to fabricate)", () => {
  const unified = toUnifiedFootballEvent(baseRow(), EFOOTBALL);
  assert.ok(unified);
  const keys = Object.keys(unified as object);
  const coordinateLikeNames = ["x", "y", "pos", "coordinate", "coordinates", "lat", "lng"];
  for (const k of keys) {
    assert.ok(!coordinateLikeNames.includes(k), `unexpected coordinate-shaped field: ${k}`);
  }
});

check("player reference is preserved when known", () => {
  const unified = toUnifiedFootballEvent(baseRow({ player_id: "player-1", statistics_evidence: ["12 tackles"] }), EFOOTBALL);
  assert.ok(unified);
  assert.equal(unified!.player_id, "player-1");
  assert.deepEqual(unified!.evidence, ["12 tackles"]);
});

check("a row with an unmappable event_type returns null defensively, never a guessed unified type", () => {
  const unified = toUnifiedFootballEvent(baseRow({ event_type: "not_a_real_event_type" }), EFOOTBALL);
  assert.equal(unified, null);
});

console.log("\nvalidateUnifiedFootballEventInput — valid drafts");

check("valid eFootball event passes", () => {
  const result = validateUnifiedFootballEventInput(baseDraft(), { footballContext: EFOOTBALL });
  assert.deepEqual(result.errors, []);
  assert.equal(result.valid, true);
});

check("valid real-football event passes", () => {
  const result = validateUnifiedFootballEventInput(
    baseDraft({ event_type: "good_interception", category: "defending", severity: "good" }),
    { footballContext: REAL_FOOTBALL }
  );
  assert.deepEqual(result.errors, []);
  assert.equal(result.valid, true);
});

check("valid event with unknown/null football context (legacy match) passes", () => {
  const result = validateUnifiedFootballEventInput(baseDraft(), { footballContext: null });
  assert.equal(result.valid, true);
});

check("timestamp_seconds omitted/null is valid (single-screenshot event)", () => {
  const result = validateUnifiedFootballEventInput(baseDraft({ timestamp_seconds: null }), { footballContext: EFOOTBALL });
  assert.equal(result.valid, true);
});

console.log("\nvalidateUnifiedFootballEventInput — invalid event type / football type");

check("invalid event type is rejected", () => {
  const result = validateUnifiedFootballEventInput(baseDraft({ event_type: "scored_a_goal" }), { footballContext: EFOOTBALL });
  assert.equal(result.valid, false);
  assert.ok(result.errors.some((e) => e.includes("event_type")));
});

check("invalid football type in context is rejected", () => {
  const result = validateUnifiedFootballEventInput(baseDraft(), {
    footballContext: { football_type: "esports" as any, team_size: 11 },
  });
  assert.equal(result.valid, false);
  assert.ok(result.errors.some((e) => e.includes("football_type")));
});

check("football_type supplied on the event itself is rejected — it is a match-level attribute", () => {
  const result = validateUnifiedFootballEventInput(baseDraft({ football_type: "efootball" } as any), {
    footballContext: EFOOTBALL,
  });
  assert.equal(result.valid, false);
  assert.ok(result.errors.some((e) => e.includes("football_type must not be supplied")));
});

console.log("\nvalidateUnifiedFootballEventInput — eFootball-only fields gated for real football");

check("eFootball-only field is rejected for a real_football event", () => {
  const result = validateUnifiedFootballEventInput(baseDraft({ playstyle: "Anchor Man" } as any), {
    footballContext: REAL_FOOTBALL,
  });
  assert.equal(result.valid, false);
  assert.ok(result.errors.some((e) => e.includes("playstyle") && e.includes("eFootball-only")));
});

check("eFootball-only field is rejected for an unknown (null) football context — never assumed eFootball", () => {
  const result = validateUnifiedFootballEventInput(baseDraft({ attributes: { pace: 90 } } as any), {
    footballContext: null,
  });
  assert.equal(result.valid, false);
  assert.ok(result.errors.some((e) => e.includes("attributes")));
});

check("eFootball-only field IS allowed when football_type is positively 'efootball'", () => {
  const result = validateUnifiedFootballEventInput(baseDraft({ playstyle: "Anchor Man" } as any), {
    footballContext: EFOOTBALL,
  });
  assert.equal(result.valid, true);
});

console.log("\nvalidateUnifiedFootballEventInput — malformed timestamps/context window");

check("negative timestamp_seconds is rejected", () => {
  const result = validateUnifiedFootballEventInput(baseDraft({ timestamp_seconds: -5 }), { footballContext: EFOOTBALL });
  assert.equal(result.valid, false);
  assert.ok(result.errors.some((e) => e.includes("timestamp_seconds")));
});

check("non-numeric timestamp_seconds is rejected", () => {
  const result = validateUnifiedFootballEventInput(baseDraft({ timestamp_seconds: "late" as any }), {
    footballContext: EFOOTBALL,
  });
  assert.equal(result.valid, false);
});

check("context_end_seconds before context_start_seconds is rejected", () => {
  const result = validateUnifiedFootballEventInput(
    baseDraft({ context_start_seconds: 100, context_end_seconds: 90 }),
    { footballContext: EFOOTBALL }
  );
  assert.equal(result.valid, false);
  assert.ok(result.errors.some((e) => e.includes("context_end_seconds")));
});

console.log("\nvalidateUnifiedFootballEventInput — ownership / match integrity");

check("matching match_id and player ownership passes", () => {
  const result = validateUnifiedFootballEventInput(baseDraft({ match_id: "match-1", player_id: "player-1" }), {
    footballContext: EFOOTBALL,
    ownership: { matchId: "match-1", userId: "user-1", player: { id: "player-1", user_id: "user-1" } },
  });
  assert.equal(result.valid, true);
});

check("a cross-match event reference (mismatched match_id) is rejected", () => {
  const result = validateUnifiedFootballEventInput(baseDraft({ match_id: "some-other-match" }), {
    footballContext: EFOOTBALL,
    ownership: { matchId: "match-1", userId: "user-1", player: null },
  });
  assert.equal(result.valid, false);
  assert.ok(result.errors.some((e) => e.includes("cross-match")));
});

check("a cross-user player reference is rejected", () => {
  const result = validateUnifiedFootballEventInput(baseDraft({ player_id: "player-1" }), {
    footballContext: EFOOTBALL,
    ownership: { matchId: "match-1", userId: "user-1", player: { id: "player-1", user_id: "someone-else" } },
  });
  assert.equal(result.valid, false);
  assert.ok(result.errors.some((e) => e.includes("cross-user")));
});

check("a player_id that doesn't match the resolved player is rejected", () => {
  const result = validateUnifiedFootballEventInput(baseDraft({ player_id: "player-999" }), {
    footballContext: EFOOTBALL,
    ownership: { matchId: "match-1", userId: "user-1", player: { id: "player-1", user_id: "user-1" } },
  });
  assert.equal(result.valid, false);
  assert.ok(result.errors.some((e) => e.includes("player_id does not match")));
});

check("no player_id supplied, no player resolved — valid (event not tied to a specific player)", () => {
  const result = validateUnifiedFootballEventInput(baseDraft({ player_id: null }), {
    footballContext: EFOOTBALL,
    ownership: { matchId: "match-1", userId: "user-1", player: null },
  });
  assert.equal(result.valid, true);
});

console.log(`\n${passed} check(s) passed.`);
if (process.exitCode) {
  console.error("\nSome checks FAILED.");
} else {
  console.log("All checks passed.");
}
