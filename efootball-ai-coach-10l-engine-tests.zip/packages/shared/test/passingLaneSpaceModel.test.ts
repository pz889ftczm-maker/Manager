// Batch 10F — lightweight, framework-free tests for
// passingLaneSpaceModel.ts's unified passing lane / space model. Same
// convention as tacticalPosition.test.ts/footballEvent.test.ts — no
// test runner/framework, Node's built-in `assert`, run via `tsx`.
//
// Run with:  npx tsx packages/shared/test/passingLaneSpaceModel.test.ts
//        or: npm test --workspace=packages/shared
//
// SCOPE NOTE: pure, in-process tests of the shared model/builders/
// validation only — no database, no RLS, no worker integration.

import assert from "node:assert/strict";
import {
  passingLaneFromAnalysisEntry,
  passingLanesFromTacticalAnalysis,
  spaceFromOpenSpaceEntry,
  spaceFromPressureZoneEntry,
  spacesFromTacticalAnalysis,
  validatePassingLaneInput,
  validateSpaceInput,
  SPACE_STATUSES,
  isSpaceStatus,
  PASSING_LANE_QUALITIES,
  isPassingLaneQuality,
  type PassingLaneValidationInput,
  type SpaceValidationInput,
} from "../src/passingLaneSpaceModel.js";
import type { TacticalAnalysisPositionContext } from "../src/tacticalPosition.js";
// 10E regression — this batch must not break the existing tactical
// position model it sits alongside, and this batch's own context type
// is reused directly from that file (see passingLaneSpaceModel.ts's
// header comment).
import {
  tacticalPositionFromAnalysisEntry,
  tacticalPositionsFromEfootballContext,
} from "../src/tacticalPosition.js";
import type { EfootballContextPlayer, EfootballMatchContextResult } from "../src/efootballMatchContext.js";
// 10D regression — this batch must not break the existing unified event
// schema/validation it sits alongside.
import { isUnifiedEventType, unifiedEventTypeForLegacyEvent, UNIFIED_EVENT_TYPES } from "../src/footballEvent.js";

let passed = 0;

function check(name: string, fn: () => void): void {
  try {
    fn();
    passed += 1;
    console.log(`  ok — ${name}`);
  } catch (err) {
    process.exitCode = 1;
    console.error(`  FAIL — ${name}`);
    console.error(err);
  }
}

function ctx(overrides: Partial<TacticalAnalysisPositionContext> = {}): TacticalAnalysisPositionContext {
  return {
    footballType: "efootball",
    matchId: "m1",
    eventId: "e1",
    timestampSeconds: 305,
    isApproximate: false,
    ...overrides,
  };
}

function efootballPlayer(overrides: Partial<EfootballContextPlayer> = {}): EfootballContextPlayer {
  return {
    player_id: "p1",
    name: "Alex Striker",
    position: "ST",
    position_slot: "st",
    overall: 88,
    playstyle: "Goal Poacher",
    attributes: { pace: 90 },
    ...overrides,
  };
}

// ============================================================
// 1. Passing Lane — tactical_analysis entry -> PassingLane
// ============================================================

console.log("passingLaneFromAnalysisEntry — eFootball, both endpoints supported by evidence");

check("builds a lane with both endpoints from a well-formed eFootball entry", () => {
  const lane = passingLaneFromAnalysisEntry(
    { from: { x: 20, y: 40 }, to: { x: 55, y: 60 }, quality: "good" },
    ctx({ footballType: "efootball", matchId: "m1", eventId: "e1", timestampSeconds: 305, isApproximate: false })
  );
  assert.ok(lane);
  assert.equal(lane!.football_type, "efootball");
  assert.equal(lane!.match_id, "m1");
  assert.deepEqual(lane!.from_coordinates, { x: 20, y: 40 });
  assert.deepEqual(lane!.to_coordinates, { x: 55, y: 60 });
  assert.equal(lane!.quality, "good");
  assert.equal(lane!.timestamp_seconds, 305);
  assert.equal(lane!.confidence_level, "confirmed");
  assert.deepEqual(lane!.source, { type: "tactical_analysis", event_id: "e1", is_approximate: false });
  // Never fabricated — see "missing player references" section below.
  assert.equal(lane!.from_player, null);
  assert.equal(lane!.to_player, null);
});

console.log("passingLaneFromAnalysisEntry — Real Football, both endpoints supported by evidence");

check("builds a lane with both endpoints from a well-formed real_football entry", () => {
  const lane = passingLaneFromAnalysisEntry(
    { from: { x: 30, y: 50 }, to: { x: 70, y: 65 }, quality: "risky" },
    ctx({ footballType: "real_football", matchId: "m2", eventId: "e2", timestampSeconds: 12, isApproximate: true })
  );
  assert.ok(lane);
  assert.equal(lane!.football_type, "real_football");
  assert.equal(lane!.match_id, "m2");
  assert.deepEqual(lane!.from_coordinates, { x: 30, y: 50 });
  assert.deepEqual(lane!.to_coordinates, { x: 70, y: 65 });
  assert.equal(lane!.quality, "risky");
  assert.equal(lane!.confidence_level, "uncertain");
  assert.equal(lane!.source.event_id, "e2");
  assert.equal(lane!.source.is_approximate, true);
});

check("recommended-quality lane still builds normally (closed vocabulary, not a special case)", () => {
  const lane = passingLaneFromAnalysisEntry(
    { from: { x: 10, y: 10 }, to: { x: 90, y: 90 }, quality: "recommended" },
    ctx()
  );
  assert.equal(lane!.quality, "recommended");
});

console.log("passingLaneFromAnalysisEntry — missing player references (never fabricated)");

check("from_player/to_player are always null — raw passing_lanes entries carry no player identity", () => {
  const lane = passingLaneFromAnalysisEntry({ from: { x: 5, y: 5 }, to: { x: 95, y: 95 } }, ctx());
  assert.ok(lane);
  assert.equal(lane!.from_player, null);
  assert.equal(lane!.to_player, null);
  // Even if a caller's raw entry accidentally carried player-shaped
  // data, this builder never reads or surfaces it — the shape only
  // ever has `from`/`to`/`quality` per migration 0001.
});

console.log("passingLaneFromAnalysisEntry — NULL spatial data / fabricated endpoints rejected");

check("missing `to` -> whole lane dropped (a lane with only one known endpoint is not a lane)", () => {
  const lane = passingLaneFromAnalysisEntry({ from: { x: 20, y: 40 }, quality: "good" }, ctx());
  assert.equal(lane, null);
});

check("missing `from` -> whole lane dropped", () => {
  const lane = passingLaneFromAnalysisEntry({ to: { x: 20, y: 40 }, quality: "good" }, ctx());
  assert.equal(lane, null);
});

check("malformed coordinates (non-numeric) -> whole lane dropped, never coerced", () => {
  const lane = passingLaneFromAnalysisEntry(
    { from: { x: "wide", y: null }, to: { x: 50, y: 50 } },
    ctx()
  );
  assert.equal(lane, null);
});

check("out-of-range coordinates -> whole lane dropped, never clamped", () => {
  const lane = passingLaneFromAnalysisEntry(
    { from: { x: 140, y: -5 }, to: { x: 50, y: 50 } },
    ctx()
  );
  assert.equal(lane, null);
});

check("entry with neither endpoint returns null", () => {
  const lane = passingLaneFromAnalysisEntry({ quality: "good" }, ctx());
  assert.equal(lane, null);
});

check("non-object entry returns null defensively", () => {
  const lane = passingLaneFromAnalysisEntry("not an object", ctx());
  assert.equal(lane, null);
});

check("invalid/fabricated quality -> quality null, endpoints still preserved (never guessed)", () => {
  const lane = passingLaneFromAnalysisEntry(
    { from: { x: 20, y: 40 }, to: { x: 55, y: 60 }, quality: "unstoppable" },
    ctx()
  );
  assert.ok(lane);
  assert.equal(lane!.quality, null);
  assert.deepEqual(lane!.from_coordinates, { x: 20, y: 40 });
});

console.log("passingLanesFromTacticalAnalysis — row-level aggregation");

check("maps every well-formed entry, drops malformed ones, never fabricates placeholders", () => {
  const lanes = passingLanesFromTacticalAnalysis(
    {
      event_id: "e9",
      passing_lanes: [
        { from: { x: 10, y: 10 }, to: { x: 20, y: 20 }, quality: "good" },
        { from: { x: 30, y: 30 } }, // half a lane -> dropped
        { from: { x: 40, y: 40 }, to: { x: 50, y: 50 }, quality: "recommended" },
      ],
      is_approximate: false,
    },
    { footballType: "efootball", matchId: "m1", timestampSeconds: 100 }
  );
  assert.equal(lanes.length, 2);
  assert.ok(lanes.every((l) => l.match_id === "m1" && l.source.event_id === "e9"));
});

check("null/non-array passing_lanes yields no fabricated entries", () => {
  const lanes = passingLanesFromTacticalAnalysis(
    { event_id: "e10", passing_lanes: null, is_approximate: true },
    { footballType: "efootball", matchId: "m1", timestampSeconds: null }
  );
  assert.deepEqual(lanes, []);
});

// ============================================================
// 2. Space — tactical_analysis entry -> Space
// ============================================================

console.log("spaceFromOpenSpaceEntry / spaceFromPressureZoneEntry — valid open/occupied/pressured space");

check("builds an 'open' space from a well-formed open_spaces entry", () => {
  const space = spaceFromOpenSpaceEntry({ center: { x: 60, y: 40 }, radius: 12 }, ctx({ isApproximate: false }));
  assert.ok(space);
  assert.equal(space!.status, "open");
  assert.deepEqual(space!.center, { x: 60, y: 40 });
  assert.equal(space!.radius, 12);
  assert.equal(space!.intensity, null);
  assert.equal(space!.confidence_level, "confirmed");
  assert.deepEqual(space!.source, { type: "tactical_analysis", event_id: "e1", is_approximate: false });
});

check("builds a 'pressured' space with intensity from a well-formed pressure_zones entry", () => {
  const space = spaceFromPressureZoneEntry(
    { center: { x: 45, y: 55 }, radius: 8, intensity: 0.7 },
    ctx({ isApproximate: true })
  );
  assert.ok(space);
  assert.equal(space!.status, "pressured");
  assert.equal(space!.radius, 8);
  assert.equal(space!.intensity, 0.7);
  assert.equal(space!.confidence_level, "uncertain");
});

check('"occupied" is a supported status for schema completeness, even though no current builder produces it', () => {
  assert.ok(SPACE_STATUSES.includes("occupied"));
  assert.equal(isSpaceStatus("occupied"), true);
  // Demonstrated via the write-path gate accepting a hand-built,
  // fully-evidenced "occupied" draft — never via a builder guessing it.
  const draft: SpaceValidationInput = {
    status: "occupied",
    center: { x: 50, y: 50 },
    source: { type: "tactical_analysis", event_id: "e1", is_approximate: false },
  };
  const result = validateSpaceInput(draft, { footballType: "efootball" });
  assert.equal(result.valid, true);
});

console.log("spaceFromOpenSpaceEntry / spaceFromPressureZoneEntry — NULL spatial data");

check("missing center -> whole space dropped (open_spaces)", () => {
  const space = spaceFromOpenSpaceEntry({ radius: 10 }, ctx());
  assert.equal(space, null);
});

check("missing center -> whole space dropped (pressure_zones)", () => {
  const space = spaceFromPressureZoneEntry({ radius: 10, intensity: 0.5 }, ctx());
  assert.equal(space, null);
});

check("malformed/out-of-range center -> whole space dropped, never clamped", () => {
  const space = spaceFromOpenSpaceEntry({ center: { x: 500, y: -1 }, radius: 10 }, ctx());
  assert.equal(space, null);
});

check("missing radius -> radius null, center/status still preserved", () => {
  const space = spaceFromOpenSpaceEntry({ center: { x: 60, y: 40 } }, ctx());
  assert.ok(space);
  assert.equal(space!.radius, null);
  assert.deepEqual(space!.center, { x: 60, y: 40 });
});

check("out-of-range intensity -> intensity null, rest of the pressured space still preserved", () => {
  const space = spaceFromPressureZoneEntry({ center: { x: 60, y: 40 }, intensity: 4 }, ctx());
  assert.ok(space);
  assert.equal(space!.intensity, null);
  assert.equal(space!.status, "pressured");
});

check("non-object entry returns null defensively", () => {
  assert.equal(spaceFromOpenSpaceEntry(42, ctx()), null);
  assert.equal(spaceFromPressureZoneEntry(null, ctx()), null);
});

console.log("spacesFromTacticalAnalysis — row-level aggregation of open_spaces + pressure_zones");

check("combines open_spaces and pressure_zones into one unified list", () => {
  const spaces = spacesFromTacticalAnalysis(
    {
      event_id: "e11",
      open_spaces: [{ center: { x: 10, y: 10 }, radius: 5 }],
      pressure_zones: [{ center: { x: 90, y: 90 }, radius: 6, intensity: 0.9 }],
      is_approximate: false,
    },
    { footballType: "real_football", matchId: "m3", timestampSeconds: 50 }
  );
  assert.equal(spaces.length, 2);
  assert.equal(spaces.filter((s) => s.status === "open").length, 1);
  assert.equal(spaces.filter((s) => s.status === "pressured").length, 1);
  assert.ok(spaces.every((s) => s.match_id === "m3" && s.football_type === "real_football"));
});

check("null/non-array open_spaces and pressure_zones yields no fabricated entries", () => {
  const spaces = spacesFromTacticalAnalysis(
    { event_id: "e12", open_spaces: null, pressure_zones: null, is_approximate: true },
    { footballType: "efootball", matchId: "m1", timestampSeconds: null }
  );
  assert.deepEqual(spaces, []);
});

// ============================================================
// 3. Coordinate safety — formation coordinates never treated as
//    tracking coordinates
// ============================================================

console.log("coordinate safety — formation-derived data is never accepted as lane/space evidence");

check("a bare formation-slot-shaped object (flat id/role/x/y, no from/to) is never treated as lane coordinates", () => {
  // teamFormations.ts's own PositionDefinition shape is flat: { id,
  // role, x, y } (a layout hint, never tracking evidence — see that
  // file's own header comment). This file's passingLaneFromAnalysisEntry
  // only ever reads a nested {x, y} pair under an entry's own `from`/
  // `to` key — never x/y sitting directly on the entry itself. A
  // formation slot object has no `from`/`to` property at all, so it is
  // correctly read as "no endpoints" and dropped, never silently
  // reinterpreted as coordinate evidence.
  const lane = passingLaneFromAnalysisEntry({ id: "cb", role: "CB", x: 40, y: 20 }, ctx());
  assert.equal(lane, null);
});

check("a bare formation-slot-shaped object is never treated as space coordinates either", () => {
  const space = spaceFromOpenSpaceEntry({ id: "cb", role: "CB", x: 40, y: 20 }, ctx());
  assert.equal(space, null);
});

check("validatePassingLaneInput rejects a formation/roster-derived source outright", () => {
  const draft: PassingLaneValidationInput = {
    from_coordinates: { x: 10, y: 10 },
    to_coordinates: { x: 20, y: 20 },
    source: { type: "efootball_context", context_source: "current_data" },
  };
  const result = validatePassingLaneInput(draft, { footballType: "efootball" });
  assert.equal(result.valid, false);
  assert.ok(result.errors.some((e) => e.includes("tactical_analysis")));
});

check("validateSpaceInput rejects a formation/roster-derived source outright", () => {
  const draft: SpaceValidationInput = {
    center: { x: 10, y: 10 },
    status: "open",
    source: { type: "real_football_context", context_source: "current_data" },
  };
  const result = validateSpaceInput(draft, { footballType: "real_football" });
  assert.equal(result.valid, false);
  assert.ok(result.errors.some((e) => e.includes("tactical_analysis")));
});

// ============================================================
// 4. Rejection of fabricated/inferred coordinates + invalid drafts
//    (write-path gate)
// ============================================================

console.log("validatePassingLaneInput — rejection of fabricated/inferred coordinates and invalid drafts");

check("accepts a well-formed tactical_analysis-sourced lane", () => {
  const draft: PassingLaneValidationInput = {
    from_coordinates: { x: 20, y: 40 },
    to_coordinates: { x: 55, y: 60 },
    quality: "good",
    source: { type: "tactical_analysis", event_id: "e1", is_approximate: false },
  };
  const result = validatePassingLaneInput(draft, { footballType: "efootball" });
  assert.equal(result.valid, true);
  assert.deepEqual(result.errors, []);
});

check("rejects a draft with no coordinates at all", () => {
  const draft: PassingLaneValidationInput = { source: { type: "tactical_analysis", event_id: "e1", is_approximate: false } };
  const result = validatePassingLaneInput(draft, { footballType: "efootball" });
  assert.equal(result.valid, false);
  assert.ok(result.errors.some((e) => e.includes("both from_coordinates and to_coordinates")));
});

check("rejects a draft with only from_coordinates (half a lane)", () => {
  const draft: PassingLaneValidationInput = {
    from_coordinates: { x: 20, y: 40 },
    source: { type: "tactical_analysis", event_id: "e1", is_approximate: false },
  };
  const result = validatePassingLaneInput(draft, { footballType: "efootball" });
  assert.equal(result.valid, false);
  assert.ok(result.errors.some((e) => e.includes("only one known endpoint")));
});

check("rejects out-of-range coordinates even with a valid tactical_analysis source", () => {
  const draft: PassingLaneValidationInput = {
    from_coordinates: { x: 400, y: 40 },
    to_coordinates: { x: 55, y: 60 },
    source: { type: "tactical_analysis", event_id: "e1", is_approximate: false },
  };
  const result = validatePassingLaneInput(draft, { footballType: "efootball" });
  assert.equal(result.valid, false);
});

check("rejects tactical_analysis-sourced coordinates missing event_id (broken evidence chain)", () => {
  const draft: PassingLaneValidationInput = {
    from_coordinates: { x: 20, y: 40 },
    to_coordinates: { x: 55, y: 60 },
    source: { type: "tactical_analysis", is_approximate: false },
  };
  const result = validatePassingLaneInput(draft, { footballType: "efootball" });
  assert.equal(result.valid, false);
  assert.ok(result.errors.some((e) => e.includes("event_id")));
});

check("rejects tactical_analysis-sourced coordinates missing is_approximate", () => {
  const draft: PassingLaneValidationInput = {
    from_coordinates: { x: 20, y: 40 },
    to_coordinates: { x: 55, y: 60 },
    source: { type: "tactical_analysis", event_id: "e1" },
  };
  const result = validatePassingLaneInput(draft, { footballType: "efootball" });
  assert.equal(result.valid, false);
  assert.ok(result.errors.some((e) => e.includes("is_approximate")));
});

check("rejects an invalid/fabricated quality value", () => {
  const draft: PassingLaneValidationInput = {
    from_coordinates: { x: 20, y: 40 },
    to_coordinates: { x: 55, y: 60 },
    quality: "unbeatable",
    source: { type: "tactical_analysis", event_id: "e1", is_approximate: false },
  };
  const result = validatePassingLaneInput(draft, { footballType: "efootball" });
  assert.equal(result.valid, false);
});

check("rejects a malformed player reference (empty player_id)", () => {
  const draft: PassingLaneValidationInput = {
    from_coordinates: { x: 20, y: 40 },
    to_coordinates: { x: 55, y: 60 },
    from_player: { player_id: "", name: "Ghost" },
    source: { type: "tactical_analysis", event_id: "e1", is_approximate: false },
  };
  const result = validatePassingLaneInput(draft, { footballType: "efootball" });
  assert.equal(result.valid, false);
});

check("rejects football_type supplied directly on the lane draft", () => {
  const draft: PassingLaneValidationInput = { football_type: "efootball" };
  const result = validatePassingLaneInput(draft, { footballType: "efootball" });
  assert.equal(result.valid, false);
  assert.ok(result.errors.some((e) => e.includes("football_type")));
});

console.log("validatePassingLaneInput / validateSpaceInput — eFootball data blocked for Real Football");

check("rejects an eFootball-only key on a passing lane draft for a real_football match", () => {
  const draft: PassingLaneValidationInput = {
    from_coordinates: { x: 20, y: 40 },
    to_coordinates: { x: 55, y: 60 },
    source: { type: "tactical_analysis", event_id: "e1", is_approximate: false },
    playstyle: "Anchor Man",
  };
  const result = validatePassingLaneInput(draft, { footballType: "real_football" });
  assert.equal(result.valid, false);
  assert.ok(result.errors.some((e) => e.includes("playstyle")));
});

check("rejects an eFootball-only key on a space draft regardless of football_type", () => {
  const draft: SpaceValidationInput = {
    center: { x: 20, y: 40 },
    status: "open",
    source: { type: "tactical_analysis", event_id: "e1", is_approximate: false },
    tactical_instructions: { press: "high" },
  };
  const result = validateSpaceInput(draft, { footballType: "efootball" });
  assert.equal(result.valid, false);
  assert.ok(result.errors.some((e) => e.includes("tactical_instructions")));
});

check("rejects a negative timestamp_seconds on a lane draft", () => {
  const draft: PassingLaneValidationInput = { timestamp_seconds: -5 };
  const result = validatePassingLaneInput(draft, { footballType: "efootball" });
  assert.equal(result.valid, false);
});

check("null draft is rejected, not thrown (lane)", () => {
  const result = validatePassingLaneInput(null as unknown as PassingLaneValidationInput, { footballType: null });
  assert.equal(result.valid, false);
});

console.log("validateSpaceInput — rejection of fabricated/inferred coordinates and invalid drafts");

check("accepts a well-formed tactical_analysis-sourced open space", () => {
  const draft: SpaceValidationInput = {
    center: { x: 60, y: 40 },
    radius: 12,
    status: "open",
    source: { type: "tactical_analysis", event_id: "e1", is_approximate: false },
  };
  const result = validateSpaceInput(draft, { footballType: "efootball" });
  assert.equal(result.valid, true);
  assert.deepEqual(result.errors, []);
});

check("rejects a draft with no center", () => {
  const draft: SpaceValidationInput = {
    status: "open",
    source: { type: "tactical_analysis", event_id: "e1", is_approximate: false },
  };
  const result = validateSpaceInput(draft, { footballType: "efootball" });
  assert.equal(result.valid, false);
  assert.ok(result.errors.some((e) => e.includes("center is required")));
});

check("rejects out-of-range center even with a valid tactical_analysis source", () => {
  const draft: SpaceValidationInput = {
    center: { x: 500, y: 40 },
    status: "open",
    source: { type: "tactical_analysis", event_id: "e1", is_approximate: false },
  };
  const result = validateSpaceInput(draft, { footballType: "efootball" });
  assert.equal(result.valid, false);
});

check("rejects an invalid status value", () => {
  const draft: SpaceValidationInput = {
    center: { x: 60, y: 40 },
    status: "haunted",
    source: { type: "tactical_analysis", event_id: "e1", is_approximate: false },
  };
  const result = validateSpaceInput(draft, { footballType: "efootball" });
  assert.equal(result.valid, false);
});

check("rejects intensity supplied on a non-pressured status", () => {
  const draft: SpaceValidationInput = {
    center: { x: 60, y: 40 },
    status: "open",
    intensity: 0.5,
    source: { type: "tactical_analysis", event_id: "e1", is_approximate: false },
  };
  const result = validateSpaceInput(draft, { footballType: "efootball" });
  assert.equal(result.valid, false);
  assert.ok(result.errors.some((e) => e.includes("pressure-specific")));
});

check("rejects out-of-range intensity on a pressured space", () => {
  const draft: SpaceValidationInput = {
    center: { x: 60, y: 40 },
    status: "pressured",
    intensity: 4,
    source: { type: "tactical_analysis", event_id: "e1", is_approximate: false },
  };
  const result = validateSpaceInput(draft, { footballType: "efootball" });
  assert.equal(result.valid, false);
});

check("rejects out-of-range radius", () => {
  const draft: SpaceValidationInput = {
    center: { x: 60, y: 40 },
    status: "open",
    radius: 250,
    source: { type: "tactical_analysis", event_id: "e1", is_approximate: false },
  };
  const result = validateSpaceInput(draft, { footballType: "efootball" });
  assert.equal(result.valid, false);
});

check("rejects an invalid team value", () => {
  const draft: SpaceValidationInput = {
    center: { x: 60, y: 40 },
    status: "open",
    team: "referee",
    source: { type: "tactical_analysis", event_id: "e1", is_approximate: false },
  };
  const result = validateSpaceInput(draft, { footballType: "efootball" });
  assert.equal(result.valid, false);
});

check("rejects tactical_analysis-sourced space missing event_id/is_approximate", () => {
  const draft: SpaceValidationInput = {
    center: { x: 60, y: 40 },
    status: "open",
    source: { type: "tactical_analysis" },
  };
  const result = validateSpaceInput(draft, { footballType: "efootball" });
  assert.equal(result.valid, false);
  assert.ok(result.errors.some((e) => e.includes("event_id")));
  assert.ok(result.errors.some((e) => e.includes("is_approximate")));
});

check("rejects football_type supplied directly on the space draft", () => {
  const draft: SpaceValidationInput = { football_type: "real_football" };
  const result = validateSpaceInput(draft, { footballType: "real_football" });
  assert.equal(result.valid, false);
  assert.ok(result.errors.some((e) => e.includes("football_type")));
});

check("rejects a negative timestamp_seconds on a space draft", () => {
  const draft: SpaceValidationInput = { timestamp_seconds: -1 };
  const result = validateSpaceInput(draft, { footballType: "efootball" });
  assert.equal(result.valid, false);
});

check("null draft is rejected, not thrown (space)", () => {
  const result = validateSpaceInput(null as unknown as SpaceValidationInput, { footballType: null });
  assert.equal(result.valid, false);
});

// ============================================================
// 5. Historical context precedence
// ============================================================

console.log("historical context precedence — no live Team/Formation/Player data is ever read or preferred");

check("passing lanes/space for a match are built purely from the event-scoped tactical_analysis row and the caller's already-resolved football context — never from a 'live' roster, and unaffected by what that roster contains", () => {
  // A historical snapshot's roster for this match (built the same way
  // 10E's own tacticalPositionsFromEfootballContext already does).
  const historicalContext: EfootballMatchContextResult = {
    available: true,
    source: "historical_snapshot",
    players: [efootballPlayer()],
    manager: null,
    formation: null,
  };
  const historicalPositions = tacticalPositionsFromEfootballContext(historicalContext, "m1");
  assert.equal(historicalPositions[0]!.source.context_source, "historical_snapshot");

  // The SAME match's passing lanes/space, built independently — note
  // the function signature below takes only { footballType, matchId,
  // timestampSeconds } plus the tactical_analysis row itself; there is
  // no parameter through which a 'live' or 'current_data' roster could
  // even be supplied, let alone silently override the historical one.
  const row = {
    event_id: "e-hist",
    passing_lanes: [{ from: { x: 10, y: 10 }, to: { x: 20, y: 20 }, quality: "good" as const }],
    open_spaces: [{ center: { x: 50, y: 50 }, radius: 5 }],
    pressure_zones: null,
    is_approximate: false,
  };
  const lanesFirstPass = passingLanesFromTacticalAnalysis(row, {
    footballType: "efootball",
    matchId: "m1",
    timestampSeconds: 10,
  });
  const spacesFirstPass = spacesFromTacticalAnalysis(row, {
    footballType: "efootball",
    matchId: "m1",
    timestampSeconds: 10,
  });

  // Re-run with a completely different (hypothetical "live") roster in
  // scope for the same match — since the roster is never an input to
  // these builders at all, the output is byte-for-byte identical,
  // proving the historical tactical_analysis evidence is never
  // silently replaced by current Team/Formation/Player Library data.
  const differentLiveContext: EfootballMatchContextResult = {
    available: true,
    source: "current_data",
    players: [efootballPlayer({ player_id: "different-player", name: "Someone Else" })],
    manager: null,
    formation: null,
  };
  void differentLiveContext; // never consulted by the builders below
  const lanesSecondPass = passingLanesFromTacticalAnalysis(row, {
    footballType: "efootball",
    matchId: "m1",
    timestampSeconds: 10,
  });
  const spacesSecondPass = spacesFromTacticalAnalysis(row, {
    footballType: "efootball",
    matchId: "m1",
    timestampSeconds: 10,
  });

  assert.deepEqual(lanesFirstPass, lanesSecondPass);
  assert.deepEqual(spacesFirstPass, spacesSecondPass);
});

// ============================================================
// 6. Existing 10D/10E behavior remains intact
// ============================================================

console.log("10D/10E regression — unified event schema + tactical position model untouched by 10F");

check("UNIFIED_EVENT_TYPES / isUnifiedEventType / unifiedEventTypeForLegacyEvent still behave as before", () => {
  assert.ok(UNIFIED_EVENT_TYPES.includes("pass"));
  assert.equal(isUnifiedEventType("shot"), true);
  assert.equal(isUnifiedEventType("not_a_type"), false);
  assert.equal(unifiedEventTypeForLegacyEvent("bad_pass"), "pass");
  assert.equal(unifiedEventTypeForLegacyEvent("good_interception"), "defensive_action");
});

check("tacticalPositionFromAnalysisEntry (10E) still behaves as before", () => {
  const pos = tacticalPositionFromAnalysisEntry(
    { role: "CB", team: "user", pos: { x: 40, y: 25 } },
    { footballType: "efootball", matchId: "m1", eventId: "e1", timestampSeconds: 305, isApproximate: false }
  );
  assert.ok(pos);
  assert.equal(pos!.role, "CB");
  assert.deepEqual(pos!.coordinates, { x: 40, y: 25 });
  assert.equal(pos!.confidence_level, "confirmed");
});

check("isPassingLaneQuality / PASSING_LANE_QUALITIES form a closed, exhaustive vocabulary", () => {
  assert.deepEqual(PASSING_LANE_QUALITIES, ["good", "risky", "recommended"]);
  assert.equal(isPassingLaneQuality("good"), true);
  assert.equal(isPassingLaneQuality("legendary"), false);
});

console.log(`\n${passed} check(s) passed.`);
