// Batch 7D — lightweight, framework-free tests for teamManager.ts's
// pure validation helper. Same convention as teamMembers.test.ts — no
// test runner/framework, uses Node's built-in `assert` module, runs via
// `tsx`.
//
// Run with:  npx tsx packages/shared/test/teamManager.test.ts
//        or: npm test --workspace=packages/shared
//
// SCOPE NOTE: these are pure, in-process unit tests of validation logic
// only — nothing here talks to a real Supabase/Postgres instance. The
// actual authorization boundary for this batch — team ownership,
// manager ownership, cross-user rejection on both INSERT and UPDATE,
// and ON DELETE SET NULL when a manager_library row is deleted (spec
// section 10's cases) — lives entirely in migration
// 0020_team_manager_assignment.sql's RLS policies,
// check_team_library_manager_ownership trigger, and the manager_id
// foreign key's `on delete set null` clause, reviewed by hand, not
// exercised by a live integration test here. No live Supabase testing
// was performed for this batch.

import assert from "node:assert/strict";
import { validateManagerAssignmentInput } from "../src/teamManager.js";

let passed = 0;

function check(name: string, fn: () => void): void {
  try {
    fn();
    passed += 1;
    console.log(`  ok — ${name}`);
  } catch (err) {
    process.exitCode = 1;
    console.error(`  FAIL — ${name}`);
    console.error(err);
  }
}

const TEAM_A = "11111111-1111-4111-8111-111111111111";
const MANAGER_A = "33333333-3333-4333-8333-333333333333";

console.log("validateManagerAssignmentInput — valid owned assignment (spec section 10)");

check("a well-formed (team_id, manager_id) uuid pair is valid", () => {
  const { valid, errors } = validateManagerAssignmentInput({ team_id: TEAM_A, manager_id: MANAGER_A });
  assert.equal(valid, true);
  assert.deepEqual(errors, []);
});

console.log("validateManagerAssignmentInput — NULL manager (spec section 3 — 'valid manager -> NULL')");

check("manager_id: null is a first-class valid state, not an error", () => {
  const { valid, errors } = validateManagerAssignmentInput({ team_id: TEAM_A, manager_id: null });
  assert.equal(valid, true);
  assert.deepEqual(errors, []);
});

console.log("validateManagerAssignmentInput — switch manager (spec section 3)");

check("switching from one uuid to a different uuid is just two independent valid calls", () => {
  const first = validateManagerAssignmentInput({ team_id: TEAM_A, manager_id: MANAGER_A });
  const MANAGER_B = "44444444-4444-4444-8444-444444444444";
  const second = validateManagerAssignmentInput({ team_id: TEAM_A, manager_id: MANAGER_B });
  assert.equal(first.valid, true);
  assert.equal(second.valid, true);
});

console.log("validateManagerAssignmentInput — clear manager (spec section 6/8)");

check("clearing (manager_id: null) with a valid team_id passes", () => {
  const { valid } = validateManagerAssignmentInput({ team_id: TEAM_A, manager_id: null });
  assert.equal(valid, true);
});

console.log("validateManagerAssignmentInput — invalid UUID (spec section 10)");

check("a non-uuid-shaped manager_id is rejected", () => {
  const { valid, errors } = validateManagerAssignmentInput({ team_id: TEAM_A, manager_id: "not-a-uuid" });
  assert.equal(valid, false);
  assert.ok(errors.some((e) => e.includes("manager_id") && e.includes("uuid")));
});

check("a non-uuid-shaped team_id is rejected", () => {
  const { valid, errors } = validateManagerAssignmentInput({ team_id: "nope", manager_id: MANAGER_A });
  assert.equal(valid, false);
  assert.ok(errors.some((e) => e.includes("team_id") && e.includes("uuid")));
});

check("an omitted manager_id (undefined) is treated as malformed, not the same as explicit null", () => {
  const { valid, errors } = validateManagerAssignmentInput({ team_id: TEAM_A });
  assert.equal(valid, false);
  assert.ok(errors.some((e) => e.includes("manager_id")));
});

check("empty-string manager_id is rejected (not treated as clearing)", () => {
  const { valid, errors } = validateManagerAssignmentInput({ team_id: TEAM_A, manager_id: "" });
  assert.equal(valid, false);
  assert.ok(errors.some((e) => e.includes("manager_id")));
});

check("missing team_id is rejected outright", () => {
  const { valid, errors } = validateManagerAssignmentInput({ manager_id: MANAGER_A });
  assert.equal(valid, false);
  assert.ok(errors.some((e) => e.includes("team_id")));
});

check("non-object input is rejected outright", () => {
  const { valid, errors } = validateManagerAssignmentInput(null);
  assert.equal(valid, false);
  assert.equal(errors.length, 1);
});

console.log(`\n${passed} check(s) passed.`);
