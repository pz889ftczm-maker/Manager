// Batch 8D — lightweight, framework-free tests for
// teamFormationPresetPlayers.ts's pure validation helpers. Same
// convention as teamFormationPlayers.test.ts — no test runner/
// framework, uses Node's built-in `assert` module, runs via `tsx`.
//
// Run with:  npx tsx packages/shared/test/teamFormationPresetPlayers.test.ts
//        or: npm test --workspace=packages/shared
//
// SCOPE NOTE: pure, in-process unit tests of validation/duplicate-
// detection logic only — no live Supabase/Postgres/RLS verification.

import assert from "node:assert/strict";
import type { TeamFormationPresetPlayer } from "../src/teamFormationPresetPlayers.js";
import {
  validateTeamFormationPresetPlayerInput,
  isDuplicateFormationPresetPlayer,
  TEAM_FORMATION_PRESET_PLAYER_UNIQUE_CONSTRAINT,
  isDuplicateFormationPresetSlot,
  TEAM_FORMATION_PRESET_PLAYER_SLOT_UNIQUE_CONSTRAINT,
} from "../src/teamFormationPresetPlayers.js";

let passed = 0;

function check(name: string, fn: () => void): void {
  try {
    fn();
    passed += 1;
    console.log(`  ok — ${name}`);
  } catch (err) {
    process.exitCode = 1;
    console.error(`  FAIL — ${name}`);
    console.error(err);
  }
}

const PRESET_A = "11111111-1111-1111-1111-111111111111";
const PLAYER_A = "33333333-3333-3333-3333-333333333333";
const PLAYER_B = "44444444-4444-4444-4444-444444444444";

console.log("validateTeamFormationPresetPlayerInput — a valid preset player assignment");

check("a well-formed (preset_id, player_id, position_slot) triple is valid", () => {
  const { valid, sanitized, errors } = validateTeamFormationPresetPlayerInput({
    preset_id: PRESET_A,
    player_id: PLAYER_A,
    position_slot: "GK",
  });
  assert.equal(valid, true);
  assert.equal(sanitized.preset_id, PRESET_A);
  assert.equal(sanitized.player_id, PLAYER_A);
  assert.equal(sanitized.position_slot, "GK");
  assert.deepEqual(errors, []);
});

check("position_slot is trimmed", () => {
  const { sanitized } = validateTeamFormationPresetPlayerInput({
    preset_id: PRESET_A,
    player_id: PLAYER_A,
    position_slot: "  CB1  ",
  });
  assert.equal(sanitized.position_slot, "CB1");
});

console.log("");
console.log("validateTeamFormationPresetPlayerInput — malformed input never fabricated into something valid");

check("missing preset_id is rejected, not silently defaulted", () => {
  const { valid, errors } = validateTeamFormationPresetPlayerInput({ player_id: PLAYER_A, position_slot: "GK" });
  assert.equal(valid, false);
  assert.ok(errors.some((e) => e.startsWith("preset_id:")));
});

check("missing player_id is rejected, not silently defaulted", () => {
  const { valid, errors } = validateTeamFormationPresetPlayerInput({ preset_id: PRESET_A, position_slot: "GK" });
  assert.equal(valid, false);
  assert.ok(errors.some((e) => e.startsWith("player_id:")));
});

check("missing position_slot is rejected, not silently defaulted", () => {
  const { valid, errors } = validateTeamFormationPresetPlayerInput({ preset_id: PRESET_A, player_id: PLAYER_A });
  assert.equal(valid, false);
  assert.ok(errors.some((e) => e.startsWith("position_slot:")));
});

check("a whitespace-only position_slot is rejected", () => {
  const { valid, errors } = validateTeamFormationPresetPlayerInput({
    preset_id: PRESET_A,
    player_id: PLAYER_A,
    position_slot: "   ",
  });
  assert.equal(valid, false);
  assert.ok(errors.some((e) => e.startsWith("position_slot:")));
});

check("a non-uuid-shaped preset_id is rejected, never coerced into a fake id", () => {
  const { valid, sanitized, errors } = validateTeamFormationPresetPlayerInput({
    preset_id: "not-a-uuid",
    player_id: PLAYER_A,
    position_slot: "GK",
  });
  assert.equal(valid, false);
  assert.equal(sanitized.preset_id, "");
  assert.ok(errors.some((e) => e.includes("preset_id") && e.includes("uuid")));
});

check("a non-uuid-shaped player_id is rejected, never coerced into a fake id", () => {
  const { valid, sanitized, errors } = validateTeamFormationPresetPlayerInput({
    preset_id: PRESET_A,
    player_id: "not-a-uuid",
    position_slot: "GK",
  });
  assert.equal(valid, false);
  assert.equal(sanitized.player_id, "");
  assert.ok(errors.some((e) => e.includes("player_id") && e.includes("uuid")));
});

check("non-object input is rejected outright", () => {
  const { valid, errors } = validateTeamFormationPresetPlayerInput(null);
  assert.equal(valid, false);
  assert.equal(errors.length, 1);
});

check("array input is rejected outright (not treated as an object)", () => {
  const { valid } = validateTeamFormationPresetPlayerInput([PRESET_A, PLAYER_A, "GK"]);
  assert.equal(valid, false);
});

console.log("");
console.log("TeamFormationPresetPlayer — no coordinates, no player data duplication (spec section 2)");

check("a TeamFormationPresetPlayer value only ever needs preset_id/player_id/position_slot/timestamps", () => {
  const row: TeamFormationPresetPlayer = {
    id: PRESET_A,
    preset_id: PRESET_A,
    player_id: PLAYER_A,
    position_slot: "ST",
    created_at: "2026-01-01T00:00:00.000Z",
    updated_at: "2026-01-01T00:00:00.000Z",
  };
  assert.deepEqual(Object.keys(row).sort(), [
    "created_at",
    "id",
    "player_id",
    "position_slot",
    "preset_id",
    "updated_at",
  ]);
});

console.log("");
console.log("duplicate player/slot handling (spec section 6/17 — 'must fail safely')");

check("isDuplicateFormationPresetPlayer recognizes the preset-player constraint by name", () => {
  const err = {
    code: "23505",
    message: `duplicate key value violates unique constraint "${TEAM_FORMATION_PRESET_PLAYER_UNIQUE_CONSTRAINT}"`,
  };
  assert.equal(isDuplicateFormationPresetPlayer(err), true);
});

check("isDuplicateFormationPresetPlayer does not misattribute the slot constraint", () => {
  const err = {
    code: "23505",
    message: `duplicate key value violates unique constraint "${TEAM_FORMATION_PRESET_PLAYER_SLOT_UNIQUE_CONSTRAINT}"`,
  };
  assert.equal(isDuplicateFormationPresetPlayer(err), false);
});

check("isDuplicateFormationPresetPlayer rejects a non-23505 error even with a matching message", () => {
  const err = { code: "23503", message: TEAM_FORMATION_PRESET_PLAYER_UNIQUE_CONSTRAINT };
  assert.equal(isDuplicateFormationPresetPlayer(err), false);
});

check("isDuplicateFormationPresetSlot recognizes the preset-slot constraint by name", () => {
  const err = {
    code: "23505",
    message: `duplicate key value violates unique constraint "${TEAM_FORMATION_PRESET_PLAYER_SLOT_UNIQUE_CONSTRAINT}"`,
  };
  assert.equal(isDuplicateFormationPresetSlot(err), true);
});

check("isDuplicateFormationPresetSlot does not misattribute the player constraint", () => {
  const err = {
    code: "23505",
    message: `duplicate key value violates unique constraint "${TEAM_FORMATION_PRESET_PLAYER_UNIQUE_CONSTRAINT}"`,
  };
  assert.equal(isDuplicateFormationPresetSlot(err), false);
});

console.log("");
console.log("NOTE: 'same player allowed in different presets' and 'ON DELETE CASCADE' are properties of the");
console.log("unique index scope — (preset_id, player_id)/(preset_id, position_slot), not player_id/position_slot");
console.log("alone — and of the foreign keys' ON DELETE CASCADE clauses in migration");
console.log("0024_team_formation_presets.sql. Both were reviewed by hand in that migration; neither is something a");
console.log("pure-function unit test here can exercise without a live Postgres instance.");

// Explicitly exercise that PLAYER_B is a distinct, valid id (kept for
// symmetry with teamFormationPlayers.test.ts's P1/P2 naming, and to
// avoid an unused-import lint warning in strict configs).
check("a second distinct player id is also accepted on its own assignment", () => {
  const { valid, sanitized } = validateTeamFormationPresetPlayerInput({
    preset_id: PRESET_A,
    player_id: PLAYER_B,
    position_slot: "cb1",
  });
  assert.equal(valid, true);
  assert.equal(sanitized.player_id, PLAYER_B);
});

console.log("");
if (process.exitCode === 1) {
  console.error(`${passed} check(s) passed, at least one FAILED.`);
} else {
  console.log(`All ${passed} checks passed.`);
}
