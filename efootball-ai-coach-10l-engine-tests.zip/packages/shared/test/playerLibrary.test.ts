// Batch 6A-4 — lightweight, framework-free tests for playerLibrary.ts's
// pure validation/helper functions, plus uploadValidation.ts's new
// isPathOwnedByUser. No existing test runner/framework was found
// anywhere in this repository (no jest/vitest config, no *.test.* files
// before this batch) — per the 6A-4 spec ("If the repository has an
// existing test pattern, add focused tests... Do not install
// unnecessary dependencies"), this uses only Node's built-in `assert`
// module and runs directly via the `tsx` binary already present in this
// monorepo's own devDependencies (apps/worker/package.json) — no new
// dependency was added for this.
//
// Run with:  npx tsx packages/shared/test/playerLibrary.test.ts
//        or: npm test --workspace=packages/shared
//
// SCOPE NOTE: these are pure, in-process unit tests of validation/helper
// logic only — nothing here talks to a real Supabase/Postgres instance.
// RLS enforcement and the player_library_user_variant_uniq constraint's
// actual database-level behavior are exercised by migration
// 0011_player_library.sql and the player-library-save Edge Function's
// own logic, reviewed by hand, not by a live integration test. No live
// Supabase testing was performed for this batch.

import assert from "node:assert/strict";
import {
  validatePlayerLibraryInput,
  isUniqueViolation,
  playerLibraryVariantKey,
  PLAYER_LIBRARY_VARIANT_UNIQUE_CONSTRAINT,
} from "../src/playerLibrary.js";
import { isPathOwnedByUser } from "../src/uploadValidation.js";

let passed = 0;

function check(name: string, fn: () => void): void {
  try {
    fn();
    passed += 1;
    console.log(`  ok — ${name}`);
  } catch (err) {
    process.exitCode = 1;
    console.error(`  FAIL — ${name}`);
    console.error(err);
  }
}

console.log("validatePlayerLibraryInput — NULL/UNKNOWN handling (spec section 2)");

check("explicit nulls stay null — never guessed, never zeroed — and the input is valid", () => {
  const { valid, sanitized, errors } = validatePlayerLibraryInput({
    name: null,
    position: null,
    overall: null,
    playstyle: null,
    attributes: {},
    player_card_image_path: null,
  });
  assert.equal(sanitized.name, null);
  assert.equal(sanitized.overall, null);
  assert.deepEqual(errors, []);
  assert.equal(valid, true);
});

check("a known overall of 0 is preserved, distinct from unknown", () => {
  const { sanitized } = validatePlayerLibraryInput({
    name: "Test Player",
    position: "CF",
    overall: 0,
    playstyle: null,
    attributes: {},
    player_card_image_path: null,
  });
  assert.equal(sanitized.overall, 0);
});

check("an attribute reported present-but-unreadable (null) is kept as a key, not dropped", () => {
  const { sanitized } = validatePlayerLibraryInput({
    name: "Test",
    position: null,
    overall: null,
    playstyle: null,
    attributes: { speed: null, finishing: 88 },
    player_card_image_path: null,
  });
  assert.deepEqual(sanitized.attributes, { speed: null, finishing: 88 });
});

console.log("validatePlayerLibraryInput — overall validation (spec section 7)");

check("a negative overall is rejected to null AND fails the whole input (6A-4)", () => {
  const { valid, sanitized, errors } = validatePlayerLibraryInput({
    name: null,
    position: null,
    overall: -5,
    playstyle: null,
    attributes: {},
    player_card_image_path: null,
  });
  assert.equal(sanitized.overall, null);
  assert.ok(errors.some((e) => e.startsWith("overall:")));
  assert.equal(valid, false);
});

check("a non-integer (decimal) overall is rejected to null AND fails the whole input (6A-4)", () => {
  const { valid, sanitized, errors } = validatePlayerLibraryInput({
    name: null,
    position: null,
    overall: 82.5,
    playstyle: null,
    attributes: {},
    player_card_image_path: null,
  });
  assert.equal(sanitized.overall, null);
  assert.ok(errors.length > 0);
  assert.equal(valid, false);
});

check("a string overall is rejected to null (must be a real number) AND fails the whole input (6A-4)", () => {
  const { valid, sanitized, errors } = validatePlayerLibraryInput({
    name: null,
    position: null,
    overall: "82" as unknown,
    playstyle: null,
    attributes: {},
    player_card_image_path: null,
  });
  assert.equal(sanitized.overall, null);
  assert.ok(errors.length > 0);
  assert.equal(valid, false);
});

check("an explicit NaN overall is rejected to null AND fails the whole input (6A-4)", () => {
  const { valid, sanitized, errors } = validatePlayerLibraryInput({
    name: null,
    position: null,
    overall: Number.NaN,
    playstyle: null,
    attributes: {},
    player_card_image_path: null,
  });
  assert.equal(sanitized.overall, null);
  assert.ok(errors.length > 0);
  assert.equal(valid, false);
});

check("overall is never clamped to an assumed max like 99, and >99 remains valid", () => {
  const { valid, sanitized, errors } = validatePlayerLibraryInput({
    name: null,
    position: null,
    overall: 150,
    playstyle: null,
    attributes: {},
    player_card_image_path: null,
  });
  assert.equal(sanitized.overall, 150);
  assert.deepEqual(errors, []);
  assert.equal(valid, true);
});

check("a NaN attribute value is discarded to null AND fails the whole input (6A-4)", () => {
  const { valid, sanitized, errors } = validatePlayerLibraryInput({
    name: null,
    position: null,
    overall: null,
    playstyle: null,
    attributes: { weird: Number.NaN },
    player_card_image_path: null,
  });
  assert.equal(sanitized.attributes.weird, null);
  assert.ok(errors.length > 0);
  assert.equal(valid, false);
});

console.log("validatePlayerLibraryInput — malformed input must fail validation, not be silently nulled (6A-4)");

check("attributes that aren't an object at all fails the whole input", () => {
  const { valid, sanitized, errors } = validatePlayerLibraryInput({
    name: null,
    position: null,
    overall: null,
    playstyle: null,
    attributes: "not-an-object" as unknown,
    player_card_image_path: null,
  });
  assert.deepEqual(sanitized.attributes, {});
  assert.ok(errors.some((e) => e.startsWith("attributes:")));
  assert.equal(valid, false);
});

check("an invalid attribute value type (e.g. boolean) fails the whole input", () => {
  const { valid, sanitized, errors } = validatePlayerLibraryInput({
    name: null,
    position: null,
    overall: null,
    playstyle: null,
    attributes: { finishing: true as unknown },
    player_card_image_path: null,
  });
  assert.equal(sanitized.attributes.finishing, null);
  assert.ok(errors.some((e) => e.startsWith("attributes.finishing:")));
  assert.equal(valid, false);
});

check("a wrong-typed field (e.g. name as a number) fails the whole input", () => {
  const { valid, sanitized, errors } = validatePlayerLibraryInput({
    name: 12345 as unknown,
    position: null,
    overall: null,
    playstyle: null,
    attributes: {},
    player_card_image_path: null,
  });
  assert.equal(sanitized.name, null);
  assert.ok(errors.some((e) => e.startsWith("name:")));
  assert.equal(valid, false);
});

check("a normal, fully valid entry passes with no errors", () => {
  const { valid, errors, sanitized } = validatePlayerLibraryInput({
    name: "Kylian Mbappé",
    position: "LWF",
    overall: 91,
    playstyle: "Speedster",
    attributes: { pace: 97, finishing: 90, dribbling: "Excellent" },
    player_card_image_path: "user-a/card.png",
  });
  assert.equal(valid, true);
  assert.deepEqual(errors, []);
  assert.equal(sanitized.name, "Kylian Mbappé");
  assert.equal(sanitized.overall, 91);
  assert.equal(sanitized.player_card_image_path, "user-a/card.png");
});

console.log("validatePlayerLibraryInput — no fabricated required fields (spec section 7)");

check("a fully-empty entry is still `valid` — nothing is force-required", () => {
  const { valid, errors } = validatePlayerLibraryInput({
    name: null,
    position: null,
    overall: null,
    playstyle: null,
    attributes: {},
    player_card_image_path: null,
  });
  assert.equal(valid, true);
  assert.deepEqual(errors, []);
});

console.log("validatePlayerLibraryInput — image path safety");

check("a path traversal sequence is rejected to null AND fails the whole input (6A-4)", () => {
  const { valid, sanitized, errors } = validatePlayerLibraryInput({
    name: null,
    position: null,
    overall: null,
    playstyle: null,
    attributes: {},
    player_card_image_path: "user-a/../user-b/card.png",
  });
  assert.equal(sanitized.player_card_image_path, null);
  assert.ok(errors.length > 0);
  assert.equal(valid, false);
});

console.log("isPathOwnedByUser — ownership (spec sections 5/8/17)");

check("a path under the caller's own prefix is owned", () => {
  assert.equal(isPathOwnedByUser("user-a/card.png", "user-a"), true);
});

check("a path under a different user's prefix is NOT owned", () => {
  assert.equal(isPathOwnedByUser("user-b/card.png", "user-a"), false);
});

check("a lookalike prefix that isn't an exact folder match is NOT owned", () => {
  // "user-ax/..." must not be treated as owned by "user-a" just because
  // the string happens to start with "user-a" — ownership requires the
  // full "{userId}/" path segment, not a plain string prefix.
  assert.equal(isPathOwnedByUser("user-ax/card.png", "user-a"), false);
});

check("a null/empty path is never treated as owned", () => {
  assert.equal(isPathOwnedByUser(null, "user-a"), false);
  assert.equal(isPathOwnedByUser("", "user-a"), false);
});

console.log("duplicate-save handling (spec section 9)");

check("isUniqueViolation recognizes Postgres SQLSTATE 23505 for the right constraint", () => {
  const pgError = {
    code: "23505",
    message: `duplicate key value violates unique constraint "${PLAYER_LIBRARY_VARIANT_UNIQUE_CONSTRAINT}"`,
  };
  assert.equal(isUniqueViolation(pgError, PLAYER_LIBRARY_VARIANT_UNIQUE_CONSTRAINT), true);
});

check("isUniqueViolation rejects a unique violation on an unrelated constraint", () => {
  const pgError = { code: "23505", message: 'duplicate key value violates unique constraint "some_other_constraint"' };
  assert.equal(isUniqueViolation(pgError, PLAYER_LIBRARY_VARIANT_UNIQUE_CONSTRAINT), false);
});

check("isUniqueViolation rejects a non-unique-violation error entirely", () => {
  assert.equal(isUniqueViolation({ code: "23502", message: "null value in column" }), false);
});

check("playerLibraryVariantKey normalizes name case the same way the DB's expression index does", () => {
  const key = playerLibraryVariantKey({ name: "Kylian Mbappé", position: "LWF", overall: 91 });
  assert.deepEqual(key, { nameLower: "kylian mbappé", position: "LWF", overall: 91 });
});

check("playerLibraryVariantKey returns null when name is null — the partial index doesn't apply", () => {
  assert.equal(playerLibraryVariantKey({ name: null, position: "LWF", overall: 91 }), null);
});

console.log("");
if (process.exitCode === 1) {
  console.error(`${passed} check(s) passed, at least one FAILED.`);
} else {
  console.log(`All ${passed} checks passed.`);
}
