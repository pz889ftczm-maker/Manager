// Batch 9A — lightweight, framework-free tests for matchSnapshots.ts's
// pure validation helpers. Same convention as teamFormations.test.ts/
// playerLibrary.test.ts — no test runner/framework, uses Node's built-in
// `assert` module, runs via `tsx`.
//
// Run with:  npx tsx packages/shared/test/matchSnapshots.test.ts
//        or: npm test --workspace=packages/shared
//
// SCOPE NOTE: these are pure, in-process unit tests of validation logic
// only — nothing here talks to a real Supabase/Postgres instance. The
// actual authorization boundary (user_id = auth.uid() ownership, the
// match-ownership trigger, the RLS policies themselves, the
// match+team uniqueness constraint) lives entirely in migration
// 0025_match_snapshots.sql, reviewed by hand, not exercised by a live
// integration test here. No live Supabase/RLS verification was
// performed for this batch.

import assert from "node:assert/strict";
import {
  validateMatchSnapshotInput,
  validateMatchSnapshotPlayerInput,
  isDuplicateMatchSnapshot,
  MATCH_SNAPSHOT_MATCH_TEAM_UNIQUE_CONSTRAINT,
} from "../src/matchSnapshots.js";

let passed = 0;

function check(name: string, fn: () => void): void {
  try {
    fn();
    passed += 1;
    console.log(`  ok — ${name}`);
  } catch (err) {
    process.exitCode = 1;
    console.error(`  FAIL — ${name}`);
    console.error(err);
  }
}

const VALID_USER_ID = "11111111-1111-1111-1111-111111111111";
const VALID_MATCH_ID = "22222222-2222-2222-2222-222222222222";
const VALID_TEAM_ID = "33333333-3333-3333-3333-333333333333";
const VALID_SNAPSHOT_ID = "44444444-4444-4444-4444-444444444444";
const VALID_PLAYER_ID = "55555555-5555-5555-5555-555555555555";

console.log("validateMatchSnapshotInput — valid snapshot");

check("a well-formed snapshot with every field set is valid", () => {
  const { valid, sanitized, errors } = validateMatchSnapshotInput({
    user_id: VALID_USER_ID,
    match_id: VALID_MATCH_ID,
    team_id: VALID_TEAM_ID,
    formation_id: null,
    manager_id: null,
    formation_code: "4-3-3",
    formation_name: "Balanced 4-3-3",
    positions: [{ id: "gk", role: "GK", x: 0.05, y: 0.5 }],
    tactical_instructions: { pressing: "high" },
    team_name: "My Team",
    team_motto: "Never give up",
    team_description: "A description",
    team_founded_year: 2020,
    team_stadium: "Home Stadium",
    manager_name: "Manager Name",
    manager_ratings: { possession_rating: 80 },
  });
  assert.equal(valid, true);
  assert.equal(sanitized.user_id, VALID_USER_ID);
  assert.equal(sanitized.match_id, VALID_MATCH_ID);
  assert.equal(sanitized.team_id, VALID_TEAM_ID);
  assert.equal(sanitized.team_name, "My Team");
  assert.deepEqual(errors, []);
});

check("a minimal snapshot with only the required ids is valid — nullable fields", () => {
  const { valid, sanitized, errors } = validateMatchSnapshotInput({
    user_id: VALID_USER_ID,
    match_id: VALID_MATCH_ID,
  });
  assert.equal(valid, true);
  assert.equal(sanitized.team_id, null);
  assert.equal(sanitized.formation_id, null);
  assert.equal(sanitized.manager_id, null);
  assert.equal(sanitized.formation_code, null);
  assert.equal(sanitized.formation_name, null);
  assert.equal(sanitized.positions, null);
  assert.equal(sanitized.tactical_instructions, null);
  assert.equal(sanitized.team_name, null);
  assert.equal(sanitized.team_motto, null);
  assert.equal(sanitized.team_description, null);
  assert.equal(sanitized.team_founded_year, null);
  assert.equal(sanitized.team_stadium, null);
  assert.equal(sanitized.manager_name, null);
  assert.equal(sanitized.manager_ratings, null);
  assert.deepEqual(errors, []);
});

console.log("\nvalidateMatchSnapshotInput — unknown values remain NULL, never fabricated");

check("unknown overall-like numeric fields are never defaulted to 0 — team_founded_year stays null", () => {
  const { sanitized, errors } = validateMatchSnapshotInput({
    user_id: VALID_USER_ID,
    match_id: VALID_MATCH_ID,
    team_founded_year: undefined,
  });
  assert.equal(sanitized.team_founded_year, null);
  assert.deepEqual(errors, []);
});

check("an invalid team_founded_year is discarded to null, never coerced", () => {
  const { sanitized, errors } = validateMatchSnapshotInput({
    user_id: VALID_USER_ID,
    match_id: VALID_MATCH_ID,
    team_founded_year: 0,
  });
  assert.equal(sanitized.team_founded_year, null);
  assert.ok(errors.some((e) => e.includes("team_founded_year")));
});

check("a negative team_founded_year is rejected", () => {
  const { sanitized, errors } = validateMatchSnapshotInput({
    user_id: VALID_USER_ID,
    match_id: VALID_MATCH_ID,
    team_founded_year: -5,
  });
  assert.equal(sanitized.team_founded_year, null);
  assert.ok(errors.length > 0);
});

check("empty-string optional text fields normalize to null, not empty string", () => {
  const { sanitized } = validateMatchSnapshotInput({
    user_id: VALID_USER_ID,
    match_id: VALID_MATCH_ID,
    team_name: "   ",
    manager_name: "",
  });
  assert.equal(sanitized.team_name, null);
  assert.equal(sanitized.manager_name, null);
});

console.log("\nvalidateMatchSnapshotInput — malformed ids rejected");

check("a missing user_id is rejected", () => {
  const { valid, errors } = validateMatchSnapshotInput({
    match_id: VALID_MATCH_ID,
  });
  assert.equal(valid, false);
  assert.ok(errors.some((e) => e.includes("user_id")));
});

check("a missing match_id is rejected", () => {
  const { valid, errors } = validateMatchSnapshotInput({
    user_id: VALID_USER_ID,
  });
  assert.equal(valid, false);
  assert.ok(errors.some((e) => e.includes("match_id")));
});

check("a malformed team_id is discarded to null but does not fail the whole record", () => {
  const { valid, sanitized, errors } = validateMatchSnapshotInput({
    user_id: VALID_USER_ID,
    match_id: VALID_MATCH_ID,
    team_id: "not-a-uuid",
  });
  assert.equal(valid, false);
  assert.equal(sanitized.team_id, null);
  assert.ok(errors.some((e) => e.includes("team_id")));
});

check("non-object input is rejected outright", () => {
  const { valid, errors } = validateMatchSnapshotInput("not an object");
  assert.equal(valid, false);
  assert.ok(errors.length > 0);
});

console.log("\nvalidateMatchSnapshotInput — jsonb shape checks");

check("a malformed tactical_instructions (array instead of object) is rejected", () => {
  const { valid, sanitized, errors } = validateMatchSnapshotInput({
    user_id: VALID_USER_ID,
    match_id: VALID_MATCH_ID,
    tactical_instructions: ["not", "an", "object"],
  });
  assert.equal(valid, false);
  assert.equal(sanitized.tactical_instructions, null);
  assert.ok(errors.some((e) => e.includes("tactical_instructions")));
});

check("a malformed manager_ratings (array instead of object) is rejected", () => {
  const { valid, sanitized, errors } = validateMatchSnapshotInput({
    user_id: VALID_USER_ID,
    match_id: VALID_MATCH_ID,
    manager_ratings: [1, 2, 3],
  });
  assert.equal(valid, false);
  assert.equal(sanitized.manager_ratings, null);
  assert.ok(errors.some((e) => e.includes("manager_ratings")));
});

check("a malformed positions value (a bare string) is rejected", () => {
  const { valid, errors } = validateMatchSnapshotInput({
    user_id: VALID_USER_ID,
    match_id: VALID_MATCH_ID,
    positions: "gk,cb,cb",
  });
  assert.equal(valid, false);
  assert.ok(errors.some((e) => e.includes("positions")));
});

console.log("\nvalidateMatchSnapshotPlayerInput — valid snapshot player");

check("a well-formed snapshot player is valid", () => {
  const { valid, sanitized, errors } = validateMatchSnapshotPlayerInput({
    snapshot_id: VALID_SNAPSHOT_ID,
    player_id: VALID_PLAYER_ID,
    player_name: "Test Player",
    position: "CAM",
    overall: 85,
    playstyle: "Creative Playmaker",
    attributes: { offensive_awareness: 87, speed: null },
    position_slot: "cam1",
  });
  assert.equal(valid, true);
  assert.equal(sanitized.snapshot_id, VALID_SNAPSHOT_ID);
  assert.equal(sanitized.overall, 85);
  assert.deepEqual(errors, []);
});

check("a minimal snapshot player with only snapshot_id is valid", () => {
  const { valid, sanitized, errors } = validateMatchSnapshotPlayerInput({
    snapshot_id: VALID_SNAPSHOT_ID,
  });
  assert.equal(valid, true);
  assert.equal(sanitized.player_id, null);
  assert.equal(sanitized.player_name, null);
  assert.equal(sanitized.position, null);
  assert.equal(sanitized.overall, null);
  assert.equal(sanitized.playstyle, null);
  assert.equal(sanitized.attributes, null);
  assert.equal(sanitized.position_slot, null);
  assert.deepEqual(errors, []);
});

check("snapshot player does not require or accept a user_id field", () => {
  const { sanitized } = validateMatchSnapshotPlayerInput({
    snapshot_id: VALID_SNAPSHOT_ID,
    user_id: VALID_USER_ID,
  } as unknown);
  assert.ok(!("user_id" in sanitized));
});

console.log("\nvalidateMatchSnapshotPlayerInput — unknown values remain NULL, never fabricated");

check("an unknown overall stays null, never defaulted to 0", () => {
  const { sanitized, errors } = validateMatchSnapshotPlayerInput({
    snapshot_id: VALID_SNAPSHOT_ID,
  });
  assert.equal(sanitized.overall, null);
  assert.deepEqual(errors, []);
});

check("an invalid overall (negative) is rejected, not clamped to 0", () => {
  const { valid, sanitized, errors } = validateMatchSnapshotPlayerInput({
    snapshot_id: VALID_SNAPSHOT_ID,
    overall: -1,
  });
  assert.equal(valid, false);
  assert.equal(sanitized.overall, null);
  assert.ok(errors.some((e) => e.includes("overall")));
});

check("a non-integer overall is rejected", () => {
  const { valid, sanitized } = validateMatchSnapshotPlayerInput({
    snapshot_id: VALID_SNAPSHOT_ID,
    overall: 85.5,
  });
  assert.equal(valid, false);
  assert.equal(sanitized.overall, null);
});

check("an unreadable attribute stays present with a null value, key not dropped", () => {
  const { sanitized } = validateMatchSnapshotPlayerInput({
    snapshot_id: VALID_SNAPSHOT_ID,
    attributes: { speed: null, finishing: 90 },
  });
  assert.deepEqual(sanitized.attributes, { speed: null, finishing: 90 });
});

console.log("\nvalidateMatchSnapshotPlayerInput — malformed ids rejected");

check("a missing snapshot_id is rejected", () => {
  const { valid, errors } = validateMatchSnapshotPlayerInput({});
  assert.equal(valid, false);
  assert.ok(errors.some((e) => e.includes("snapshot_id")));
});

check("a malformed player_id is discarded to null but does not fail the whole record", () => {
  const { valid, sanitized, errors } = validateMatchSnapshotPlayerInput({
    snapshot_id: VALID_SNAPSHOT_ID,
    player_id: "not-a-uuid",
  });
  assert.equal(valid, false);
  assert.equal(sanitized.player_id, null);
  assert.ok(errors.some((e) => e.includes("player_id")));
});

check("non-object input is rejected outright", () => {
  const { valid, errors } = validateMatchSnapshotPlayerInput(null);
  assert.equal(valid, false);
  assert.ok(errors.length > 0);
});

console.log("\nHistorical independence (conceptual)");

check("player snapshot survives player deletion conceptually — sanitized fields don't depend on player_id", () => {
  // A snapshot player row is valid, and its historical fields fully
  // populated, even with player_id explicitly null (as it would be
  // after the source player_library row is deleted — migration 0025's
  // `on delete set null`). Nothing in validateMatchSnapshotPlayerInput
  // requires player_id to reconstruct player_name/position/overall/etc.
  const { valid, sanitized, errors } = validateMatchSnapshotPlayerInput({
    snapshot_id: VALID_SNAPSHOT_ID,
    player_id: null,
    player_name: "Deleted Player's Historical Name",
    position: "ST",
    overall: 91,
    playstyle: "Poacher",
    attributes: { finishing: 93 },
    position_slot: "st1",
  });
  assert.equal(valid, true);
  assert.equal(sanitized.player_id, null);
  assert.equal(sanitized.player_name, "Deleted Player's Historical Name");
  assert.equal(sanitized.overall, 91);
  assert.deepEqual(errors, []);
});

check("historical values are stored independently of any live-library id", () => {
  // Same team_name/formation_code/manager_name persist regardless of
  // whether team_id/formation_id/manager_id are present or null —
  // nothing in validateMatchSnapshotInput ties the historical text/
  // jsonb fields to the provenance ids.
  const withIds = validateMatchSnapshotInput({
    user_id: VALID_USER_ID,
    match_id: VALID_MATCH_ID,
    team_id: VALID_TEAM_ID,
    team_name: "Historic FC",
    formation_code: "4-2-3-1",
  });
  const withoutIds = validateMatchSnapshotInput({
    user_id: VALID_USER_ID,
    match_id: VALID_MATCH_ID,
    team_id: null,
    team_name: "Historic FC",
    formation_code: "4-2-3-1",
  });
  assert.equal(withIds.sanitized.team_name, withoutIds.sanitized.team_name);
  assert.equal(withIds.sanitized.formation_code, withoutIds.sanitized.formation_code);
});

console.log("\nDuplicate-snapshot handling");

check("isDuplicateMatchSnapshot recognizes the exact constraint violation", () => {
  const err = {
    code: "23505",
    message: `duplicate key value violates unique constraint "${MATCH_SNAPSHOT_MATCH_TEAM_UNIQUE_CONSTRAINT}"`,
  };
  assert.equal(isDuplicateMatchSnapshot(err), true);
});

check("isDuplicateMatchSnapshot returns false for an unrelated unique violation", () => {
  const err = {
    code: "23505",
    message: 'duplicate key value violates unique constraint "some_other_constraint"',
  };
  assert.equal(isDuplicateMatchSnapshot(err), false);
});

check("isDuplicateMatchSnapshot returns false for a non-unique-violation error", () => {
  assert.equal(isDuplicateMatchSnapshot({ code: "23503", message: "fk violation" }), false);
  assert.equal(isDuplicateMatchSnapshot(new Error("random error")), false);
  assert.equal(isDuplicateMatchSnapshot(null), false);
});

console.log(`\n${passed} check(s) passed.`);
if (process.exitCode) {
  console.error("\nSome checks FAILED.");
} else {
  console.log("All checks passed.");
}
