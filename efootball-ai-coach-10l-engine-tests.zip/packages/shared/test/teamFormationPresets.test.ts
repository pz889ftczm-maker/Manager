// Batch 8D — lightweight, framework-free tests for
// teamFormationPresets.ts's pure validation helpers. Same convention as
// teamFormations.test.ts/teamFormationPlayers.test.ts — no test
// runner/framework, uses Node's built-in `assert` module, runs via
// `tsx`.
//
// Run with:  npx tsx packages/shared/test/teamFormationPresets.test.ts
//        or: npm test --workspace=packages/shared
//
// SCOPE NOTE: these are pure, in-process unit tests of validation/
// duplicate-detection logic only — nothing here talks to a real
// Supabase/Postgres instance. The actual authorization boundary (RLS
// policies, the ownership-consistency trigger, ON DELETE CASCADE
// behavior) lives entirely in migration
// 0024_team_formation_presets.sql, reviewed by hand, not exercised by a
// live integration test here. No live Supabase/RLS/cascade
// verification was performed for this batch.

import assert from "node:assert/strict";
import {
  validateTeamFormationPresetInput,
  validateTeamFormationPresetFields,
  isDuplicateFormationPresetName,
  TEAM_FORMATION_PRESET_NAME_UNIQUE_CONSTRAINT,
  assertSameTeamForPresetApply,
  isFormationPresetTeamMismatchError,
  FormationPresetTeamMismatchError,
  type TeamFormationPreset,
} from "../src/teamFormationPresets.js";

let passed = 0;

function check(name: string, fn: () => void): void {
  try {
    fn();
    passed += 1;
    console.log(`  ok — ${name}`);
  } catch (err) {
    process.exitCode = 1;
    console.error(`  FAIL — ${name}`);
    console.error(err);
  }
}

const TEAM_A = "11111111-1111-1111-1111-111111111111";
const TEAM_B = "22222222-2222-2222-2222-222222222222";

console.log("validateTeamFormationPresetInput — a valid preset");

check("a well-formed preset input is valid", () => {
  const { valid, sanitized, errors } = validateTeamFormationPresetInput({
    team_id: TEAM_A,
    name: "My 4-3-3",
    formation_code: "4-3-3",
    positions: [{ id: "gk", role: "GK", x: 0.5, y: 0.92 }],
    tactical_instructions: null,
  });
  assert.equal(valid, true);
  assert.equal(sanitized.team_id, TEAM_A);
  assert.equal(sanitized.name, "My 4-3-3");
  assert.equal(sanitized.formation_code, "4-3-3");
  assert.deepEqual(errors, []);
});

check("name and formation_code are trimmed", () => {
  const { sanitized } = validateTeamFormationPresetInput({
    team_id: TEAM_A,
    name: "  Gegenpress  ",
    formation_code: "  4-2-3-1  ",
    positions: [{ id: "gk" }],
    tactical_instructions: null,
  });
  assert.equal(sanitized.name, "Gegenpress");
  assert.equal(sanitized.formation_code, "4-2-3-1");
});

check("tactical_instructions may be a generic object", () => {
  const { valid, sanitized } = validateTeamFormationPresetInput({
    team_id: TEAM_A,
    name: "Custom",
    formation_code: "4-3-3",
    positions: [{ id: "gk" }],
    tactical_instructions: { pressing: "high" },
  });
  assert.equal(valid, true);
  assert.deepEqual(sanitized.tactical_instructions, { pressing: "high" });
});

console.log("");
console.log("validateTeamFormationPresetInput — required fields");

check("missing team_id is rejected, not silently defaulted", () => {
  const { valid, errors } = validateTeamFormationPresetInput({
    name: "My 4-3-3",
    formation_code: "4-3-3",
    positions: [{ id: "gk" }],
    tactical_instructions: null,
  });
  assert.equal(valid, false);
  assert.ok(errors.some((e) => e.startsWith("team_id:")));
});

check("blank name is rejected", () => {
  const { valid, errors } = validateTeamFormationPresetInput({
    team_id: TEAM_A,
    name: "   ",
    formation_code: "4-3-3",
    positions: [{ id: "gk" }],
    tactical_instructions: null,
  });
  assert.equal(valid, false);
  assert.ok(errors.some((e) => e.startsWith("name:")));
});

check("blank formation_code is rejected", () => {
  const { valid, errors } = validateTeamFormationPresetInput({
    team_id: TEAM_A,
    name: "My 4-3-3",
    formation_code: "",
    positions: [{ id: "gk" }],
    tactical_instructions: null,
  });
  assert.equal(valid, false);
  assert.ok(errors.some((e) => e.startsWith("formation_code:")));
});

check("non-object input is rejected outright", () => {
  const { valid, errors } = validateTeamFormationPresetInput(null);
  assert.equal(valid, false);
  assert.equal(errors.length, 1);
});

console.log("");
console.log("positions validation is REUSED from teamFormations.ts (spec section 8)");

check("a player_id smuggled into a position entry is rejected, same as team_formations", () => {
  const { valid, errors } = validateTeamFormationPresetInput({
    team_id: TEAM_A,
    name: "Bad preset",
    formation_code: "4-3-3",
    positions: [{ id: "gk", player_id: "33333333-3333-3333-3333-333333333333" }],
    tactical_instructions: null,
  });
  assert.equal(valid, false);
  assert.ok(errors.some((e) => e.includes("player_id") && e.includes("not allowed")));
});

check("a playerId (camelCase) smuggled into a position entry is rejected", () => {
  const { valid, errors } = validateTeamFormationPresetInput({
    team_id: TEAM_A,
    name: "Bad preset",
    formation_code: "4-3-3",
    positions: [{ id: "gk", playerId: "33333333-3333-3333-3333-333333333333" }],
    tactical_instructions: null,
  });
  assert.equal(valid, false);
  assert.ok(errors.some((e) => e.includes("playerId")));
});

check("a player_name smuggled into a position entry is rejected", () => {
  const { valid, errors } = validateTeamFormationPresetInput({
    team_id: TEAM_A,
    name: "Bad preset",
    formation_code: "4-3-3",
    positions: [{ id: "gk", player_name: "Alisson" }],
    tactical_instructions: null,
  });
  assert.equal(valid, false);
  assert.ok(errors.some((e) => e.includes("player_name")));
});

check("a playerName (camelCase) smuggled into a position entry is rejected", () => {
  const { valid, errors } = validateTeamFormationPresetInput({
    team_id: TEAM_A,
    name: "Bad preset",
    formation_code: "4-3-3",
    positions: [{ id: "gk", playerName: "Alisson" }],
    tactical_instructions: null,
  });
  assert.equal(valid, false);
  assert.ok(errors.some((e) => e.includes("playerName")));
});

check("out-of-range coordinates are rejected, same 0..1 rule as team_formations", () => {
  const { valid, errors } = validateTeamFormationPresetInput({
    team_id: TEAM_A,
    name: "Bad preset",
    formation_code: "4-3-3",
    positions: [{ id: "gk", x: 1.5, y: 0.5 }],
    tactical_instructions: null,
  });
  assert.equal(valid, false);
  assert.ok(errors.some((e) => e.includes("x must be a finite number between 0 and 1")));
});

console.log("");
console.log("validateTeamFormationPresetFields — team-id-independent (for renames/edits)");

check("valid fields without team_id pass", () => {
  const { valid, sanitized } = validateTeamFormationPresetFields({
    name: "Renamed",
    formation_code: "4-3-3",
    positions: [{ id: "gk" }],
    tactical_instructions: null,
  });
  assert.equal(valid, true);
  assert.equal(sanitized.name, "Renamed");
});

check("does not require or touch team_id at all", () => {
  const result = validateTeamFormationPresetFields({
    name: "Renamed",
    formation_code: "4-3-3",
    positions: [{ id: "gk" }],
    tactical_instructions: null,
  });
  assert.ok(!("team_id" in result.sanitized));
});

console.log("");
console.log("TeamFormationPreset — no historical/match fields (spec section 7/16)");

check("a TeamFormationPreset value has exactly the expected keys — no match_id/snapshot_id", () => {
  const row: TeamFormationPreset = {
    id: TEAM_A,
    team_id: TEAM_A,
    name: "My 4-3-3",
    formation_code: "4-3-3",
    positions: [],
    tactical_instructions: null,
    created_at: "2026-01-01T00:00:00.000Z",
    updated_at: "2026-01-01T00:00:00.000Z",
  };
  assert.deepEqual(Object.keys(row).sort(), [
    "created_at",
    "formation_code",
    "id",
    "name",
    "positions",
    "tactical_instructions",
    "team_id",
    "updated_at",
  ]);
});

console.log("");
console.log("assertSameTeamForPresetApply — cross-team apply guard (Batch 8D quick fix)");

check("same team_id on both sides does not throw — same-team apply is allowed", () => {
  assert.doesNotThrow(() => {
    assertSameTeamForPresetApply({ team_id: TEAM_A }, { team_id: TEAM_A });
  });
});

check("preset.team_id !== formation.team_id throws FormationPresetTeamMismatchError", () => {
  assert.throws(
    () => assertSameTeamForPresetApply({ team_id: TEAM_A }, { team_id: TEAM_B }),
    FormationPresetTeamMismatchError
  );
});

check("the mismatch error message is fixed/sanitized — never interpolates either team_id", () => {
  try {
    assertSameTeamForPresetApply({ team_id: TEAM_A }, { team_id: TEAM_B });
    assert.fail("expected assertSameTeamForPresetApply to throw");
  } catch (err) {
    assert.ok(err instanceof Error);
    assert.equal((err as Error).message, "Formation preset belongs to a different team.");
    assert.ok(!(err as Error).message.includes(TEAM_A));
    assert.ok(!(err as Error).message.includes(TEAM_B));
  }
});

check("isFormationPresetTeamMismatchError recognizes the guard's own error", () => {
  try {
    assertSameTeamForPresetApply({ team_id: TEAM_A }, { team_id: TEAM_B });
    assert.fail("expected assertSameTeamForPresetApply to throw");
  } catch (err) {
    assert.equal(isFormationPresetTeamMismatchError(err), true);
  }
});

check("isFormationPresetTeamMismatchError rejects an unrelated Error", () => {
  assert.equal(isFormationPresetTeamMismatchError(new Error("Formation preset belongs to a different team.")), false);
});

check("isFormationPresetTeamMismatchError rejects a plain Postgres-shaped error object", () => {
  assert.equal(isFormationPresetTeamMismatchError({ code: "42501", message: "row-level security" }), false);
});

console.log("");
console.log("duplicate preset name handling (spec section 6)");

check("isDuplicateFormationPresetName recognizes the team_formation_presets constraint by name", () => {
  const err = {
    code: "23505",
    message: `duplicate key value violates unique constraint "${TEAM_FORMATION_PRESET_NAME_UNIQUE_CONSTRAINT}"`,
  };
  assert.equal(isDuplicateFormationPresetName(err), true);
});

check("isDuplicateFormationPresetName does not misattribute the team_formations name constraint", () => {
  const err = {
    code: "23505",
    message: 'duplicate key value violates unique constraint "team_formations_team_name_uniq"',
  };
  assert.equal(isDuplicateFormationPresetName(err), false);
});

check("isDuplicateFormationPresetName rejects a non-23505 error even with a matching message", () => {
  const err = { code: "23503", message: TEAM_FORMATION_PRESET_NAME_UNIQUE_CONSTRAINT };
  assert.equal(isDuplicateFormationPresetName(err), false);
});

console.log("");
if (process.exitCode === 1) {
  console.error(`${passed} check(s) passed, at least one FAILED.`);
} else {
  console.log(`All ${passed} checks passed.`);
}
