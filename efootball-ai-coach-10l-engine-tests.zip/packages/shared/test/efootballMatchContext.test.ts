// Batch 10B — lightweight, framework-free tests for
// efootballMatchContext.ts's pure builder. Same convention as
// footballMatchContext.test.ts/matchSnapshots.test.ts — no test
// runner/framework, Node's built-in `assert`, run via `tsx`.
//
// Run with:  npx tsx packages/shared/test/efootballMatchContext.test.ts
//        or: npm test --workspace=packages/shared
//
// SCOPE NOTE: pure, in-process tests of buildEfootballMatchContext's
// gating/assembly logic only — no database, no ownership check (that's
// apps/worker/src/efootballContext.ts's job, covered by its own test
// file), no snapshot/live query construction.

import assert from "node:assert/strict";
import { buildEfootballMatchContext, type EfootballContextSources } from "../src/efootballMatchContext.js";
import type { FootballMatchContext } from "../src/footballMatchContext.js";
import type { MatchSnapshot, MatchSnapshotPlayer } from "../src/matchSnapshots.js";
import type { TeamFormation } from "../src/teamFormations.js";
import type { PlayerLibrary, ManagerLibrary } from "../src/types.js";

let passed = 0;

function check(name: string, fn: () => void): void {
  try {
    fn();
    passed += 1;
    console.log(`  ok — ${name}`);
  } catch (err) {
    process.exitCode = 1;
    console.error(`  FAIL — ${name}`);
    console.error(err);
  }
}

const EFOOTBALL: FootballMatchContext = { football_type: "efootball", team_size: 11 };
const REAL_FOOTBALL: FootballMatchContext = { football_type: "real_football", team_size: 7 };

const NO_SOURCES: EfootballContextSources = { snapshot: null, live: null };

function makeSnapshot(overrides: Partial<MatchSnapshot> = {}): MatchSnapshot {
  return {
    id: "s1",
    user_id: "u1",
    match_id: "m1",
    team_id: "t1",
    formation_id: "f1",
    manager_id: "mg1",
    formation_code: "4-3-3",
    formation_name: "Attacking 4-3-3",
    positions: { GK: { x: 0.5, y: 0.05 } },
    tactical_instructions: { press: "high" },
    team_name: "Real Testers",
    team_motto: null,
    team_description: null,
    team_founded_year: null,
    team_stadium: null,
    manager_name: "Test Manager",
    manager_ratings: {
      possession_rating: 80,
      quick_counter_rating: 70,
      long_ball_counter_rating: 60,
      out_wide_rating: 50,
      long_ball_rating: 40,
    },
    created_at: "2026-01-01T00:00:00Z",
    ...overrides,
  };
}

function makeSnapshotPlayer(overrides: Partial<MatchSnapshotPlayer> = {}): MatchSnapshotPlayer {
  return {
    id: "sp1",
    snapshot_id: "s1",
    player_id: "p1",
    player_name: "Alex Striker",
    position: "ST",
    overall: 88,
    playstyle: "Goal Poacher",
    attributes: { pace: 90, shooting: 85 },
    position_slot: "st",
    created_at: "2026-01-01T00:00:00Z",
    ...overrides,
  };
}

function makePlayerLibrary(overrides: Partial<PlayerLibrary> = {}): PlayerLibrary {
  return {
    id: "p1",
    user_id: "u1",
    name: "Alex Striker",
    position: "ST",
    overall: 88,
    playstyle: "Goal Poacher",
    player_card_image_path: null,
    attributes: { pace: 90, shooting: 85 },
    metadata: null,
    created_at: "2026-01-01T00:00:00Z",
    updated_at: "2026-01-01T00:00:00Z",
    ...overrides,
  };
}

function makeManagerLibrary(overrides: Partial<ManagerLibrary> = {}): ManagerLibrary {
  return {
    id: "mg1",
    user_id: "u1",
    name: "Test Manager",
    possession_rating: 80,
    quick_counter_rating: 70,
    long_ball_counter_rating: 60,
    out_wide_rating: 50,
    long_ball_rating: 40,
    manager_image_path: null,
    metadata: null,
    created_at: "2026-01-01T00:00:00Z",
    updated_at: "2026-01-01T00:00:00Z",
    ...overrides,
  };
}

function makeTeamFormation(overrides: Partial<TeamFormation> = {}): TeamFormation {
  return {
    id: "f1",
    team_id: "t1",
    name: "Attacking 4-3-3",
    formation_code: "4-3-3",
    positions: { GK: { x: 0.5, y: 0.05 } },
    tactical_instructions: { press: "high" },
    created_at: "2026-01-01T00:00:00Z",
    updated_at: "2026-01-01T00:00:00Z",
    ...overrides,
  };
}

console.log("buildEfootballMatchContext — gating (spec section 3)");

check("football_type=real_football: context is unavailable, reason=not_efootball", () => {
  const result = buildEfootballMatchContext(REAL_FOOTBALL, NO_SOURCES);
  assert.deepEqual(result, { available: false, reason: "not_efootball" });
});

check("football_type=null (legacy): context is unavailable, reason=unknown_football_type — never assumed eFootball", () => {
  const result = buildEfootballMatchContext(null, NO_SOURCES);
  assert.deepEqual(result, { available: false, reason: "unknown_football_type" });
});

check("football_type=efootball with no data at all: unavailable, reason=no_data (not fabricated)", () => {
  const result = buildEfootballMatchContext(EFOOTBALL, NO_SOURCES);
  assert.deepEqual(result, { available: false, reason: "no_data" });
});

check("real_football is never given eFootball context even when snapshot/live data is (incorrectly) supplied", () => {
  const result = buildEfootballMatchContext(REAL_FOOTBALL, {
    snapshot: { snapshot: makeSnapshot(), players: [makeSnapshotPlayer()] },
    live: null,
  });
  assert.equal(result.available, false);
  assert.equal((result as { reason: string }).reason, "not_efootball");
});

console.log("\nbuildEfootballMatchContext — eFootball match returns real, grounded eFootball context (spec item 1)");

check("returns available=true with source=historical_snapshot when a snapshot exists", () => {
  const result = buildEfootballMatchContext(EFOOTBALL, {
    snapshot: { snapshot: makeSnapshot(), players: [makeSnapshotPlayer()] },
    live: null,
  });
  assert.equal(result.available, true);
  if (result.available) assert.equal(result.source, "historical_snapshot");
});

check("returns available=true with source=current_data when only live data exists", () => {
  const result = buildEfootballMatchContext(EFOOTBALL, {
    snapshot: null,
    live: { formation: makeTeamFormation(), manager: makeManagerLibrary(), players: [] },
  });
  assert.equal(result.available, true);
  if (result.available) assert.equal(result.source, "current_data");
});

console.log("\nbuildEfootballMatchContext — historical snapshot preferred over current data (spec section 2, items 5/6)");

check("when both a snapshot and live data are supplied, the snapshot wins exclusively", () => {
  const snapshot = makeSnapshot({ manager_name: "Historical Manager", formation_name: "Historical Formation" });
  const result = buildEfootballMatchContext(EFOOTBALL, {
    snapshot: { snapshot, players: [makeSnapshotPlayer({ player_name: "Historical Player" })] },
    live: {
      formation: makeTeamFormation({ name: "Current Formation (edited since match)" }),
      manager: makeManagerLibrary({ name: "Current Manager (edited since match)" }),
      players: [{ position_slot: "st", player: makePlayerLibrary({ name: "Current Player (edited since match)" }) }],
    },
  });

  assert.equal(result.available, true);
  if (!result.available) return;
  assert.equal(result.source, "historical_snapshot");
  assert.equal(result.manager?.name, "Historical Manager");
  assert.equal(result.formation?.name, "Historical Formation");
  assert.equal(result.players[0].name, "Historical Player");
});

check("current Player/Manager/Formation edits never leak into a historical result even for fields the snapshot has as null", () => {
  // Spec section 2: "If a historical snapshot does not contain a
  // value, preserve NULL/unknown rather than silently substituting
  // current library data."
  const snapshot = makeSnapshot({ manager_name: null, manager_id: null, manager_ratings: null });
  const result = buildEfootballMatchContext(EFOOTBALL, {
    snapshot: { snapshot, players: [] },
    live: { formation: null, manager: makeManagerLibrary({ name: "Should never appear" }), players: [] },
  });

  assert.equal(result.available, true);
  if (!result.available) return;
  // The snapshot legitimately captured no manager at all — must stay
  // null, never backfilled from the live manager supplied above.
  assert.equal(result.manager, null);
});

console.log("\nbuildEfootballMatchContext — player data comes from actual stored data (spec item 2)");

check("historical players are copied field-for-field from match_snapshot_players", () => {
  const player = makeSnapshotPlayer({
    player_id: "p42",
    player_name: "Sam Wing",
    position: "RW",
    position_slot: "rw",
    overall: 91,
    playstyle: "Speedster",
    attributes: { pace: 95 },
  });
  const result = buildEfootballMatchContext(EFOOTBALL, { snapshot: { snapshot: makeSnapshot(), players: [player] }, live: null });
  assert.equal(result.available, true);
  if (!result.available) return;
  assert.deepEqual(result.players, [
    {
      player_id: "p42",
      name: "Sam Wing",
      position: "RW",
      position_slot: "rw",
      overall: 91,
      playstyle: "Speedster",
      attributes: { pace: 95 },
    },
  ]);
});

check("live players are copied field-for-field from the joined Player Library row", () => {
  const player = makePlayerLibrary({ id: "p9", name: "Jamie Back", position: "CB", overall: 84, playstyle: "Anchor Man", attributes: { defending: 88 } });
  const result = buildEfootballMatchContext(EFOOTBALL, {
    snapshot: null,
    live: { formation: null, manager: null, players: [{ position_slot: "cb1", player }] },
  });
  assert.equal(result.available, true);
  if (!result.available) return;
  assert.deepEqual(result.players, [
    { player_id: "p9", name: "Jamie Back", position: "CB", position_slot: "cb1", overall: 84, playstyle: "Anchor Man", attributes: { defending: 88 } },
  ]);
});

console.log("\nbuildEfootballMatchContext — manager data comes from actual stored data (spec item 3)");

check("historical manager ratings are copied from the snapshot's manager_ratings jsonb", () => {
  const result = buildEfootballMatchContext(EFOOTBALL, { snapshot: { snapshot: makeSnapshot(), players: [] }, live: null });
  assert.equal(result.available, true);
  if (!result.available) return;
  assert.deepEqual(result.manager, {
    manager_id: "mg1",
    name: "Test Manager",
    ratings: {
      possession_rating: 80,
      quick_counter_rating: 70,
      long_ball_counter_rating: 60,
      out_wide_rating: 50,
      long_ball_rating: 40,
    },
  });
});

check("live manager ratings are copied from the Manager Library row", () => {
  const manager = makeManagerLibrary({ id: "mg9", name: "Live Gaffer", possession_rating: 99 });
  const result = buildEfootballMatchContext(EFOOTBALL, { snapshot: null, live: { formation: null, manager, players: [] } });
  assert.equal(result.available, true);
  if (!result.available) return;
  assert.equal(result.manager?.manager_id, "mg9");
  assert.equal(result.manager?.name, "Live Gaffer");
  assert.equal(result.manager?.ratings?.possession_rating, 99);
});

console.log("\nbuildEfootballMatchContext — formation/tactical data comes from actual stored data (spec item 4)");

check("historical formation + tactical_instructions are copied from the snapshot", () => {
  const result = buildEfootballMatchContext(EFOOTBALL, { snapshot: { snapshot: makeSnapshot(), players: [] }, live: null });
  assert.equal(result.available, true);
  if (!result.available) return;
  assert.deepEqual(result.formation, {
    formation_id: "f1",
    formation_code: "4-3-3",
    name: "Attacking 4-3-3",
    positions: { GK: { x: 0.5, y: 0.05 } },
    tactical_instructions: { press: "high" },
  });
});

check("live formation + tactical_instructions are copied from the team_formations row", () => {
  const formation = makeTeamFormation({ id: "f9", formation_code: "4-4-2", tactical_instructions: { width: "narrow" } });
  const result = buildEfootballMatchContext(EFOOTBALL, { snapshot: null, live: { formation, manager: null, players: [] } });
  assert.equal(result.available, true);
  if (!result.available) return;
  assert.equal(result.formation?.formation_id, "f9");
  assert.equal(result.formation?.formation_code, "4-4-2");
  assert.deepEqual(result.formation?.tactical_instructions, { width: "narrow" });
});

console.log("\nbuildEfootballMatchContext — NULL values remain NULL (spec item 7 / section 4)");

check("a snapshot player's null fields stay null, never coerced to 0/''", () => {
  const player = makeSnapshotPlayer({ overall: null, playstyle: null, attributes: null, position: null });
  const result = buildEfootballMatchContext(EFOOTBALL, { snapshot: { snapshot: makeSnapshot(), players: [player] }, live: null });
  assert.equal(result.available, true);
  if (!result.available) return;
  assert.equal(result.players[0].overall, null);
  assert.equal(result.players[0].playstyle, null);
  assert.equal(result.players[0].attributes, null);
  assert.equal(result.players[0].position, null);
});

check("a live player's null fields stay null, never coerced to 0/''", () => {
  const player = makePlayerLibrary({ overall: null, playstyle: null, attributes: null, position: null });
  const result = buildEfootballMatchContext(EFOOTBALL, {
    snapshot: null,
    live: { formation: null, manager: null, players: [{ position_slot: null, player }] },
  });
  assert.equal(result.available, true);
  if (!result.available) return;
  assert.equal(result.players[0].overall, null);
  assert.equal(result.players[0].position_slot, null);
});

check("a snapshot with no formation at all (all formation fields null) reports formation=null, not an all-null object", () => {
  const snapshot = makeSnapshot({
    formation_id: null,
    formation_code: null,
    formation_name: null,
    positions: null,
    tactical_instructions: null,
  });
  const result = buildEfootballMatchContext(EFOOTBALL, { snapshot: { snapshot, players: [] }, live: null });
  assert.equal(result.available, true);
  if (!result.available) return;
  assert.equal(result.formation, null);
});

console.log("\nbuildEfootballMatchContext — no fabricated values anywhere (spec item 11)");

check("live data with no formation/manager and zero players reports no_data rather than an empty-but-available context", () => {
  const result = buildEfootballMatchContext(EFOOTBALL, { snapshot: null, live: { formation: null, manager: null, players: [] } });
  assert.deepEqual(result, { available: false, reason: "no_data" });
});

check("nothing in this module invents a football_type — buildEfootballMatchContext takes it as a required first argument", () => {
  assert.equal(buildEfootballMatchContext.length, 2);
});

console.log(`\n${passed} check(s) passed.`);
if (process.exitCode) {
  console.error("\nSome checks FAILED.");
} else {
  console.log("All checks passed.");
}
