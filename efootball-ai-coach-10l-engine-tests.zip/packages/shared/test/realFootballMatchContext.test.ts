// Batch 10C — lightweight, framework-free tests for
// realFootballMatchContext.ts's pure builder. Same convention as
// efootballMatchContext.test.ts — no test runner/framework, Node's
// built-in `assert`, run via `tsx`.
//
// Run with:  npx tsx packages/shared/test/realFootballMatchContext.test.ts
//        or: npm test --workspace=packages/shared
//
// SCOPE NOTE: pure, in-process tests of buildRealFootballMatchContext's
// gating/assembly logic only — no database, no ownership check (that's
// apps/worker/src/realFootballContext.ts's job, covered by its own
// test file), no snapshot/live query construction.

import assert from "node:assert/strict";
import { buildRealFootballMatchContext, type RealFootballContextSources } from "../src/realFootballMatchContext.js";
import type { FootballMatchContext } from "../src/footballMatchContext.js";
import type { MatchSnapshot, MatchSnapshotPlayer } from "../src/matchSnapshots.js";
import type { TeamFormation } from "../src/teamFormations.js";
import type { PlayerLibrary } from "../src/types.js";

let passed = 0;

function check(name: string, fn: () => void): void {
  try {
    fn();
    passed += 1;
    console.log(`  ok — ${name}`);
  } catch (err) {
    process.exitCode = 1;
    console.error(`  FAIL — ${name}`);
    console.error(err);
  }
}

const EFOOTBALL: FootballMatchContext = { football_type: "efootball", team_size: 11 };
const REAL_FOOTBALL: FootballMatchContext = { football_type: "real_football", team_size: 7 };

const NO_SOURCES: RealFootballContextSources = { snapshot: null, live: null };

function makeSnapshot(overrides: Partial<MatchSnapshot> = {}): MatchSnapshot {
  return {
    id: "s1",
    user_id: "u1",
    match_id: "m1",
    team_id: "t1",
    formation_id: "f1",
    manager_id: null,
    formation_code: "2-3-1",
    formation_name: "7v7 Attacking",
    positions: { GK: { x: 0.5, y: 0.05, role: "goalkeeper" }, st: { id: "st", role: "forward", x: 0.5, y: 0.9 } },
    tactical_instructions: { press: "high" },
    team_name: "Real Testers",
    team_motto: null,
    team_description: null,
    team_founded_year: null,
    team_stadium: null,
    manager_name: null,
    manager_ratings: null,
    created_at: "2026-01-01T00:00:00Z",
    ...overrides,
  };
}

function makeSnapshotPlayer(overrides: Partial<MatchSnapshotPlayer> = {}): MatchSnapshotPlayer {
  return {
    id: "sp1",
    snapshot_id: "s1",
    player_id: "p1",
    player_name: "Alex Striker",
    position: "ST",
    overall: 88,
    playstyle: "Goal Poacher",
    attributes: { pace: 90 },
    position_slot: "st",
    created_at: "2026-01-01T00:00:00Z",
    ...overrides,
  };
}

function makePlayerLibrary(overrides: Partial<PlayerLibrary> = {}): PlayerLibrary {
  return {
    id: "p1",
    user_id: "u1",
    name: "Alex Striker",
    position: "ST",
    overall: 88,
    playstyle: "Goal Poacher",
    player_card_image_path: null,
    attributes: { pace: 90 },
    metadata: null,
    created_at: "2026-01-01T00:00:00Z",
    updated_at: "2026-01-01T00:00:00Z",
    ...overrides,
  };
}

function makeTeamFormation(overrides: Partial<TeamFormation> = {}): TeamFormation {
  return {
    id: "f1",
    team_id: "t1",
    name: "7v7 Attacking",
    formation_code: "2-3-1",
    positions: { GK: { x: 0.5, y: 0.05, role: "goalkeeper" }, st: { id: "st", role: "forward", x: 0.5, y: 0.9 } },
    tactical_instructions: { press: "high" },
    created_at: "2026-01-01T00:00:00Z",
    updated_at: "2026-01-01T00:00:00Z",
    ...overrides,
  };
}

console.log("buildRealFootballMatchContext — gating (spec section 4)");

check("football_type=efootball: context is unavailable, reason=not_real_football", () => {
  const result = buildRealFootballMatchContext(EFOOTBALL, NO_SOURCES);
  assert.deepEqual(result, { available: false, reason: "not_real_football" });
});

check("football_type=null (legacy): context is unavailable, reason=unknown_football_type — never assumed real_football", () => {
  const result = buildRealFootballMatchContext(null, NO_SOURCES);
  assert.deepEqual(result, { available: false, reason: "unknown_football_type" });
});

check("football_type=real_football with no data at all: unavailable, reason=no_data (not fabricated)", () => {
  const result = buildRealFootballMatchContext(REAL_FOOTBALL, NO_SOURCES);
  assert.deepEqual(result, { available: false, reason: "no_data" });
});

check("efootball is never given real-football context even when snapshot/live data is (incorrectly) supplied", () => {
  const result = buildRealFootballMatchContext(EFOOTBALL, {
    snapshot: { snapshot: makeSnapshot(), players: [makeSnapshotPlayer()] },
    live: null,
  });
  assert.equal(result.available, false);
  assert.equal((result as { reason: string }).reason, "not_real_football");
});

console.log("\nbuildRealFootballMatchContext — valid contexts (spec items 1/12)");

check("returns available=true with football_type/team_size fixed to real_football/7 and source=historical_snapshot", () => {
  const result = buildRealFootballMatchContext(REAL_FOOTBALL, {
    snapshot: { snapshot: makeSnapshot(), players: [makeSnapshotPlayer()] },
    live: null,
  });
  assert.equal(result.available, true);
  if (!result.available) return;
  assert.equal(result.football_type, "real_football");
  assert.equal(result.team_size, 7);
  assert.equal(result.source, "historical_snapshot");
});

check("returns available=true with source=current_data when only live data exists (works without a snapshot)", () => {
  const result = buildRealFootballMatchContext(REAL_FOOTBALL, {
    snapshot: null,
    live: { formation: makeTeamFormation(), players: [] },
  });
  assert.equal(result.available, true);
  if (result.available) assert.equal(result.source, "current_data");
});

console.log("\nbuildRealFootballMatchContext — historical snapshot preferred over current data (spec section 2, item 5)");

check("when both a snapshot and live data are supplied, the snapshot wins exclusively", () => {
  const snapshot = makeSnapshot({ formation_name: "Historical Formation" });
  const result = buildRealFootballMatchContext(REAL_FOOTBALL, {
    snapshot: { snapshot, players: [makeSnapshotPlayer({ player_name: "Historical Player" })] },
    live: {
      formation: makeTeamFormation({ name: "Current Formation (edited since match)" }),
      players: [{ position_slot: "st", player: makePlayerLibrary({ name: "Current Player (edited since match)" }) }],
    },
  });

  assert.equal(result.available, true);
  if (!result.available) return;
  assert.equal(result.source, "historical_snapshot");
  assert.equal(result.formation?.name, "Historical Formation");
  assert.equal(result.players[0].name, "Historical Player");
});

check("current Formation/Player edits never leak into a historical result even for fields the snapshot has as null", () => {
  const snapshot = makeSnapshot({ formation_id: null, formation_code: null, formation_name: null, positions: null, tactical_instructions: null });
  const result = buildRealFootballMatchContext(REAL_FOOTBALL, {
    snapshot: { snapshot, players: [] },
    live: { formation: makeTeamFormation({ name: "Should never appear" }), players: [] },
  });

  assert.equal(result.available, true);
  if (!result.available) return;
  // The snapshot legitimately captured no formation at all — must
  // stay null, never backfilled from the live formation supplied above.
  assert.equal(result.formation, null);
});

console.log("\nbuildRealFootballMatchContext — no eFootball-specific fields appear (spec item 9)");

check("historical players never carry overall/playstyle/attributes even though the snapshot row has them", () => {
  const result = buildRealFootballMatchContext(REAL_FOOTBALL, {
    snapshot: { snapshot: makeSnapshot(), players: [makeSnapshotPlayer()] },
    live: null,
  });
  assert.equal(result.available, true);
  if (!result.available) return;
  const player = result.players[0] as unknown as Record<string, unknown>;
  assert.equal("overall" in player, false);
  assert.equal("playstyle" in player, false);
  assert.equal("attributes" in player, false);
});

check("live players never carry overall/playstyle/attributes/player_card_image_path even though the Player Library row has them", () => {
  const result = buildRealFootballMatchContext(REAL_FOOTBALL, {
    snapshot: null,
    live: { formation: null, players: [{ position_slot: "st", player: makePlayerLibrary() }] },
  });
  assert.equal(result.available, true);
  if (!result.available) return;
  const player = result.players[0] as unknown as Record<string, unknown>;
  assert.equal("overall" in player, false);
  assert.equal("playstyle" in player, false);
  assert.equal("attributes" in player, false);
  assert.equal("player_card_image_path" in player, false);
});

check("the context has no manager field at all — Real Football has no manager-style-rating concept", () => {
  const result = buildRealFootballMatchContext(REAL_FOOTBALL, {
    snapshot: { snapshot: makeSnapshot(), players: [] },
    live: null,
  });
  assert.equal(result.available, true);
  if (!result.available) return;
  assert.equal("manager" in (result as unknown as Record<string, unknown>), false);
});

console.log("\nbuildRealFootballMatchContext — player roles sourced from stored position data, never invented (spec item 6/11)");

check("a historical player's role is looked up from the snapshot's own positions[slot].role", () => {
  const result = buildRealFootballMatchContext(REAL_FOOTBALL, {
    snapshot: { snapshot: makeSnapshot(), players: [makeSnapshotPlayer({ position_slot: "st" })] },
    live: null,
  });
  assert.equal(result.available, true);
  if (!result.available) return;
  assert.equal(result.players[0].role, "forward");
});

check("a live player's role is looked up from the live formation's own positions[slot].role", () => {
  const result = buildRealFootballMatchContext(REAL_FOOTBALL, {
    snapshot: null,
    live: { formation: makeTeamFormation(), players: [{ position_slot: "st", player: makePlayerLibrary() }] },
  });
  assert.equal(result.available, true);
  if (!result.available) return;
  assert.equal(result.players[0].role, "forward");
});

check("a player whose position_slot has no matching entry in positions gets role=null, never invented", () => {
  const result = buildRealFootballMatchContext(REAL_FOOTBALL, {
    snapshot: { snapshot: makeSnapshot(), players: [makeSnapshotPlayer({ position_slot: "cb1" })] },
    live: null,
  });
  assert.equal(result.available, true);
  if (!result.available) return;
  assert.equal(result.players[0].role, null);
});

check("role is never derived from the player's own `position` string (e.g. ST is not mapped to 'forward' by guessing)", () => {
  // No positions data at all on the snapshot — role must stay null
  // even though position="ST" might tempt a naive implementation to
  // guess "forward".
  const snapshot = makeSnapshot({ positions: null });
  const result = buildRealFootballMatchContext(REAL_FOOTBALL, {
    snapshot: { snapshot, players: [makeSnapshotPlayer({ position: "ST", position_slot: "st" })] },
    live: null,
  });
  assert.equal(result.available, true);
  if (!result.available) return;
  assert.equal(result.players[0].role, null);
});

console.log("\nbuildRealFootballMatchContext — NULL values remain NULL (spec item 10 / section 4)");

check("a snapshot player's null fields stay null, never coerced to 0/''", () => {
  const player = makeSnapshotPlayer({ position: null, position_slot: null, player_name: null, player_id: null });
  const result = buildRealFootballMatchContext(REAL_FOOTBALL, { snapshot: { snapshot: makeSnapshot(), players: [player] }, live: null });
  assert.equal(result.available, true);
  if (!result.available) return;
  assert.deepEqual(result.players[0], { player_id: null, name: null, position: null, position_slot: null, role: null });
});

check("a snapshot with no formation at all (all formation fields null) reports formation=null, not an all-null object", () => {
  const snapshot = makeSnapshot({
    formation_id: null,
    formation_code: null,
    formation_name: null,
    positions: null,
    tactical_instructions: null,
  });
  const result = buildRealFootballMatchContext(REAL_FOOTBALL, { snapshot: { snapshot, players: [] }, live: null });
  assert.equal(result.available, true);
  if (!result.available) return;
  assert.equal(result.formation, null);
});

console.log("\nbuildRealFootballMatchContext — no fabricated values anywhere (spec item 11)");

check("live data with no formation and zero players reports no_data rather than an empty-but-available context", () => {
  const result = buildRealFootballMatchContext(REAL_FOOTBALL, { snapshot: null, live: { formation: null, players: [] } });
  assert.deepEqual(result, { available: false, reason: "no_data" });
});

check("nothing in this module invents a football_type — buildRealFootballMatchContext takes it as a required first argument", () => {
  assert.equal(buildRealFootballMatchContext.length, 2);
});

check("formation/tactical_instructions are copied field-for-field from the live team_formations row", () => {
  const formation = makeTeamFormation({ id: "f9", formation_code: "3-2-1", tactical_instructions: { width: "narrow" } });
  const result = buildRealFootballMatchContext(REAL_FOOTBALL, { snapshot: null, live: { formation, players: [] } });
  assert.equal(result.available, true);
  if (!result.available) return;
  assert.equal(result.formation?.formation_id, "f9");
  assert.equal(result.formation?.formation_code, "3-2-1");
  assert.deepEqual(result.formation?.tactical_instructions, { width: "narrow" });
});

console.log(`\n${passed} check(s) passed.`);
if (process.exitCode) {
  console.error("\nSome checks FAILED.");
} else {
  console.log("All checks passed.");
}
