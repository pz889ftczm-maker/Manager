// Batch 10H — lightweight, framework-free tests for momentExplanation.ts.
// Same convention as decisionQuality.test.ts/decisionQualityEvidence.test.ts
// — no test runner/framework, Node's built-in `assert`, run via `tsx`.
//
// Run with:  npx tsx packages/shared/test/momentExplanation.test.ts
//        or: npm test --workspace=packages/shared
//
// SCOPE NOTE: pure, in-process tests of the shared model/builder only —
// no database, no RLS, no worker integration, no AI calls (10H makes
// none). Proves composition/reuse of 10D/10E/10F/10G, not the internal
// rules of any of those files (already covered by their own test files).

import assert from "node:assert/strict";
import {
  buildMomentExplanationFromUnifiedEvent,
  type MomentExplanationContext,
} from "../src/momentExplanation.js";
import type { UnifiedFootballEvent } from "../src/footballEvent.js";
import type { TacticalPosition, TacticalPositionState } from "../src/tacticalPosition.js";
import type { PassingLane, Space } from "../src/passingLaneSpaceModel.js";

let passed = 0;

function check(name: string, fn: () => void): void {
  try {
    fn();
    passed += 1;
    console.log(`  ok — ${name}`);
  } catch (err) {
    process.exitCode = 1;
    console.error(`  FAIL — ${name}`);
    console.error(err);
  }
}

function baseUnifiedEvent(overrides: Partial<UnifiedFootballEvent> = {}): UnifiedFootballEvent {
  return {
    id: "event-1",
    match_id: "match-1",
    football_type: "efootball",
    timestamp_seconds: 120.5,
    event_type: "pass",
    legacy_event_type: "bad_pass",
    legacy_category: "passing",
    severity: "mistake",
    confidence: 80,
    confidence_level: "likely",
    decision_score: 20,
    description: "Played a risky central pass into a double press.",
    better_option: null,
    reasoning: null,
    player_id: null,
    evidence: null,
    before_frame_url: null,
    decision_frame_url: null,
    after_frame_url: null,
    context_start_seconds: 118,
    context_end_seconds: 123,
    created_at: "2026-01-01T00:00:00Z",
    ...overrides,
  };
}

function basePosition(overrides: Partial<TacticalPosition> = {}): TacticalPosition {
  return {
    football_type: "efootball",
    match_id: "match-1",
    team: "user",
    player: { player_id: "p1", name: "Alex Striker" },
    role: "CM",
    position_slot: null,
    coordinates: { x: 50, y: 60 },
    timestamp_seconds: 120.5,
    confidence_level: "confirmed",
    source: { type: "tactical_analysis", event_id: "event-1", is_approximate: false, context_source: null },
    ...overrides,
  };
}

function basePassingLane(overrides: Partial<PassingLane> = {}): PassingLane {
  return {
    football_type: "efootball",
    match_id: "match-1",
    from_player: null,
    to_player: null,
    from_coordinates: { x: 50, y: 60 },
    to_coordinates: { x: 70, y: 65 },
    quality: "risky",
    timestamp_seconds: 120.5,
    confidence_level: "confirmed",
    source: { type: "tactical_analysis", event_id: "event-1", is_approximate: false },
    ...overrides,
  };
}

function baseSpace(overrides: Partial<Space> = {}): Space {
  return {
    football_type: "efootball",
    match_id: "match-1",
    status: "pressured",
    center: { x: 55, y: 62 },
    radius: 8,
    intensity: 0.7,
    team: null,
    timestamp_seconds: 120.5,
    confidence_level: "confirmed",
    source: { type: "tactical_analysis", event_id: "event-1", is_approximate: false },
    ...overrides,
  };
}

console.log("buildMomentExplanationFromUnifiedEvent — WHAT/WHY/confidence pass through DecisionQuality");

check("what_happened reuses DecisionQuality's action (event description), verbatim", () => {
  const event = baseUnifiedEvent();
  const explanation = buildMomentExplanationFromUnifiedEvent(event);
  assert.equal(explanation.what_happened, "Played a risky central pass into a double press.");
  assert.equal(explanation.event_id, "event-1");
  assert.equal(explanation.football_type, "efootball");
  assert.equal(explanation.match_id, "match-1");
});

check("why_it_happened reuses DecisionQuality's reasons (event reasoning) when present", () => {
  const event = baseUnifiedEvent({ reasoning: "The double press was visible before the pass was played." });
  const explanation = buildMomentExplanationFromUnifiedEvent(event);
  assert.deepEqual(explanation.why_it_happened, ["The double press was visible before the pass was played."]);
});

check("why_it_happened is null when the event carries no reasoning", () => {
  const event = baseUnifiedEvent({ reasoning: null });
  const explanation = buildMomentExplanationFromUnifiedEvent(event);
  assert.equal(explanation.why_it_happened, null);
});

check("confidence passes through DecisionQuality's own confidence, independent of evidence", () => {
  const event = baseUnifiedEvent({ confidence: 55, reasoning: null });
  const explanation = buildMomentExplanationFromUnifiedEvent(event);
  assert.equal(explanation.confidence, 55);
  // No evidence anywhere on this event -> insufficient, yet confidence
  // still passes through unchanged (score/confidence/evidence are
  // independent — same convention as decisionQuality.ts).
  assert.equal(explanation.has_sufficient_evidence, false);
});

console.log("\nbuildMomentExplanationFromUnifiedEvent — better_option/why_better/actionable_improvement are evidence-gated");

check("sufficient evidence + a better_option string -> better_option, why_better, and actionable_improvement are all populated", () => {
  const event = baseUnifiedEvent({
    better_option: "Switch the ball to the far side instead.",
    reasoning: "The near side was already collapsed by two defenders.",
  });
  const explanation = buildMomentExplanationFromUnifiedEvent(event);

  assert.notEqual(explanation.better_option, null);
  assert.equal(explanation.better_option?.label, "Switch the ball to the far side instead.");
  assert.deepEqual(explanation.why_better, ["The near side was already collapsed by two defenders."]);
  assert.equal(explanation.actionable_improvement, "Switch the ball to the far side instead.");
  assert.equal(explanation.has_sufficient_evidence, true);
});

check("a better_option string with no supporting evidence (no reasoning) is NOT accepted — better_option/why_better/actionable_improvement all stay null", () => {
  const event = baseUnifiedEvent({
    better_option: "Switch the ball to the far side instead.",
    reasoning: null,
  });
  const explanation = buildMomentExplanationFromUnifiedEvent(event);

  assert.equal(explanation.better_option, null);
  assert.equal(explanation.why_better, null);
  assert.equal(explanation.actionable_improvement, null);
  assert.equal(explanation.has_sufficient_evidence, false);
});

check("no better_option string at all -> better_option/why_better/actionable_improvement stay null even with other evidence present", () => {
  const event = baseUnifiedEvent({
    better_option: null,
    reasoning: "Clear evidence the pass was risky.",
  });
  const explanation = buildMomentExplanationFromUnifiedEvent(event);

  assert.equal(explanation.better_option, null);
  assert.equal(explanation.why_better, null);
  assert.equal(explanation.actionable_improvement, null);
  // Overall evidence is still sufficient (reasons present) even though
  // there is no better_option to report — the two checks are independent.
  assert.equal(explanation.has_sufficient_evidence, true);
});

console.log("\nbuildMomentExplanationFromUnifiedEvent — evidence field is the de-duplicated union of reasons/source_references");

check("evidence merges reasons and source_references without duplicating a shared entry", () => {
  const event = baseUnifiedEvent({
    reasoning: "Shared evidence line.",
    evidence: ["Shared evidence line.", "Statistic: pass success rate 42%."],
  });
  const explanation = buildMomentExplanationFromUnifiedEvent(event);

  assert.deepEqual(explanation.evidence, ["Shared evidence line.", "Statistic: pass success rate 42%."]);
});

check("evidence is null when neither reasons nor source_references exist", () => {
  const event = baseUnifiedEvent({ reasoning: null, evidence: null });
  const explanation = buildMomentExplanationFromUnifiedEvent(event);
  assert.equal(explanation.evidence, null);
});

console.log("\nbuildMomentExplanationFromUnifiedEvent — insufficient evidence => null/unknown, never a partial/default grade");

check("no score at all -> insufficient evidence regardless of reasoning text", () => {
  const event = baseUnifiedEvent({ decision_score: null, reasoning: "Some reasoning text." });
  const explanation = buildMomentExplanationFromUnifiedEvent(event);
  assert.equal(explanation.has_sufficient_evidence, false);
});

console.log("\nbuildMomentExplanationFromUnifiedEvent — tactical/spatial context (10E/10F) is reused verbatim, matched by event_id");

check("a TacticalPositionState/PassingLane/Space sourced from THIS event are all attached, unchanged", () => {
  const event = baseUnifiedEvent();
  const context: MomentExplanationContext = {
    positions: { actual: basePosition(), recommended: null } as TacticalPositionState,
    passingLane: basePassingLane(),
    space: baseSpace(),
  };

  const explanation = buildMomentExplanationFromUnifiedEvent(event, context);

  assert.deepEqual(explanation.positions, context.positions);
  assert.deepEqual(explanation.passing_lane, context.passingLane);
  assert.deepEqual(explanation.space, context.space);
});

check("a PassingLane/Space sourced from a DIFFERENT event is dropped (null), never misattributed", () => {
  const event = baseUnifiedEvent({ id: "event-1" });
  const context: MomentExplanationContext = {
    passingLane: basePassingLane({ source: { type: "tactical_analysis", event_id: "event-999", is_approximate: false } }),
    space: baseSpace({ source: { type: "tactical_analysis", event_id: "event-999", is_approximate: false } }),
  };

  const explanation = buildMomentExplanationFromUnifiedEvent(event, context);

  assert.equal(explanation.passing_lane, null);
  assert.equal(explanation.space, null);
});

check("a TacticalPositionState sourced from a DIFFERENT event's tactical_analysis row is dropped (null)", () => {
  const event = baseUnifiedEvent({ id: "event-1" });
  const context: MomentExplanationContext = {
    positions: {
      actual: basePosition({
        source: { type: "tactical_analysis", event_id: "event-999", is_approximate: false, context_source: null },
      }),
      recommended: null,
    },
  };

  const explanation = buildMomentExplanationFromUnifiedEvent(event, context);

  assert.equal(explanation.positions, null);
});

check("a context-sourced TacticalPositionState (no event_id at all) is always attached — it is never event-specific", () => {
  const event = baseUnifiedEvent({ id: "event-1" });
  const context: MomentExplanationContext = {
    positions: {
      actual: basePosition({
        source: { type: "efootball_context", event_id: null, is_approximate: null, context_source: "current_data" },
      }),
      recommended: null,
    },
  };

  const explanation = buildMomentExplanationFromUnifiedEvent(event, context);

  assert.notEqual(explanation.positions, null);
});

check("no context supplied at all -> positions/passing_lane/space all stay null", () => {
  const event = baseUnifiedEvent();
  const explanation = buildMomentExplanationFromUnifiedEvent(event);

  assert.equal(explanation.positions, null);
  assert.equal(explanation.passing_lane, null);
  assert.equal(explanation.space, null);
});

console.log("\nbuildMomentExplanationFromUnifiedEvent — player/timestamp reuse DecisionQuality, never re-derived");

check("player is reused from DecisionQuality (built from the event's own player_id) verbatim", () => {
  const event = baseUnifiedEvent({ player_id: "p1" });
  const explanation = buildMomentExplanationFromUnifiedEvent(event);
  assert.deepEqual(explanation.player, { player_id: "p1", name: null });
});

check("real-football events are never branched on — same builder, no football_type-specific behavior", () => {
  const event = baseUnifiedEvent({
    football_type: "real_football",
    better_option: "Hold possession instead.",
    reasoning: "Team was already outnumbered in that channel.",
  });
  const explanation = buildMomentExplanationFromUnifiedEvent(event);

  assert.equal(explanation.football_type, "real_football");
  assert.notEqual(explanation.better_option, null);
  assert.equal(explanation.has_sufficient_evidence, true);
});

console.log(`\n${passed} check(s) passed`);
if (process.exitCode) {
  console.error("\nSome checks FAILED — see above.");
} else {
  console.log("All checks passed.");
}
