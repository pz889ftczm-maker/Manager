// Batch 10G-2 — lightweight, framework-free tests for
// decisionQualityEvidence.ts. Same convention as decisionQuality.test.ts
// — no test runner/framework, Node's built-in `assert`, run via `tsx`.
//
// Run with:  npx tsx packages/shared/test/decisionQualityEvidence.test.ts
//        or: npm test --workspace=packages/shared

import assert from "node:assert/strict";
import {
  hasSufficientEvidence,
  hasSufficientEvidenceForBetterOption,
  evaluateDecisionQualityEvidence,
} from "../src/decisionQualityEvidence.js";
import type { DecisionQuality } from "../src/decisionQuality.js";

let passed = 0;

function check(name: string, fn: () => void): void {
  try {
    fn();
    passed += 1;
    console.log(`  ok — ${name}`);
  } catch (err) {
    process.exitCode = 1;
    console.error(`  FAIL — ${name}`);
    console.error(err);
  }
}

function baseDecision(overrides: Partial<DecisionQuality> = {}): DecisionQuality {
  return {
    football_type: "efootball",
    match_id: "match-1",
    event_id: "event-1",
    player: null,
    timestamp_seconds: 120.5,
    action: "Played a risky central pass into a double press.",
    available_options: null,
    chosen_option: null,
    better_option: null,
    score: 20,
    confidence: 80,
    reasons: null,
    source_references: null,
    ...overrides,
  };
}

// ============================================================
// hasSufficientEvidence
// ============================================================

check("no score -> insufficient, regardless of evidence fields", () => {
  const d = baseDecision({ score: null, reasons: ["some reason"] });
  assert.equal(hasSufficientEvidence(d), false);
});

check("score with no evidence anywhere -> insufficient", () => {
  const d = baseDecision({ score: 90, reasons: null, source_references: null });
  assert.equal(hasSufficientEvidence(d), false);
});

check("score + non-empty reasons -> sufficient", () => {
  const d = baseDecision({ score: 90, reasons: ["Cited passing lane analysis."] });
  assert.equal(hasSufficientEvidence(d), true);
});

check("score + non-empty source_references -> sufficient", () => {
  const d = baseDecision({ score: 90, source_references: ["frame:decision_frame_url"] });
  assert.equal(hasSufficientEvidence(d), true);
});

check("score + chosen_option with evidence -> sufficient", () => {
  const d = baseDecision({
    score: 55,
    chosen_option: { label: "pass to right winger", evidence: ["AI reasoning text"] },
  });
  assert.equal(hasSufficientEvidence(d), true);
});

check("score + chosen_option WITHOUT evidence -> insufficient", () => {
  const d = baseDecision({
    score: 55,
    chosen_option: { label: "pass to right winger", evidence: null },
  });
  assert.equal(hasSufficientEvidence(d), false);
});

check("score + available_options where one has evidence -> sufficient", () => {
  const d = baseDecision({
    score: 55,
    available_options: [
      { label: "hold up play", evidence: null },
      { label: "shoot first time", evidence: ["cited stat"] },
    ],
  });
  assert.equal(hasSufficientEvidence(d), true);
});

check("score + available_options where none have evidence -> insufficient", () => {
  const d = baseDecision({
    score: 55,
    available_options: [
      { label: "hold up play", evidence: null },
      { label: "shoot first time", evidence: [] },
    ],
  });
  assert.equal(hasSufficientEvidence(d), false);
});

check("better_option's own evidence does NOT by itself make the decision gradable", () => {
  const d = baseDecision({
    score: 55,
    reasons: null,
    source_references: null,
    better_option: { label: "shoot first time", evidence: ["cited stat"] },
  });
  assert.equal(hasSufficientEvidence(d), false);
});

// ============================================================
// hasSufficientEvidenceForBetterOption
// ============================================================

check("no better_option -> false", () => {
  const d = baseDecision({ better_option: null });
  assert.equal(hasSufficientEvidenceForBetterOption(d), false);
});

check("better_option with its own evidence -> true", () => {
  const d = baseDecision({
    better_option: { label: "shoot first time", evidence: ["cited stat"] },
  });
  assert.equal(hasSufficientEvidenceForBetterOption(d), true);
});

check("better_option with no own evidence but record-level reasons -> true", () => {
  const d = baseDecision({
    better_option: { label: "shoot first time", evidence: null },
    reasons: ["AI reasoning supports this"],
  });
  assert.equal(hasSufficientEvidenceForBetterOption(d), true);
});

check("better_option with no own evidence and no record-level reasons -> false", () => {
  const d = baseDecision({
    better_option: { label: "shoot first time", evidence: null },
    reasons: null,
  });
  assert.equal(hasSufficientEvidenceForBetterOption(d), false);
});

// ============================================================
// evaluateDecisionQualityEvidence
// ============================================================

check("insufficient evidence -> quality null, has_sufficient_evidence false", () => {
  const d = baseDecision({ score: 95, reasons: null, source_references: null });
  const result = evaluateDecisionQualityEvidence(d);
  assert.equal(result.has_sufficient_evidence, false);
  assert.equal(result.quality, null);
});

check("sufficient evidence, high score -> good", () => {
  const d = baseDecision({ score: 85, reasons: ["evidenced reasoning"] });
  const result = evaluateDecisionQualityEvidence(d);
  assert.equal(result.has_sufficient_evidence, true);
  assert.equal(result.quality, "good");
});

check("sufficient evidence, mid score -> average", () => {
  const d = baseDecision({ score: 55, reasons: ["evidenced reasoning"] });
  const result = evaluateDecisionQualityEvidence(d);
  assert.equal(result.quality, "average");
});

check("sufficient evidence, low score -> poor", () => {
  const d = baseDecision({ score: 10, reasons: ["evidenced reasoning"] });
  const result = evaluateDecisionQualityEvidence(d);
  assert.equal(result.quality, "poor");
});

check("better_option passed through only when evidenced", () => {
  const evidencedBetter = { label: "shoot first time", evidence: ["cited stat"] };
  const withEvidence = baseDecision({
    score: 40,
    reasons: ["evidenced reasoning"],
    better_option: evidencedBetter,
  });
  assert.deepEqual(evaluateDecisionQualityEvidence(withEvidence).better_option, evidencedBetter);

  const unevidencedBetter = { label: "shoot first time", evidence: null };
  const withoutEvidence = baseDecision({
    score: 40,
    reasons: null,
    source_references: ["frame:x"],
    better_option: unevidencedBetter,
  });
  assert.equal(evaluateDecisionQualityEvidence(withoutEvidence).better_option, null);
});

check("football_type and event_id pass through unchanged", () => {
  const d = baseDecision({ football_type: "real_football", event_id: "event-42", score: 60, reasons: ["r"] });
  const result = evaluateDecisionQualityEvidence(d);
  assert.equal(result.football_type, "real_football");
  assert.equal(result.event_id, "event-42");
});

check("never reads/derives from an outcome field — DecisionQuality has none to read", () => {
  // Structural check: the DecisionQuality shape itself carries no
  // outcome/result/score-from-goals field for this file to have
  // accidentally consulted.
  const d = baseDecision({ score: 100, reasons: ["evidenced"] });
  assert.equal((d as unknown as Record<string, unknown>).outcome, undefined);
  assert.equal((d as unknown as Record<string, unknown>).result, undefined);
});

console.log(`\n${passed} passed`);
