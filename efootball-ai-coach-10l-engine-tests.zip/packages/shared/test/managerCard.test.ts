// Batch 6B-3 — lightweight, framework-free tests for
// validateManagerCardDraft (packages/shared/src/managerCard.ts), the
// semantic validation layer the manager-card-extract Edge Function runs
// every AI response through before returning a draft to the caller.
// Same convention as playerLibrary.test.ts / managerImageUpload.test.ts
// (no jest/vitest in this repo; run via tsx).
//
// Run with:  npx tsx packages/shared/test/managerCard.test.ts
//        or: npm test --workspace=packages/shared
//
// SCOPE NOTE — what this file does and does not cover:
// This batch's spec also asks for tests of storage ownership, wrong-user
// path rejection, path traversal rejection, magic-byte validation, and
// provider routing. The manager-card-extract Edge Function implements
// every one of those using the SAME already-tested, unmodified functions
// player-card-extract relies on:
//   - storage ownership / wrong-user path / path traversal:
//     isPathOwnedByUser (packages/shared/src/uploadValidation.ts) — see
//     packages/shared/test/managerImageUpload.test.ts, which already
//     exercises this exact function with manager-image-shaped paths.
//   - magic-byte validation: sniffKind (supabase/functions/_shared/
//     helpers.ts, Deno-only, duplicated from sniffFileType) — covered by
//     validateUpload's sniffFileType exercises in
//     managerImageUpload.test.ts, since both wrap the identical
//     magic-byte signature table.
//   - provider routing (Gemini primary -> Anthropic fallback, at most
//     one call to each): ProviderRouter (packages/ai/src/
//     providerRouter.ts) is reused completely unchanged — this batch
//     only adds one more delegating method (extractManagerCard) to it,
//     following the exact same runWithFallback() call shape as every
//     other AiProvider method already on that class. No dedicated
//     ProviderRouter unit test exists anywhere in this repo today (there
//     was none for player-card-extract's routing either) — this is a
//     pre-existing test-coverage gap for the router itself, not
//     something introduced by this batch. No live Gemini/Anthropic API
//     calls or live Supabase Storage calls were made for this batch.
//
// What IS new and untested elsewhere is validateManagerCardDraft's own
// field-by-field sanitization logic, which is what this file covers.

import assert from "node:assert/strict";
import { validateManagerCardDraft } from "../src/managerCard.js";

let passed = 0;

function check(name: string, fn: () => void): void {
  try {
    fn();
    passed += 1;
    console.log(`  ok — ${name}`);
  } catch (err) {
    process.exitCode = 1;
    console.error(`  FAIL — ${name}`);
    console.error(err);
  }
}

console.log("validateManagerCardDraft — valid extraction (spec section 6/9)");

check("a fully-populated, valid draft passes through unchanged", () => {
  const raw = {
    name: "Jose Mourinho",
    possession_rating: 85,
    quick_counter_rating: 72,
    long_ball_counter_rating: 60,
    out_wide_rating: 55,
    long_ball_rating: 68,
    extraction_confidence: 91,
    field_evidence: [
      { field: "name", visible: true, confidence: 95, note: "printed under portrait" },
      { field: "possession_rating", visible: true, confidence: 90, note: null },
    ],
  };
  const { valid, sanitized, errors } = validateManagerCardDraft(raw);
  assert.equal(valid, true);
  assert.equal(errors.length, 0);
  assert.equal(sanitized.name, "Jose Mourinho");
  assert.equal(sanitized.possession_rating, 85);
  assert.equal(sanitized.quick_counter_rating, 72);
  assert.equal(sanitized.long_ball_counter_rating, 60);
  assert.equal(sanitized.out_wide_rating, 55);
  assert.equal(sanitized.long_ball_rating, 68);
  assert.equal(sanitized.extraction_confidence, 91);
  assert.equal(sanitized.field_evidence.length, 2);
});

console.log("validateManagerCardDraft — unreadable/missing field -> NULL, never fabricated (spec section 6/7)");

check("a missing rating field is null, not 0 or omitted", () => {
  const raw = { name: "Some Manager", possession_rating: 80 };
  const { sanitized } = validateManagerCardDraft(raw);
  assert.equal(sanitized.quick_counter_rating, null);
  assert.equal(sanitized.long_ball_counter_rating, null);
  assert.equal(sanitized.out_wide_rating, null);
  assert.equal(sanitized.long_ball_rating, null);
});

check("an explicit null rating stays null", () => {
  const raw = { possession_rating: null };
  const { sanitized } = validateManagerCardDraft(raw);
  assert.equal(sanitized.possession_rating, null);
});

check("a missing name is null, not an empty string or a guessed name", () => {
  const { sanitized } = validateManagerCardDraft({});
  assert.equal(sanitized.name, null);
});

check("an unreadable (non-numeric) rating is discarded to null, with an error recorded", () => {
  const raw = { possession_rating: "high" };
  const { sanitized, errors } = validateManagerCardDraft(raw);
  assert.equal(sanitized.possession_rating, null);
  assert.ok(errors.some((e) => e.includes("possession_rating")));
});

console.log("validateManagerCardDraft — valid/errors boundary (QUICK FIX: valid iff errors.length === 0)");

check("a draft with zero discarded fields is valid: true", () => {
  const raw = { name: "Clean Draft", possession_rating: 80 };
  const { valid, errors } = validateManagerCardDraft(raw);
  assert.equal(errors.length, 0);
  assert.equal(valid, true);
});

check("a draft with a legitimately-missing/null field (no error) is still valid: true", () => {
  // Missing fields are never errors on their own — only a present-but-
  // invalid value is. A card that simply doesn't show every rating must
  // not be flagged as an invalid draft.
  const raw = { name: "Partial Card" };
  const { valid, errors } = validateManagerCardDraft(raw);
  assert.equal(errors.length, 0);
  assert.equal(valid, true);
});

check("a single discarded field makes the whole result valid: false, even though sanitized is fully populated", () => {
  const raw = { name: "Some Manager", possession_rating: "high" };
  const { valid, sanitized, errors } = validateManagerCardDraft(raw);
  assert.ok(errors.length > 0);
  assert.equal(valid, false);
  // sanitized is still fully formed — the caller decides whether to
  // reject based on `valid`, not by inspecting `sanitized` itself.
  assert.equal(sanitized.name, "Some Manager");
  assert.equal(sanitized.possession_rating, null);
});

check("an invalid extraction_confidence alone makes the draft valid: false", () => {
  const { valid, errors } = validateManagerCardDraft({ extraction_confidence: "very confident" });
  assert.ok(errors.length > 0);
  assert.equal(valid, false);
});

check("a malformed field_evidence entry alone makes the draft valid: false", () => {
  const raw = { field_evidence: [{ field: 123, visible: true }] };
  const { valid, errors } = validateManagerCardDraft(raw);
  assert.ok(errors.length > 0);
  assert.equal(valid, false);
});

console.log("validateManagerCardDraft — NEVER 0 as a placeholder for unknown data (spec's explicit hard rule)");

check("a missing extraction_confidence is null, never defaulted to 0", () => {
  const { sanitized } = validateManagerCardDraft({ name: "X" });
  assert.equal(sanitized.extraction_confidence, null);
  assert.notEqual(sanitized.extraction_confidence, 0);
});

check("an invalid extraction_confidence is discarded to null, never coerced to 0", () => {
  const { sanitized, errors } = validateManagerCardDraft({ extraction_confidence: "very confident" });
  assert.equal(sanitized.extraction_confidence, null);
  assert.ok(errors.some((e) => e.includes("extraction_confidence")));
});

check("a legitimately-reported confidence of 0 is preserved as 0, not treated as missing", () => {
  // Distinguishes "the model said 0" from "the model said nothing" — both
  // must be representable, and only the latter is null.
  const { sanitized } = validateManagerCardDraft({ extraction_confidence: 0 });
  assert.equal(sanitized.extraction_confidence, 0);
});

check("a rating value of 0 is preserved as 0, never confused with unknown/null", () => {
  const { sanitized } = validateManagerCardDraft({ possession_rating: 0 });
  assert.equal(sanitized.possession_rating, 0);
});

console.log("validateManagerCardDraft — invalid schema / types rejected (spec section 7/9)");

check("a non-object draft is rejected as invalid, with a fully-null sanitized fallback", () => {
  const { valid, sanitized, errors } = validateManagerCardDraft("not an object");
  assert.equal(valid, false);
  assert.ok(errors.length > 0);
  assert.equal(sanitized.name, null);
  assert.equal(sanitized.possession_rating, null);
  assert.equal(sanitized.extraction_confidence, null);
  assert.deepEqual(sanitized.field_evidence, []);
});

check("null input is rejected as invalid", () => {
  const { valid } = validateManagerCardDraft(null);
  assert.equal(valid, false);
});

check("an array is rejected as invalid (not a draft object)", () => {
  const { valid } = validateManagerCardDraft([1, 2, 3]);
  assert.equal(valid, false);
});

check("a negative rating is rejected to null (ratings are non-negative only)", () => {
  const { sanitized, errors } = validateManagerCardDraft({ long_ball_rating: -5 });
  assert.equal(sanitized.long_ball_rating, null);
  assert.ok(errors.some((e) => e.includes("long_ball_rating")));
});

check("a non-integer rating is rejected to null", () => {
  const { sanitized } = validateManagerCardDraft({ out_wide_rating: 72.5 });
  assert.equal(sanitized.out_wide_rating, null);
});

check("a malformed field_evidence array entry is dropped, not the whole array", () => {
  const raw = {
    field_evidence: [
      { field: "name", visible: true, confidence: 80 },
      { field: 123, visible: true }, // invalid "field" — dropped
      "not an object", // dropped
    ],
  };
  const { sanitized, errors } = validateManagerCardDraft(raw);
  assert.equal(sanitized.field_evidence.length, 1);
  assert.equal(sanitized.field_evidence[0].field, "name");
  assert.ok(errors.length >= 2);
});

console.log("validateManagerCardDraft — confidence validation (spec section 9)");

check("field_evidence confidence out of 0-100 range is discarded to null", () => {
  const raw = { field_evidence: [{ field: "name", visible: true, confidence: 150 }] };
  const { sanitized } = validateManagerCardDraft(raw);
  assert.equal(sanitized.field_evidence[0].confidence, null);
});

check("extraction_confidence out of 0-100 range is discarded to null", () => {
  const { sanitized } = validateManagerCardDraft({ extraction_confidence: 250 });
  assert.equal(sanitized.extraction_confidence, null);
});

console.log(`\n${passed} checks passed`);
