// Batch 8A — lightweight, framework-free tests for teamFormations.ts's
// pure validation helpers. Same convention as teamLibrary.test.ts/
// teamMembers.test.ts — no test runner/framework, uses Node's built-in
// `assert` module, runs via `tsx`.
//
// Run with:  npx tsx packages/shared/test/teamFormations.test.ts
//        or: npm test --workspace=packages/shared
//
// SCOPE NOTE: these are pure, in-process unit tests of validation/
// duplicate-detection logic only — nothing here talks to a real
// Supabase/Postgres instance. The actual authorization boundary
// (team_id -> team_library.user_id ownership, the RLS policies
// themselves, the name-uniqueness constraint) lives entirely in
// migration 0021_team_formations.sql, reviewed by hand, not exercised
// by a live integration test here. No live Supabase/RLS verification
// was performed for this batch.

import assert from "node:assert/strict";
import {
  validateTeamFormationInput,
  validateTeamFormationFields,
  validatePositions,
  normalizePositions,
  isDuplicateTeamFormationName,
  TEAM_FORMATION_NAME_UNIQUE_CONSTRAINT,
} from "../src/teamFormations.js";

let passed = 0;

function check(name: string, fn: () => void): void {
  try {
    fn();
    passed += 1;
    console.log(`  ok — ${name}`);
  } catch (err) {
    process.exitCode = 1;
    console.error(`  FAIL — ${name}`);
    console.error(err);
  }
}

const VALID_TEAM_ID = "11111111-1111-1111-1111-111111111111";

console.log("validateTeamFormationInput — a valid formation shape");

check("a well-formed formation (array positions) is valid", () => {
  const { valid, sanitized, errors } = validateTeamFormationInput({
    team_id: VALID_TEAM_ID,
    name: "Balanced 4-3-3",
    formation_code: "4-3-3",
    positions: [
      { id: "gk", role: "GK", x: 0.05, y: 0.5 },
      { id: "cb1", role: "CB", x: 0.3, y: 0.35 },
    ],
    tactical_instructions: null,
  });
  assert.equal(valid, true);
  assert.equal(sanitized.name, "Balanced 4-3-3");
  assert.equal(sanitized.formation_code, "4-3-3");
  assert.deepEqual(errors, []);
});

check("a well-formed formation (role-keyed object positions) is valid", () => {
  const { valid, errors } = validateTeamFormationInput({
    team_id: VALID_TEAM_ID,
    name: "Custom shape",
    formation_code: "4-4-2",
    positions: { GK: { x: 0.5, y: 0.92 }, CB1: { x: 0.38, y: 0.72 } },
    tactical_instructions: null,
  });
  assert.equal(valid, true);
  assert.deepEqual(errors, []);
});

check("name and formation_code are trimmed", () => {
  const { sanitized } = validateTeamFormationInput({
    team_id: VALID_TEAM_ID,
    name: "  My Formation  ",
    formation_code: "  4-3-3  ",
    positions: [{ id: "gk" }],
  });
  assert.equal(sanitized.name, "My Formation");
  assert.equal(sanitized.formation_code, "4-3-3");
});

console.log("validateTeamFormationInput — required name / formation_code / positions");

check("an empty name is rejected", () => {
  const { valid, errors } = validateTeamFormationInput({
    team_id: VALID_TEAM_ID,
    name: "",
    formation_code: "4-3-3",
    positions: [{ id: "gk" }],
  });
  assert.equal(valid, false);
  assert.ok(errors.some((e) => e.startsWith("name:")));
});

check("a whitespace-only name is rejected", () => {
  const { valid, errors } = validateTeamFormationInput({
    team_id: VALID_TEAM_ID,
    name: "   ",
    formation_code: "4-3-3",
    positions: [{ id: "gk" }],
  });
  assert.equal(valid, false);
  assert.ok(errors.some((e) => e.startsWith("name:")));
});

check("an empty formation_code is rejected", () => {
  const { valid, errors } = validateTeamFormationInput({
    team_id: VALID_TEAM_ID,
    name: "My Formation",
    formation_code: "",
    positions: [{ id: "gk" }],
  });
  assert.equal(valid, false);
  assert.ok(errors.some((e) => e.startsWith("formation_code:")));
});

check("a whitespace-only formation_code is rejected", () => {
  const { valid, errors } = validateTeamFormationInput({
    team_id: VALID_TEAM_ID,
    name: "My Formation",
    formation_code: "   ",
    positions: [{ id: "gk" }],
  });
  assert.equal(valid, false);
  assert.ok(errors.some((e) => e.startsWith("formation_code:")));
});

check("a missing positions value is rejected, never silently defaulted to a fake layout", () => {
  const { valid, errors } = validateTeamFormationInput({
    team_id: VALID_TEAM_ID,
    name: "My Formation",
    formation_code: "4-3-3",
  });
  assert.equal(valid, false);
  assert.ok(errors.some((e) => e.includes("positions")));
});

check("a null positions value is rejected", () => {
  const { valid, errors } = validateTeamFormationInput({
    team_id: VALID_TEAM_ID,
    name: "My Formation",
    formation_code: "4-3-3",
    positions: null,
  });
  assert.equal(valid, false);
  assert.ok(errors.some((e) => e.includes("positions")));
});

console.log("validateTeamFormationInput — team_id");

check("a non-uuid team_id is rejected", () => {
  const { valid, errors } = validateTeamFormationInput({
    team_id: "not-a-uuid",
    name: "My Formation",
    formation_code: "4-3-3",
    positions: [{ id: "gk" }],
  });
  assert.equal(valid, false);
  assert.ok(errors.some((e) => e.startsWith("team_id:")));
});

check("a missing team_id is rejected", () => {
  const { valid, errors } = validateTeamFormationInput({
    name: "My Formation",
    formation_code: "4-3-3",
    positions: [{ id: "gk" }],
  });
  assert.equal(valid, false);
  assert.ok(errors.some((e) => e.startsWith("team_id:")));
});

console.log("validateTeamFormationInput — tactical_instructions stays nullable/generic");

check("a null tactical_instructions is valid", () => {
  const { valid, sanitized } = validateTeamFormationInput({
    team_id: VALID_TEAM_ID,
    name: "My Formation",
    formation_code: "4-3-3",
    positions: [{ id: "gk" }],
    tactical_instructions: null,
  });
  assert.equal(valid, true);
  assert.equal(sanitized.tactical_instructions, null);
});

check("an omitted tactical_instructions defaults to null and stays valid", () => {
  const { valid, sanitized } = validateTeamFormationInput({
    team_id: VALID_TEAM_ID,
    name: "My Formation",
    formation_code: "4-3-3",
    positions: [{ id: "gk" }],
  });
  assert.equal(valid, true);
  assert.equal(sanitized.tactical_instructions, null);
});

check("an arbitrary generic object tactical_instructions is accepted as-is (no eFootball-specific shape enforced)", () => {
  const { valid, sanitized } = validateTeamFormationInput({
    team_id: VALID_TEAM_ID,
    name: "My Formation",
    formation_code: "4-3-3",
    positions: [{ id: "gk" }],
    tactical_instructions: { anything: "goes", nested: { ok: true } },
  });
  assert.equal(valid, true);
  assert.deepEqual(sanitized.tactical_instructions, { anything: "goes", nested: { ok: true } });
});

check("an array tactical_instructions is rejected, not silently accepted", () => {
  const { valid, sanitized, errors } = validateTeamFormationInput({
    team_id: VALID_TEAM_ID,
    name: "My Formation",
    formation_code: "4-3-3",
    positions: [{ id: "gk" }],
    tactical_instructions: [1, 2, 3],
  });
  assert.equal(valid, false);
  assert.equal(sanitized.tactical_instructions, null);
  assert.ok(errors.some((e) => e.startsWith("tactical_instructions:")));
});

console.log("validatePositions — no player IDs required or allowed by this batch's model");

check("a position with only an id (no role/coordinates) is valid — nothing else is required", () => {
  const { valid, errors } = validatePositions([{ id: "gk" }]);
  assert.equal(valid, true);
  assert.deepEqual(errors, []);
});

check("a position entry missing id is rejected", () => {
  const { valid, errors } = validatePositions([{ role: "GK" }]);
  assert.equal(valid, false);
  assert.ok(errors.some((e) => e.includes("id")));
});

check("a position entry carrying a player_id is rejected — player assignment is not this batch's job", () => {
  const { valid, errors } = validatePositions([{ id: "gk", player_id: "22222222-2222-2222-2222-222222222222" }]);
  assert.equal(valid, false);
  assert.ok(errors.some((e) => e.includes("player_id")));
});

check("a role-keyed position carrying a player_name is rejected", () => {
  const { valid, errors } = validatePositions({ GK: { x: 0.5, y: 0.9, player_name: "Someone" } });
  assert.equal(valid, false);
  assert.ok(errors.some((e) => e.includes("player_name")));
});

check("an out-of-range x coordinate is rejected, not silently clamped", () => {
  const { valid, errors } = validatePositions([{ id: "gk", x: 1.5, y: 0.5 }]);
  assert.equal(valid, false);
  assert.ok(errors.some((e) => e.includes("x must be")));
});

check("a non-numeric y coordinate is rejected", () => {
  const { valid, errors } = validatePositions([{ id: "gk", y: "middle" }]);
  assert.equal(valid, false);
  assert.ok(errors.some((e) => e.includes("y must be")));
});

check("a bare string positions value is rejected outright", () => {
  const { valid, errors } = validatePositions("4-3-3");
  assert.equal(valid, false);
  assert.ok(errors.length > 0);
});

check("a bare number positions value is rejected outright", () => {
  const { valid, errors } = validatePositions(42);
  assert.equal(valid, false);
  assert.ok(errors.length > 0);
});

console.log("duplicate formation-name handling");

check("isDuplicateTeamFormationName recognizes the team_formations constraint by name", () => {
  const pgError = {
    code: "23505",
    message: `duplicate key value violates unique constraint "${TEAM_FORMATION_NAME_UNIQUE_CONSTRAINT}"`,
  };
  assert.equal(isDuplicateTeamFormationName(pgError), true);
});

check("isDuplicateTeamFormationName does not misattribute an unrelated unique violation", () => {
  const pgError = { code: "23505", message: 'duplicate key value violates unique constraint "some_other_constraint"' };
  assert.equal(isDuplicateTeamFormationName(pgError), false);
});

check("isDuplicateTeamFormationName rejects a non-23505 error even with a matching message", () => {
  assert.equal(
    isDuplicateTeamFormationName({ code: "23502", message: `violates "${TEAM_FORMATION_NAME_UNIQUE_CONSTRAINT}"` }),
    false
  );
});

console.log("");
console.log("validateTeamFormationFields — same field checks, no team_id required (Batch 8C, for updates)");

check("valid fields with no team_id present are accepted", () => {
  const { valid, sanitized, errors } = validateTeamFormationFields({
    name: "Balanced 4-3-3",
    formation_code: "4-3-3",
    positions: [{ id: "gk", role: "GK", x: 0.05, y: 0.5 }],
    tactical_instructions: null,
  });
  assert.equal(valid, true);
  assert.equal(sanitized.name, "Balanced 4-3-3");
  assert.deepEqual(errors, []);
});

check("an invalid positions value is still rejected with no team_id involved", () => {
  const { valid, errors } = validateTeamFormationFields({
    name: "X",
    formation_code: "4-3-3",
    positions: "not an object",
    tactical_instructions: null,
  });
  assert.equal(valid, false);
  assert.ok(errors.some((e) => e.includes("positions")));
});

check("validateTeamFormationInput still requires team_id and delegates the rest to validateTeamFormationFields", () => {
  const { valid, errors } = validateTeamFormationInput({
    name: "",
    formation_code: "4-3-3",
    positions: [{ id: "gk" }],
    tactical_instructions: null,
  });
  assert.equal(valid, false);
  assert.ok(errors.some((e) => e.startsWith("team_id")));
  assert.ok(errors.some((e) => e.startsWith("name")));
});

console.log("");
console.log("normalizePositions — flattening either stored shape for rendering (Batch 8C)");

check("array-shaped positions normalize in order, with role/x/y passed through", () => {
  const result = normalizePositions([
    { id: "gk", role: "GK", x: 0.5, y: 0.92 },
    { id: "cb1", role: "CB", x: 0.35, y: 0.78 },
  ]);
  assert.deepEqual(result, [
    { id: "gk", role: "GK", x: 0.5, y: 0.92 },
    { id: "cb1", role: "CB", x: 0.35, y: 0.78 },
  ]);
});

check("role-keyed object positions normalize using the key as the slot id", () => {
  const result = normalizePositions({ GK: { x: 0.5, y: 0.92 }, CB: { x: 0.35, y: 0.78 } });
  assert.deepEqual(result, [
    { id: "GK", role: null, x: 0.5, y: 0.92 },
    { id: "CB", role: null, x: 0.35, y: 0.78 },
  ]);
});

check("an entry with only an id has null role/x/y — nothing is coerced to a fake 0", () => {
  const result = normalizePositions([{ id: "st" }]);
  assert.deepEqual(result, [{ id: "st", role: null, x: null, y: null }]);
});

check("a malformed entry (no id, in an array) is skipped rather than thrown", () => {
  const result = normalizePositions([{ role: "GK" }, { id: "st", role: "ST" }]);
  assert.deepEqual(result, [{ id: "st", role: "ST", x: null, y: null }]);
});

check("a non-object/array positions value normalizes to an empty list rather than throwing", () => {
  assert.deepEqual(normalizePositions("nonsense" as unknown as Parameters<typeof normalizePositions>[0]), []);
});

console.log("");
if (process.exitCode === 1) {
  console.error(`${passed} check(s) passed, at least one FAILED.`);
} else {
  console.log(`All ${passed} checks passed.`);
}
