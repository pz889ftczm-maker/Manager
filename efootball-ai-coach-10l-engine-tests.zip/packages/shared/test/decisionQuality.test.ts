// Batch 10G-1 — lightweight, framework-free tests for
// decisionQuality.ts's shared decision-quality model. Same convention
// as footballEvent.test.ts/tacticalPosition.test.ts — no test runner/
// framework, Node's built-in `assert`, run via `tsx`.
//
// Run with:  npx tsx packages/shared/test/decisionQuality.test.ts
//        or: npm test --workspace=packages/shared
//
// SCOPE NOTE: pure, in-process tests of the shared schema/builders/
// validation only — no database, no RLS, no worker integration, no AI
// calls (10G-1 makes none).

import assert from "node:assert/strict";
import {
  buildDecisionQualityFromUnifiedEvent,
  withOptions,
  validateDecisionQualityInput,
  type DecisionQuality,
  type DecisionQualityValidationInput,
} from "../src/decisionQuality.js";
import type { UnifiedFootballEvent } from "../src/footballEvent.js";

let passed = 0;

function check(name: string, fn: () => void): void {
  try {
    fn();
    passed += 1;
    console.log(`  ok — ${name}`);
  } catch (err) {
    process.exitCode = 1;
    console.error(`  FAIL — ${name}`);
    console.error(err);
  }
}

function baseUnifiedEvent(overrides: Partial<UnifiedFootballEvent> = {}): UnifiedFootballEvent {
  return {
    id: "event-1",
    match_id: "match-1",
    football_type: "efootball",
    timestamp_seconds: 120.5,
    event_type: "pass",
    legacy_event_type: "bad_pass",
    legacy_category: "passing",
    severity: "mistake",
    confidence: 80,
    confidence_level: "likely",
    decision_score: 20,
    description: "Played a risky central pass into a double press.",
    better_option: null,
    reasoning: null,
    player_id: null,
    evidence: null,
    before_frame_url: null,
    decision_frame_url: null,
    after_frame_url: null,
    context_start_seconds: 118,
    context_end_seconds: 123,
    created_at: "2026-01-01T00:00:00Z",
    ...overrides,
  };
}

function baseDraft(overrides: DecisionQualityValidationInput = {}): DecisionQualityValidationInput {
  return {
    event_id: "event-1",
    match_id: "match-1",
    timestamp_seconds: 120.5,
    action: "Played a risky central pass into a double press.",
    score: 20,
    confidence: 80,
    ...overrides,
  };
}

// ============================================================
// buildDecisionQualityFromUnifiedEvent
// ============================================================

console.log("buildDecisionQualityFromUnifiedEvent — reuse, no fabrication");

check("carries event_id/match_id/football_type/timestamp/score/confidence straight from the event", () => {
  const dq = buildDecisionQualityFromUnifiedEvent(baseUnifiedEvent());
  assert.equal(dq.event_id, "event-1");
  assert.equal(dq.match_id, "match-1");
  assert.equal(dq.football_type, "efootball");
  assert.equal(dq.timestamp_seconds, 120.5);
  assert.equal(dq.score, 20);
  assert.equal(dq.confidence, 80);
  assert.equal(dq.action, "Played a risky central pass into a double press.");
});

check("available_options and chosen_option are always null — no existing evidence source", () => {
  const dq = buildDecisionQualityFromUnifiedEvent(baseUnifiedEvent());
  assert.equal(dq.available_options, null);
  assert.equal(dq.chosen_option, null);
});

check("better_option stays null when the underlying event has none", () => {
  const dq = buildDecisionQualityFromUnifiedEvent(baseUnifiedEvent({ better_option: null }));
  assert.equal(dq.better_option, null);
});

check("better_option is populated only when the event already carries evidence for it", () => {
  const dq = buildDecisionQualityFromUnifiedEvent(
    baseUnifiedEvent({
      better_option: "Switch play to the weak side instead.",
      reasoning: "The right flank was already overloaded with two defenders.",
    })
  );
  assert.ok(dq.better_option);
  assert.equal(dq.better_option!.label, "Switch play to the weak side instead.");
  assert.deepEqual(dq.better_option!.evidence, ["The right flank was already overloaded with two defenders."]);
  assert.deepEqual(dq.reasons, ["The right flank was already overloaded with two defenders."]);
});

check("player reference is null when the event has no player_id, populated when it does", () => {
  const withoutPlayer = buildDecisionQualityFromUnifiedEvent(baseUnifiedEvent({ player_id: null }));
  assert.equal(withoutPlayer.player, null);

  const withPlayer = buildDecisionQualityFromUnifiedEvent(baseUnifiedEvent({ player_id: "player-9" }));
  assert.deepEqual(withPlayer.player, { player_id: "player-9", name: null });
});

check("source_references mirrors the event's own evidence array, null when empty/absent", () => {
  const withEvidence = buildDecisionQualityFromUnifiedEvent(
    baseUnifiedEvent({ evidence: ["passing_accuracy: 62%"] })
  );
  assert.deepEqual(withEvidence.source_references, ["passing_accuracy: 62%"]);

  const withoutEvidence = buildDecisionQualityFromUnifiedEvent(baseUnifiedEvent({ evidence: [] }));
  assert.equal(withoutEvidence.source_references, null);

  const nullEvidence = buildDecisionQualityFromUnifiedEvent(baseUnifiedEvent({ evidence: null }));
  assert.equal(nullEvidence.source_references, null);
});

check("null football context and null timestamp/description stay null, never fabricated", () => {
  const dq = buildDecisionQualityFromUnifiedEvent(
    baseUnifiedEvent({ football_type: null, timestamp_seconds: null, description: "" })
  );
  assert.equal(dq.football_type, null);
  assert.equal(dq.timestamp_seconds, null);
  assert.equal(dq.action, null);
});

// ============================================================
// withOptions
// ============================================================

console.log("\nwithOptions — explicit, caller-only attachment");

check("attaches available_options/chosen_option without touching other fields", () => {
  const base = buildDecisionQualityFromUnifiedEvent(baseUnifiedEvent());
  const withOpts = withOptions(base, {
    available_options: [
      { label: "Pass to right winger", evidence: ["Right winger was unmarked"] },
      { label: "Shoot first time", evidence: null },
    ],
    chosen_option: { label: "Pass to right winger", evidence: ["Right winger was unmarked"] },
  });
  assert.equal(withOpts.available_options?.length, 2);
  assert.equal(withOpts.chosen_option?.label, "Pass to right winger");
  // Untouched fields still match the base record.
  assert.equal(withOpts.event_id, base.event_id);
  assert.equal(withOpts.score, base.score);
});

check("omitted keys leave existing values untouched; explicit null clears them", () => {
  const base: DecisionQuality = {
    ...buildDecisionQualityFromUnifiedEvent(baseUnifiedEvent()),
    available_options: [{ label: "Pass short", evidence: null }],
  };
  const untouched = withOptions(base, {});
  assert.deepEqual(untouched.available_options, [{ label: "Pass short", evidence: null }]);

  const cleared = withOptions(base, { available_options: null });
  assert.equal(cleared.available_options, null);
});

// ============================================================
// validateDecisionQualityInput
// ============================================================

console.log("\nvalidateDecisionQualityInput — write-path gate");

check("accepts a minimal, well-formed draft", () => {
  const result = validateDecisionQualityInput(baseDraft());
  assert.equal(result.valid, true);
  assert.deepEqual(result.errors, []);
});

check("requires a non-empty event_id", () => {
  const missing = validateDecisionQualityInput(baseDraft({ event_id: undefined }));
  assert.equal(missing.valid, false);
  assert.ok(missing.errors.some((e) => e.includes("event_id")));

  const empty = validateDecisionQualityInput(baseDraft({ event_id: "   " }));
  assert.equal(empty.valid, false);
});

check("rejects football_type supplied directly on the record", () => {
  const result = validateDecisionQualityInput(baseDraft({ football_type: "efootball" }));
  assert.equal(result.valid, false);
  assert.ok(result.errors.some((e) => e.includes("football_type")));
});

check("rejects a malformed timestamp_seconds", () => {
  assert.equal(validateDecisionQualityInput(baseDraft({ timestamp_seconds: -5 })).valid, false);
  assert.equal(validateDecisionQualityInput(baseDraft({ timestamp_seconds: "later" })).valid, false);
  assert.equal(validateDecisionQualityInput(baseDraft({ timestamp_seconds: null })).valid, true);
});

check("score and confidence are validated independently, both must be 0-100 integers", () => {
  assert.equal(validateDecisionQualityInput(baseDraft({ score: 101 })).valid, false);
  assert.equal(validateDecisionQualityInput(baseDraft({ score: -1 })).valid, false);
  assert.equal(validateDecisionQualityInput(baseDraft({ score: 50.5 })).valid, false);
  assert.equal(validateDecisionQualityInput(baseDraft({ confidence: 200 })).valid, false);
  // An out-of-range score does not affect an in-range confidence, and
  // vice versa — each field's own error is independent.
  const badScoreOnly = validateDecisionQualityInput(baseDraft({ score: 999, confidence: 50 }));
  assert.equal(badScoreOnly.valid, false);
  assert.ok(badScoreOnly.errors.some((e) => e.includes("score")));
  assert.ok(!badScoreOnly.errors.some((e) => e.includes("confidence")));
});

check("score/confidence may independently be null — unknown stays unknown", () => {
  const result = validateDecisionQualityInput(baseDraft({ score: null, confidence: null }));
  assert.equal(result.valid, true);
});

check("validates available_options/chosen_option shape", () => {
  assert.equal(
    validateDecisionQualityInput(baseDraft({ available_options: [{ label: "", evidence: null }] })).valid,
    false
  );
  assert.equal(
    validateDecisionQualityInput(baseDraft({ available_options: [{ label: "Pass short" }] })).valid,
    true
  );
  assert.equal(
    validateDecisionQualityInput(baseDraft({ chosen_option: { label: "Pass short", evidence: [1, 2] } })).valid,
    false
  );
  assert.equal(validateDecisionQualityInput(baseDraft({ available_options: null })).valid, true);
});

check("rejects better_option without any supporting evidence", () => {
  const result = validateDecisionQualityInput(
    baseDraft({ better_option: { label: "Switch play instead", evidence: null } })
  );
  assert.equal(result.valid, false);
  assert.ok(result.errors.some((e) => e.includes("better_option cannot be set")));
});

check("accepts better_option when it carries its own evidence", () => {
  const result = validateDecisionQualityInput(
    baseDraft({
      better_option: { label: "Switch play instead", evidence: ["Weak side was completely open"] },
    })
  );
  assert.equal(result.valid, true);
});

check("accepts better_option when record-level reasons supply the evidence", () => {
  const result = validateDecisionQualityInput(
    baseDraft({
      better_option: { label: "Switch play instead", evidence: null },
      reasons: ["Weak side was completely open"],
    })
  );
  assert.equal(result.valid, true);
});

check("better_option may be null — nullability is preserved, never required", () => {
  const result = validateDecisionQualityInput(baseDraft({ better_option: null }));
  assert.equal(result.valid, true);
});

check("reasons/source_references must be non-empty arrays of non-empty strings, or null", () => {
  assert.equal(validateDecisionQualityInput(baseDraft({ reasons: [] })).valid, false);
  assert.equal(validateDecisionQualityInput(baseDraft({ reasons: [""] })).valid, false);
  assert.equal(validateDecisionQualityInput(baseDraft({ reasons: ["Valid reason"] })).valid, true);
  assert.equal(validateDecisionQualityInput(baseDraft({ reasons: null })).valid, true);
  assert.equal(validateDecisionQualityInput(baseDraft({ source_references: [42] })).valid, false);
});

console.log("\nvalidateDecisionQualityInput — ownership/integrity");

const OWNERSHIP = { matchId: "match-1", userId: "user-1", player: { id: "player-1", user_id: "user-1" } };

check("rejects a match_id that does not match the resolved ownership context", () => {
  const result = validateDecisionQualityInput(baseDraft({ match_id: "match-2" }), { ownership: OWNERSHIP });
  assert.equal(result.valid, false);
  assert.ok(result.errors.some((e) => e.includes("cross-match")));
});

check("accepts a match_id that matches the resolved ownership context", () => {
  const result = validateDecisionQualityInput(baseDraft({ match_id: "match-1" }), { ownership: OWNERSHIP });
  assert.equal(result.valid, true);
});

check("rejects a resolved player belonging to a different user", () => {
  const result = validateDecisionQualityInput(baseDraft(), {
    ownership: { matchId: "match-1", userId: "user-1", player: { id: "player-1", user_id: "someone-else" } },
  });
  assert.equal(result.valid, false);
  assert.ok(result.errors.some((e) => e.includes("cross-user")));
});

check("rejects a player reference that does not match the resolved player", () => {
  const result = validateDecisionQualityInput(baseDraft({ player: { player_id: "player-99" } }), {
    ownership: OWNERSHIP,
  });
  assert.equal(result.valid, false);
  assert.ok(result.errors.some((e) => e.includes("does not match the resolved player")));
});

check("rejects a player reference when no player was resolved/owned for this request", () => {
  const result = validateDecisionQualityInput(baseDraft({ player: { player_id: "player-1" } }), {
    ownership: { matchId: "match-1", userId: "user-1", player: null },
  });
  assert.equal(result.valid, false);
  assert.ok(result.errors.some((e) => e.includes("no player was resolved")));
});

check("accepts a player reference that matches the resolved player", () => {
  const result = validateDecisionQualityInput(baseDraft({ player: { player_id: "player-1" } }), {
    ownership: OWNERSHIP,
  });
  assert.equal(result.valid, true);
});

check("no ownership context supplied — match_id/player are not cross-checked", () => {
  const result = validateDecisionQualityInput(baseDraft({ match_id: "any-match", player: { player_id: "any-player" } }));
  assert.equal(result.valid, true);
});

console.log(`\n${passed} decisionQuality.ts check(s) passed.`);
