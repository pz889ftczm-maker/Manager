import { useEffect, useState } from "react";
import { getTeamImageSignedUrl } from "../lib/teamImageStorage";
import { isPathOwnedByUser } from "@efootball/shared";

// Batch 7E — shared signed-image loader for a team's saved logo/image,
// mirroring ManagerImage.tsx's/PlayerCardSlot.tsx's pattern applied to
// the private `team-images` bucket (0017_team_images_storage.sql)
// instead of `manager-images`/`player-cards`. Used by both the Team
// Library list's card thumbnails and the Team Detail header, so the
// ownership-check + signed-URL fetch logic lives in exactly one place.
//
// Ownership is checked here first via isPathOwnedByUser
// (uploadValidation.ts) so a signed URL is never even requested for a
// team image path that isn't this user's own — defense-in-depth on top
// of Storage RLS (0017), which is the actual gate. Renders a clean
// fallback (never a generated/fake image) when there's no image, the
// image isn't owned, or loading it fails — never displays "0"/a
// fabricated placeholder logo for a team with no image (spec section 7).

type ImageStatus = "idle" | "loading" | "loaded" | "error";

export function TeamImage({
  imagePath,
  userId,
  className,
  fallback,
}: {
  imagePath: string | null;
  userId: string;
  /** Applied to both the <img> and the fallback placeholder, so callers
   * control size/shape from one prop. */
  className: string;
  /** Text shown in the fallback box when there's no image, it isn't
   * owned by this user, or it fails to load. */
  fallback: string;
}) {
  const [status, setStatus] = useState<ImageStatus>("idle");
  const [signedUrl, setSignedUrl] = useState<string | null>(null);
  // Bumped to force exactly one fresh signed-url fetch when the <img>
  // itself fails to load (an expired signed URL must not permanently
  // break the thumbnail — retry once, then fall back cleanly).
  const [retryToken, setRetryToken] = useState(0);

  useEffect(() => {
    let cancelled = false;
    setSignedUrl(null);

    if (!imagePath) {
      setStatus("idle"); // no image on this team — clean fallback, not an error
      return;
    }
    if (!isPathOwnedByUser(imagePath, userId)) {
      setStatus("error");
      return;
    }

    setStatus("loading");
    getTeamImageSignedUrl(imagePath)
      .then((url) => {
        if (cancelled) return;
        setSignedUrl(url);
        setStatus("loaded");
      })
      .catch(() => {
        if (!cancelled) setStatus("error");
      });

    return () => {
      cancelled = true;
    };
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [imagePath, userId, retryToken]);

  function handleImageError() {
    if (retryToken < 1) {
      setRetryToken((t) => t + 1);
    } else {
      setStatus("error");
    }
  }

  if (status === "loaded" && signedUrl) {
    return <img src={signedUrl} alt="" onError={handleImageError} className={className} />;
  }

  return (
    <span
      className={`${className} flex items-center justify-center border border-pitch-700 bg-pitch-900 text-center text-[10px] leading-tight text-slate-500`}
    >
      {status === "loading" ? "…" : fallback}
    </span>
  );
}
