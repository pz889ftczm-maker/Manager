import type { PlayerLibrary } from "@efootball/shared";

// Batch 6A-5 — lists the caller's already-loaded Player Library entries
// (fetched via the existing listPlayerLibrary() wrapper in
// apps/web/src/lib/playerLibrary.ts — no duplicate query logic added,
// per spec section 8) so one can be assigned to a formation slot. Picking
// a player already used elsewhere in the formation is allowed; the
// caller (Formation.tsx) moves them rather than duplicating them into
// two slots, since a real formation only fields a player once.

export function PlayerPickerModal({
  players,
  assignedIds,
  onPick,
  onClose,
}: {
  players: PlayerLibrary[];
  assignedIds: Set<string>;
  onPick: (entry: PlayerLibrary) => void;
  onClose: () => void;
}) {
  return (
    <div
      className="fixed inset-0 z-20 flex items-end justify-center bg-black/60 sm:items-center"
      onClick={onClose}
    >
      <div
        className="max-h-[70vh] w-full max-w-sm overflow-y-auto rounded-t-lg border border-pitch-700 bg-pitch-900 p-4 sm:rounded-lg"
        onClick={(e) => e.stopPropagation()}
      >
        <div className="mb-3 flex items-center justify-between">
          <h2 className="text-sm font-semibold text-slate-100">Choose a player</h2>
          <button
            type="button"
            onClick={onClose}
            aria-label="Close"
            className="text-slate-400 hover:text-slate-200"
          >
            ×
          </button>
        </div>

        <ul className="space-y-1">
          {players.map((p) => (
            <li key={p.id}>
              <button
                type="button"
                onClick={() => onPick(p)}
                className="flex w-full items-center justify-between gap-2 rounded-md border border-pitch-700 bg-pitch-800 px-3 py-2 text-left text-sm text-slate-100 hover:border-accent"
              >
                <span className="truncate">
                  {p.name ?? "Unnamed player"}
                  {assignedIds.has(p.id) && (
                    <span className="ml-2 text-[10px] text-slate-500">(already in formation)</span>
                  )}
                </span>
                <span className="shrink-0 text-xs text-slate-400">
                  {[p.position ?? "Position unknown", p.overall != null ? `OVR ${p.overall}` : null]
                    .filter(Boolean)
                    .join(" · ")}
                </span>
              </button>
            </li>
          ))}
        </ul>
      </div>
    </div>
  );
}
