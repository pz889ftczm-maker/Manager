import { useEffect, useState } from "react";
import { getPlayerCardSignedUrl } from "../lib/playerCardStorage";
import { getFormationCardDisplay, isFormationCardImageOwned, type FormationPlayerRef } from "@efootball/shared";

// Batch 6A-5 — a single formation slot. Renders the player's REAL saved
// player-card image via a short-lived signed URL when one exists and is
// verifiably owned by the current user (spec sections 3/6); otherwise a
// clean placeholder — never a generated/fake image (spec section 3/11).
//
// Signed URLs are minted client-side via the existing
// getPlayerCardSignedUrl() (playerCardStorage.ts, Batch 6A-2) — same
// private `player-cards` bucket, same short-lived (1hr) expiry, no new
// storage code path. Ownership is checked here first via
// isFormationCardImageOwned (packages/shared/src/formation.ts, which
// itself reuses isPathOwnedByUser) so a signed URL is never even
// requested for a path that isn't this user's own (spec section 6) —
// defense-in-depth on top of Storage RLS, which is the actual gate.

type ImageStatus = "idle" | "loading" | "loaded" | "error";

export function PlayerCardSlot({
  slotLabel,
  player,
  userId,
  onAssign,
  onClear,
  unavailable = false,
}: {
  /** Position code shown in an empty slot, e.g. "GK", "CB". */
  slotLabel: string;
  player: FormationPlayerRef | null;
  userId: string;
  onAssign: () => void;
  onClear: () => void;
  /**
   * Batch 8C — true when this slot HAS a persisted
   * team_formation_players assignment, but the player_library row it
   * points at couldn't be found in the caller's currently-loaded
   * roster (e.g. the two loads raced, or a since-changed ownership
   * state hid it under RLS). This is intentionally distinct from an
   * empty slot (`player: null` with `unavailable: false`, which is the
   * normal "nothing assigned yet" case): here there IS an assignment,
   * so `onClear` still removes it, but nothing about the player
   * (name/position/image) can be rendered. In the common case this
   * shouldn't happen at all — deleting a player_library row cascades
   * to delete its assignment row too (migration 0022's
   * `on delete cascade`) — so this is a defensive/transient state, not
   * something the data model produces on purpose. When true, `player`
   * is expected to be null; this component never tries to partially
   * render a player it was told is unavailable.
   */
  unavailable?: boolean;
}) {
  const display = getFormationCardDisplay(player);
  const [status, setStatus] = useState<ImageStatus>("idle");
  const [signedUrl, setSignedUrl] = useState<string | null>(null);
  // Bumped to force exactly one fresh signed-url fetch when the <img>
  // itself fails to load (spec section 7: an expired signed URL or a
  // deleted/missing object must not break the whole formation — retry
  // once with a freshly minted URL, then fall back cleanly).
  const [retryToken, setRetryToken] = useState(0);

  useEffect(() => {
    let cancelled = false;
    setSignedUrl(null);

    if (!player?.player_card_image_path) {
      setStatus("idle"); // no image on this player — clean fallback, not an error
      return;
    }
    if (!isFormationCardImageOwned(player, userId)) {
      // Treated the same as any other unavailable-image case (spec
      // section 7's "permission error") — never surfaced as a fetch,
      // never breaks the rest of the formation.
      setStatus("error");
      return;
    }

    setStatus("loading");
    getPlayerCardSignedUrl(player.player_card_image_path)
      .then((url) => {
        if (cancelled) return;
        setSignedUrl(url);
        setStatus("loaded");
      })
      .catch(() => {
        if (!cancelled) setStatus("error");
      });

    return () => {
      cancelled = true;
    };
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [player?.player_library_id, player?.player_card_image_path, userId, retryToken]);

  function handleImageError() {
    if (retryToken < 1) {
      setRetryToken((t) => t + 1); // one retry with a fresh signed URL
    } else {
      setStatus("error"); // still broken (deleted object, etc.) — fallback, don't loop
    }
  }

  return (
    <div className="flex w-20 flex-col items-center gap-1 text-center sm:w-24">
      <div className="relative">
        <button
          type="button"
          onClick={onAssign}
          title={player ? "Change player" : "Assign a player"}
          className="flex h-24 w-20 items-center justify-center overflow-hidden rounded-md border border-pitch-700 bg-pitch-800 sm:h-28 sm:w-24"
        >
          {unavailable ? (
            <span className="px-1 text-[10px] text-slate-500">Player unavailable</span>
          ) : status === "loaded" && signedUrl ? (
            <img
              src={signedUrl}
              alt={display.displayName}
              onError={handleImageError}
              className="h-full w-full object-cover"
            />
          ) : status === "loading" ? (
            <span className="text-[10px] text-slate-400">Loading…</span>
          ) : player ? (
            <span className="px-1 text-[10px] text-slate-500">
              {status === "error" ? "Image unavailable" : "No card image"}
            </span>
          ) : (
            <span className="text-[11px] font-medium text-slate-500">{slotLabel}</span>
          )}
        </button>
        {(player || unavailable) && (
          <button
            type="button"
            onClick={onClear}
            aria-label={unavailable ? `Remove unavailable player from ${slotLabel}` : `Remove ${display.displayName} from ${slotLabel}`}
            className="absolute -right-1.5 -top-1.5 flex h-5 w-5 items-center justify-center rounded-full border border-pitch-700 bg-pitch-900 text-xs text-slate-300 hover:border-danger hover:text-danger"
          >
            ×
          </button>
        )}
      </div>

      <div className="max-w-full truncate text-[11px] font-medium leading-tight text-slate-100">
        {unavailable ? "Unavailable" : player ? display.displayName : slotLabel}
      </div>
      {!unavailable && player && (display.positionLabel || display.overallLabel) && (
        <div className="text-[10px] leading-tight text-slate-400">
          {[display.positionLabel, display.overallLabel].filter(Boolean).join(" · ")}
        </div>
      )}
    </div>
  );
}
