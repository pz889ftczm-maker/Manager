import type { AnalysisEvent, EventSeverity } from "@efootball/shared";

export interface EventTimelineProps {
  events: AnalysisEvent[];
  /** Real video duration once known (VideoPlayer's onLoadedMetadata), or
   * falls back to matches.duration_seconds — never fabricated. Markers
   * are simply not positioned if neither is available. */
  durationSeconds: number | null;
  selectedEventId: string | null;
  /** Current video playback position, for highlighting the nearest event
   * as it plays (Part E: "current time can update timeline"). */
  currentTimeSeconds?: number;
  onSelectEvent: (eventId: string) => void;
}

// Semantic distinction (Part D) driven entirely by the event's own
// persisted severity — never inferred or guessed here.
const SEVERITY_STYLE: Record<EventSeverity, { dot: string; label: string }> = {
  excellent: { dot: "bg-emerald-400", label: "positive" },
  good: { dot: "bg-emerald-400", label: "positive" },
  minor_issue: { dot: "bg-amber-400", label: "neutral" },
  mistake: { dot: "bg-red-500", label: "negative" },
  critical_mistake: { dot: "bg-red-500", label: "negative" },
};

function formatTimestamp(seconds: number | null): string {
  if (seconds == null) return "";
  const m = Math.floor(seconds / 60);
  const s = Math.round(seconds % 60);
  return `${m}:${s.toString().padStart(2, "0")}`;
}

/**
 * Batch 4, Part D/E — a visual scrubber-style timeline of this match's
 * real analysis_events, positioned proportionally along the video's
 * actual duration. Every marker's position comes straight from
 * event.timestamp_seconds — nothing here invents a timestamp for
 * display purposes (Part D's explicit "do not create a new timestamp
 * for the UI" rule).
 */
export function EventTimeline({
  events,
  durationSeconds,
  selectedEventId,
  currentTimeSeconds,
  onSelectEvent,
}: EventTimelineProps) {
  const timedEvents = events.filter((e) => e.timestamp_seconds != null);

  if (timedEvents.length === 0) {
    return <p className="text-sm text-slate-500">No decision events detected.</p>;
  }

  // Without a known duration we can't place markers proportionally —
  // rather than guessing a scale, fall back to an evenly-spaced list.
  if (!durationSeconds || durationSeconds <= 0) {
    return (
      <div className="flex flex-wrap gap-2">
        {timedEvents.map((e) => (
          <button
            key={e.id}
            onClick={() => onSelectEvent(e.id)}
            className={`rounded-full border px-2.5 py-1 text-xs ${
              selectedEventId === e.id ? "border-accent bg-accent/10 text-accent" : "border-pitch-700 text-slate-400"
            }`}
          >
            <span className={`mr-1.5 inline-block h-1.5 w-1.5 rounded-full ${SEVERITY_STYLE[e.severity].dot}`} />
            {formatTimestamp(e.timestamp_seconds)}
          </button>
        ))}
      </div>
    );
  }

  const nearestEventId =
    currentTimeSeconds != null
      ? timedEvents.reduce((closest, e) => {
          const closestDelta = closest ? Math.abs((closest.timestamp_seconds ?? 0) - currentTimeSeconds) : Infinity;
          const delta = Math.abs((e.timestamp_seconds ?? 0) - currentTimeSeconds);
          return delta < closestDelta && delta < 2 ? e : closest;
        }, null as AnalysisEvent | null)?.id ?? null
      : null;

  return (
    <div>
      <div className="relative h-8 rounded-full bg-pitch-800">
        {timedEvents.map((e) => {
          const pct = Math.min(100, Math.max(0, ((e.timestamp_seconds ?? 0) / durationSeconds) * 100));
          const isSelected = selectedEventId === e.id;
          const isNearest = nearestEventId === e.id;
          return (
            <button
              key={e.id}
              onClick={() => onSelectEvent(e.id)}
              title={`${formatTimestamp(e.timestamp_seconds)} — ${e.event_type.replace(/_/g, " ")}`}
              style={{ left: `${pct}%` }}
              className={`absolute top-1/2 h-3.5 w-3.5 -translate-x-1/2 -translate-y-1/2 rounded-full border-2 transition ${
                SEVERITY_STYLE[e.severity].dot
              } ${
                isSelected
                  ? "scale-125 border-white"
                  : isNearest
                  ? "border-white/70"
                  : "border-pitch-900"
              }`}
            />
          );
        })}
      </div>
      <div className="mt-1 flex justify-between text-[10px] text-slate-500">
        <span>0:00</span>
        <span>{formatTimestamp(durationSeconds)}</span>
      </div>

      <div className="mt-3 space-y-1">
        {timedEvents.map((e) => (
          <button
            key={e.id}
            onClick={() => onSelectEvent(e.id)}
            className={`flex w-full items-center justify-between rounded-md border px-3 py-2 text-left text-sm ${
              selectedEventId === e.id ? "border-accent bg-accent/10" : "border-pitch-700 bg-pitch-900"
            }`}
          >
            <span className="flex items-center gap-2">
              <span className={`inline-block h-2 w-2 rounded-full ${SEVERITY_STYLE[e.severity].dot}`} />
              {formatTimestamp(e.timestamp_seconds)} {e.event_type.replace(/_/g, " ")}
            </span>
            <span className="text-xs text-slate-500">{Math.round(Number(e.decision_score ?? 0))}</span>
          </button>
        ))}
      </div>
    </div>
  );
}
