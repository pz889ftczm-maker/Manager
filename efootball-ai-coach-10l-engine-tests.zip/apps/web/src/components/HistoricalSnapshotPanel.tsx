import type { MatchSnapshotDisplay, MatchSnapshotKeyValueEntry } from "@efootball/shared";

// Batch 9D — read-only rendering of a MatchSnapshotDisplay
// (packages/shared/src/matchSnapshotDisplay.ts). This component never
// edits or deletes anything (spec 9D-10/11 — no such action exists
// anywhere in this file), and never fabricates a value: every blank
// below ("—") means the underlying column was genuinely null at
// snapshot time (spec 9D-6), not that this component invented a
// default.

/** A missing/unknown value renders as an em dash, never as 0 or "" —
 * this is purely a display convention (the underlying value stays
 * `null` all the way through packages/shared/src/matchSnapshotDisplay.ts,
 * see that file's own NULL SAFETY note); nothing here writes a
 * fabricated value back into any state. */
function displayValue(value: string | number | null): string {
  return value === null || value === "" ? "—" : String(value);
}

function KeyValueList({ entries }: { entries: MatchSnapshotKeyValueEntry[] }) {
  if (entries.length === 0) return null;
  return (
    <dl className="grid grid-cols-2 gap-x-4 gap-y-1 text-sm sm:grid-cols-3">
      {entries.map((entry) => (
        <div key={entry.key} className="flex justify-between gap-2 sm:block">
          <dt className="text-slate-500">{entry.key.replace(/_/g, " ")}</dt>
          <dd className="font-medium text-slate-200">{displayValue(entry.value)}</dd>
        </div>
      ))}
    </dl>
  );
}

export function HistoricalSnapshotPanel({
  display,
  loading,
}: {
  display: MatchSnapshotDisplay | null;
  loading: boolean;
}) {
  if (loading) {
    return (
      <div className="rounded-lg border border-pitch-700 bg-pitch-900 p-6 text-center text-sm text-slate-500">
        Loading historical snapshot…
      </div>
    );
  }

  // Spec 9D-7 — no snapshot exists: a clean, explicit "unavailable"
  // state, never a broken/empty-looking section.
  if (!display) {
    return (
      <div className="rounded-lg border border-pitch-700 bg-pitch-900 p-6 text-center text-sm text-slate-500">
        Historical snapshot unavailable for this match.
      </div>
    );
  }

  const hasTeamInfo =
    display.teamName || display.teamMotto || display.teamDescription || display.teamFoundedYear || display.teamStadium;
  const hasFormationInfo = display.formationName || display.formationCode || display.tacticalInstructions.length > 0;
  const hasManagerInfo = display.managerName || display.managerRatings.length > 0;

  return (
    <div className="space-y-4 rounded-lg border border-pitch-700 bg-pitch-900 p-4">
      <div className="flex items-baseline justify-between">
        <h2 className="text-lg font-semibold">Historical Match Context</h2>
        <span className="text-xs text-slate-500">as captured at match time</span>
      </div>

      {hasTeamInfo && (
        <section>
          <h3 className="mb-1 text-sm font-semibold text-accent">Team</h3>
          <div className="text-sm text-slate-300">
            <div className="font-medium text-slate-100">{displayValue(display.teamName)}</div>
            {display.teamMotto && <div className="italic text-slate-400">“{display.teamMotto}”</div>}
            {display.teamDescription && <p className="mt-1 text-slate-400">{display.teamDescription}</p>}
            <div className="mt-1 flex gap-4 text-xs text-slate-500">
              <span>Founded: {displayValue(display.teamFoundedYear)}</span>
              <span>Stadium: {displayValue(display.teamStadium)}</span>
            </div>
          </div>
        </section>
      )}

      {hasFormationInfo && (
        <section>
          <h3 className="mb-1 text-sm font-semibold text-accent">Formation</h3>
          <div className="text-sm text-slate-300">
            {displayValue(display.formationName)}
            {display.formationCode ? ` (${display.formationCode})` : ""}
          </div>
          {display.tacticalInstructions.length > 0 && (
            <div className="mt-2">
              <div className="mb-1 text-xs uppercase tracking-wide text-slate-500">Tactical instructions</div>
              <KeyValueList entries={display.tacticalInstructions} />
            </div>
          )}
        </section>
      )}

      {hasManagerInfo && (
        <section>
          <h3 className="mb-1 text-sm font-semibold text-accent">Manager</h3>
          <div className="text-sm text-slate-300">{displayValue(display.managerName)}</div>
          {display.managerRatings.length > 0 && (
            <div className="mt-2">
              <KeyValueList entries={display.managerRatings} />
            </div>
          )}
        </section>
      )}

      {display.players.length > 0 && (
        <section>
          <h3 className="mb-2 text-sm font-semibold text-accent">Players</h3>
          <div className="overflow-x-auto">
            <table className="w-full text-left text-sm">
              <thead>
                <tr className="text-xs uppercase tracking-wide text-slate-500">
                  <th className="pb-1 pr-3">Slot</th>
                  <th className="pb-1 pr-3">Name</th>
                  <th className="pb-1 pr-3">Position</th>
                  <th className="pb-1 pr-3">Overall</th>
                  <th className="pb-1 pr-3">Playstyle</th>
                </tr>
              </thead>
              <tbody>
                {display.players.map((player) => (
                  <tr key={player.id} className="border-t border-pitch-800">
                    <td className="py-1 pr-3 text-slate-400">{displayValue(player.positionSlot)}</td>
                    <td className="py-1 pr-3 font-medium text-slate-100">{displayValue(player.playerName)}</td>
                    <td className="py-1 pr-3 text-slate-300">{displayValue(player.position)}</td>
                    <td className="py-1 pr-3 text-slate-300">{displayValue(player.overall)}</td>
                    <td className="py-1 pr-3 text-slate-300">{displayValue(player.playstyle)}</td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        </section>
      )}

      {!hasTeamInfo && !hasFormationInfo && !hasManagerInfo && display.players.length === 0 && (
        <p className="text-sm text-slate-500">This snapshot has no recorded historical values.</p>
      )}
    </div>
  );
}
