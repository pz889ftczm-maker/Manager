import { NavLink } from "react-router-dom";
import { useAuth } from "../hooks/useAuth";

const links = [
  { to: "/dashboard", label: "Dashboard" },
  { to: "/analyze", label: "Analyze" },
  { to: "/matches", label: "Matches" },
  { to: "/progress", label: "Progress" },
  { to: "/coach", label: "AI Coach" },
  { to: "/player-library", label: "Player Library" },
  { to: "/formation", label: "Formation" },
  { to: "/manager-library", label: "Manager Library" },
  { to: "/team-library", label: "Team Library" },
  { to: "/profile", label: "Profile" },
  { to: "/settings", label: "Settings" },
];

export function Sidebar() {
  const { signOut } = useAuth();

  return (
    <>
      {/* Desktop sidebar */}
      <aside className="hidden md:flex md:w-56 md:flex-col md:border-r md:border-pitch-700 md:bg-pitch-900 md:p-4">
        <div className="mb-8 px-2 text-lg font-bold text-accent">eFootball AI Coach</div>
        <nav className="flex flex-1 flex-col gap-1">
          {links.map((l) => (
            <NavLink
              key={l.to}
              to={l.to}
              className={({ isActive }) =>
                `rounded-md px-3 py-2 text-sm font-medium transition-colors ${
                  isActive ? "bg-pitch-700 text-accent" : "text-slate-300 hover:bg-pitch-800"
                }`
              }
            >
              {l.label}
            </NavLink>
          ))}
        </nav>
        <button
          onClick={signOut}
          className="mt-4 rounded-md px-3 py-2 text-left text-sm text-slate-400 hover:bg-pitch-800"
        >
          Log out
        </button>
      </aside>

      {/* Mobile bottom nav — touch-friendly, per spec section 35/37 */}
      <nav className="fixed inset-x-0 bottom-0 z-10 flex justify-around border-t border-pitch-700 bg-pitch-900 py-2 md:hidden">
        {links.slice(0, 7).map((l) => (
          <NavLink
            key={l.to}
            to={l.to}
            className={({ isActive }) =>
              `flex-1 py-2 text-center text-xs font-medium ${isActive ? "text-accent" : "text-slate-400"}`
            }
          >
            {l.label}
          </NavLink>
        ))}
      </nav>
    </>
  );
}
