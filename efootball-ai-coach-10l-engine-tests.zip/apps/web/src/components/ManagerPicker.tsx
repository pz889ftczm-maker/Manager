import { ManagerImage } from "./ManagerImage";
import { getFormationManagerDisplay, toFormationManagerRef, type ManagerLibrary } from "@efootball/shared";

// Batch 6B-5 — lists the caller's saved Manager Library entries (loaded
// by the caller via listManagerLibrary() — apps/web/src/lib/managerLibrary.ts,
// same RLS-scoped read ManagerLibrary.tsx already uses — no duplicate
// query logic added here, same convention as PlayerPickerModal.tsx) so
// one can be selected as the Formation page's current manager/team
// context. Follows PlayerPickerModal's modal shell/markup conventions
// directly.
//
// Unlike PlayerPickerModal (which only ever receives an already-loaded
// list, since Formation.tsx blocks the whole page on the player load),
// this component also renders the loading/error/empty states itself.
// Manager loading is a SEPARATE, independent load in Formation.tsx from
// the existing player load — a slow/failed manager fetch must never
// block or change the existing player/formation behavior (DO NOT change
// existing player assignment behavior), so this picker has to be able
// to show "still loading"/"failed"/"empty" on its own rather than
// assuming its caller already resolved those states first.

export function ManagerPicker({
  managers,
  loading,
  error,
  selectedId,
  userId,
  onPick,
  onClear,
  onClose,
}: {
  managers: ManagerLibrary[];
  loading: boolean;
  error: string | null;
  /** The currently-selected manager's id, if any — used only to mark the
   * selected row and to show a "Clear selected manager" entry. Never
   * changes which managers are listed. */
  selectedId: string | null;
  userId: string;
  onPick: (entry: ManagerLibrary) => void;
  /** Present only when a manager is currently selected — the "Clear
   * selected manager" row is omitted entirely when nothing is selected,
   * same as PlayerCardSlot only rendering its own "x" when occupied. */
  onClear?: () => void;
  onClose: () => void;
}) {
  return (
    <div
      className="fixed inset-0 z-20 flex items-end justify-center bg-black/60 sm:items-center"
      onClick={onClose}
    >
      <div
        className="max-h-[70vh] w-full max-w-sm overflow-y-auto rounded-t-lg border border-pitch-700 bg-pitch-900 p-4 sm:rounded-lg"
        onClick={(e) => e.stopPropagation()}
      >
        <div className="mb-3 flex items-center justify-between">
          <h2 className="text-sm font-semibold text-slate-100">Choose a manager</h2>
          <button
            type="button"
            onClick={onClose}
            aria-label="Close"
            className="text-slate-400 hover:text-slate-200"
          >
            ×
          </button>
        </div>

        {loading ? (
          <p className="py-6 text-center text-sm text-slate-400">Loading your managers…</p>
        ) : error ? (
          <p className="rounded-md bg-danger/10 px-3 py-2 text-sm text-danger">{error}</p>
        ) : managers.length === 0 ? (
          <p className="py-6 text-center text-sm text-slate-400">
            No saved managers yet — add one in Manager Library first.
          </p>
        ) : (
          <ul className="space-y-1">
            {selectedId && onClear && (
              <li>
                <button
                  type="button"
                  onClick={onClear}
                  className="w-full rounded-md border border-pitch-700 bg-pitch-800 px-3 py-2 text-left text-sm text-slate-400 hover:border-danger hover:text-danger"
                >
                  Clear selected manager
                </button>
              </li>
            )}
            {managers.map((m) => {
              const ref = toFormationManagerRef(m);
              const display = getFormationManagerDisplay(ref);
              const isSelected = m.id === selectedId;
              return (
                <li key={m.id}>
                  <button
                    type="button"
                    onClick={() => onPick(m)}
                    className={`flex w-full items-center gap-3 rounded-md border px-3 py-2 text-left text-sm text-slate-100 hover:border-accent ${
                      isSelected ? "border-accent bg-pitch-800" : "border-pitch-700 bg-pitch-800"
                    }`}
                  >
                    <ManagerImage
                      manager={ref}
                      userId={userId}
                      className="h-10 w-10 shrink-0 rounded-full object-cover"
                      fallback="No image"
                    />
                    <span className="min-w-0 flex-1">
                      <span className="block truncate font-medium">
                        {display.displayName}
                        {isSelected && <span className="ml-2 text-[10px] text-slate-500">(selected)</span>}
                      </span>
                      <span className="block truncate text-xs text-slate-400">
                        {display.possessionLabel} · {display.longBallLabel}
                      </span>
                    </span>
                  </button>
                </li>
              );
            })}
          </ul>
        )}
      </div>
    </div>
  );
}
