import { useState } from "react";
import type { MatchPlayerStatistics, Player } from "@efootball/shared";
import { PLAYER_STAT_CATEGORIES, type PlayerStatCategory } from "@efootball/shared";

const CATEGORY_LABELS: Record<PlayerStatCategory, string> = {
  passing: "Passing",
  dribbling: "Dribbling / Possession",
  defending: "Defending",
  duels: "Duels",
  attack: "Attack",
  goalkeeping: "Goalkeeping",
  discipline: "Discipline",
};

const FIELD_LABELS: Record<string, string> = {
  passes_attempted: "Passes Attempted",
  passes_completed: "Passes Completed",
  pass_completion_percentage: "Pass Completion %",
  key_passes: "Key Passes",
  through_passes: "Through Passes",
  crosses: "Crosses",
  progressive_passes: "Progressive Passes",
  forward_passes: "Forward Passes",
  backward_passes: "Backward Passes",
  long_passes: "Long Passes",
  short_passes: "Short Passes",
  dribbles_attempted: "Dribbles Attempted",
  successful_dribbles: "Successful Dribbles",
  dribble_success_percentage: "Dribble Success %",
  ball_control: "Ball Control (actions)",
  tight_possession: "Tight Possession",
  ball_retention: "Ball Retention",
  possession_losses: "Possession Losses",
  progressive_carries: "Progressive Carries",
  tackles: "Tackles",
  successful_tackles: "Successful Tackles",
  interceptions: "Interceptions",
  clearances: "Clearances",
  blocks: "Blocks",
  defensive_recoveries: "Recoveries",
  defensive_actions: "Defensive Actions",
  pressures: "Pressures",
  total_duels: "Total Duels",
  ground_duels: "Ground Duels",
  ground_duels_won: "Ground Duels Won",
  aerial_duels: "Aerial Duels",
  aerial_duels_won: "Aerial Duels Won",
  physical_challenges: "Physical Challenges",
  duel_win_percentage: "Duel Win %",
  shots: "Shots",
  shots_on_target: "Shots on Target",
  goals: "Goals",
  assists: "Assists",
  chances_created: "Chances Created",
  touches_attacking_third: "Touches (Att. Third)",
  progressive_actions: "Progressive Actions",
  saves: "Saves",
  save_percentage: "Save %",
  claims: "Claims",
  punches: "Punches",
  sweeper_actions: "Sweeper Actions",
  goalkeeper_distribution: "Distribution",
  fouls: "Fouls",
  yellow_cards: "Yellow Cards",
  red_cards: "Red Cards",
  offsides: "Offsides",
};

const PERCENTAGE_FIELDS = new Set([
  "pass_completion_percentage",
  "dribble_success_percentage",
  "duel_win_percentage",
  "save_percentage",
]);

type StatRow = MatchPlayerStatistics & { players: Player | null };

function formatValue(field: string, value: number | null | undefined): string {
  if (value == null) return "—";
  return PERCENTAGE_FIELDS.has(field) ? `${Number(value).toFixed(1)}%` : `${Math.round(Number(value))}`;
}

const SOURCE_LABEL: Record<string, string> = {
  screenshot: "From screenshot",
  structured_data: "From structured data",
  ai_confirmed: "AI-confirmed from match media",
  unavailable: "Unavailable",
};

function PlayerStatCard({ row }: { row: StatRow }) {
  const [activeCategory, setActiveCategory] = useState<PlayerStatCategory>("passing");
  const categories = Object.entries(PLAYER_STAT_CATEGORIES) as [PlayerStatCategory, readonly string[]][];

  // Only offer categories/tabs that actually have at least one real value —
  // spec section 24: no decorative sections for data that isn't there.
  const categoriesWithData = categories.filter(([, fields]) =>
    fields.some((f) => (row as unknown as Record<string, number | null>)[f] != null)
  );

  if (categoriesWithData.length === 0) {
    return (
      <div className="rounded-lg border border-pitch-700 bg-pitch-900 p-4 text-sm text-slate-500">
        {row.players?.name ?? "Player"}: statistics were extracted but none passed validation for this match.
      </div>
    );
  }

  const current = categoriesWithData.find(([cat]) => cat === activeCategory) ?? categoriesWithData[0];
  const [currentCategory, currentFields] = current;
  const visibleFields = currentFields.filter(
    (f) => (row as unknown as Record<string, number | null>)[f] != null
  );

  return (
    <div className="rounded-lg border border-pitch-700 bg-pitch-900 p-4">
      <div className="mb-3 flex flex-wrap items-center justify-between gap-2">
        <div>
          <div className="text-sm font-semibold text-slate-100">
            {row.players?.name ?? (row.players?.is_self ? "You" : "Player")}
          </div>
          <div className="text-[11px] text-slate-500">
            {SOURCE_LABEL[row.source] ?? row.source}
            {row.confidence != null && ` · confidence ${Math.round(Number(row.confidence))}%`}
          </div>
        </div>
      </div>

      <div className="mb-3 flex flex-wrap gap-1.5">
        {categoriesWithData.map(([cat]) => (
          <button
            key={cat}
            onClick={() => setActiveCategory(cat)}
            className={`rounded-md px-2.5 py-1 text-[11px] font-medium transition-colors ${
              currentCategory === cat
                ? "bg-accent/15 text-accent"
                : "bg-pitch-800 text-slate-400 hover:text-slate-200"
            }`}
          >
            {CATEGORY_LABELS[cat]}
          </button>
        ))}
      </div>

      <div className="grid grid-cols-2 gap-2 sm:grid-cols-3">
        {visibleFields.map((field) => (
          <div key={field} className="rounded-md bg-pitch-800 p-2.5 text-center">
            <div className="text-lg font-bold text-slate-100">
              {formatValue(field, (row as unknown as Record<string, number | null>)[field])}
            </div>
            <div className="text-[10px] leading-tight text-slate-500">{FIELD_LABELS[field] ?? field}</div>
          </div>
        ))}
      </div>

      {row.validation_errors && row.validation_errors.length > 0 && (
        <div className="mt-3 rounded-md border border-warn/30 bg-warn/5 p-2 text-[11px] text-warn">
          {row.validation_errors.length} field{row.validation_errors.length > 1 ? "s" : ""} from the source
          didn't pass validation and were left out above.
        </div>
      )}
    </div>
  );
}

/**
 * Batch 3.5 spec section 14/23/24 — real individual player statistics for
 * this match. Deliberately shows ONLY fields with a real, validated value;
 * no scores, no charts, no numbers are generated here for data the source
 * didn't actually provide.
 */
export function PlayerPerformance({ rows }: { rows: StatRow[] }) {
  if (rows.length === 0) {
    return (
      <div className="rounded-lg border border-dashed border-pitch-700 bg-pitch-900/50 p-6 text-center">
        <div className="text-sm font-medium text-slate-300">Player Performance</div>
        <p className="mt-1 text-xs text-slate-500">
          Insufficient data — no statistics screen was detected in this match's uploaded media.
        </p>
      </div>
    );
  }

  return (
    <div>
      <h2 className="mb-3 text-lg font-semibold">Player Performance</h2>
      <div className="grid grid-cols-1 gap-4 lg:grid-cols-2">
        {rows.map((row) => (
          <PlayerStatCard key={row.id} row={row} />
        ))}
      </div>
    </div>
  );
}
