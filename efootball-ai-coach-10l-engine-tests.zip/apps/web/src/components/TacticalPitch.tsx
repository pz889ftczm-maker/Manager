import type { TacticalAnalysis } from "@efootball/shared";

/**
 * Renders actual_positions/recommended_positions/passing_lanes/etc as SVG
 * on a schematic pitch. Coordinates are 0-100 percentages (x = width,
 * y = length), matching packages/shared/src/types.ts::Point.
 *
 * `variant` selects which half of the "what you did vs better option"
 * comparison (spec section 17) to draw from the same TacticalAnalysis row.
 */
export function TacticalPitch({
  data,
  variant,
}: {
  data: TacticalAnalysis;
  variant: "actual" | "recommended";
}) {
  const positions = variant === "actual" ? data.actual_positions : data.recommended_positions;

  return (
    <div className="relative overflow-hidden rounded-lg border border-pitch-700 bg-pitch-800">
      {data.is_approximate && (
        <div className="absolute right-2 top-2 z-10 rounded bg-warn/20 px-2 py-0.5 text-[10px] font-medium text-warn">
          Approximate
        </div>
      )}
      <svg viewBox="0 0 100 100" className="aspect-[2/3] w-full">
        {/* Pitch markings */}
        <rect x="1" y="1" width="98" height="98" fill="none" stroke="#2a3a30" strokeWidth="0.5" />
        <line x1="1" y1="50" x2="99" y2="50" stroke="#2a3a30" strokeWidth="0.5" />
        <circle cx="50" cy="50" r="8" fill="none" stroke="#2a3a30" strokeWidth="0.5" />

        {/* Pressure zones */}
        {variant === "actual" &&
          data.pressure_zones?.map((z, i) => (
            <circle
              key={`pz-${i}`}
              cx={z.center.x}
              cy={z.center.y}
              r={z.radius}
              fill="#ef4444"
              opacity={0.15 + z.intensity * 0.2}
            />
          ))}

        {/* Open spaces */}
        {variant === "recommended" &&
          data.open_spaces?.map((s, i) => (
            <circle key={`os-${i}`} cx={s.center.x} cy={s.center.y} r={s.radius} fill="#22c55e" opacity={0.15} />
          ))}

        {/* Passing lanes */}
        {data.passing_lanes
          ?.filter((l) => (variant === "actual" ? l.quality !== "recommended" : l.quality === "recommended"))
          .map((l, i) => (
            <line
              key={`pl-${i}`}
              x1={l.from.x}
              y1={l.from.y}
              x2={l.to.x}
              y2={l.to.y}
              stroke={l.quality === "risky" ? "#ef4444" : l.quality === "recommended" ? "#22c55e" : "#94a3b8"}
              strokeWidth="0.6"
              strokeDasharray={l.quality === "recommended" ? "2,1" : undefined}
              markerEnd="url(#arrow)"
            />
          ))}

        {/* Movement arrows (recommended variant only, spec section 17) */}
        {variant === "recommended" &&
          data.movement_arrows?.map((a, i) => (
            <line
              key={`ma-${i}`}
              x1={a.from.x}
              y1={a.from.y}
              x2={a.to.x}
              y2={a.to.y}
              stroke="#22c55e"
              strokeWidth="0.6"
              markerEnd="url(#arrow)"
            />
          ))}

        <defs>
          <marker id="arrow" markerWidth="4" markerHeight="4" refX="3" refY="2" orient="auto">
            <path d="M0,0 L4,2 L0,4 z" fill="#22c55e" />
          </marker>
        </defs>

        {/* Players */}
        {positions?.map((p, i) => (
          <g key={`pos-${i}`}>
            <circle
              cx={p.pos.x}
              cy={p.pos.y}
              r="2.2"
              fill={p.team === "user" ? "#22c55e" : "#ef4444"}
              stroke="#0a0f0d"
              strokeWidth="0.3"
            />
            <text x={p.pos.x} y={p.pos.y - 3} fontSize="2.5" textAnchor="middle" fill="#cbd5e1">
              {p.role}
            </text>
          </g>
        ))}
      </svg>

      {!positions && (
        <div className="absolute inset-0 flex items-center justify-center text-xs text-slate-500">
          Not enough visual data to render positions
        </div>
      )}
    </div>
  );
}
