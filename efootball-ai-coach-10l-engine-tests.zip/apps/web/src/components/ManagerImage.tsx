import { useEffect, useState } from "react";
import { getManagerImageSignedUrl } from "../lib/managerImageStorage";
import { isFormationManagerImageOwned, type FormationManagerRef } from "@efootball/shared";

// Batch 6B-5 — shared signed-image loader for a manager's saved image.
// Used by both ManagerPicker.tsx's compact list rows and Formation.tsx's
// larger Selected Manager display, so the ownership-check + signed-URL
// fetch logic (same pattern as PlayerCardSlot.tsx's image loading — spec
// section 3/4/6 — applied to the private `manager-images` bucket instead
// of `player-cards`) lives in exactly one place rather than being copied
// into each caller.
//
// Ownership is checked here first via isFormationManagerImageOwned
// (packages/shared/src/formation.ts, which reuses isPathOwnedByUser) so
// a signed URL is never even requested for a manager image that isn't
// this user's own — defense-in-depth on top of Storage RLS
// (0015_manager_images_storage.sql), which is the actual gate. Renders a
// clean fallback (never a generated/fake image) when there's no image,
// the image isn't owned, or loading it fails.

type ImageStatus = "idle" | "loading" | "loaded" | "error";

export function ManagerImage({
  manager,
  userId,
  className,
  fallback,
}: {
  manager: FormationManagerRef | null;
  userId: string;
  /** Applied to both the <img> and the fallback placeholder, so callers
   * control size/shape (e.g. a small round avatar in the picker vs. a
   * larger one in the Selected Manager panel) from one prop. */
  className: string;
  /** Text shown in the fallback box when there's no image, it isn't
   * owned by this user, or it fails to load. */
  fallback: string;
}) {
  const [status, setStatus] = useState<ImageStatus>("idle");
  const [signedUrl, setSignedUrl] = useState<string | null>(null);

  useEffect(() => {
    let cancelled = false;
    setSignedUrl(null);

    if (!manager?.manager_image_path) {
      setStatus("idle"); // no image on this manager — clean fallback, not an error
      return;
    }
    if (!isFormationManagerImageOwned(manager, userId)) {
      // Treated the same as any other unavailable-image case — never
      // surfaced as a fetch, never breaks the rest of the page.
      setStatus("error");
      return;
    }

    setStatus("loading");
    getManagerImageSignedUrl(manager.manager_image_path)
      .then((url) => {
        if (cancelled) return;
        setSignedUrl(url);
        setStatus("loaded");
      })
      .catch(() => {
        if (!cancelled) setStatus("error");
      });

    return () => {
      cancelled = true;
    };
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [manager?.manager_library_id, manager?.manager_image_path, userId]);

  if (status === "loaded" && signedUrl) {
    return <img src={signedUrl} alt="" onError={() => setStatus("error")} className={className} />;
  }

  return (
    <span
      className={`${className} flex items-center justify-center border border-pitch-700 bg-pitch-900 text-center text-[10px] leading-tight text-slate-500`}
    >
      {status === "loading" ? "…" : fallback}
    </span>
  );
}
