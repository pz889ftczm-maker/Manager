import { forwardRef, useImperativeHandle, useRef, useState } from "react";

export interface VideoPlayerHandle {
  /** Seeks to `seconds` and starts playback. Used by Watch Moment (Part F)
   * and by clicking an event on the timeline (Part E). */
  seekAndPlay: (seconds: number) => void;
  pause: () => void;
  getCurrentTime: () => number;
}

export interface VideoPlayerProps {
  src: string;
  /** Reported once metadata loads — lets callers (Watch Moment, timeline)
   * clamp against the real video duration rather than matches.duration_seconds,
   * which can lag slightly behind the actual encoded file. */
  onDurationChange?: (durationSeconds: number) => void;
  onTimeUpdate?: (currentSeconds: number) => void;
}

/**
 * Batch 4, Part C — a real HTML5 <video> player (play/pause, seek,
 * progress, volume, loading/error states are all native <video controls>
 * behavior here) wired with an imperative handle so parent components
 * (MatchReport's Watch Moment button, EventTimeline clicks) can seek it
 * without re-implementing player chrome themselves.
 */
export const VideoPlayer = forwardRef<VideoPlayerHandle, VideoPlayerProps>(function VideoPlayer(
  { src, onDurationChange, onTimeUpdate },
  ref
) {
  const videoRef = useRef<HTMLVideoElement | null>(null);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);

  useImperativeHandle(ref, () => ({
    seekAndPlay: (seconds: number) => {
      const el = videoRef.current;
      if (!el) return;
      el.currentTime = seconds;
      void el.play();
    },
    pause: () => videoRef.current?.pause(),
    getCurrentTime: () => videoRef.current?.currentTime ?? 0,
  }));

  return (
    <div className="overflow-hidden rounded-lg border border-pitch-700 bg-black">
      {error && (
        <div className="flex h-64 items-center justify-center text-sm text-danger">
          Couldn't load the video: {error}
        </div>
      )}
      <video
        ref={videoRef}
        src={src}
        controls
        preload="metadata"
        className={`w-full ${error ? "hidden" : ""}`}
        style={{ maxHeight: 480 }}
        onLoadedMetadata={(e: { currentTarget: HTMLVideoElement }) => {
          setLoading(false);
          onDurationChange?.(e.currentTarget.duration);
        }}
        onTimeUpdate={(e: { currentTarget: HTMLVideoElement }) => onTimeUpdate?.(e.currentTarget.currentTime)}
        onError={() => {
          setLoading(false);
          setError("playback failed — the signed URL may have expired, try reloading.");
        }}
      />
      {loading && !error && <div className="p-2 text-center text-xs text-slate-500">Loading video…</div>}
    </div>
  );
});
