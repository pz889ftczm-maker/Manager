import { BrowserRouter, Routes, Route, Navigate } from "react-router-dom";
import { AuthProvider } from "./hooks/useAuth";
import { ProtectedRoute } from "./components/ProtectedRoute";
import { AppShell } from "./components/AppShell";

import { Landing } from "./routes/Landing";
import { Login } from "./routes/Login";
import { SignUp } from "./routes/SignUp";
import { ForgotPassword } from "./routes/ForgotPassword";
import { Dashboard } from "./routes/Dashboard";
import { Analyze } from "./routes/Analyze";
import { PlayerLibraryPage } from "./routes/PlayerLibrary";
import { ManagerLibraryPage } from "./routes/ManagerLibrary";
import { TeamLibraryPage } from "./routes/TeamLibrary";
import { Formation } from "./routes/Formation";
import { MatchHistory } from "./routes/MatchHistory";
import { MatchReport } from "./routes/MatchReport";
import { Progress } from "./routes/Progress";
import { AiCoach } from "./routes/AiCoach";
import { Profile } from "./routes/Profile";
import { Settings } from "./routes/Settings";

function Protected({ children }: { children: React.ReactNode }) {
  return (
    <ProtectedRoute>
      <AppShell>{children}</AppShell>
    </ProtectedRoute>
  );
}

export function App() {
  return (
    <AuthProvider>
      <BrowserRouter>
        <Routes>
          <Route path="/" element={<Landing />} />
          <Route path="/login" element={<Login />} />
          <Route path="/signup" element={<SignUp />} />
          <Route path="/forgot-password" element={<ForgotPassword />} />

          <Route path="/dashboard" element={<Protected><Dashboard /></Protected>} />
          <Route path="/analyze" element={<Protected><Analyze /></Protected>} />
          <Route path="/player-library" element={<Protected><PlayerLibraryPage /></Protected>} />
          <Route path="/manager-library" element={<Protected><ManagerLibraryPage /></Protected>} />
          <Route path="/team-library" element={<Protected><TeamLibraryPage /></Protected>} />
          <Route path="/formation" element={<Protected><Formation /></Protected>} />
          <Route path="/matches" element={<Protected><MatchHistory /></Protected>} />
          <Route path="/matches/:matchId" element={<Protected><MatchReport /></Protected>} />
          <Route path="/progress" element={<Protected><Progress /></Protected>} />
          <Route path="/coach" element={<Protected><AiCoach /></Protected>} />
          <Route path="/profile" element={<Protected><Profile /></Protected>} />
          <Route path="/settings" element={<Protected><Settings /></Protected>} />

          <Route path="*" element={<Navigate to="/" replace />} />
        </Routes>
      </BrowserRouter>
    </AuthProvider>
  );
}
