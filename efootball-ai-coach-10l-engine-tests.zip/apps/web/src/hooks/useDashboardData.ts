import { useEffect, useState } from "react";
import { supabase } from "../lib/supabaseClient";
import { useAuth } from "./useAuth";
import type { Match, PlayerProgress } from "@efootball/shared";

export interface DashboardData {
  isDemo: boolean;
  recentMatches: Match[];
  progress: PlayerProgress | null;
  loading: boolean;
}

/** Spec section 7/30: real data when it exists, clearly-labeled demo data
 * (never mixed) when the user has no analyzed matches yet. */
export function useDashboardData(): DashboardData {
  const { user } = useAuth();
  const [state, setState] = useState<DashboardData>({
    isDemo: false,
    recentMatches: [],
    progress: null,
    loading: true,
  });

  useEffect(() => {
    if (!user) return;

    (async () => {
      const { data: matches } = await supabase
        .from("matches")
        .select("*")
        .eq("user_id", user.id)
        .eq("is_demo", false)
        .order("created_at", { ascending: false })
        .limit(5);

      if (matches && matches.length > 0) {
        const { data: progress } = await supabase
          .from("player_progress")
          .select("*")
          .eq("user_id", user.id)
          .maybeSingle();

        setState({ isDemo: false, recentMatches: matches, progress: progress ?? null, loading: false });
        return;
      }

      // No real matches yet — fall back to this user's demo match rows
      // (seeded by supabase/seed.sql with is_demo=true, still scoped to
      // the user via RLS so this stays a real query, not hardcoded UI data).
      const { data: demoMatches } = await supabase
        .from("matches")
        .select("*")
        .eq("user_id", user.id)
        .eq("is_demo", true)
        .order("created_at", { ascending: false })
        .limit(5);

      setState({ isDemo: true, recentMatches: demoMatches ?? [], progress: null, loading: false });
    })();
  }, [user]);

  return state;
}
