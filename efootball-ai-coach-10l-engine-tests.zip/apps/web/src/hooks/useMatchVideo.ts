import { useEffect, useState } from "react";
import { supabase } from "../lib/supabaseClient";

const MATCH_VIDEO_BUCKET = "match-videos"; // matches STORAGE_BUCKET_MATCH_VIDEOS default (.env.example)
const SIGNED_URL_TTL_SECONDS = 60 * 60; // 1 hour — regenerated on next mount/hook use, never persisted long-term

export interface MatchVideoState {
  videoUrl: string | null;
  loading: boolean;
  /** null = still loading or genuinely no video for this match (never a fabricated reason). */
  error: string | null;
}

/**
 * Batch 4 (B/C) — resolves the persisted, playable match video (written by
 * apps/worker/src/jobs/processMatchVideo.ts::persistProcessedVideoMedia,
 * see migration 0008_video_experience.sql) into a short-lived signed URL.
 *
 * Deliberately calls supabase.storage directly rather than going through
 * an Edge Function: the `match-videos` bucket is private, and its storage
 * RLS policy (0008_video_experience.sql) already restricts
 * createSignedUrl() to the object's own owner via the caller's JWT — the
 * exact "signed URL + ownership check" shape spec Part B asks for, with
 * no extra server hop needed just to read a URL the user already owns.
 * A different user's match_id simply returns no media row at all (RLS on
 * `media` itself), so there's nothing to sign in the first place.
 */
export function useMatchVideo(matchId: string | undefined): MatchVideoState {
  const [state, setState] = useState<MatchVideoState>({ videoUrl: null, loading: true, error: null });

  useEffect(() => {
    if (!matchId) {
      setState({ videoUrl: null, loading: false, error: null });
      return;
    }

    let cancelled = false;
    setState((s) => ({ ...s, loading: true, error: null }));

    (async () => {
      const { data: media, error: mediaError } = await supabase
        .from("media")
        .select("storage_reference, status")
        .eq("match_id", matchId)
        .eq("type", "video")
        .eq("is_temporary", false)
        .maybeSingle();

      if (cancelled) return;

      if (mediaError) {
        setState({ videoUrl: null, loading: false, error: mediaError.message });
        return;
      }
      if (!media || !media.storage_reference || media.status !== "processed") {
        // Not an error state — this match may be screenshot-only, or the
        // video row simply doesn't exist. Callers render a "no video"
        // state rather than treating this as a failure (spec Part N).
        setState({ videoUrl: null, loading: false, error: null });
        return;
      }

      const { data: signed, error: signError } = await supabase.storage
        .from(MATCH_VIDEO_BUCKET)
        .createSignedUrl(media.storage_reference, SIGNED_URL_TTL_SECONDS);

      if (cancelled) return;

      if (signError || !signed) {
        setState({ videoUrl: null, loading: false, error: signError?.message ?? "Failed to sign video URL" });
        return;
      }

      setState({ videoUrl: signed.signedUrl, loading: false, error: null });
    })();

    return () => {
      cancelled = true;
    };
  }, [matchId]);

  return state;
}
