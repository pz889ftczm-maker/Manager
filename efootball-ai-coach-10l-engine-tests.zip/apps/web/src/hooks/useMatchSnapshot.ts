import { useEffect, useState } from "react";
import { supabase } from "../lib/supabaseClient";
import {
  selectMatchSnapshotForMatch,
  buildMatchSnapshotDisplay,
  type MatchSnapshot,
  type MatchSnapshotPlayer,
  type MatchSnapshotDisplay,
} from "@efootball/shared";

export interface MatchSnapshotState {
  /** null while loading, or when this match genuinely has no historical
   * snapshot (spec 9D-7 — a normal state, never an error). */
  display: MatchSnapshotDisplay | null;
  loading: boolean;
  error: string | null;
}

/**
 * Batch 9D — read-only Historical Match Snapshot for the Match Report.
 *
 * OWNERSHIP (spec 9D-1/2/3): never queries by a snapshot's own id at
 * all — only ever by match_id, exactly like every other Match Report
 * fetch on this page (see MatchReport.tsx's own `matches`/
 * `match_statistics`/`analysis_events` queries). Both `match_snapshots`
 * and `match_snapshot_players` already carry a SELECT policy scoped to
 * `auth.uid()` (directly, and one-hop-derived through snapshot_id —
 * migration 0025), so this hook returns nothing at all for a match the
 * caller doesn't own, without any ownership logic of its own. On top
 * of that RLS scoping, selectMatchSnapshotForMatch (packages/shared)
 * re-checks that every candidate row's own match_id actually equals
 * the one being displayed before it's ever shown — defense-in-depth
 * against a stale/misrouted result, never a trust decision made here.
 *
 * NO JOIN BACK TO ANY LIBRARY TABLE (spec 9D-4/8/9): the two queries
 * below select only from match_snapshots / match_snapshot_players —
 * the exact two tables migration 0025 designed to make a full
 * historical reconstruction possible from, with zero joins back to
 * team_library/player_library/manager_library/team_formations. A
 * since-edited or since-deleted source Library row cannot affect what
 * this hook returns.
 *
 * READ-ONLY (spec 9D-10/11): this hook only ever SELECTs. It has no
 * insert/update/delete path of any kind — match_snapshots/
 * match_snapshot_players have no such RLS policy for the browser to
 * use in the first place (0025).
 */
export function useMatchSnapshot(matchId: string | undefined): MatchSnapshotState {
  const [state, setState] = useState<MatchSnapshotState>({ display: null, loading: true, error: null });

  useEffect(() => {
    if (!matchId) {
      setState({ display: null, loading: false, error: null });
      return;
    }

    let cancelled = false;
    setState((s) => ({ ...s, loading: true, error: null }));

    (async () => {
      const { data: snapshotRows, error: snapshotError } = await supabase
        .from("match_snapshots")
        .select("*")
        .eq("match_id", matchId);

      if (cancelled) return;

      if (snapshotError) {
        setState({ display: null, loading: false, error: snapshotError.message });
        return;
      }

      const snapshot = selectMatchSnapshotForMatch((snapshotRows as MatchSnapshot[]) ?? [], matchId);
      if (!snapshot) {
        // No snapshot for this match at all — a clean, expected state
        // (spec 9D-7), not an error.
        setState({ display: null, loading: false, error: null });
        return;
      }

      const { data: playerRows, error: playersError } = await supabase
        .from("match_snapshot_players")
        .select("*")
        .eq("snapshot_id", snapshot.id);

      if (cancelled) return;

      if (playersError) {
        setState({ display: null, loading: false, error: playersError.message });
        return;
      }

      const display = buildMatchSnapshotDisplay(snapshot, (playerRows as MatchSnapshotPlayer[]) ?? []);
      setState({ display, loading: false, error: null });
    })();

    return () => {
      cancelled = true;
    };
  }, [matchId]);

  return state;
}
