import { useCallback, useEffect, useRef, useState } from "react";
import { supabase } from "../lib/supabaseClient";
import type { VideoClipStatus } from "@efootball/shared";

const VIDEO_CLIP_BUCKET = "video-clips"; // matches STORAGE_BUCKET_VIDEO_CLIPS default (.env.example)
const SIGNED_URL_TTL_SECONDS = 60 * 60;
const POLL_INTERVAL_MS = 3000;

export interface ClipState {
  clipId: string | null;
  status: VideoClipStatus | "idle";
  clipUrl: string | null;
  error: string | null;
}

const IDLE_STATE: ClipState = { clipId: null, status: "idle", clipUrl: null, error: null };

/**
 * Batch 4 (Parts I/K/L/M) — drives "Generate Clip" for events in
 * MatchReport.tsx. State is keyed by eventId so multiple events on the
 * same match report can each track their own clip independently.
 *
 * The frontend never talks to the worker or Redis directly (Part L) —
 * every request goes through the clip-request Edge Function, which is
 * also where ownership/idempotency actually live. This hook only:
 *   1. calls that function,
 *   2. polls the resulting video_clips row until it leaves
 *      pending/processing (stopping polling as soon as it does, and on
 *      unmount — Part M),
 *   3. resolves a signed URL for the finished clip once status=completed.
 */
export function useVideoClips(matchId: string | undefined) {
  const [clips, setClips] = useState<Record<string, ClipState>>({});
  const timersRef = useRef<Record<string, ReturnType<typeof setInterval>>>({});

  const stopPolling = useCallback((eventId: string) => {
    const timer = timersRef.current[eventId];
    if (timer) {
      clearInterval(timer);
      delete timersRef.current[eventId];
    }
  }, []);

  useEffect(() => {
    // Cleanup all timers on unmount (Part M: "cleanup timers on unmount").
    return () => {
      Object.values(timersRef.current).forEach((t) => clearInterval(t));
      timersRef.current = {};
    };
  }, []);

  const pollClip = useCallback(
    (eventId: string, clipId: string) => {
      stopPolling(eventId);
      timersRef.current[eventId] = setInterval(async () => {
        const { data: row, error } = await supabase
          .from("video_clips")
          .select("id, status, storage_path, error_message")
          .eq("id", clipId)
          .maybeSingle();

        if (error) {
          stopPolling(eventId);
          setClips((prev) => ({ ...prev, [eventId]: { clipId, status: "failed", clipUrl: null, error: error.message } }));
          return;
        }
        if (!row) return; // transient — keep polling

        if (row.status === "completed" && row.storage_path) {
          stopPolling(eventId);
          const { data: signed, error: signError } = await supabase.storage
            .from(VIDEO_CLIP_BUCKET)
            .createSignedUrl(row.storage_path, SIGNED_URL_TTL_SECONDS);
          setClips((prev) => ({
            ...prev,
            [eventId]: {
              clipId,
              status: "completed",
              clipUrl: signed?.signedUrl ?? null,
              error: signError?.message ?? null,
            },
          }));
          return;
        }

        if (row.status === "failed") {
          stopPolling(eventId);
          setClips((prev) => ({
            ...prev,
            [eventId]: { clipId, status: "failed", clipUrl: null, error: row.error_message ?? "Clip generation failed" },
          }));
          return;
        }

        // still pending/processing — keep polling, but reflect the latest status.
        setClips((prev) => ({ ...prev, [eventId]: { clipId, status: row.status, clipUrl: null, error: null } }));
      }, POLL_INTERVAL_MS);
    },
    [stopPolling]
  );

  const requestClip = useCallback(
    async (eventId: string) => {
      if (!matchId) return;

      setClips((prev) => ({ ...prev, [eventId]: { clipId: null, status: "pending", clipUrl: null, error: null } }));

      try {
        const { data: sessionData } = await supabase.auth.getSession();
        const res = await fetch(`${import.meta.env.VITE_SUPABASE_URL}/functions/v1/clip-request`, {
          method: "POST",
          headers: {
            "Content-Type": "application/json",
            Authorization: `Bearer ${sessionData.session?.access_token}`,
          },
          body: JSON.stringify({ matchId, eventId }),
        });

        const body = await res.json().catch(() => ({}));
        if (!res.ok) throw new Error(body?.error ?? "Failed to request clip");

        setClips((prev) => ({
          ...prev,
          [eventId]: { clipId: body.clipId, status: body.status, clipUrl: null, error: null },
        }));

        if (body.status === "pending" || body.status === "processing") {
          pollClip(eventId, body.clipId);
        } else if (body.status === "completed") {
          // Already generated previously (idempotent hit) — resolve the URL right away.
          pollClip(eventId, body.clipId);
        }
      } catch (err) {
        setClips((prev) => ({
          ...prev,
          [eventId]: { clipId: null, status: "failed", clipUrl: null, error: (err as Error).message },
        }));
      }
    },
    [matchId, pollClip]
  );

  const getClipState = useCallback((eventId: string): ClipState => clips[eventId] ?? IDLE_STATE, [clips]);

  return { getClipState, requestClip };
}
