import { useEffect, useState } from "react";
import { supabase } from "../lib/supabaseClient";
import { useAuth } from "../hooks/useAuth";
import type { Profile as ProfileType } from "@efootball/shared";

const POSITIONS = ["CB", "LB", "RB", "DMF", "CMF", "AMF", "LWF", "RWF", "CF"];

export function Profile() {
  const { user } = useAuth();
  const [profile, setProfile] = useState<ProfileType | null>(null);
  const [displayName, setDisplayName] = useState("");
  const [preferredPosition, setPreferredPosition] = useState("");
  const [saved, setSaved] = useState(false);

  useEffect(() => {
    if (!user) return;
    supabase
      .from("profiles")
      .select("*")
      .eq("id", user.id)
      .single()
      .then(({ data }) => {
        if (data) {
          setProfile(data);
          setDisplayName(data.display_name ?? "");
          setPreferredPosition(data.preferred_position ?? "");
        }
      });
  }, [user]);

  async function handleSave() {
    if (!user) return;
    const { error } = await supabase
      .from("profiles")
      .update({ display_name: displayName, preferred_position: preferredPosition })
      .eq("id", user.id);
    if (!error) {
      setSaved(true);
      setTimeout(() => setSaved(false), 2000);
    }
  }

  if (!profile) return <div className="text-slate-400">Loading profile…</div>;

  return (
    <div className="mx-auto max-w-md">
      <h1 className="mb-6 text-2xl font-bold">Profile</h1>

      <label className="mb-1 block text-sm text-slate-400">Display name</label>
      <input
        value={displayName}
        onChange={(e) => setDisplayName(e.target.value)}
        className="mb-4 w-full rounded-md border border-pitch-700 bg-pitch-800 px-3 py-2 text-sm text-slate-100"
      />

      <label className="mb-1 block text-sm text-slate-400">Preferred position</label>
      <select
        value={preferredPosition}
        onChange={(e) => setPreferredPosition(e.target.value)}
        className="mb-6 w-full rounded-md border border-pitch-700 bg-pitch-800 px-3 py-2 text-sm text-slate-100"
      >
        <option value="">Not set</option>
        {POSITIONS.map((p) => (
          <option key={p} value={p}>
            {p}
          </option>
        ))}
      </select>

      <button
        onClick={handleSave}
        className="rounded-md bg-accent px-4 py-2 text-sm font-semibold text-pitch-950 hover:bg-accent-dim"
      >
        Save changes
      </button>
      {saved && <span className="ml-3 text-sm text-accent">Saved</span>}
    </div>
  );
}
