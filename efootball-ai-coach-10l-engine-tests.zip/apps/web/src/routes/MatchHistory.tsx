import { useEffect, useState } from "react";
import { Link } from "react-router-dom";
import { supabase } from "../lib/supabaseClient";
import { useAuth } from "../hooks/useAuth";
import { enqueueAnalysis } from "../lib/enqueueAnalysis";
import type { Match } from "@efootball/shared";

const STATUS_LABEL: Record<string, string> = {
  uploading: "Uploading",
  // Batch 5: idempotent-enqueue sentinel (0009_production_hardening.sql)
  // — briefly visible between hand-off and the worker picking up the job.
  queued: "Queued",
  optimizing: "Optimizing video",
  processing: "Processing",
  detecting_moments: "Detecting moments",
  analyzing: "AI analyzing",
  generating_report: "Generating report",
  complete: "Complete",
  error: "Error",
};

export function MatchHistory() {
  const { user } = useAuth();
  const [matches, setMatches] = useState<Match[]>([]);
  const [loading, setLoading] = useState(true);
  const [retryingId, setRetryingId] = useState<string | null>(null);
  const [retryError, setRetryError] = useState<{ id: string; message: string } | null>(null);

  function loadMatches() {
    if (!user) return;
    return supabase
      .from("matches")
      .select("*")
      .eq("user_id", user.id)
      .order("created_at", { ascending: false })
      .then(({ data }) => {
        setMatches(data ?? []);
        setLoading(false);
      });
  }

  useEffect(() => {
    loadMatches();
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [user]);

  // Part R/S — "allow retry after failure" for a match that already has
  // its raw file(s) sitting in storage (the pipeline preserves them on any
  // failure specifically so this is possible — see processMatchVideo.ts /
  // processScreenshot.ts). Re-uses the exact same media rows and the exact
  // same enqueueAnalysis() call Analyze.tsx uses for a first submission;
  // analysis-enqueue's idempotent-enqueue claim (Part J) is what makes
  // this safe to click more than once.
  async function handleRetry(match: Match, e: React.MouseEvent) {
    e.preventDefault();
    e.stopPropagation();
    if (retryingId) return;

    setRetryingId(match.id);
    setRetryError(null);
    try {
      const { data: mediaRows, error: mediaErr } = await supabase
        .from("media")
        .select("id, type, storage_reference")
        .eq("match_id", match.id)
        .not("storage_reference", "is", null);
      if (mediaErr) throw mediaErr;
      if (!mediaRows || mediaRows.length === 0) {
        throw new Error("The original upload for this match is no longer available. Please start a new analysis.");
      }

      const mode = match.source_type as "video" | "screenshot";
      const storageObjectPaths = mediaRows.map((m) => m.storage_reference as string);
      const videoMedia = mode === "video" ? mediaRows.find((m) => m.type === "video") : undefined;

      await enqueueAnalysis({
        matchId: match.id,
        mode,
        storageObjectPaths,
        mediaId: videoMedia?.id ?? null,
      });

      await loadMatches();
    } catch (err) {
      setRetryError({ id: match.id, message: (err as Error).message });
    } finally {
      setRetryingId(null);
    }
  }

  if (loading) return <div className="text-slate-400">Loading matches…</div>;

  return (
    <div>
      <h1 className="mb-6 text-2xl font-bold">Match History</h1>
      <div className="space-y-2">
        {matches.length === 0 && <p className="text-sm text-slate-500">No matches yet — start a new analysis.</p>}
        {matches.map((m) => (
          <div key={m.id}>
            <Link
              to={`/matches/${m.id}`}
              className="flex items-center justify-between rounded-lg border border-pitch-700 bg-pitch-900 px-4 py-3 hover:border-accent"
            >
              <div>
                <div className="font-medium">
                  {m.title ?? "Untitled match"} {m.is_demo && <span className="ml-2 text-xs text-warn">DEMO</span>}
                </div>
                <div className="text-xs text-slate-500">
                  {m.source_type} · {STATUS_LABEL[m.status] ?? m.status}
                  {m.status === "error" && m.error_message ? ` — ${m.error_message}` : ""}
                </div>
              </div>
              <div className="flex items-center gap-3">
                {m.status === "error" && (
                  <button
                    onClick={(e) => handleRetry(m, e)}
                    disabled={retryingId === m.id}
                    className="rounded-md border border-pitch-700 px-3 py-1.5 text-xs font-medium text-slate-300 hover:border-accent disabled:opacity-50"
                  >
                    {retryingId === m.id ? "Retrying…" : "Retry"}
                  </button>
                )}
                <div className="text-lg font-bold text-accent">
                  {m.overall_score != null ? Math.round(Number(m.overall_score)) : "—"}
                </div>
              </div>
            </Link>
            {retryError?.id === m.id && (
              <p className="mt-1 rounded-md bg-danger/10 px-3 py-1.5 text-xs text-danger">{retryError.message}</p>
            )}
          </div>
        ))}
      </div>
    </div>
  );
}
