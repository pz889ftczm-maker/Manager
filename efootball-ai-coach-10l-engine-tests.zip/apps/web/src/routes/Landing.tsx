import { Link } from "react-router-dom";

const features = [
  { title: "AI Gameplay Analysis", desc: "Every screenshot or match video is broken down decision by decision." },
  { title: "Decision Analysis", desc: "Not just what happened — why it was good or bad, and what to do instead." },
  { title: "Full-Match Video Analysis", desc: "Upload an entire match. The AI searches the whole thing for key moments." },
  { title: "Tactical Visualization", desc: "See the better option drawn on the pitch, not just described in text." },
  { title: "Personalized Coaching", desc: "An AI Coach that references your actual matches, not generic tips." },
  { title: "Progress Tracking", desc: "Watch your decision-making score improve match over match." },
];

export function Landing() {
  return (
    <div className="min-h-screen bg-pitch-950 text-slate-100">
      <header className="flex items-center justify-between px-6 py-5 md:px-12">
        <div className="text-lg font-bold text-accent">eFootball AI Coach</div>
        <div className="flex gap-3">
          <Link to="/login" className="rounded-md px-4 py-2 text-sm font-medium text-slate-300 hover:text-white">
            Log in
          </Link>
          <Link
            to="/signup"
            className="rounded-md bg-accent px-4 py-2 text-sm font-semibold text-pitch-950 hover:bg-accent-dim"
          >
            Start Analysis
          </Link>
        </div>
      </header>

      <section className="mx-auto max-w-3xl px-6 py-20 text-center md:py-32">
        <h1 className="text-4xl font-extrabold tracking-tight md:text-6xl">eFootball AI Coach</h1>
        <p className="mt-6 text-lg text-slate-400">
          Upload your gameplay. Understand your decisions. Play smarter.
        </p>
        <div className="mt-10 flex justify-center gap-4">
          <Link
            to="/signup"
            className="rounded-md bg-accent px-6 py-3 text-sm font-semibold text-pitch-950 hover:bg-accent-dim"
          >
            Start Analysis
          </Link>
          <a
            href="#how-it-works"
            className="rounded-md border border-pitch-700 px-6 py-3 text-sm font-semibold text-slate-200 hover:bg-pitch-800"
          >
            See How It Works
          </a>
        </div>
      </section>

      <section id="how-it-works" className="mx-auto grid max-w-5xl grid-cols-1 gap-6 px-6 pb-24 md:grid-cols-3">
        {features.map((f) => (
          <div key={f.title} className="rounded-xl border border-pitch-700 bg-pitch-900 p-6">
            <h3 className="font-semibold text-accent">{f.title}</h3>
            <p className="mt-2 text-sm text-slate-400">{f.desc}</p>
          </div>
        ))}
      </section>
    </div>
  );
}
