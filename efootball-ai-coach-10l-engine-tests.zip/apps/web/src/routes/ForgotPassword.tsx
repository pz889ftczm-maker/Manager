import { useState } from "react";
import { Link } from "react-router-dom";
import { useAuth } from "../hooks/useAuth";

export function ForgotPassword() {
  const { requestPasswordReset } = useAuth();
  const [email, setEmail] = useState("");
  const [sent, setSent] = useState(false);
  const [error, setError] = useState<string | null>(null);

  async function handleSubmit(e: React.FormEvent) {
    e.preventDefault();
    const { error } = await requestPasswordReset(email);
    if (error) setError(error);
    else setSent(true);
  }

  return (
    <div className="flex min-h-screen items-center justify-center bg-pitch-950 px-4">
      <form onSubmit={handleSubmit} className="w-full max-w-sm rounded-xl border border-pitch-700 bg-pitch-900 p-8">
        <h1 className="mb-6 text-xl font-bold text-slate-100">Reset password</h1>
        {sent ? (
          <p className="text-sm text-slate-400">If that email exists, a reset link is on its way.</p>
        ) : (
          <>
            {error && <p className="mb-4 rounded-md bg-danger/10 px-3 py-2 text-sm text-danger">{error}</p>}
            <label className="mb-1 block text-sm text-slate-400">Email</label>
            <input
              type="email"
              required
              value={email}
              onChange={(e) => setEmail(e.target.value)}
              className="mb-6 w-full rounded-md border border-pitch-700 bg-pitch-800 px-3 py-2 text-sm text-slate-100 focus:border-accent focus:outline-none"
            />
            <button
              type="submit"
              className="w-full rounded-md bg-accent py-2 text-sm font-semibold text-pitch-950 hover:bg-accent-dim"
            >
              Send reset link
            </button>
          </>
        )}
        <p className="mt-4 text-center text-sm text-slate-400">
          <Link to="/login" className="text-accent hover:underline">
            Back to login
          </Link>
        </p>
      </form>
    </div>
  );
}
