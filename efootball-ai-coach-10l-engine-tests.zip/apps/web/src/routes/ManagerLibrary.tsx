import { useEffect, useRef, useState } from "react";
import { useAuth } from "../hooks/useAuth";
import { uploadManagerImage, deleteManagerImage, getManagerImageSignedUrl } from "../lib/managerImageStorage";
import { requestManagerCardExtraction } from "../lib/managerCardExtraction";
import { saveManagerLibraryEntry, listManagerLibrary } from "../lib/managerLibrary";
import {
  DEFAULT_MAX_IMAGE_MB,
  validateManagerLibraryInput,
  type ManagerCardDraft,
  type ManagerCardFieldEvidence,
  type ManagerLibrary,
} from "@efootball/shared";

// Batch 6B-4 — Manager Card Review/Edit/Save flow ONLY (see the batch
// spec: no manager picker, no Team Library, no Team Profile, no
// formation changes, no historical snapshots). Flow:
//
//   Upload Manager Card -> AI extraction draft -> Review/Edit
//   -> user confirms/corrects values -> Save Manager -> manager_library
//
// AI extraction is only ever a draft — this component never writes
// anything to manager_library itself; saveManagerLibraryEntry (->
// manager-library-save Edge Function) is the one path that does, and
// only after the user explicitly presses Save. Editing an already-saved
// entry is deliberately fields-only in this batch — the original
// manager image is shown but not replaced/re-extracted here, so an edit
// can never be silently overwritten by a fresh AI read.

const MAX_MANAGER_IMAGE_MB = Number(import.meta.env.VITE_MAX_IMAGE_UPLOAD_MB ?? DEFAULT_MAX_IMAGE_MB);

type View = "list" | "review";
type ReviewSource = "draft" | "existing";
type UploadPhase = "idle" | "uploading" | "extracting" | "error";

interface FormState {
  name: string;
  possession_rating: string; // "" means unknown — never displayed/stored as 0
  quick_counter_rating: string;
  long_ball_counter_rating: string;
  out_wide_rating: string;
  long_ball_rating: string;
}

function emptyForm(): FormState {
  return {
    name: "",
    possession_rating: "",
    quick_counter_rating: "",
    long_ball_counter_rating: "",
    out_wide_rating: "",
    long_ball_rating: "",
  };
}

function draftToForm(draft: ManagerCardDraft): FormState {
  return {
    name: draft.name ?? "",
    possession_rating: draft.possession_rating == null ? "" : String(draft.possession_rating),
    quick_counter_rating: draft.quick_counter_rating == null ? "" : String(draft.quick_counter_rating),
    long_ball_counter_rating: draft.long_ball_counter_rating == null ? "" : String(draft.long_ball_counter_rating),
    out_wide_rating: draft.out_wide_rating == null ? "" : String(draft.out_wide_rating),
    long_ball_rating: draft.long_ball_rating == null ? "" : String(draft.long_ball_rating),
  };
}

function libraryEntryToForm(entry: ManagerLibrary): FormState {
  return {
    name: entry.name ?? "",
    possession_rating: entry.possession_rating == null ? "" : String(entry.possession_rating),
    quick_counter_rating: entry.quick_counter_rating == null ? "" : String(entry.quick_counter_rating),
    long_ball_counter_rating: entry.long_ball_counter_rating == null ? "" : String(entry.long_ball_counter_rating),
    out_wide_rating: entry.out_wide_rating == null ? "" : String(entry.out_wide_rating),
    long_ball_rating: entry.long_ball_rating == null ? "" : String(entry.long_ball_rating),
  };
}

/** "" -> null (unknown, never coerced to 0); anything else -> Number(...)
 * so validateManagerLibraryInput can reject a non-numeric entry itself
 * rather than this silently swallowing it. */
function ratingFieldToValue(raw: string): number | null {
  return raw.trim() === "" ? null : Number(raw);
}

export function ManagerLibraryPage() {
  const { user } = useAuth();

  const [view, setView] = useState<View>("list");
  const [managers, setManagers] = useState<ManagerLibrary[]>([]);
  const [listLoading, setListLoading] = useState(true);
  const [listError, setListError] = useState<string | null>(null);

  const [uploadPhase, setUploadPhase] = useState<UploadPhase>("idle");
  const [uploadError, setUploadError] = useState<string | null>(null);

  const [reviewSource, setReviewSource] = useState<ReviewSource>("draft");
  const [editingId, setEditingId] = useState<string | null>(null);
  // Only set for a fresh draft (the image this session just uploaded).
  // Left null when editing an existing entry — its image is shown via
  // imageSignedUrl below but is never re-sent/re-touched on save.
  const [draftImagePath, setDraftImagePath] = useState<string | null>(null);
  const [imageSignedUrl, setImageSignedUrl] = useState<string | null>(null);
  const [draftMeta, setDraftMeta] = useState<{
    confidence: number | null;
    evidence: ManagerCardFieldEvidence[];
  } | null>(null);
  const [form, setForm] = useState<FormState>(emptyForm());
  const [saving, setSaving] = useState(false);
  const [saveError, setSaveError] = useState<string | null>(null);

  const fileInputRef = useRef<HTMLInputElement>(null);

  useEffect(() => {
    if (user) void refreshList();
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [user]);

  async function refreshList() {
    setListLoading(true);
    setListError(null);
    try {
      const rows = await listManagerLibrary();
      setManagers(rows);
    } catch (err) {
      setListError((err as Error).message);
    } finally {
      setListLoading(false);
    }
  }

  async function handleFileSelected(e: React.ChangeEvent<HTMLInputElement>) {
    const file = e.target.files?.[0];
    e.target.value = ""; // allow re-selecting the same file on a retry
    if (!file || !user) return;

    setUploadError(null);
    setUploadPhase("uploading");
    try {
      const { objectPath } = await uploadManagerImage(file, user.id);

      setUploadPhase("extracting");
      const { draft } = await requestManagerCardExtraction({ objectPath });

      const signedUrl = await getManagerImageSignedUrl(objectPath);

      setReviewSource("draft");
      setEditingId(null);
      setDraftImagePath(objectPath);
      setImageSignedUrl(signedUrl);
      setDraftMeta({ confidence: draft.extraction_confidence, evidence: draft.field_evidence });
      setForm(draftToForm(draft));
      setSaveError(null);
      setUploadPhase("idle");
      setView("review");
    } catch (err) {
      setUploadError((err as Error).message);
      setUploadPhase("error");
    }
  }

  function startEdit(entry: ManagerLibrary) {
    setReviewSource("existing");
    setEditingId(entry.id);
    setDraftImagePath(null); // editing never replaces the stored image in this batch
    setDraftMeta(null);
    setForm(libraryEntryToForm(entry));
    setSaveError(null);
    setImageSignedUrl(null);
    if (entry.manager_image_path) {
      getManagerImageSignedUrl(entry.manager_image_path)
        .then(setImageSignedUrl)
        .catch(() => setImageSignedUrl(null));
    }
    setView("review");
  }

  function resetReviewState() {
    setDraftImagePath(null);
    setImageSignedUrl(null);
    setDraftMeta(null);
    setEditingId(null);
    setForm(emptyForm());
    setSaveError(null);
  }

  async function handleCancel() {
    // A brand-new (not-yet-saved) upload leaves its manager image in
    // storage unless we clean it up — editing an existing entry never
    // uploaded anything new this session, so there's nothing to remove.
    if (reviewSource === "draft" && draftImagePath && user) {
      try {
        await deleteManagerImage(draftImagePath, user.id);
      } catch {
        // best-effort cleanup only — never block navigation on it
      }
    }
    resetReviewState();
    setView("list");
  }

  async function handleSave() {
    setSaveError(null);

    // Client-side pre-check with the SAME shared validator the server
    // re-runs as the actual authority — early feedback only, never the
    // final word.
    const { sanitized, errors } = validateManagerLibraryInput({
      name: form.name.trim() || null,
      possession_rating: ratingFieldToValue(form.possession_rating),
      quick_counter_rating: ratingFieldToValue(form.quick_counter_rating),
      long_ball_counter_rating: ratingFieldToValue(form.long_ball_counter_rating),
      out_wide_rating: ratingFieldToValue(form.out_wide_rating),
      long_ball_rating: ratingFieldToValue(form.long_ball_rating),
      manager_image_path: null, // not evaluated here — see payload construction below
    });

    if (errors.length > 0) {
      setSaveError(errors.join(" "));
      return;
    }

    setSaving(true);
    try {
      // Duplicate saves are recovered server-side and returned as an
      // ordinary success (result.duplicate === true) — deliberately no
      // special-cased UI here, so an accidental double-click/retry just
      // looks like a normal save.
      await saveManagerLibraryEntry({
        ...(editingId ? { id: editingId } : {}),
        name: sanitized.name,
        possession_rating: sanitized.possession_rating,
        quick_counter_rating: sanitized.quick_counter_rating,
        long_ball_counter_rating: sanitized.long_ball_counter_rating,
        out_wide_rating: sanitized.out_wide_rating,
        long_ball_rating: sanitized.long_ball_rating,
        // Omit the key entirely when editing an existing entry, so the
        // Edge Function leaves its already-saved image untouched; always
        // include it for a brand-new entry from a fresh upload.
        ...(reviewSource === "draft" ? { manager_image_path: draftImagePath } : {}),
      });
      resetReviewState();
      setView("list");
      await refreshList();
    } catch (err) {
      setSaveError((err as Error).message);
    } finally {
      setSaving(false);
    }
  }

  if (!user) return null;

  const ratingFields: Array<{ key: keyof FormState; label: string }> = [
    { key: "possession_rating", label: "Possession" },
    { key: "quick_counter_rating", label: "Quick Counter" },
    { key: "long_ball_counter_rating", label: "Long Ball Counter" },
    { key: "out_wide_rating", label: "Out Wide" },
    { key: "long_ball_rating", label: "Long Ball" },
  ];

  return (
    <div className="mx-auto max-w-xl">
      {view === "list" && (
        <div>
          <h1 className="mb-6 text-2xl font-bold">Manager Library</h1>

          <label className="mb-6 block">
            <span className="mb-1 block text-sm text-slate-400">
              Add a manager card (max {MAX_MANAGER_IMAGE_MB}MB — JPEG, PNG, or WEBP)
            </span>
            <input
              ref={fileInputRef}
              type="file"
              accept="image/png,image/jpeg,image/webp"
              onChange={handleFileSelected}
              disabled={uploadPhase === "uploading" || uploadPhase === "extracting"}
              className="w-full rounded-md border border-dashed border-pitch-700 bg-pitch-800 px-3 py-6 text-sm text-slate-400 disabled:opacity-50"
            />
          </label>

          {uploadPhase === "uploading" && <p className="mb-4 text-sm text-slate-400">Uploading manager image…</p>}
          {uploadPhase === "extracting" && <p className="mb-4 text-sm text-slate-400">Reading card…</p>}
          {uploadError && <p className="mb-4 rounded-md bg-danger/10 px-3 py-2 text-sm text-danger">{uploadError}</p>}

          {listLoading ? (
            <p className="text-slate-400">Loading your managers…</p>
          ) : listError ? (
            <p className="rounded-md bg-danger/10 px-3 py-2 text-sm text-danger">{listError}</p>
          ) : managers.length === 0 ? (
            <p className="text-slate-400">No saved managers yet — upload a card above to add your first one.</p>
          ) : (
            <ul className="space-y-2">
              {managers.map((m) => (
                <li
                  key={m.id}
                  className="flex items-center justify-between rounded-md border border-pitch-700 bg-pitch-800 px-4 py-3"
                >
                  <div>
                    <div className="font-medium text-slate-100">{m.name ?? "Unnamed manager"}</div>
                    <div className="text-xs text-slate-400">
                      {[
                        m.possession_rating != null ? `Possession ${m.possession_rating}` : "Possession unknown",
                        m.long_ball_rating != null ? `Long Ball ${m.long_ball_rating}` : "Long Ball unknown",
                      ].join(" · ")}
                    </div>
                  </div>
                  <button
                    onClick={() => startEdit(m)}
                    className="rounded-md border border-pitch-700 px-3 py-1.5 text-sm text-slate-300 hover:border-accent"
                  >
                    Edit
                  </button>
                </li>
              ))}
            </ul>
          )}
        </div>
      )}

      {view === "review" && (
        <div>
          <h1 className="mb-6 text-2xl font-bold">
            {reviewSource === "draft" ? "Review Manager Card" : "Edit Manager"}
          </h1>

          {imageSignedUrl && (
            <img
              src={imageSignedUrl}
              alt="Manager card"
              className="mb-4 max-h-64 w-auto rounded-md border border-pitch-700"
            />
          )}

          {reviewSource === "draft" && draftMeta && (
            <p className="mb-4 text-xs text-slate-400">
              {draftMeta.confidence != null ? `Extraction confidence: ${draftMeta.confidence}%` : "Extraction confidence: unknown"}
              {draftMeta.evidence.some((e) => !e.visible) && (
                <> — {draftMeta.evidence.filter((e) => !e.visible).length} field(s) not visible on the card</>
              )}
            </p>
          )}

          <label className="mb-1 block text-sm text-slate-400">Name</label>
          <input
            value={form.name}
            onChange={(e) => setForm((f) => ({ ...f, name: e.target.value }))}
            placeholder="Unknown"
            className="mb-4 w-full rounded-md border border-pitch-700 bg-pitch-800 px-3 py-2 text-sm text-slate-100"
          />

          {ratingFields.map(({ key, label }) => (
            <div key={key}>
              <label className="mb-1 block text-sm text-slate-400">{label}</label>
              <input
                type="number"
                inputMode="numeric"
                value={form[key]}
                onChange={(e) => setForm((f) => ({ ...f, [key]: e.target.value }))}
                placeholder="Unknown"
                className="mb-4 w-full rounded-md border border-pitch-700 bg-pitch-800 px-3 py-2 text-sm text-slate-100"
              />
            </div>
          ))}

          {saveError && <p className="mb-4 rounded-md bg-danger/10 px-3 py-2 text-sm text-danger">{saveError}</p>}

          <div className="flex gap-2">
            <button
              onClick={handleSave}
              disabled={saving}
              className="flex-1 rounded-md bg-accent py-3 text-sm font-semibold text-pitch-950 hover:bg-accent-dim disabled:opacity-50"
            >
              {saving ? "Saving…" : "Save Manager"}
            </button>
            <button
              onClick={handleCancel}
              disabled={saving}
              className="rounded-md border border-pitch-700 px-4 py-3 text-sm text-slate-300 hover:border-accent disabled:opacity-50"
            >
              Cancel
            </button>
          </div>
        </div>
      )}
    </div>
  );
}
