import { useEffect, useRef, useState } from "react";
import { useAuth } from "../hooks/useAuth";
import { uploadTeamImage, deleteTeamImage } from "../lib/teamImageStorage";
import { listTeamLibrary, getTeamLibraryEntry, createTeam, updateTeam, deleteTeam } from "../lib/teamLibrary";
import { listTeamMembers, addTeamMember, removeTeamMember, isDuplicateTeamMember } from "../lib/teamMembers";
import { assignTeamManager, clearTeamManager } from "../lib/teamManager";
import { listPlayerLibrary } from "../lib/playerLibrary";
import { listManagerLibrary } from "../lib/managerLibrary";
import { getPlayerCardSignedUrl } from "../lib/playerCardStorage";
import { TeamImage } from "../components/TeamImage";
import { ManagerImage } from "../components/ManagerImage";
import { ManagerPicker } from "../components/ManagerPicker";
import { PlayerPickerModal } from "../components/PlayerPickerModal";
import {
  DEFAULT_MAX_IMAGE_MB,
  validateTeamLibraryInput,
  toFormationManagerRef,
  getFormationManagerDisplay,
  isPathOwnedByUser,
  type TeamLibrary,
  type TeamMember,
  type PlayerLibrary,
  type ManagerLibrary,
} from "@efootball/shared";

// Batch 7E — the real Team Library UI (final UI batch for Phase 7). No
// Formation/Team Presets here (out of scope — see the batch spec) —
// this is create/view/edit/delete for team_library rows plus managing
// a team's current roster (team_members, 0019) and manager assignment
// (team_library.manager_id, 0020) ONLY. Everything below reads/writes
// through the existing RLS-scoped helpers (teamLibrary.ts/
// teamMembers.ts/teamManager.ts/teamImageStorage.ts) — no client-supplied
// user_id anywhere, no mock/demo/hardcoded team data, and RLS remains
// the actual authorization boundary regardless of what's checked here.

const MAX_TEAM_IMAGE_MB = Math.min(Number(import.meta.env.VITE_MAX_IMAGE_UPLOAD_MB ?? DEFAULT_MAX_IMAGE_MB), 15);

type View = "list" | "form" | "detail";
type FormMode = "create" | "edit";
type UploadPhase = "idle" | "uploading" | "error";

interface FormState {
  name: string;
  motto: string;
  description: string;
  founded_year: string; // "" means unknown — never displayed/stored as 0
  stadium: string;
}

function emptyForm(): FormState {
  return { name: "", motto: "", description: "", founded_year: "", stadium: "" };
}

function teamToForm(team: TeamLibrary): FormState {
  return {
    name: team.name,
    motto: team.motto ?? "",
    description: team.description ?? "",
    founded_year: team.founded_year == null ? "" : String(team.founded_year),
    stadium: team.stadium ?? "",
  };
}

/** A single roster row — the team_members junction row joined (client-side,
 * never duplicated into a table — spec section 5) with its player_library
 * details for display. */
function RosterRow({
  member,
  player,
  userId,
  onRemove,
  removing,
}: {
  member: TeamMember;
  player: PlayerLibrary | undefined;
  userId: string;
  onRemove: () => void;
  removing: boolean;
}) {
  const [signedUrl, setSignedUrl] = useState<string | null>(null);
  const [imageStatus, setImageStatus] = useState<"idle" | "loading" | "loaded" | "error">("idle");

  useEffect(() => {
    let cancelled = false;
    const path = player?.player_card_image_path ?? null;
    if (!path || !isPathOwnedByUser(path, userId)) {
      setImageStatus("idle");
      return;
    }
    setImageStatus("loading");
    getPlayerCardSignedUrl(path)
      .then((url) => {
        if (cancelled) return;
        setSignedUrl(url);
        setImageStatus("loaded");
      })
      .catch(() => {
        if (!cancelled) setImageStatus("error");
      });
    return () => {
      cancelled = true;
    };
  }, [player?.player_card_image_path, userId]);

  return (
    <li className="flex items-center justify-between gap-3 rounded-md border border-pitch-700 bg-pitch-800 px-4 py-3">
      <div className="flex min-w-0 items-center gap-3">
        <span className="flex h-10 w-10 shrink-0 items-center justify-center overflow-hidden rounded-md border border-pitch-700 bg-pitch-900 text-[10px] text-slate-500">
          {imageStatus === "loaded" && signedUrl ? (
            <img src={signedUrl} alt="" className="h-full w-full object-cover" />
          ) : imageStatus === "loading" ? (
            "…"
          ) : (
            "No image"
          )}
        </span>
        <div className="min-w-0">
          <div className="truncate font-medium text-slate-100">
            {player ? player.name ?? "Unnamed player" : "Player unavailable"}
          </div>
          <div className="truncate text-xs text-slate-400">
            {player
              ? [
                  player.position ?? "Position unknown",
                  player.overall != null ? `OVR ${player.overall}` : "OVR unknown",
                  player.playstyle ?? null,
                ]
                  .filter(Boolean)
                  .join(" · ")
              : "This player may have been removed from your Player Library."}
          </div>
        </div>
      </div>
      <button
        onClick={onRemove}
        disabled={removing}
        className="shrink-0 rounded-md border border-pitch-700 px-3 py-1.5 text-xs text-slate-300 hover:border-danger hover:text-danger disabled:opacity-50"
      >
        {removing ? "Removing…" : "Remove"}
      </button>
    </li>
  );
}

export function TeamLibraryPage() {
  const { user } = useAuth();

  const [view, setView] = useState<View>("list");
  const [teams, setTeams] = useState<TeamLibrary[]>([]);
  const [listLoading, setListLoading] = useState(true);
  const [listError, setListError] = useState<string | null>(null);
  const [deletingId, setDeletingId] = useState<string | null>(null);
  const [listActionError, setListActionError] = useState<string | null>(null);

  // ---- create/edit form state ----
  const [formMode, setFormMode] = useState<FormMode>("create");
  const [formTeamId, setFormTeamId] = useState<string | null>(null);
  const [returnView, setReturnView] = useState<View>("list");
  const [form, setForm] = useState<FormState>(emptyForm());
  const [formImagePath, setFormImagePath] = useState<string | null>(null);
  const [formOriginalImagePath, setFormOriginalImagePath] = useState<string | null>(null);
  const [formUploadPhase, setFormUploadPhase] = useState<UploadPhase>("idle");
  const [formUploadError, setFormUploadError] = useState<string | null>(null);
  const [saving, setSaving] = useState(false);
  const [saveError, setSaveError] = useState<string | null>(null);
  const fileInputRef = useRef<HTMLInputElement>(null);

  // ---- detail view state ----
  const [detailTeam, setDetailTeam] = useState<TeamLibrary | null>(null);
  const [detailLoading, setDetailLoading] = useState(false);
  const [detailError, setDetailError] = useState<string | null>(null);

  const [members, setMembers] = useState<TeamMember[]>([]);
  const [membersLoading, setMembersLoading] = useState(false);
  const [membersError, setMembersError] = useState<string | null>(null);
  const [removingMemberId, setRemovingMemberId] = useState<string | null>(null);

  const [playerLibrary, setPlayerLibrary] = useState<PlayerLibrary[]>([]);
  const [playerLibraryLoading, setPlayerLibraryLoading] = useState(false);
  const [playerLibraryError, setPlayerLibraryError] = useState<string | null>(null);
  const [showAddPlayer, setShowAddPlayer] = useState(false);
  const [addPlayerError, setAddPlayerError] = useState<string | null>(null);

  const [managerLibrary, setManagerLibrary] = useState<ManagerLibrary[]>([]);
  const [managerLibraryLoading, setManagerLibraryLoading] = useState(false);
  const [managerLibraryError, setManagerLibraryError] = useState<string | null>(null);
  const [showManagerPicker, setShowManagerPicker] = useState(false);
  const [managerActionError, setManagerActionError] = useState<string | null>(null);
  const [managerActionBusy, setManagerActionBusy] = useState(false);

  useEffect(() => {
    if (user) void refreshList();
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [user]);

  async function refreshList() {
    setListLoading(true);
    setListError(null);
    try {
      const rows = await listTeamLibrary();
      setTeams(rows);
    } catch (err) {
      setListError((err as Error).message);
    } finally {
      setListLoading(false);
    }
  }

  // ============================================================
  // Create / Edit form
  // ============================================================

  function openCreateForm(from: View) {
    setFormMode("create");
    setFormTeamId(null);
    setReturnView(from);
    setForm(emptyForm());
    setFormImagePath(null);
    setFormOriginalImagePath(null);
    setFormUploadError(null);
    setFormUploadPhase("idle");
    setSaveError(null);
    setView("form");
  }

  function openEditForm(team: TeamLibrary, from: View) {
    setFormMode("edit");
    setFormTeamId(team.id);
    setReturnView(from);
    setForm(teamToForm(team));
    setFormImagePath(team.team_image_path);
    setFormOriginalImagePath(team.team_image_path);
    setFormUploadError(null);
    setFormUploadPhase("idle");
    setSaveError(null);
    setView("form");
  }

  async function handleFormImageSelected(e: React.ChangeEvent<HTMLInputElement>) {
    const file = e.target.files?.[0];
    e.target.value = ""; // allow re-selecting the same file on a retry
    if (!file || !user) return;

    // Replacing an existing image: upload the new object first, only
    // then drop the old path from form state — if the upload fails we
    // still have the original path intact (spec: "upload a new safe
    // path... update team_image_path").
    setFormUploadError(null);
    setFormUploadPhase("uploading");
    try {
      const { objectPath } = await uploadTeamImage(file, user.id);
      // A previous NEW (not-yet-saved-to-a-row) upload this same
      // session, now superseded, is cleaned up rather than left orphaned.
      if (formImagePath && formImagePath !== formOriginalImagePath) {
        deleteTeamImage(formImagePath, user.id).catch(() => {});
      }
      setFormImagePath(objectPath);
      setFormUploadPhase("idle");
    } catch (err) {
      setFormUploadError((err as Error).message);
      setFormUploadPhase("error");
    }
  }

  function handleFormImageRemove() {
    // If this was a fresh (not-yet-saved) upload this session, clean it
    // up immediately rather than leaving it orphaned in storage.
    if (formImagePath && formImagePath !== formOriginalImagePath && user) {
      deleteTeamImage(formImagePath, user.id).catch(() => {});
    }
    setFormImagePath(null);
  }

  async function handleFormCancel() {
    // A brand-new (not-yet-saved) upload this session leaves an orphan
    // object in storage unless cleaned up here.
    if (formImagePath && formImagePath !== formOriginalImagePath && user) {
      try {
        await deleteTeamImage(formImagePath, user.id);
      } catch {
        // best-effort cleanup only — never block navigation on it
      }
    }
    setView(returnView);
  }

  async function handleFormSave() {
    setSaveError(null);

    const { sanitized, errors } = validateTeamLibraryInput({
      name: form.name.trim(),
      motto: form.motto.trim() || null,
      description: form.description.trim() || null,
      founded_year: form.founded_year.trim() === "" ? null : Number(form.founded_year),
      stadium: form.stadium.trim() || null,
      team_image_path: formImagePath,
      manager_id: null, // manager assignment is managed separately (Team Detail), never touched by this form
    });

    if (errors.length > 0) {
      setSaveError(errors.join(" "));
      return;
    }

    setSaving(true);
    try {
      if (formMode === "create") {
        const result = await createTeam({
          name: sanitized.name,
          motto: sanitized.motto,
          description: sanitized.description,
          founded_year: sanitized.founded_year,
          stadium: sanitized.stadium,
          team_image_path: sanitized.team_image_path,
        });
        await refreshList();
        setView("list");
        if (!result.duplicate) {
          // nothing further — new team is now visible in the list
        }
      } else if (formTeamId) {
        const previousImagePath = formOriginalImagePath;
        await updateTeam(formTeamId, {
          name: sanitized.name,
          motto: sanitized.motto,
          description: sanitized.description,
          founded_year: sanitized.founded_year,
          stadium: sanitized.stadium,
          team_image_path: sanitized.team_image_path,
        });
        // Clean up the old image object only after the row itself was
        // successfully repointed away from it.
        if (previousImagePath && previousImagePath !== sanitized.team_image_path && user) {
          deleteTeamImage(previousImagePath, user.id).catch(() => {});
        }
        await refreshList();
        if (returnView === "detail") {
          await openDetailById(formTeamId);
        } else {
          setView("list");
        }
      }
    } catch (err) {
      setSaveError((err as Error).message);
    } finally {
      setSaving(false);
    }
  }

  // ============================================================
  // Team Detail — profile, roster, manager
  // ============================================================

  async function openDetailById(teamId: string) {
    setView("detail");
    setDetailLoading(true);
    setDetailError(null);
    try {
      const team = await getTeamLibraryEntry(teamId);
      setDetailTeam(team);
      if (team) {
        await refreshMembers(team.id);
      }
    } catch (err) {
      setDetailError((err as Error).message);
    } finally {
      setDetailLoading(false);
    }
  }

  async function refreshMembers(teamId: string) {
    setMembersLoading(true);
    setMembersError(null);
    try {
      const rows = await listTeamMembers(teamId);
      setMembers(rows);
      await ensurePlayerLibraryLoaded();
    } catch (err) {
      setMembersError((err as Error).message);
    } finally {
      setMembersLoading(false);
    }
  }

  async function ensurePlayerLibraryLoaded() {
    if (playerLibrary.length > 0 || playerLibraryLoading) return;
    setPlayerLibraryLoading(true);
    setPlayerLibraryError(null);
    try {
      const rows = await listPlayerLibrary();
      setPlayerLibrary(rows);
    } catch (err) {
      setPlayerLibraryError((err as Error).message);
    } finally {
      setPlayerLibraryLoading(false);
    }
  }

  async function ensureManagerLibraryLoaded() {
    if (managerLibrary.length > 0 || managerLibraryLoading) return;
    setManagerLibraryLoading(true);
    setManagerLibraryError(null);
    try {
      const rows = await listManagerLibrary();
      setManagerLibrary(rows);
    } catch (err) {
      setManagerLibraryError((err as Error).message);
    } finally {
      setManagerLibraryLoading(false);
    }
  }

  async function handleAddPlayer(player: PlayerLibrary) {
    if (!detailTeam) return;
    setAddPlayerError(null);
    try {
      const result = await addTeamMember(detailTeam.id, player.id);
      if (!result.duplicate) {
        await refreshMembers(detailTeam.id);
      }
      // A duplicate add (already on this team) is a normal, silent
      // no-op here — the roster already reflects it, nothing to change.
      setShowAddPlayer(false);
    } catch (err) {
      if (isDuplicateTeamMember(err)) {
        setShowAddPlayer(false);
      } else {
        setAddPlayerError((err as Error).message);
      }
    }
  }

  async function handleRemoveMember(member: TeamMember) {
    if (!detailTeam) return;
    if (!window.confirm("Remove this player from the team? This does not delete them from your Player Library.")) {
      return;
    }
    setRemovingMemberId(member.id);
    setMembersError(null);
    try {
      await removeTeamMember(member.id);
      setMembers((prev) => prev.filter((m) => m.id !== member.id));
    } catch (err) {
      setMembersError((err as Error).message);
    } finally {
      setRemovingMemberId(null);
    }
  }

  async function handleAssignManager(manager: ManagerLibrary) {
    if (!detailTeam) return;
    setManagerActionError(null);
    setManagerActionBusy(true);
    try {
      const updated = await assignTeamManager(detailTeam.id, manager.id);
      setDetailTeam(updated);
      setShowManagerPicker(false);
    } catch (err) {
      setManagerActionError((err as Error).message);
    } finally {
      setManagerActionBusy(false);
    }
  }

  async function handleClearManager() {
    if (!detailTeam) return;
    setManagerActionError(null);
    setManagerActionBusy(true);
    try {
      const updated = await clearTeamManager(detailTeam.id);
      setDetailTeam(updated);
      setShowManagerPicker(false);
    } catch (err) {
      setManagerActionError((err as Error).message);
    } finally {
      setManagerActionBusy(false);
    }
  }

  async function handleDeleteTeam(team: TeamLibrary, from: View) {
    if (!window.confirm(`Delete "${team.name}"? This cannot be undone. Your players and managers are not deleted.`)) {
      return;
    }
    setDeletingId(team.id);
    setListActionError(null);
    setDetailError(null);
    try {
      await deleteTeam(team.id);
      if (team.team_image_path && user) {
        deleteTeamImage(team.team_image_path, user.id).catch(() => {});
      }
      await refreshList();
      if (from === "detail") {
        setDetailTeam(null);
        setView("list");
      }
    } catch (err) {
      if (from === "detail") {
        setDetailError((err as Error).message);
      } else {
        setListActionError((err as Error).message);
      }
    } finally {
      setDeletingId(null);
    }
  }

  if (!user) return null;

  // The team's assigned manager, looked up in the caller's own loaded
  // managerLibrary — never fabricated. If manager_id is set but no
  // matching row is found (not yet loaded, or since deleted/
  // reassigned away), this stays null rather than inventing a
  // placeholder ManagerLibrary object with guessed/blank fields.
  const currentManagerEntry = detailTeam?.manager_id
    ? managerLibrary.find((m) => m.id === detailTeam.manager_id) ?? null
    : null;
  const currentManagerKnown = currentManagerEntry !== null;
  const currentManagerRef = currentManagerEntry ? toFormationManagerRef(currentManagerEntry) : null;
  const currentManagerDisplay = getFormationManagerDisplay(currentManagerRef);

  const memberById = new Map(playerLibrary.map((p) => [p.id, p] as const));
  const assignedPlayerIds = new Set(members.map((m) => m.player_id));

  return (
    <div className="mx-auto max-w-2xl">
      {/* ============================================================ */}
      {/* LIST VIEW */}
      {/* ============================================================ */}
      {view === "list" && (
        <div>
          <div className="mb-6 flex items-center justify-between">
            <h1 className="text-2xl font-bold">Team Library</h1>
            <button
              onClick={() => openCreateForm("list")}
              className="rounded-md bg-accent px-4 py-2 text-sm font-semibold text-pitch-950 hover:bg-accent-dim"
            >
              + Create Team
            </button>
          </div>

          {listActionError && (
            <p className="mb-4 rounded-md bg-danger/10 px-3 py-2 text-sm text-danger">{listActionError}</p>
          )}

          {listLoading ? (
            <p className="text-slate-400">Loading your teams…</p>
          ) : listError ? (
            <p className="rounded-md bg-danger/10 px-3 py-2 text-sm text-danger">{listError}</p>
          ) : teams.length === 0 ? (
            <p className="text-slate-400">No saved teams yet — create your first one above.</p>
          ) : (
            <ul className="space-y-2">
              {teams.map((t) => (
                <li key={t.id} className="rounded-md border border-pitch-700 bg-pitch-800 px-4 py-3">
                  <div className="flex items-center gap-3">
                    <TeamImage
                      imagePath={t.team_image_path}
                      userId={user.id}
                      className="h-12 w-12 shrink-0 rounded-md object-cover"
                      fallback="No logo"
                    />
                    <button
                      onClick={() => openDetailById(t.id)}
                      className="min-w-0 flex-1 text-left"
                      title="View team"
                    >
                      <div className="truncate font-medium text-slate-100">{t.name}</div>
                      <div className="truncate text-xs text-slate-400">
                        {[t.motto, t.stadium].filter(Boolean).join(" · ") || "No motto or stadium set"}
                      </div>
                    </button>
                    <div className="flex shrink-0 gap-2">
                      <button
                        onClick={() => openEditForm(t, "list")}
                        className="rounded-md border border-pitch-700 px-3 py-1.5 text-xs text-slate-300 hover:border-accent"
                      >
                        Edit
                      </button>
                      <button
                        onClick={() => handleDeleteTeam(t, "list")}
                        disabled={deletingId === t.id}
                        className="rounded-md border border-pitch-700 px-3 py-1.5 text-xs text-slate-300 hover:border-danger hover:text-danger disabled:opacity-50"
                      >
                        {deletingId === t.id ? "Deleting…" : "Delete"}
                      </button>
                    </div>
                  </div>
                </li>
              ))}
            </ul>
          )}
        </div>
      )}

      {/* ============================================================ */}
      {/* CREATE / EDIT FORM */}
      {/* ============================================================ */}
      {view === "form" && (
        <div>
          <h1 className="mb-6 text-2xl font-bold">{formMode === "create" ? "Create Team" : "Edit Team"}</h1>

          <div className="mb-4 flex items-center gap-4">
            {formImagePath ? (
              <TeamImage
                imagePath={formImagePath}
                userId={user.id}
                className="h-20 w-20 rounded-md object-cover"
                fallback="No logo"
              />
            ) : (
              <span className="flex h-20 w-20 items-center justify-center rounded-md border border-dashed border-pitch-700 bg-pitch-900 text-[11px] text-slate-500">
                No logo
              </span>
            )}
            <div className="flex flex-col gap-2">
              <label className="cursor-pointer rounded-md border border-pitch-700 px-3 py-1.5 text-xs text-slate-300 hover:border-accent">
                {formImagePath ? "Change image" : "Upload image"}
                <input
                  ref={fileInputRef}
                  type="file"
                  accept="image/png,image/jpeg,image/webp"
                  onChange={handleFormImageSelected}
                  disabled={formUploadPhase === "uploading"}
                  className="hidden"
                />
              </label>
              {formImagePath && (
                <button
                  onClick={handleFormImageRemove}
                  className="rounded-md border border-pitch-700 px-3 py-1.5 text-xs text-slate-300 hover:border-danger hover:text-danger"
                >
                  Remove image
                </button>
              )}
              <span className="text-[11px] text-slate-500">Max {MAX_TEAM_IMAGE_MB}MB — JPEG, PNG, or WEBP</span>
            </div>
          </div>
          {formUploadPhase === "uploading" && <p className="mb-4 text-sm text-slate-400">Uploading team image…</p>}
          {formUploadError && (
            <p className="mb-4 rounded-md bg-danger/10 px-3 py-2 text-sm text-danger">{formUploadError}</p>
          )}

          <label className="mb-1 block text-sm text-slate-400">Name (required)</label>
          <input
            value={form.name}
            onChange={(e) => setForm((f) => ({ ...f, name: e.target.value }))}
            placeholder="Team name"
            className="mb-4 w-full rounded-md border border-pitch-700 bg-pitch-800 px-3 py-2 text-sm text-slate-100"
          />

          <label className="mb-1 block text-sm text-slate-400">Motto</label>
          <input
            value={form.motto}
            onChange={(e) => setForm((f) => ({ ...f, motto: e.target.value }))}
            placeholder="Unknown"
            className="mb-4 w-full rounded-md border border-pitch-700 bg-pitch-800 px-3 py-2 text-sm text-slate-100"
          />

          <label className="mb-1 block text-sm text-slate-400">Description</label>
          <textarea
            value={form.description}
            onChange={(e) => setForm((f) => ({ ...f, description: e.target.value }))}
            placeholder="Unknown"
            rows={3}
            className="mb-4 w-full rounded-md border border-pitch-700 bg-pitch-800 px-3 py-2 text-sm text-slate-100"
          />

          <label className="mb-1 block text-sm text-slate-400">Founded Year</label>
          <input
            type="number"
            inputMode="numeric"
            value={form.founded_year}
            onChange={(e) => setForm((f) => ({ ...f, founded_year: e.target.value }))}
            placeholder="Unknown"
            className="mb-4 w-full rounded-md border border-pitch-700 bg-pitch-800 px-3 py-2 text-sm text-slate-100"
          />

          <label className="mb-1 block text-sm text-slate-400">Stadium</label>
          <input
            value={form.stadium}
            onChange={(e) => setForm((f) => ({ ...f, stadium: e.target.value }))}
            placeholder="Unknown"
            className="mb-4 w-full rounded-md border border-pitch-700 bg-pitch-800 px-3 py-2 text-sm text-slate-100"
          />

          {saveError && <p className="mb-4 rounded-md bg-danger/10 px-3 py-2 text-sm text-danger">{saveError}</p>}

          <div className="flex gap-2">
            <button
              onClick={handleFormSave}
              disabled={saving || formUploadPhase === "uploading"}
              className="flex-1 rounded-md bg-accent py-3 text-sm font-semibold text-pitch-950 hover:bg-accent-dim disabled:opacity-50"
            >
              {saving ? "Saving…" : "Save Team"}
            </button>
            <button
              onClick={handleFormCancel}
              disabled={saving}
              className="rounded-md border border-pitch-700 px-4 py-3 text-sm text-slate-300 hover:border-accent disabled:opacity-50"
            >
              Cancel
            </button>
          </div>
        </div>
      )}

      {/* ============================================================ */}
      {/* TEAM DETAIL */}
      {/* ============================================================ */}
      {view === "detail" && (
        <div>
          <button onClick={() => setView("list")} className="mb-4 text-sm text-slate-400 hover:text-accent">
            ← Back to Team Library
          </button>

          {detailLoading ? (
            <p className="text-slate-400">Loading team…</p>
          ) : detailError ? (
            <p className="rounded-md bg-danger/10 px-3 py-2 text-sm text-danger">{detailError}</p>
          ) : !detailTeam ? (
            <p className="text-slate-400">This team could not be found.</p>
          ) : (
            <div>
              <div className="mb-6 flex items-start gap-4">
                <TeamImage
                  imagePath={detailTeam.team_image_path}
                  userId={user.id}
                  className="h-20 w-20 shrink-0 rounded-md object-cover"
                  fallback="No logo"
                />
                <div className="min-w-0 flex-1">
                  <h1 className="truncate text-2xl font-bold">{detailTeam.name}</h1>
                  <p className="text-sm text-slate-400">{detailTeam.motto ?? "No motto set"}</p>
                </div>
                <div className="flex shrink-0 gap-2">
                  <button
                    onClick={() => openEditForm(detailTeam, "detail")}
                    className="rounded-md border border-pitch-700 px-3 py-1.5 text-xs text-slate-300 hover:border-accent"
                  >
                    Edit
                  </button>
                  <button
                    onClick={() => handleDeleteTeam(detailTeam, "detail")}
                    disabled={deletingId === detailTeam.id}
                    className="rounded-md border border-pitch-700 px-3 py-1.5 text-xs text-slate-300 hover:border-danger hover:text-danger disabled:opacity-50"
                  >
                    {deletingId === detailTeam.id ? "Deleting…" : "Delete"}
                  </button>
                </div>
              </div>

              <div className="mb-6 grid grid-cols-2 gap-4 text-sm sm:grid-cols-4">
                <div>
                  <div className="text-xs text-slate-500">Founded</div>
                  <div className="text-slate-200">{detailTeam.founded_year ?? "Unknown"}</div>
                </div>
                <div>
                  <div className="text-xs text-slate-500">Stadium</div>
                  <div className="text-slate-200">{detailTeam.stadium ?? "Unknown"}</div>
                </div>
                <div>
                  <div className="text-xs text-slate-500">Players</div>
                  <div className="text-slate-200">{membersLoading ? "…" : members.length}</div>
                </div>
              </div>

              {detailTeam.description && (
                <p className="mb-6 whitespace-pre-wrap text-sm text-slate-300">{detailTeam.description}</p>
              )}

              {/* ---- Manager ---- */}
              <div className="mb-6 rounded-md border border-pitch-700 bg-pitch-800 p-4">
                <div className="mb-3 flex items-center justify-between">
                  <h2 className="text-sm font-semibold text-slate-100">Manager</h2>
                  <button
                    onClick={() => {
                      void ensureManagerLibraryLoaded();
                      setManagerActionError(null);
                      setShowManagerPicker(true);
                    }}
                    className="text-xs text-accent hover:underline"
                  >
                    {detailTeam.manager_id ? "Change" : "Assign manager"}
                  </button>
                </div>
                {detailTeam.manager_id ? (
                  <div className="flex items-center gap-3">
                    <ManagerImage
                      manager={currentManagerRef}
                      userId={user.id}
                      className="h-12 w-12 rounded-full object-cover"
                      fallback="No image"
                    />
                    <div className="min-w-0">
                      <div className="truncate text-sm text-slate-100">
                        {currentManagerKnown ? currentManagerDisplay.displayName : "Manager unavailable"}
                      </div>
                      {currentManagerKnown && (
                        <div className="truncate text-xs text-slate-400">
                          {currentManagerDisplay.possessionLabel} · {currentManagerDisplay.longBallLabel}
                        </div>
                      )}
                    </div>
                    <button
                      onClick={handleClearManager}
                      disabled={managerActionBusy}
                      className="ml-auto shrink-0 rounded-md border border-pitch-700 px-3 py-1.5 text-xs text-slate-300 hover:border-danger hover:text-danger disabled:opacity-50"
                    >
                      Clear
                    </button>
                  </div>
                ) : (
                  <p className="text-sm text-slate-400">No manager assigned.</p>
                )}
                {managerActionError && <p className="mt-2 text-xs text-danger">{managerActionError}</p>}
              </div>

              {/* ---- Players ---- */}
              <div className="rounded-md border border-pitch-700 bg-pitch-800 p-4">
                <div className="mb-3 flex items-center justify-between">
                  <h2 className="text-sm font-semibold text-slate-100">Players</h2>
                  <button
                    onClick={() => {
                      void ensurePlayerLibraryLoaded();
                      setAddPlayerError(null);
                      setShowAddPlayer(true);
                    }}
                    className="text-xs text-accent hover:underline"
                  >
                    + Add Player
                  </button>
                </div>

                {addPlayerError && <p className="mb-2 text-xs text-danger">{addPlayerError}</p>}

                {membersLoading ? (
                  <p className="text-sm text-slate-400">Loading roster…</p>
                ) : membersError ? (
                  <p className="rounded-md bg-danger/10 px-3 py-2 text-sm text-danger">{membersError}</p>
                ) : members.length === 0 ? (
                  <p className="text-sm text-slate-400">
                    No players on this team yet — add one from your Player Library above.
                  </p>
                ) : (
                  <ul className="space-y-2">
                    {members.map((m) => (
                      <RosterRow
                        key={m.id}
                        member={m}
                        player={memberById.get(m.player_id)}
                        userId={user.id}
                        onRemove={() => handleRemoveMember(m)}
                        removing={removingMemberId === m.id}
                      />
                    ))}
                  </ul>
                )}
              </div>
            </div>
          )}
        </div>
      )}

      {showAddPlayer && (
        <>
          {playerLibraryLoading ? (
            <div className="fixed inset-0 z-20 flex items-center justify-center bg-black/60">
              <p className="text-sm text-slate-300">Loading your players…</p>
            </div>
          ) : playerLibraryError ? (
            <div
              className="fixed inset-0 z-20 flex items-center justify-center bg-black/60"
              onClick={() => setShowAddPlayer(false)}
            >
              <p className="rounded-md bg-pitch-900 px-4 py-3 text-sm text-danger">{playerLibraryError}</p>
            </div>
          ) : playerLibrary.length === 0 ? (
            <div
              className="fixed inset-0 z-20 flex items-center justify-center bg-black/60"
              onClick={() => setShowAddPlayer(false)}
            >
              <p className="rounded-md bg-pitch-900 px-4 py-3 text-sm text-slate-300">
                No saved players yet — add some in Player Library first.
              </p>
            </div>
          ) : (
            <PlayerPickerModal
              players={playerLibrary}
              assignedIds={assignedPlayerIds}
              onPick={handleAddPlayer}
              onClose={() => setShowAddPlayer(false)}
            />
          )}
        </>
      )}

      {showManagerPicker && (
        <ManagerPicker
          managers={managerLibrary}
          loading={managerLibraryLoading}
          error={managerLibraryError}
          selectedId={detailTeam?.manager_id ?? null}
          userId={user.id}
          onPick={handleAssignManager}
          onClear={detailTeam?.manager_id ? handleClearManager : undefined}
          onClose={() => setShowManagerPicker(false)}
        />
      )}
    </div>
  );
}
