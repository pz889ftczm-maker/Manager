import { Link } from "react-router-dom";
import { useDashboardData } from "../hooks/useDashboardData";

function StatCard({ label, value }: { label: string; value: string | number }) {
  return (
    <div className="rounded-xl border border-pitch-700 bg-pitch-900 p-5">
      <div className="text-xs uppercase tracking-wide text-slate-500">{label}</div>
      <div className="mt-1 text-2xl font-bold text-slate-100">{value}</div>
    </div>
  );
}

export function Dashboard() {
  const { isDemo, recentMatches, progress, loading } = useDashboardData();

  if (loading) return <div className="text-slate-400">Loading dashboard…</div>;

  const latestScore = recentMatches[0]?.overall_score;

  return (
    <div>
      <div className="mb-6 flex items-center justify-between">
        <h1 className="text-2xl font-bold">Dashboard</h1>
        <Link to="/analyze" className="rounded-md bg-accent px-4 py-2 text-sm font-semibold text-pitch-950">
          New Analysis
        </Link>
      </div>

      {isDemo && (
        <div className="mb-6 rounded-md border border-warn/40 bg-warn/10 px-4 py-2 text-sm text-warn">
          Showing demo data — analyze a real match to replace this with your own stats.
        </div>
      )}

      <div className="grid grid-cols-2 gap-4 md:grid-cols-4">
        <StatCard label="Overall Decision Score" value={latestScore != null ? Math.round(Number(latestScore)) : "—"} />
        <StatCard label="Matches Analyzed" value={progress?.matches_analyzed ?? recentMatches.length} />
        <StatCard label="Biggest Weakness" value={progress?.biggest_weakness ?? "—"} />
        <StatCard label="Most Common Mistake" value={progress?.most_common_mistake ?? "—"} />
      </div>

      <h2 className="mb-3 mt-8 text-lg font-semibold">Recent Matches</h2>
      <div className="space-y-2">
        {recentMatches.length === 0 && <p className="text-sm text-slate-500">No matches yet.</p>}
        {recentMatches.map((m) => (
          <Link
            key={m.id}
            to={`/matches/${m.id}`}
            className="flex items-center justify-between rounded-lg border border-pitch-700 bg-pitch-900 px-4 py-3 hover:border-accent"
          >
            <div>
              <div className="font-medium">{m.title ?? "Untitled match"}</div>
              <div className="text-xs text-slate-500">{m.status}</div>
            </div>
            <div className="text-lg font-bold text-accent">
              {m.overall_score != null ? Math.round(Number(m.overall_score)) : "—"}
            </div>
          </Link>
        ))}
      </div>
    </div>
  );
}
