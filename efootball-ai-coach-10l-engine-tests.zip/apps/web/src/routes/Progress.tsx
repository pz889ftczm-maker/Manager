import { useEffect, useState } from "react";
import { LineChart, Line, XAxis, YAxis, CartesianGrid, Tooltip, ResponsiveContainer } from "recharts";
import { supabase } from "../lib/supabaseClient";
import { useAuth } from "../hooks/useAuth";
import type { PlayerProgress } from "@efootball/shared";
import { PERCENTAGE_FIELDS } from "@efootball/shared";

const PLAYER_STAT_TREND_LABELS: Record<string, string> = {
  pass_completion_percentage: "Passing",
  successful_dribbles: "Successful Dribbles",
  dribble_success_percentage: "Dribbling",
  possession_losses: "Possession Loss",
  duel_win_percentage: "Duel Win Rate",
  tackles: "Tackles",
  interceptions: "Interceptions",
  shots: "Shots",
  goals: "Goals",
  assists: "Assists",
};

// A field is "good when up" for almost every tracked stat except
// possession losses, where fewer is better — so the up/down arrow below
// flips direction only for that one field rather than always meaning
// "up = green".
const LOWER_IS_BETTER = new Set(["possession_losses"]);

function formatTrendValue(field: string, value: number): string {
  return PERCENTAGE_FIELDS.has(field) ? `${value.toFixed(1)}%` : value % 1 === 0 ? `${value}` : value.toFixed(1);
}

/** Real-data-only direction: compares the average of the earlier half of
 * the field's actual recorded points against the later half — never
 * interpolates or assumes a trend from a single data point (the caller
 * already only reaches here with 2+ real points, per
 * computePlayerStatTrends in packages/shared/src/progress.ts). Returns the
 * RAW numeric direction the value moved (up/down/flat); whether that
 * movement is "good" depends on the field (see LOWER_IS_BETTER, used only
 * for color, not for flipping the arrow itself). */
function trendDirection(points: { value: number }[]): "up" | "down" | "flat" {
  const mid = Math.ceil(points.length / 2);
  const earlier = points.slice(0, mid).map((p) => p.value);
  const recent = (points.slice(mid).length > 0 ? points.slice(mid) : points.slice(-1)).map((p) => p.value);
  const earlierAvg = earlier.reduce((s, v) => s + v, 0) / earlier.length;
  const recentAvg = recent.reduce((s, v) => s + v, 0) / recent.length;
  const delta = recentAvg - earlierAvg;
  if (Math.abs(delta) < 0.5) return "flat";
  return delta > 0 ? "up" : "down";
}

export function Progress() {
  const { user } = useAuth();
  const [progress, setProgress] = useState<PlayerProgress | null>(null);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    if (!user) return;
    supabase
      .from("player_progress")
      .select("*")
      .eq("user_id", user.id)
      .maybeSingle()
      .then(({ data }) => {
        setProgress(data ?? null);
        setLoading(false);
      });
  }, [user]);

  if (loading) return <div className="text-slate-400">Loading progress…</div>;

  if (!progress || !progress.overall_trend || progress.overall_trend.length === 0) {
    return (
      <div>
        <h1 className="mb-6 text-2xl font-bold">Progress</h1>
        <p className="text-sm text-slate-500">
          Analyze a few matches to start seeing your improvement trend here. Progress needs at least a
          couple of completed matches to be meaningful.
        </p>
      </div>
    );
  }

  const chartData = progress.overall_trend.map((t, i) => ({
    match: `M${i + 1}`,
    score: t.overall_score,
  }));

  return (
    <div>
      <h1 className="mb-6 text-2xl font-bold">Progress</h1>

      <div className="mb-8 h-64 rounded-lg border border-pitch-700 bg-pitch-900 p-4">
        <ResponsiveContainer width="100%" height="100%">
          <LineChart data={chartData}>
            <CartesianGrid stroke="#1e2b23" />
            <XAxis dataKey="match" stroke="#64748b" fontSize={12} />
            <YAxis domain={[0, 100]} stroke="#64748b" fontSize={12} />
            <Tooltip contentStyle={{ background: "#151f19", border: "1px solid #1e2b23" }} />
            <Line type="monotone" dataKey="score" stroke="#22c55e" strokeWidth={2} dot={{ r: 3 }} />
          </LineChart>
        </ResponsiveContainer>
      </div>

      <div className="grid grid-cols-1 gap-4 md:grid-cols-3">
        <InfoCard label="Most Improved Skill" value={progress.most_improved_skill} />
        <InfoCard label="Biggest Remaining Weakness" value={progress.biggest_weakness} />
        <InfoCard
          label="Recommended Position"
          value={progress.recommended_position}
          sublabel={
            progress.recommended_position && progress.recommended_position_confidence != null
              ? `${Math.round(progress.recommended_position_confidence)}% confidence`
              : undefined
          }
        />
      </div>

      {progress.player_stat_trends && Object.keys(progress.player_stat_trends).length > 0 && (
        <div className="mt-8">
          <h2 className="mb-2 text-sm font-semibold text-slate-300">Individual Statistics</h2>
          <div className="grid grid-cols-2 gap-4 md:grid-cols-4">
            {Object.entries(progress.player_stat_trends).map(([field, points]) => {
              if (points.length === 0) return null;
              const latest = points[points.length - 1].value;
              const direction = trendDirection(points);
              const goodWhenUp = !LOWER_IS_BETTER.has(field);
              const isGood = direction === "flat" ? null : direction === "up" ? goodWhenUp : !goodWhenUp;
              const arrow = direction === "up" ? "↑" : direction === "down" ? "↓" : "→";
              const colorClass =
                isGood === null ? "text-slate-300" : isGood ? "text-accent" : "text-rose-400";
              return (
                <div key={field} className="rounded-lg border border-pitch-700 bg-pitch-900 p-4">
                  <div className="text-xs uppercase tracking-wide text-slate-500">
                    {PLAYER_STAT_TREND_LABELS[field] ?? field.replace(/_/g, " ")}
                  </div>
                  <div className={`mt-1 text-lg font-semibold ${colorClass}`}>
                    {formatTrendValue(field, latest)} {arrow}
                  </div>
                </div>
              );
            })}
          </div>
          {progress.player_stat_trends_insufficient && progress.player_stat_trends_insufficient.length > 0 && (
            <p className="mt-3 text-xs text-slate-500">
              Not enough real match history yet for:{" "}
              {progress.player_stat_trends_insufficient
                .map((f) => PLAYER_STAT_TREND_LABELS[f] ?? f.replace(/_/g, " "))
                .join(", ")}
              .
            </p>
          )}
        </div>
      )}

      {progress.recommended_position && progress.recommended_position_evidence && (
        <ul className="mt-2 list-disc pl-5 text-xs text-slate-500">
          {progress.recommended_position_evidence.map((line, i) => (
            <li key={i}>{line}</li>
          ))}
        </ul>
      )}

      {progress.most_common_mistake && progress.mistake_analysis?.most_common && (
        <p className="mt-4 text-xs text-slate-500">
          Most common mistake: <span className="text-slate-300">{progress.most_common_mistake.replace(/_/g, " ")}</span> —
          seen {progress.mistake_analysis.most_common.occurrences} time
          {progress.mistake_analysis.most_common.occurrences === 1 ? "" : "s"} across{" "}
          {progress.mistake_analysis.most_common.matches_count} match
          {progress.mistake_analysis.most_common.matches_count === 1 ? "" : "es"}.
        </p>
      )}

      {progress.playstyle_tags && progress.playstyle_tags.length > 0 && (
        <div className="mt-6">
          <h2 className="mb-2 text-sm font-semibold text-slate-300">Playstyle</h2>
          <div className="flex flex-wrap gap-2">
            {progress.playstyle_tags.map((tag) => (
              <span
                key={tag}
                title={progress.playstyle_evidence?.[tag]}
                className="rounded-full bg-accent/10 px-3 py-1 text-xs font-medium text-accent"
              >
                {tag.replace(/_/g, " ")}
              </span>
            ))}
          </div>
        </div>
      )}

      {progress.insufficient_data && progress.insufficient_data.length > 0 && (
        <p className="mt-6 text-xs text-slate-500">
          Not enough match history yet to reliably compute:{" "}
          {progress.insufficient_data.map((d) => d.replace(/_/g, " ")).join(", ")}. Analyze more matches to unlock
          these.
        </p>
      )}
    </div>
  );
}

function InfoCard({ label, value, sublabel }: { label: string; value: string | null; sublabel?: string }) {
  return (
    <div className="rounded-lg border border-pitch-700 bg-pitch-900 p-4">
      <div className="text-xs uppercase tracking-wide text-slate-500">{label}</div>
      <div className="mt-1 text-lg font-semibold">{value ?? "Not enough data yet"}</div>
      {sublabel && <div className="mt-0.5 text-xs text-slate-500">{sublabel}</div>}
    </div>
  );
}
