import { useState } from "react";
import { Link, useNavigate } from "react-router-dom";
import { useAuth } from "../hooks/useAuth";

export function SignUp() {
  const { signUp } = useAuth();
  const navigate = useNavigate();
  const [displayName, setDisplayName] = useState("");
  const [email, setEmail] = useState("");
  const [password, setPassword] = useState("");
  const [error, setError] = useState<string | null>(null);
  const [submitting, setSubmitting] = useState(false);
  const [checkEmail, setCheckEmail] = useState(false);

  async function handleSubmit(e: React.FormEvent) {
    e.preventDefault();
    setSubmitting(true);
    setError(null);
    const { error } = await signUp(email, password, displayName);
    setSubmitting(false);
    if (error) setError(error);
    else setCheckEmail(true); // Supabase default: email confirmation required before session exists
  }

  if (checkEmail) {
    return (
      <div className="flex min-h-screen items-center justify-center bg-pitch-950 px-4 text-center">
        <div>
          <h1 className="mb-2 text-xl font-bold">Check your email</h1>
          <p className="text-slate-400">Confirm your address, then log in to start your first analysis.</p>
          <Link to="/login" className="mt-4 inline-block text-accent hover:underline">
            Go to login
          </Link>
        </div>
      </div>
    );
  }

  return (
    <div className="flex min-h-screen items-center justify-center bg-pitch-950 px-4">
      <form onSubmit={handleSubmit} className="w-full max-w-sm rounded-xl border border-pitch-700 bg-pitch-900 p-8">
        <h1 className="mb-6 text-xl font-bold text-slate-100">Create your account</h1>

        {error && <p className="mb-4 rounded-md bg-danger/10 px-3 py-2 text-sm text-danger">{error}</p>}

        <label className="mb-1 block text-sm text-slate-400">Display name</label>
        <input
          required
          value={displayName}
          onChange={(e) => setDisplayName(e.target.value)}
          className="mb-4 w-full rounded-md border border-pitch-700 bg-pitch-800 px-3 py-2 text-sm text-slate-100 focus:border-accent focus:outline-none"
        />

        <label className="mb-1 block text-sm text-slate-400">Email</label>
        <input
          type="email"
          required
          value={email}
          onChange={(e) => setEmail(e.target.value)}
          className="mb-4 w-full rounded-md border border-pitch-700 bg-pitch-800 px-3 py-2 text-sm text-slate-100 focus:border-accent focus:outline-none"
        />

        <label className="mb-1 block text-sm text-slate-400">Password</label>
        <input
          type="password"
          required
          minLength={8}
          value={password}
          onChange={(e) => setPassword(e.target.value)}
          className="mb-6 w-full rounded-md border border-pitch-700 bg-pitch-800 px-3 py-2 text-sm text-slate-100 focus:border-accent focus:outline-none"
        />

        <button
          type="submit"
          disabled={submitting}
          className="w-full rounded-md bg-accent py-2 text-sm font-semibold text-pitch-950 hover:bg-accent-dim disabled:opacity-50"
        >
          {submitting ? "Creating account…" : "Sign up"}
        </button>

        <p className="mt-4 text-center text-sm text-slate-400">
          Already have an account?{" "}
          <Link to="/login" className="text-accent hover:underline">
            Log in
          </Link>
        </p>
      </form>
    </div>
  );
}
