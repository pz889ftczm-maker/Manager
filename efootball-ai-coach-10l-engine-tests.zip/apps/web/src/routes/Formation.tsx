import { useEffect, useMemo, useRef, useState } from "react";
import { useAuth } from "../hooks/useAuth";
import { listPlayerLibrary } from "../lib/playerLibrary";
import { listManagerLibrary } from "../lib/managerLibrary";
import { listTeamLibrary } from "../lib/teamLibrary";
import {
  listTeamFormations,
  createTeamFormation,
  updateTeamFormation,
  isDuplicateFormationName,
} from "../lib/teamFormations";
import {
  listFormationPlayers,
  assignPlayerToFormationSlot,
  removePlayerFromFormation,
} from "../lib/teamFormationPlayers";
import {
  listTeamFormationPresets,
  saveFormationAsPreset,
  applyFormationPreset,
  renameTeamFormationPreset,
  deleteTeamFormationPreset,
} from "../lib/teamFormationPresets";
import { mapFormationError } from "../lib/formationErrors";
import { PlayerCardSlot } from "../components/PlayerCardSlot";
import { PlayerPickerModal } from "../components/PlayerPickerModal";
import { ManagerPicker } from "../components/ManagerPicker";
import { ManagerImage } from "../components/ManagerImage";
import {
  toFormationPlayerRef,
  type FormationPlayerRef,
  type PlayerLibrary,
  toFormationManagerRef,
  getFormationManagerDisplay,
  type FormationManagerRef,
  type ManagerLibrary,
  type TeamLibrary,
  type TeamFormation,
  type TeamFormationPlayer,
  type TeamFormationPreset,
  normalizePositions,
  type NormalizedPosition,
} from "@efootball/shared";

// Batch 8C — Formation Persistence UI. Wires the previously session-
// only assignment UI (Batch 6A-5/6B-5) onto the real, persisted data
// model built in 8A (team_formations)/8B (team_formation_players)/8C
// (the formation_id+position_slot uniqueness fix + the CRUD/
// orchestration helpers this page now calls). Player assignment now
// survives a page refresh — the one thing every prior Formation batch
// explicitly deferred.
//
// Scope kept deliberately narrow, matching every prior Formation
// batch's own restraint: this does NOT add a drag-and-drop layout
// editor, formation presets, or a way to design a custom pitch layout
// — team_formations.positions is real and persisted, and every
// formation this page CREATES still uses the same fixed 4-3-3 layout
// (FORMATION_433 below) that 6A-5 already used as a UI-only constant.
//
// 8C quick-fix — the one gap that WAS added here: a plain form-based
// editor (name/formation_code/positions/tactical_instructions) wired
// to the previously-unused updateTeamFormation. It's a list of
// editable rows (id/role/x/y), not a drag-and-drop pitch — the
// minimum practical UI the spec calls for — but it's a real,
// authoritative edit: whatever's in the form is exactly what's sent to
// `positions`, and the pitch below always renders whatever the
// formation's `positions` currently holds (via normalizePositions),
// so a 4-3-3 is a starting point here, never the only representable
// layout.
//
// Team selection is current-page React state, same "session, not
// persisted" convention 6B-5 used for manager selection — nothing
// about WHICH team is currently being viewed is written anywhere;
// only the formation and its assignments are.

interface SlotDef {
  id: string;
  label: string;
  x: number;
  y: number;
}

// The same fixed 4-3-3 layout Batch 6A-5 introduced as UI-only state —
// now also what gets written into a newly-created formation's
// `positions` column, so a slot's persisted position_slot id
// (team_formation_players.position_slot) always matches one of this
// layout's ids exactly.
const FORMATION_433: SlotDef[] = [
  { id: "gk", label: "GK", x: 50, y: 92 },
  { id: "lb", label: "LB", x: 15, y: 75 },
  { id: "cb1", label: "CB", x: 35, y: 78 },
  { id: "cb2", label: "CB", x: 65, y: 78 },
  { id: "rb", label: "RB", x: 85, y: 75 },
  { id: "cm1", label: "CM", x: 28, y: 55 },
  { id: "cm2", label: "CM", x: 50, y: 58 },
  { id: "cm3", label: "CM", x: 72, y: 55 },
  { id: "lw", label: "LW", x: 18, y: 25 },
  { id: "st", label: "ST", x: 50, y: 18 },
  { id: "rw", label: "RW", x: 82, y: 25 },
];

/** What createTeamFormation persists for a brand-new formation's
 * `positions` — array-shaped (matches validatePositions' array shape),
 * one entry per FORMATION_433 slot, role used as the on-pitch label. */
const DEFAULT_POSITIONS = FORMATION_433.map((slot) => ({
  id: slot.id,
  role: slot.label,
  x: slot.x / 100,
  y: slot.y / 100,
}));

/** Turns a formation's normalized positions back into this page's
 * SlotDef shape (percentage x/y, falling back to the slot id itself as
 * a label when a stored entry has no role — e.g. a role-keyed map
 * formation with a blank value). Positions with no x/y at all are
 * skipped: this page renders slots on a 2D pitch, so a slot lacking
 * layout coordinates has nothing to render at. */
function toSlotDefs(positions: NormalizedPosition[]): SlotDef[] {
  return positions
    .filter((p) => p.x != null && p.y != null)
    .map((p) => ({
      id: p.id,
      label: p.role ?? p.id,
      x: (p.x as number) * 100,
      y: (p.y as number) * 100,
    }));
}

export function Formation() {
  const { user } = useAuth();

  // ------------------------------------------------------------
  // Team selection (current-page state only — see header comment).
  // ------------------------------------------------------------
  const [teams, setTeams] = useState<TeamLibrary[]>([]);
  const [teamsLoading, setTeamsLoading] = useState(true);
  const [teamsError, setTeamsError] = useState<string | null>(null);
  const [selectedTeamId, setSelectedTeamId] = useState<string | null>(null);

  // Batch 8E — team-scoped request epoch. Bumped exactly once per
  // selectedTeamId change, BEFORE any effect below captures it, so
  // every async load triggered by/for a given team can tell whether
  // it's still the current team by the time it resolves. A late
  // response for a team the user has since navigated away from is
  // simply ignored rather than clobbering the now-current team's
  // state (spec section 11 — "Team A loading → switch to Team B →
  // Team A results must not overwrite Team B state"). Deliberately a
  // plain ref counter, not a state-management library.
  const teamEpochRef = useRef(0);
  useEffect(() => {
    teamEpochRef.current += 1;
  }, [selectedTeamId]);

  useEffect(() => {
    if (!user) return;
    setTeamsLoading(true);
    setTeamsError(null);
    listTeamLibrary()
      .then((rows) => {
        setTeams(rows);
        setSelectedTeamId((prev) => prev ?? rows[0]?.id ?? null);
      })
      .catch((err) => setTeamsError((err as Error).message))
      .finally(() => setTeamsLoading(false));
  }, [user]);

  // ------------------------------------------------------------
  // Formation load/create for the selected team.
  // ------------------------------------------------------------
  const [formation, setFormation] = useState<TeamFormation | null>(null);
  const [formationLoading, setFormationLoading] = useState(false);
  const [formationError, setFormationError] = useState<string | null>(null);
  const [creatingFormation, setCreatingFormation] = useState(false);

  useEffect(() => {
    if (!selectedTeamId) {
      setFormation(null);
      return;
    }
    const epoch = teamEpochRef.current; // already bumped for this team by the effect above
    setFormationLoading(true);
    setFormationError(null);
    listTeamFormations(selectedTeamId)
      .then((rows) => {
        if (teamEpochRef.current !== epoch) return; // a newer team was selected meanwhile
        setFormation(rows[0] ?? null); // most recently updated first
      })
      .catch((err) => {
        if (teamEpochRef.current !== epoch) return;
        setFormationError(mapFormationError(err, "loadFormations"));
      })
      .finally(() => {
        if (teamEpochRef.current !== epoch) return;
        setFormationLoading(false);
      });
  }, [selectedTeamId]);

  async function createDefaultFormation() {
    if (!selectedTeamId) return;
    setCreatingFormation(true);
    setFormationError(null);
    try {
      const { formation: created } = await createTeamFormation({
        team_id: selectedTeamId,
        name: "Default",
        formation_code: "4-3-3",
        positions: DEFAULT_POSITIONS,
        tactical_instructions: null,
      });
      setFormation(created);
    } catch (err) {
      // isDuplicateFormationName is a structural check (Postgres error
      // code + constraint name), not a read of the error's message, so
      // this specific-but-still-generic string is safe to show even
      // though it isn't routed through mapFormationError.
      setFormationError(
        isDuplicateFormationName(err)
          ? 'This team already has a formation named "Default".'
          : mapFormationError(err, "save")
      );
    } finally {
      setCreatingFormation(false);
    }
  }

  const slots = useMemo(
    () => (formation ? toSlotDefs(normalizePositions(formation.positions)) : []),
    [formation]
  );

  // ------------------------------------------------------------
  // 8C quick-fix — Formation editing (name / formation_code /
  // positions / tactical_instructions), wired to updateTeamFormation.
  // ------------------------------------------------------------
  interface EditablePositionRow {
    /** Local-only React key so rows can be reordered/removed without
     * fighting the `id` field, which the user is free to edit (it's the
     * actual persisted slot id). */
    key: string;
    id: string;
    role: string;
    x: string;
    y: string;
  }

  const [editingFormation, setEditingFormation] = useState(false);
  const [editName, setEditName] = useState("");
  const [editCode, setEditCode] = useState("");
  const [editTactical, setEditTactical] = useState("");
  const [editPositions, setEditPositions] = useState<EditablePositionRow[]>([]);
  const [savingFormation, setSavingFormation] = useState(false);
  const [editFormationError, setEditFormationError] = useState<string | null>(null);
  // A monotonically increasing counter (not component state — it must
  // never trigger or be reset by a re-render) used only to generate
  // stable, always-unique React `key`s for editable position rows,
  // independent of the user-editable `id` field on each row.
  const rowKeyCounter = useRef(0);
  function nextRowKey(): string {
    rowKeyCounter.current += 1;
    return `row-${rowKeyCounter.current}`;
  }

  /** Loads `formation`'s current persisted values into the edit form —
   * called both when the user opens the editor and implicitly kept in
   * sync afterward, since `formation` is always replaced with the
   * actual returned row after a save (never guessed/merged locally). */
  function openFormationEditor() {
    if (!formation) return;
    setEditFormationError(null);
    setEditName(formation.name);
    setEditCode(formation.formation_code);
    setEditTactical(
      formation.tactical_instructions ? JSON.stringify(formation.tactical_instructions, null, 2) : ""
    );
    setEditPositions(
      normalizePositions(formation.positions).map((p) => ({
        key: nextRowKey(),
        id: p.id,
        role: p.role ?? "",
        x: p.x != null ? String(p.x) : "",
        y: p.y != null ? String(p.y) : "",
      }))
    );
    setEditingFormation(true);
  }

  function cancelFormationEdit() {
    setEditingFormation(false);
    setEditFormationError(null);
  }

  function addPositionRow() {
    setEditPositions((prev) => [...prev, { key: nextRowKey(), id: "", role: "", x: "", y: "" }]);
  }

  function removePositionRow(key: string) {
    setEditPositions((prev) => prev.filter((r) => r.key !== key));
  }

  function updatePositionRow(key: string, field: "id" | "role" | "x" | "y", value: string) {
    setEditPositions((prev) => prev.map((r) => (r.key === key ? { ...r, [field]: value } : r)));
  }

  async function saveFormationEdit() {
    if (!formation) return;
    setEditFormationError(null);

    const name = editName.trim();
    const formation_code = editCode.trim();
    if (name.length === 0) {
      setEditFormationError("Formation name cannot be empty.");
      return;
    }
    if (formation_code.length === 0) {
      setEditFormationError("Formation code cannot be empty.");
      return;
    }

    if (editPositions.length === 0) {
      setEditFormationError("A formation needs at least one position.");
      return;
    }

    const seenIds = new Set<string>();
    const positions: Array<{ id: string; role?: string; x?: number; y?: number }> = [];
    for (const row of editPositions) {
      const id = row.id.trim();
      if (id.length === 0) {
        setEditFormationError("Every position needs a slot id (e.g. \"gk\").");
        return;
      }
      if (seenIds.has(id)) {
        setEditFormationError(`Slot id "${id}" is used more than once — slot ids must be unique.`);
        return;
      }
      seenIds.add(id);

      const entry: { id: string; role?: string; x?: number; y?: number } = { id };
      const role = row.role.trim();
      if (role.length > 0) entry.role = role;

      if (row.x.trim().length > 0) {
        const x = Number(row.x);
        if (!Number.isFinite(x) || x < 0 || x > 1) {
          setEditFormationError(`Slot "${id}": x must be a number between 0 and 1.`);
          return;
        }
        entry.x = x;
      }
      if (row.y.trim().length > 0) {
        const y = Number(row.y);
        if (!Number.isFinite(y) || y < 0 || y > 1) {
          setEditFormationError(`Slot "${id}": y must be a number between 0 and 1.`);
          return;
        }
        entry.y = y;
      }

      positions.push(entry);
    }

    let tactical_instructions: Record<string, unknown> | null = null;
    if (editTactical.trim().length > 0) {
      try {
        const parsed = JSON.parse(editTactical);
        if (!parsed || typeof parsed !== "object" || Array.isArray(parsed)) {
          setEditFormationError("Tactical instructions must be a JSON object.");
          return;
        }
        tactical_instructions = parsed as Record<string, unknown>;
      } catch {
        setEditFormationError("Tactical instructions must be valid JSON.");
        return;
      }
    }

    setSavingFormation(true);
    try {
      // team_id is intentionally never sent here — updateTeamFormation's
      // signature has no way to change it, so the currently-persisted
      // team_id is always preserved untouched.
      const updated = await updateTeamFormation(formation.id, {
        name,
        formation_code,
        positions,
        tactical_instructions,
      });
      // Local state is replaced with the actual returned database row,
      // never a locally-assembled guess — so anything the DB itself
      // normalized/defaulted is reflected immediately.
      setFormation(updated);
      setEditingFormation(false);
    } catch (err) {
      setEditFormationError(mapFormationError(err, "save"));
    } finally {
      setSavingFormation(false);
    }
  }

  /** Batch 8E — true when the open Formation editor has changes that
   * haven't been saved yet, compared field-by-field against the
   * currently persisted `formation`. Used only to decide whether
   * applying a Preset needs a confirmation first (spec section 6);
   * it does not itself block or alter Cancel, which already restores
   * persisted values unconditionally. */
  function isFormationEditDirty(): boolean {
    if (!formation || !editingFormation) return false;
    if (editName.trim() !== formation.name) return true;
    if (editCode.trim() !== formation.formation_code) return true;

    const persistedTactical = formation.tactical_instructions
      ? JSON.stringify(formation.tactical_instructions, null, 2)
      : "";
    if (editTactical.trim() !== persistedTactical) return true;

    const persistedPositions = normalizePositions(formation.positions);
    if (editPositions.length !== persistedPositions.length) return true;
    for (let i = 0; i < editPositions.length; i++) {
      const row = editPositions[i];
      const p = persistedPositions[i];
      if (!p) return true;
      if (row.id.trim() !== p.id) return true;
      if (row.role.trim() !== (p.role ?? "")) return true;
      if (row.x.trim() !== (p.x != null ? String(p.x) : "")) return true;
      if (row.y.trim() !== (p.y != null ? String(p.y) : "")) return true;
    }
    return false;
  }

  // ------------------------------------------------------------
  // Player Library (candidates for assignment — unchanged from 6A-5).
  // ------------------------------------------------------------
  const [players, setPlayers] = useState<PlayerLibrary[]>([]);
  const [loading, setLoading] = useState(true);
  const [loadError, setLoadError] = useState<string | null>(null);

  useEffect(() => {
    if (!user) return;
    setLoading(true);
    setLoadError(null);
    listPlayerLibrary()
      .then(setPlayers)
      .catch((err) => setLoadError((err as Error).message))
      .finally(() => setLoading(false));
  }, [user]);

  // ------------------------------------------------------------
  // Persisted assignments for the current formation.
  // ------------------------------------------------------------
  const [assignmentRows, setAssignmentRows] = useState<TeamFormationPlayer[]>([]);
  const [assignmentsLoading, setAssignmentsLoading] = useState(false);
  const [assignmentsError, setAssignmentsError] = useState<string | null>(null);
  const [pickerSlot, setPickerSlot] = useState<string | null>(null);
  const [assigning, setAssigning] = useState(false);

  useEffect(() => {
    if (!formation) {
      setAssignmentRows([]);
      return;
    }
    setAssignmentsLoading(true);
    setAssignmentsError(null);
    listFormationPlayers(formation.id)
      .then(setAssignmentRows)
      .catch((err) => setAssignmentsError(mapFormationError(err, "loadAssignments")))
      .finally(() => setAssignmentsLoading(false));
  }, [formation]);

  const playersById = useMemo(() => new Map(players.map((p) => [p.id, p])), [players]);

  /** slot id -> what to render, resolved from the persisted assignment
   * rows joined against the loaded player library. A slot whose
   * assignment references a player_id not found in `players` renders
   * as unavailable (see PlayerCardSlot's `unavailable` prop) rather
   * than being silently dropped or crashing — see that prop's doc for
   * why this should be rare/transient rather than a normal state. */
  const bySlot = useMemo(() => {
    const map = new Map<string, { ref: FormationPlayerRef | null; unavailable: boolean; rowId: string }>();
    for (const row of assignmentRows) {
      const entry = playersById.get(row.player_id);
      map.set(row.position_slot, {
        ref: entry ? toFormationPlayerRef(entry) : null,
        unavailable: !entry,
        rowId: row.id,
      });
    }
    return map;
  }, [assignmentRows, playersById]);

  const assignedIds = useMemo(
    () => new Set(assignmentRows.map((r) => r.player_id)),
    [assignmentRows]
  );

  // ------------------------------------------------------------
  // Batch 8D — Formation Presets. Presets belong to a TEAM (not a
  // single formation, though today each team only ever has one
  // team_formations row), so they're loaded whenever the selected team
  // changes, independent of formationLoading/formationError above.
  // ------------------------------------------------------------
  const [presets, setPresets] = useState<TeamFormationPreset[]>([]);
  const [presetsLoading, setPresetsLoading] = useState(false);
  const [presetsError, setPresetsError] = useState<string | null>(null);
  const [presetActionError, setPresetActionError] = useState<string | null>(null);
  const [presetWarnings, setPresetWarnings] = useState<string[]>([]);
  const [newPresetName, setNewPresetName] = useState("");
  const [savingPreset, setSavingPreset] = useState(false);
  const [applyingPresetId, setApplyingPresetId] = useState<string | null>(null);
  const [renamingPresetId, setRenamingPresetId] = useState<string | null>(null);
  const [renamePresetValue, setRenamePresetValue] = useState("");
  const [deletingPresetId, setDeletingPresetId] = useState<string | null>(null);

  /** Batch 8E — guarded the same way as the Formation load above: a
   * late-resolving reload for a team the user has since navigated away
   * from is ignored rather than overwriting the current team's preset
   * list. This guard is cheap enough to keep even for the
   * user-triggered call sites below (save/rename/delete) — it's a
   * no-op unless the team actually changed while that request was in
   * flight. */
  function reloadPresets(teamId: string) {
    const epoch = teamEpochRef.current;
    setPresetsLoading(true);
    setPresetsError(null);
    return listTeamFormationPresets(teamId)
      .then((rows) => {
        if (teamEpochRef.current !== epoch) return;
        setPresets(rows);
      })
      .catch((err) => {
        if (teamEpochRef.current !== epoch) return;
        setPresetsError(mapFormationError(err, "loadPresets"));
      })
      .finally(() => {
        if (teamEpochRef.current !== epoch) return;
        setPresetsLoading(false);
      });
  }

  useEffect(() => {
    if (!selectedTeamId) {
      setPresets([]);
      return;
    }
    reloadPresets(selectedTeamId);
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [selectedTeamId]);

  // Batch 8E — clear stale, team-scoped UI/selection state whenever the
  // Team changes: never leave a Preset rename/delete/apply "in
  // progress" for a preset that belonged to the previous team, never
  // leave the Formation editor open with the previous team's Formation
  // loaded into it, and never leave a stale preset-action error/warning
  // or an unrelated formation-editor error on screen. This is separate
  // from (and does not replace) each load effect's own state resets
  // above — this only clears UI selection, never data.
  useEffect(() => {
    setEditingFormation(false);
    setEditFormationError(null);
    setPickerSlot(null);
    setAssignmentsError(null);
    setAssigning(false);
    setPresetActionError(null);
    setPresetWarnings([]);
    setNewPresetName("");
    setRenamingPresetId(null);
    setRenamePresetValue("");
    setApplyingPresetId(null);
    setDeletingPresetId(null);
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [selectedTeamId]);

  async function handleSaveFormationAsPreset() {
    if (!formation) return;
    const name = newPresetName.trim();
    if (name.length === 0) {
      setPresetActionError("Give the preset a name first.");
      return;
    }
    setSavingPreset(true);
    setPresetActionError(null);
    setPresetWarnings([]);
    try {
      const { duplicate, warnings } = await saveFormationAsPreset(formation.id, name);
      if (duplicate) {
        setPresetActionError("A preset with this name already exists.");
      } else {
        setNewPresetName("");
        if (warnings.length > 0) setPresetWarnings(warnings);
      }
      if (selectedTeamId) await reloadPresets(selectedTeamId);
    } catch (err) {
      setPresetActionError(mapFormationError(err, "savePreset"));
    } finally {
      setSavingPreset(false);
    }
  }

  /** Batch 8E — true while any Preset operation (save/apply/rename/
   * delete) is in flight for the current team, regardless of which
   * preset it targets. Used to disable the OTHER preset controls so
   * two Preset writes can never overlap (spec section 6) — the
   * control(s) actually performing the in-flight operation keep their
   * own existing per-row disabled/label state and are not additionally
   * gated by this. */
  const presetOpPending =
    savingPreset || applyingPresetId !== null || deletingPresetId !== null || renamingPresetId !== null;

  async function handleApplyPreset(presetId: string) {
    if (!formation) return;

    // Batch 8E — applying a Preset overwrites this Formation's
    // formation_code/positions/tactical_instructions; if the Formation
    // editor is open with unsaved changes, applying now would silently
    // discard them. Confirm first (spec section 6 — "a simple
    // confirmation", not a full diff/merge UI).
    if (editingFormation) {
      if (isFormationEditDirty()) {
        const proceed = window.confirm(
          "Applying this preset will discard your unsaved formation changes. Continue?"
        );
        if (!proceed) return;
      }
      setEditingFormation(false);
      setEditFormationError(null);
    }

    // Batch 8E quick fix — capture the team epoch NOW, before the first
    // await. applyFormationPreset/listFormationPlayers below can take
    // long enough for the user to switch teams before they resolve; if
    // that happens, teamEpochRef.current will have moved on and every
    // state update below must be skipped rather than overwriting the
    // now-current team's Formation/assignments with the stale team's
    // result (spec section 11).
    const epoch = teamEpochRef.current;

    setApplyingPresetId(presetId);
    setPresetActionError(null);
    setPresetWarnings([]);
    try {
      const { formation: updated, warnings } = await applyFormationPreset(presetId, formation.id);
      if (teamEpochRef.current !== epoch) return; // user switched teams mid-request — discard
      setFormation(updated);
      const rows = await listFormationPlayers(updated.id);
      if (teamEpochRef.current !== epoch) return; // switched again during the second await
      setAssignmentRows(rows);
      if (warnings.length > 0) setPresetWarnings(warnings);
    } catch (err) {
      if (teamEpochRef.current !== epoch) return;
      setPresetActionError(mapFormationError(err, "applyPreset"));
    } finally {
      if (teamEpochRef.current === epoch) setApplyingPresetId(null);
    }
  }

  function startRenamePreset(preset: TeamFormationPreset) {
    setPresetActionError(null);
    setRenamingPresetId(preset.id);
    setRenamePresetValue(preset.name);
  }

  function cancelRenamePreset() {
    setRenamingPresetId(null);
    setRenamePresetValue("");
  }

  async function confirmRenamePreset() {
    if (!renamingPresetId) return;
    const name = renamePresetValue.trim();
    if (name.length === 0) {
      setPresetActionError("Give the preset a name first.");
      return;
    }
    setPresetActionError(null);
    try {
      await renameTeamFormationPreset(renamingPresetId, name);
      if (selectedTeamId) await reloadPresets(selectedTeamId);
      setRenamingPresetId(null);
      setRenamePresetValue("");
    } catch (err) {
      setPresetActionError(mapFormationError(err, "savePreset"));
    }
  }

  async function handleDeletePreset(presetId: string) {
    setDeletingPresetId(presetId);
    setPresetActionError(null);
    try {
      await deleteTeamFormationPreset(presetId);
      if (selectedTeamId) await reloadPresets(selectedTeamId);
    } catch (err) {
      setPresetActionError(mapFormationError(err, "deletePreset"));
    } finally {
      setDeletingPresetId(null);
    }
  }

  // Batch 6B-5 — Manager section state, unchanged: independent of
  // everything above, still current-session/page state (no Team
  // Preset table exists to persist a manager selection into).
  const [managers, setManagers] = useState<ManagerLibrary[]>([]);
  const [managersLoading, setManagersLoading] = useState(true);
  const [managersError, setManagersError] = useState<string | null>(null);
  const [selectedManager, setSelectedManager] = useState<FormationManagerRef | null>(null);
  const [managerPickerOpen, setManagerPickerOpen] = useState(false);

  useEffect(() => {
    if (!user) return;
    setManagersLoading(true);
    setManagersError(null);
    listManagerLibrary()
      .then(setManagers)
      .catch((err) => setManagersError((err as Error).message))
      .finally(() => setManagersLoading(false));
  }, [user]);

  async function assign(slotId: string, entry: PlayerLibrary) {
    if (!formation) return;
    setAssigning(true);
    setAssignmentsError(null);
    try {
      await assignPlayerToFormationSlot(formation.id, entry.id, slotId);
      // Re-fetch rather than optimistically patch local state: a slot
      // assignment can move/displace OTHER rows too (see
      // planFormationSlotAssignment), so a full re-fetch is the
      // simplest way to guarantee this page's view stays exactly in
      // sync with what was actually persisted.
      const rows = await listFormationPlayers(formation.id);
      setAssignmentRows(rows);
    } catch (err) {
      setAssignmentsError(mapFormationError(err, "assign"));
    } finally {
      setAssigning(false);
      setPickerSlot(null);
    }
  }

  async function clear(slotId: string) {
    if (!formation) return;
    const existing = bySlot.get(slotId);
    if (!existing) return;
    setAssigning(true);
    setAssignmentsError(null);
    try {
      await removePlayerFromFormation(existing.rowId);
      setAssignmentRows((prev) => prev.filter((r) => r.id !== existing.rowId));
    } catch (err) {
      setAssignmentsError(mapFormationError(err, "remove"));
    } finally {
      setAssigning(false);
    }
  }

  function pickManager(entry: ManagerLibrary) {
    setSelectedManager(toFormationManagerRef(entry));
    setManagerPickerOpen(false);
  }

  function clearManager() {
    setSelectedManager(null);
    setManagerPickerOpen(false);
  }

  if (!user) return null;

  const managerDisplay = getFormationManagerDisplay(selectedManager);

  return (
    <div className="mx-auto max-w-2xl pb-16">
      <h1 className="mb-2 text-2xl font-bold">Formation</h1>
      <p className="mb-6 text-sm text-slate-400">
        Assign saved players from your Player Library to a persisted formation for one of your teams.
      </p>

      {/* Team selection */}
      <div className="mb-6 rounded-lg border border-pitch-700 bg-pitch-800 p-4">
        <div className="mb-1 text-xs font-semibold uppercase tracking-wide text-slate-500">Team</div>
        {teamsLoading ? (
          <p className="text-sm text-slate-400">Loading your teams…</p>
        ) : teamsError ? (
          <p className="text-sm text-danger">Couldn't load your teams.</p>
        ) : teams.length === 0 ? (
          <p className="text-sm text-slate-400">
            No saved teams yet — create one in Team Library before building a formation.
          </p>
        ) : (
          <select
            value={selectedTeamId ?? ""}
            onChange={(e) => setSelectedTeamId(e.target.value || null)}
            className="w-full rounded-md border border-pitch-700 bg-pitch-900 px-3 py-2 text-sm text-slate-100"
          >
            {teams.map((t) => (
              <option key={t.id} value={t.id}>
                {t.name}
              </option>
            ))}
          </select>
        )}
      </div>

      {/* 8C quick-fix — Formation details + editing. Shown once a
          formation is loaded for the selected team, independent of the
          Player Library load state further below (name/code/positions/
          tactical_instructions editing has nothing to do with which
          players exist). */}
      {formation && (
        <div className="mb-6 rounded-lg border border-pitch-700 bg-pitch-800 p-4">
          <div className="mb-2 flex items-center justify-between">
            <div className="text-xs font-semibold uppercase tracking-wide text-slate-500">Formation</div>
            {!editingFormation && (
              <button
                type="button"
                onClick={openFormationEditor}
                disabled={presetOpPending}
                className="rounded-md border border-pitch-700 px-3 py-1.5 text-xs text-slate-300 hover:border-accent disabled:opacity-50"
              >
                Edit
              </button>
            )}
          </div>

          {!editingFormation ? (
            <div>
              <div className="font-medium text-slate-100">{formation.name}</div>
              <div className="text-xs text-slate-400">{formation.formation_code}</div>
            </div>
          ) : (
            <div className="space-y-4">
              {editFormationError && (
                <p className="rounded-md bg-danger/10 px-3 py-2 text-sm text-danger">{editFormationError}</p>
              )}

              <div className="grid grid-cols-1 gap-3 sm:grid-cols-2">
                <label className="block">
                  <span className="mb-1 block text-xs font-semibold uppercase tracking-wide text-slate-500">
                    Name
                  </span>
                  <input
                    value={editName}
                    onChange={(e) => setEditName(e.target.value)}
                    className="w-full rounded-md border border-pitch-700 bg-pitch-900 px-3 py-2 text-sm text-slate-100"
                  />
                </label>
                <label className="block">
                  <span className="mb-1 block text-xs font-semibold uppercase tracking-wide text-slate-500">
                    Formation code
                  </span>
                  <input
                    value={editCode}
                    onChange={(e) => setEditCode(e.target.value)}
                    placeholder="e.g. 4-3-3"
                    className="w-full rounded-md border border-pitch-700 bg-pitch-900 px-3 py-2 text-sm text-slate-100"
                  />
                </label>
              </div>

              <div>
                <div className="mb-1 flex items-center justify-between">
                  <span className="text-xs font-semibold uppercase tracking-wide text-slate-500">
                    Positions
                  </span>
                  <button
                    type="button"
                    onClick={addPositionRow}
                    className="rounded-md border border-pitch-700 px-2 py-1 text-xs text-slate-300 hover:border-accent"
                  >
                    Add position
                  </button>
                </div>
                <div className="space-y-2">
                  {editPositions.map((row) => (
                    <div key={row.key} className="grid grid-cols-12 gap-2">
                      <input
                        value={row.id}
                        onChange={(e) => updatePositionRow(row.key, "id", e.target.value)}
                        placeholder="slot id"
                        className="col-span-4 rounded-md border border-pitch-700 bg-pitch-900 px-2 py-1.5 text-xs text-slate-100 sm:col-span-3"
                      />
                      <input
                        value={row.role}
                        onChange={(e) => updatePositionRow(row.key, "role", e.target.value)}
                        placeholder="role (e.g. GK)"
                        className="col-span-4 rounded-md border border-pitch-700 bg-pitch-900 px-2 py-1.5 text-xs text-slate-100 sm:col-span-3"
                      />
                      <input
                        value={row.x}
                        onChange={(e) => updatePositionRow(row.key, "x", e.target.value)}
                        placeholder="x (0-1)"
                        inputMode="decimal"
                        className="col-span-2 rounded-md border border-pitch-700 bg-pitch-900 px-2 py-1.5 text-xs text-slate-100"
                      />
                      <input
                        value={row.y}
                        onChange={(e) => updatePositionRow(row.key, "y", e.target.value)}
                        placeholder="y (0-1)"
                        inputMode="decimal"
                        className="col-span-2 rounded-md border border-pitch-700 bg-pitch-900 px-2 py-1.5 text-xs text-slate-100"
                      />
                      <button
                        type="button"
                        onClick={() => removePositionRow(row.key)}
                        aria-label={`Remove position ${row.id || "row"}`}
                        className="col-span-12 rounded-md border border-pitch-700 px-2 py-1 text-xs text-slate-400 hover:border-danger hover:text-danger sm:col-span-2"
                      >
                        Remove
                      </button>
                    </div>
                  ))}
                </div>
              </div>

              <label className="block">
                <span className="mb-1 block text-xs font-semibold uppercase tracking-wide text-slate-500">
                  Tactical instructions (JSON, optional)
                </span>
                <textarea
                  value={editTactical}
                  onChange={(e) => setEditTactical(e.target.value)}
                  rows={4}
                  placeholder="{}"
                  className="w-full rounded-md border border-pitch-700 bg-pitch-900 px-3 py-2 font-mono text-xs text-slate-100"
                />
              </label>

              <div className="flex gap-2">
                <button
                  type="button"
                  onClick={saveFormationEdit}
                  disabled={savingFormation || presetOpPending}
                  className="rounded-md border border-accent bg-accent/10 px-4 py-2 text-sm font-medium text-accent hover:bg-accent/20 disabled:opacity-50"
                >
                  {savingFormation ? "Saving…" : "Save"}
                </button>
                <button
                  type="button"
                  onClick={cancelFormationEdit}
                  disabled={savingFormation || presetOpPending}
                  className="rounded-md border border-pitch-700 px-4 py-2 text-sm text-slate-300 hover:border-danger hover:text-danger disabled:opacity-50"
                >
                  Cancel
                </button>
              </div>
            </div>
          )}
        </div>
      )}

      {/* Batch 8D — Formation Presets. A minimal list + save/apply/
          rename/delete panel, not a redesign of the Formation page and
          not a drag-and-drop layout editor (spec section 13). Shown
          once a formation exists for the selected team, since saving/
          applying a preset always needs a current formation to copy
          from/onto. */}
      {formation && (
        <div className="mb-6 rounded-lg border border-pitch-700 bg-pitch-800 p-4">
          <div className="mb-2 text-xs font-semibold uppercase tracking-wide text-slate-500">
            Formation Presets
          </div>

          {presetActionError && (
            <p className="mb-2 rounded-md bg-danger/10 px-3 py-2 text-sm text-danger">{presetActionError}</p>
          )}
          {presetWarnings.length > 0 && (
            <div className="mb-2 rounded-md bg-amber-500/10 px-3 py-2 text-xs text-amber-400">
              {presetWarnings.map((w, i) => (
                <div key={i}>{w}</div>
              ))}
            </div>
          )}

          {/* Save current Formation as a new preset */}
          <div className="mb-3 flex gap-2">
            <input
              value={newPresetName}
              onChange={(e) => setNewPresetName(e.target.value)}
              placeholder="Preset name (e.g. High press 4-3-3)"
              className="flex-1 rounded-md border border-pitch-700 bg-pitch-900 px-3 py-2 text-sm text-slate-100"
            />
            <button
              type="button"
              onClick={handleSaveFormationAsPreset}
              disabled={presetOpPending}
              className="shrink-0 rounded-md border border-accent bg-accent/10 px-3 py-2 text-xs font-medium text-accent hover:bg-accent/20 disabled:opacity-50"
            >
              {savingPreset ? "Saving…" : "Save as preset"}
            </button>
          </div>

          {/* List of saved presets */}
          {presetsLoading ? (
            <p className="text-sm text-slate-400">Loading presets…</p>
          ) : presetsError ? (
            <p className="rounded-md bg-danger/10 px-3 py-2 text-sm text-danger">{presetsError}</p>
          ) : presets.length === 0 ? (
            <p className="text-sm text-slate-400">No saved presets yet for this team.</p>
          ) : (
            <ul className="space-y-2">
              {presets.map((preset) => (
                <li
                  key={preset.id}
                  className="flex items-center justify-between gap-2 rounded-md border border-pitch-700 bg-pitch-900 px-3 py-2"
                >
                  {renamingPresetId === preset.id ? (
                    <div className="flex flex-1 items-center gap-2">
                      <input
                        value={renamePresetValue}
                        onChange={(e) => setRenamePresetValue(e.target.value)}
                        className="flex-1 rounded-md border border-pitch-700 bg-pitch-800 px-2 py-1 text-sm text-slate-100"
                      />
                      <button
                        type="button"
                        onClick={confirmRenamePreset}
                        className="rounded-md border border-accent px-2 py-1 text-xs text-accent"
                      >
                        Save
                      </button>
                      <button
                        type="button"
                        onClick={cancelRenamePreset}
                        className="rounded-md border border-pitch-700 px-2 py-1 text-xs text-slate-400"
                      >
                        Cancel
                      </button>
                    </div>
                  ) : (
                    <>
                      <div className="min-w-0 flex-1">
                        <div className="truncate text-sm font-medium text-slate-100">{preset.name}</div>
                        <div className="text-xs text-slate-400">{preset.formation_code}</div>
                      </div>
                      <div className="flex shrink-0 items-center gap-1.5">
                        <button
                          type="button"
                          onClick={() => handleApplyPreset(preset.id)}
                          disabled={presetOpPending}
                          className="rounded-md border border-accent bg-accent/10 px-2 py-1 text-xs font-medium text-accent hover:bg-accent/20 disabled:opacity-50"
                        >
                          {applyingPresetId === preset.id ? "Applying…" : "Apply"}
                        </button>
                        <button
                          type="button"
                          onClick={() => startRenamePreset(preset)}
                          disabled={presetOpPending}
                          className="rounded-md border border-pitch-700 px-2 py-1 text-xs text-slate-300 hover:border-accent disabled:opacity-50"
                        >
                          Rename
                        </button>
                        <button
                          type="button"
                          onClick={() => handleDeletePreset(preset.id)}
                          disabled={presetOpPending}
                          className="rounded-md border border-pitch-700 px-2 py-1 text-xs text-slate-400 hover:border-danger hover:text-danger disabled:opacity-50"
                        >
                          {deletingPresetId === preset.id ? "Deleting…" : "Delete"}
                        </button>
                      </div>
                    </>
                  )}
                </li>
              ))}
            </ul>
          )}
        </div>
      )}

      {/* Batch 6B-5 — Selected Manager section, unchanged. */}
      <div className="mb-6 flex items-center gap-4 rounded-lg border border-pitch-700 bg-pitch-800 p-4">
        <ManagerImage
          manager={selectedManager}
          userId={user.id}
          className="h-16 w-16 shrink-0 rounded-full object-cover"
          fallback="No image"
        />
        <div className="min-w-0 flex-1">
          <div className="mb-1 text-xs font-semibold uppercase tracking-wide text-slate-500">Selected Manager</div>
          {selectedManager ? (
            <>
              <div className="truncate font-medium text-slate-100">{managerDisplay.displayName}</div>
              <div className="mt-1 space-y-0.5 text-xs text-slate-400">
                <div>{managerDisplay.possessionLabel}</div>
                <div>{managerDisplay.quickCounterLabel}</div>
                <div>{managerDisplay.longBallCounterLabel}</div>
                <div>{managerDisplay.outWideLabel}</div>
                <div>{managerDisplay.longBallLabel}</div>
              </div>
            </>
          ) : managersLoading ? (
            <p className="text-sm text-slate-400">Loading your managers…</p>
          ) : managersError ? (
            <p className="text-sm text-danger">Couldn't load your managers.</p>
          ) : (
            <p className="text-sm text-slate-400">No manager selected yet.</p>
          )}
        </div>
        <div className="flex shrink-0 flex-col gap-2">
          <button
            type="button"
            onClick={() => setManagerPickerOpen(true)}
            className="rounded-md border border-pitch-700 px-3 py-1.5 text-xs text-slate-300 hover:border-accent"
          >
            {selectedManager ? "Change" : "Select manager"}
          </button>
          {selectedManager && (
            <button
              type="button"
              onClick={clearManager}
              aria-label="Remove selected manager"
              className="rounded-md border border-pitch-700 px-3 py-1.5 text-xs text-slate-400 hover:border-danger hover:text-danger"
            >
              Clear
            </button>
          )}
        </div>
      </div>

      {assignmentsError && (
        <p className="mb-4 rounded-md bg-danger/10 px-3 py-2 text-sm text-danger">{assignmentsError}</p>
      )}

      {!selectedTeamId ? null : formationLoading ? (
        <p className="text-slate-400">Loading this team's formation…</p>
      ) : formationError ? (
        <p className="rounded-md bg-danger/10 px-3 py-2 text-sm text-danger">{formationError}</p>
      ) : !formation ? (
        <div className="rounded-lg border border-pitch-700 bg-pitch-800 p-4 text-center">
          <p className="mb-3 text-sm text-slate-400">This team doesn't have a saved formation yet.</p>
          <button
            type="button"
            onClick={createDefaultFormation}
            disabled={creatingFormation}
            className="rounded-md border border-accent bg-accent/10 px-4 py-2 text-sm font-medium text-accent hover:bg-accent/20 disabled:opacity-50"
          >
            {creatingFormation ? "Creating…" : "Create a 4-3-3 formation"}
          </button>
        </div>
      ) : loading ? (
        <p className="text-slate-400">Loading your players…</p>
      ) : loadError ? (
        <p className="rounded-md bg-danger/10 px-3 py-2 text-sm text-danger">{loadError}</p>
      ) : players.length === 0 ? (
        <p className="text-slate-400">
          No saved players yet — add one in Player Library before building a formation.
        </p>
      ) : assignmentsLoading ? (
        <p className="text-slate-400">Loading this formation's assignments…</p>
      ) : (
        <div className="relative aspect-[2/3] w-full overflow-hidden rounded-lg border border-pitch-700 bg-pitch-800">
          {/* Pitch markings, matching TacticalPitch's visual language */}
          <div className="pointer-events-none absolute inset-1 rounded-sm border border-pitch-700" />
          <div className="pointer-events-none absolute inset-x-1 top-1/2 border-t border-pitch-700" />

          {slots.map((slot) => {
            const occupant = bySlot.get(slot.id) ?? null;
            return (
              <div
                key={slot.id}
                className="absolute -translate-x-1/2 -translate-y-1/2"
                style={{ left: `${slot.x}%`, top: `${slot.y}%` }}
              >
                <PlayerCardSlot
                  slotLabel={slot.label}
                  player={occupant?.ref ?? null}
                  unavailable={occupant?.unavailable ?? false}
                  userId={user.id}
                  onAssign={() => !assigning && setPickerSlot(slot.id)}
                  onClear={() => clear(slot.id)}
                />
              </div>
            );
          })}
        </div>
      )}

      {pickerSlot && (
        <PlayerPickerModal
          players={players}
          assignedIds={assignedIds}
          onPick={(entry) => assign(pickerSlot, entry)}
          onClose={() => setPickerSlot(null)}
        />
      )}

      {managerPickerOpen && (
        <ManagerPicker
          managers={managers}
          loading={managersLoading}
          error={managersError}
          selectedId={selectedManager?.manager_library_id ?? null}
          userId={user.id}
          onPick={pickManager}
          onClear={selectedManager ? clearManager : undefined}
          onClose={() => setManagerPickerOpen(false)}
        />
      )}
    </div>
  );
}
