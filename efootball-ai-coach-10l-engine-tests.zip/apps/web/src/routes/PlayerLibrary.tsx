import { useEffect, useRef, useState } from "react";
import { useAuth } from "../hooks/useAuth";
import { uploadPlayerCardImage, deletePlayerCardImage, getPlayerCardSignedUrl } from "../lib/playerCardStorage";
import { requestPlayerCardExtraction } from "../lib/playerCardExtraction";
import { savePlayerLibraryEntry, listPlayerLibrary } from "../lib/playerLibrary";
import {
  DEFAULT_MAX_IMAGE_MB,
  validatePlayerLibraryInput,
  type PlayerCardDraft,
  type PlayerCardFieldEvidence,
  type PlayerLibrary,
} from "@efootball/shared";

// Batch 6A-4 — Player Card Review/Edit/Save flow ONLY (see the batch
// spec: no formation UI, no manager library, no team presets, no
// tactical animation, no demo players). Flow:
//
//   Upload Player Card -> AI extraction draft -> Review/Edit
//   -> user confirms/corrects values -> Save Player -> player_library
//
// AI extraction is only ever a draft (spec section 11) — this component
// never writes anything to player_library itself; savePlayerLibraryEntry
// (-> player-library-save Edge Function) is the one path that does, and
// only after the user explicitly presses Save. Editing an already-saved
// entry (spec section 10) is deliberately fields-only in this batch —
// the original card image is shown but not replaced/re-extracted here,
// so an edit can never be silently overwritten by a fresh AI read.

const MAX_PLAYER_CARD_MB = Number(import.meta.env.VITE_MAX_IMAGE_UPLOAD_MB ?? DEFAULT_MAX_IMAGE_MB);

type View = "list" | "review";
type ReviewSource = "draft" | "existing";
type UploadPhase = "idle" | "uploading" | "extracting" | "error";

interface AttributeRow {
  id: string;
  key: string;
  value: string;
}

interface FormState {
  name: string;
  position: string;
  overall: string; // "" means unknown — never displayed/stored as 0 (spec section 2)
  playstyle: string;
  attributes: AttributeRow[];
}

let rowIdCounter = 0;
function nextRowId(): string {
  rowIdCounter += 1;
  return `attr-${rowIdCounter}`;
}

function emptyForm(): FormState {
  return { name: "", position: "", overall: "", playstyle: "", attributes: [] };
}

function attributesToRows(attrs: Record<string, number | string | null> | null | undefined): AttributeRow[] {
  if (!attrs) return [];
  return Object.entries(attrs).map(([key, value]) => ({
    id: nextRowId(),
    key,
    value: value === null || value === undefined ? "" : String(value),
  }));
}

function draftToForm(draft: PlayerCardDraft): FormState {
  return {
    name: draft.name ?? "",
    position: draft.position ?? "",
    overall: draft.overall == null ? "" : String(draft.overall),
    playstyle: draft.playstyle ?? "",
    attributes: attributesToRows(draft.attributes),
  };
}

function libraryEntryToForm(entry: PlayerLibrary): FormState {
  return {
    name: entry.name ?? "",
    position: entry.position ?? "",
    overall: entry.overall == null ? "" : String(entry.overall),
    playstyle: entry.playstyle ?? "",
    attributes: attributesToRows(entry.attributes),
  };
}

/** Free-text attribute rows -> the open Record shape player_library
 * expects. A row with an empty value is kept as null (unknown, matching
 * the NULL/UNKNOWN rule), never coerced to 0/"". A numeric-looking value
 * is stored as a number so it participates the same way a directly
 * AI-extracted numeric attribute would. */
function attributesFromRows(rows: AttributeRow[]): Record<string, number | string | null> {
  const out: Record<string, number | string | null> = {};
  for (const row of rows) {
    const key = row.key.trim();
    if (!key) continue; // a row with no attribute name has nothing to save
    const raw = row.value.trim();
    if (raw === "") {
      out[key] = null;
      continue;
    }
    out[key] = /^-?\d+(\.\d+)?$/.test(raw) ? Number(raw) : raw;
  }
  return out;
}

export function PlayerLibraryPage() {
  const { user } = useAuth();

  const [view, setView] = useState<View>("list");
  const [players, setPlayers] = useState<PlayerLibrary[]>([]);
  const [listLoading, setListLoading] = useState(true);
  const [listError, setListError] = useState<string | null>(null);

  const [uploadPhase, setUploadPhase] = useState<UploadPhase>("idle");
  const [uploadError, setUploadError] = useState<string | null>(null);

  const [reviewSource, setReviewSource] = useState<ReviewSource>("draft");
  const [editingId, setEditingId] = useState<string | null>(null);
  // Only set for a fresh draft (the image this session just uploaded).
  // Left null when editing an existing entry — its image is shown via
  // imageSignedUrl below but is never re-sent/re-touched on save.
  const [draftImagePath, setDraftImagePath] = useState<string | null>(null);
  const [imageSignedUrl, setImageSignedUrl] = useState<string | null>(null);
  const [draftMeta, setDraftMeta] = useState<{ confidence: number; evidence: PlayerCardFieldEvidence[] } | null>(
    null
  );
  const [form, setForm] = useState<FormState>(emptyForm());
  const [saving, setSaving] = useState(false);
  const [saveError, setSaveError] = useState<string | null>(null);

  const fileInputRef = useRef<HTMLInputElement>(null);

  useEffect(() => {
    if (user) void refreshList();
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [user]);

  async function refreshList() {
    setListLoading(true);
    setListError(null);
    try {
      const rows = await listPlayerLibrary();
      setPlayers(rows);
    } catch (err) {
      setListError((err as Error).message);
    } finally {
      setListLoading(false);
    }
  }

  async function handleFileSelected(e: React.ChangeEvent<HTMLInputElement>) {
    const file = e.target.files?.[0];
    e.target.value = ""; // allow re-selecting the same file on a retry
    if (!file || !user) return;

    setUploadError(null);
    setUploadPhase("uploading");
    try {
      const { objectPath } = await uploadPlayerCardImage(file, user.id);

      setUploadPhase("extracting");
      const { draft } = await requestPlayerCardExtraction({ objectPath });

      const signedUrl = await getPlayerCardSignedUrl(objectPath);

      setReviewSource("draft");
      setEditingId(null);
      setDraftImagePath(objectPath);
      setImageSignedUrl(signedUrl);
      setDraftMeta({ confidence: draft.extraction_confidence, evidence: draft.field_evidence });
      setForm(draftToForm(draft));
      setSaveError(null);
      setUploadPhase("idle");
      setView("review");
    } catch (err) {
      setUploadError((err as Error).message);
      setUploadPhase("error");
    }
  }

  function startEdit(entry: PlayerLibrary) {
    setReviewSource("existing");
    setEditingId(entry.id);
    setDraftImagePath(null); // editing never replaces the stored image in this batch
    setDraftMeta(null);
    setForm(libraryEntryToForm(entry));
    setSaveError(null);
    setImageSignedUrl(null);
    if (entry.player_card_image_path) {
      getPlayerCardSignedUrl(entry.player_card_image_path)
        .then(setImageSignedUrl)
        .catch(() => setImageSignedUrl(null));
    }
    setView("review");
  }

  function resetReviewState() {
    setDraftImagePath(null);
    setImageSignedUrl(null);
    setDraftMeta(null);
    setEditingId(null);
    setForm(emptyForm());
    setSaveError(null);
  }

  async function handleCancel() {
    // A brand-new (not-yet-saved) upload leaves its card image in
    // storage unless we clean it up — editing an existing entry never
    // uploaded anything new this session, so there's nothing to remove.
    if (reviewSource === "draft" && draftImagePath && user) {
      try {
        await deletePlayerCardImage(draftImagePath, user.id);
      } catch {
        // best-effort cleanup only — never block navigation on it
      }
    }
    resetReviewState();
    setView("list");
  }

  function updateAttrRow(id: string, patch: Partial<Pick<AttributeRow, "key" | "value">>) {
    setForm((f) => ({ ...f, attributes: f.attributes.map((r) => (r.id === id ? { ...r, ...patch } : r)) }));
  }

  function removeAttrRow(id: string) {
    setForm((f) => ({ ...f, attributes: f.attributes.filter((r) => r.id !== id) }));
  }

  function addAttrRow() {
    setForm((f) => ({ ...f, attributes: [...f.attributes, { id: nextRowId(), key: "", value: "" }] }));
  }

  async function handleSave() {
    setSaveError(null);

    // Client-side pre-check with the SAME shared validator the server
    // re-runs as the actual authority (spec section 7) — early feedback
    // only, never the final word.
    const { sanitized, errors } = validatePlayerLibraryInput({
      name: form.name.trim() || null,
      position: form.position.trim() || null,
      overall: form.overall.trim() === "" ? null : Number(form.overall),
      playstyle: form.playstyle.trim() || null,
      attributes: attributesFromRows(form.attributes),
      player_card_image_path: null, // not evaluated here — see payload construction below
    });

    setSaving(true);
    try {
      // Duplicate saves (spec section 9) are recovered server-side and
      // returned as an ordinary success (result.duplicate === true) —
      // deliberately no special-cased UI here, so an accidental
      // double-click/retry just looks like a normal save.
      await savePlayerLibraryEntry({
        ...(editingId ? { id: editingId } : {}),
        name: sanitized.name,
        position: sanitized.position,
        overall: sanitized.overall,
        playstyle: sanitized.playstyle,
        attributes: sanitized.attributes,
        // Omit the key entirely when editing an existing entry, so the
        // Edge Function leaves its already-saved image untouched; always
        // include it for a brand-new entry from a fresh upload.
        ...(reviewSource === "draft" ? { player_card_image_path: draftImagePath } : {}),
      });
      if (errors.length > 0) {
        console.warn("[PlayerLibrary] some entered values could not be saved as-is:", errors);
      }
      resetReviewState();
      setView("list");
      await refreshList();
    } catch (err) {
      setSaveError((err as Error).message);
    } finally {
      setSaving(false);
    }
  }

  if (!user) return null;

  return (
    <div className="mx-auto max-w-xl">
      {view === "list" && (
        <div>
          <h1 className="mb-6 text-2xl font-bold">Player Library</h1>

          <label className="mb-6 block">
            <span className="mb-1 block text-sm text-slate-400">
              Add a player card (max {MAX_PLAYER_CARD_MB}MB — JPEG, PNG, or WEBP)
            </span>
            <input
              ref={fileInputRef}
              type="file"
              accept="image/png,image/jpeg,image/webp"
              onChange={handleFileSelected}
              disabled={uploadPhase === "uploading" || uploadPhase === "extracting"}
              className="w-full rounded-md border border-dashed border-pitch-700 bg-pitch-800 px-3 py-6 text-sm text-slate-400 disabled:opacity-50"
            />
          </label>

          {uploadPhase === "uploading" && <p className="mb-4 text-sm text-slate-400">Uploading card image…</p>}
          {uploadPhase === "extracting" && <p className="mb-4 text-sm text-slate-400">Reading card…</p>}
          {uploadError && <p className="mb-4 rounded-md bg-danger/10 px-3 py-2 text-sm text-danger">{uploadError}</p>}

          {listLoading ? (
            <p className="text-slate-400">Loading your players…</p>
          ) : listError ? (
            <p className="rounded-md bg-danger/10 px-3 py-2 text-sm text-danger">{listError}</p>
          ) : players.length === 0 ? (
            <p className="text-slate-400">No saved players yet — upload a card above to add your first one.</p>
          ) : (
            <ul className="space-y-2">
              {players.map((p) => (
                <li
                  key={p.id}
                  className="flex items-center justify-between rounded-md border border-pitch-700 bg-pitch-800 px-4 py-3"
                >
                  <div>
                    <div className="font-medium text-slate-100">{p.name ?? "Unnamed player"}</div>
                    <div className="text-xs text-slate-400">
                      {[p.position ?? "Position unknown", p.overall != null ? `OVR ${p.overall}` : "OVR unknown"].join(
                        " · "
                      )}
                    </div>
                  </div>
                  <button
                    onClick={() => startEdit(p)}
                    className="rounded-md border border-pitch-700 px-3 py-1.5 text-sm text-slate-300 hover:border-accent"
                  >
                    Edit
                  </button>
                </li>
              ))}
            </ul>
          )}
        </div>
      )}

      {view === "review" && (
        <div>
          <h1 className="mb-6 text-2xl font-bold">{reviewSource === "draft" ? "Review Player Card" : "Edit Player"}</h1>

          {imageSignedUrl && (
            <img
              src={imageSignedUrl}
              alt="Player card"
              className="mb-4 max-h-64 w-auto rounded-md border border-pitch-700"
            />
          )}

          {reviewSource === "draft" && draftMeta && (
            <p className="mb-4 text-xs text-slate-400">
              Extraction confidence: {draftMeta.confidence}%
              {draftMeta.evidence.some((e) => !e.visible) && (
                <> — {draftMeta.evidence.filter((e) => !e.visible).length} field(s) not visible on the card</>
              )}
            </p>
          )}

          <label className="mb-1 block text-sm text-slate-400">Name</label>
          <input
            value={form.name}
            onChange={(e) => setForm((f) => ({ ...f, name: e.target.value }))}
            placeholder="Unknown"
            className="mb-4 w-full rounded-md border border-pitch-700 bg-pitch-800 px-3 py-2 text-sm text-slate-100"
          />

          <label className="mb-1 block text-sm text-slate-400">Position</label>
          <input
            value={form.position}
            onChange={(e) => setForm((f) => ({ ...f, position: e.target.value }))}
            placeholder="Unknown"
            className="mb-4 w-full rounded-md border border-pitch-700 bg-pitch-800 px-3 py-2 text-sm text-slate-100"
          />

          <label className="mb-1 block text-sm text-slate-400">Overall</label>
          <input
            type="number"
            inputMode="numeric"
            value={form.overall}
            onChange={(e) => setForm((f) => ({ ...f, overall: e.target.value }))}
            placeholder="Unknown"
            className="mb-4 w-full rounded-md border border-pitch-700 bg-pitch-800 px-3 py-2 text-sm text-slate-100"
          />

          <label className="mb-1 block text-sm text-slate-400">Playstyle</label>
          <input
            value={form.playstyle}
            onChange={(e) => setForm((f) => ({ ...f, playstyle: e.target.value }))}
            placeholder="Unknown"
            className="mb-4 w-full rounded-md border border-pitch-700 bg-pitch-800 px-3 py-2 text-sm text-slate-100"
          />

          <div className="mb-2 flex items-center justify-between">
            <span className="text-sm text-slate-400">Attributes</span>
            <button onClick={addAttrRow} className="text-xs text-accent hover:underline">
              + Add attribute
            </button>
          </div>
          <div className="mb-4 space-y-2">
            {form.attributes.length === 0 && <p className="text-xs text-slate-500">No attributes recorded.</p>}
            {form.attributes.map((row) => (
              <div key={row.id} className="flex gap-2">
                <input
                  value={row.key}
                  onChange={(e) => updateAttrRow(row.id, { key: e.target.value })}
                  placeholder="Attribute"
                  className="w-1/2 rounded-md border border-pitch-700 bg-pitch-800 px-2 py-1.5 text-sm text-slate-100"
                />
                <input
                  value={row.value}
                  onChange={(e) => updateAttrRow(row.id, { value: e.target.value })}
                  placeholder="Unknown"
                  className="w-1/2 rounded-md border border-pitch-700 bg-pitch-800 px-2 py-1.5 text-sm text-slate-100"
                />
                <button
                  onClick={() => removeAttrRow(row.id)}
                  aria-label="Remove attribute"
                  className="px-2 text-slate-400 hover:text-danger"
                >
                  ×
                </button>
              </div>
            ))}
          </div>

          {saveError && <p className="mb-4 rounded-md bg-danger/10 px-3 py-2 text-sm text-danger">{saveError}</p>}

          <div className="flex gap-2">
            <button
              onClick={handleSave}
              disabled={saving}
              className="flex-1 rounded-md bg-accent py-3 text-sm font-semibold text-pitch-950 hover:bg-accent-dim disabled:opacity-50"
            >
              {saving ? "Saving…" : "Save Player"}
            </button>
            <button
              onClick={handleCancel}
              disabled={saving}
              className="rounded-md border border-pitch-700 px-4 py-3 text-sm text-slate-300 hover:border-accent disabled:opacity-50"
            >
              Cancel
            </button>
          </div>
        </div>
      )}
    </div>
  );
}
