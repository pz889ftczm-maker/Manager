import { useRef, useState } from "react";
import { useNavigate } from "react-router-dom";
import * as tus from "tus-js-client";
import { supabase } from "../lib/supabaseClient";
import { useAuth } from "../hooks/useAuth";
import { enqueueAnalysis } from "../lib/enqueueAnalysis";
import {
  DEFAULT_MAX_IMAGE_MB,
  DEFAULT_MAX_VIDEO_MB,
  buildSafeStoragePath,
  guessExtensionFromMimeOrName,
  sanitizeDisplayFilename,
  sniffFileType,
} from "@efootball/shared";

const MAX_VIDEO_MB = Number(import.meta.env.VITE_MAX_VIDEO_UPLOAD_MB ?? DEFAULT_MAX_VIDEO_MB);
const MAX_IMAGE_MB = Number(import.meta.env.VITE_MAX_IMAGE_UPLOAD_MB ?? DEFAULT_MAX_IMAGE_MB);
const RAW_UPLOADS_BUCKET = "raw-uploads";

type Mode = "screenshot" | "video";

// Batch 5 (Part R) — real states instead of a single "submitting"
// boolean, so the UI can show what's actually happening and offer the
// right kind of retry (re-upload vs. just re-enqueue an already-uploaded
// file) rather than one generic error.
type Phase = "idle" | "validating" | "uploading" | "upload_error" | "enqueuing" | "enqueue_error";

interface UploadedFileResult {
  objectPath: string;
  mediaId: string;
}

interface PreparedSubmission {
  matchId: string;
  mode: Mode;
  /** One entry per file in `files`, in order, for files already uploaded
   * and recorded — Part B/S: "do not restart the entire upload
   * unnecessarily" applies per-file, not just to the batch as a whole. */
  results: UploadedFileResult[];
}

export function Analyze() {
  const { user } = useAuth();
  const navigate = useNavigate();
  const [mode, setMode] = useState<Mode>("screenshot");
  const [files, setFiles] = useState<File[]>([]);
  const [title, setTitle] = useState("");
  const [uploadPct, setUploadPct] = useState(0);
  const [phase, setPhase] = useState<Phase>("idle");
  const [error, setError] = useState<string | null>(null);

  // Not React state — mutated across retries without triggering re-renders
  // mid-upload, and read back synchronously inside handleSubmit.
  const preparedRef = useRef<PreparedSubmission | null>(null);
  const tusUploadRef = useRef<tus.Upload | null>(null);

  const busy = phase === "validating" || phase === "uploading" || phase === "enqueuing";
  const hasPriorAttempt = preparedRef.current !== null;

  function resetAll() {
    tusUploadRef.current = null;
    preparedRef.current = null;
    setFiles([]);
    setError(null);
    setUploadPct(0);
    setPhase("idle");
  }

  async function handleFiles(e: React.ChangeEvent<HTMLInputElement>) {
    const selected = Array.from(e.target.files ?? []);
    resetAll();
    if (selected.length === 0) return;

    setPhase("validating");
    const expectedKind = mode === "video" ? "video" : "image";
    const maxMb = mode === "video" ? MAX_VIDEO_MB : MAX_IMAGE_MB;

    // Part A/C — early client-side feedback only. This is NEVER the only
    // enforcement layer: analysis-enqueue re-validates every one of these
    // (real size from Storage, real magic bytes) before a job ever reaches
    // the worker queue, and the worker re-checks the downloaded bytes a
    // third time before ffmpeg/the AI provider touch them.
    for (const file of selected) {
      if (file.size <= 0) {
        setError(`${file.name} is empty.`);
        setPhase("idle");
        return;
      }
      if (file.size > maxMb * 1024 * 1024) {
        setError(`${file.name} is ${(file.size / (1024 * 1024)).toFixed(1)}MB, which exceeds the ${maxMb}MB limit.`);
        setPhase("idle");
        return;
      }
      // Only reads the first 4KB — never the whole file, even for a
      // multi-hundred-MB video.
      const head = new Uint8Array(await file.slice(0, 4096).arrayBuffer());
      const detected = sniffFileType(head);
      if (!detected || detected.kind !== expectedKind) {
        setError(`${file.name} doesn't look like a supported ${expectedKind} file.`);
        setPhase("idle");
        return;
      }
    }

    setFiles(selected);
    setPhase("idle");
  }

  /** Uploads one file to raw-uploads and returns its SAFE, server-chosen
   * object path — never derived from the user-supplied filename (Part D).
   * Video goes through Supabase Storage's TUS resumable-upload endpoint
   * (Part A/B: real progress, resumable after a dropped connection);
   * screenshots are small enough that a single request is fine. */
  async function uploadOne(file: File, userId: string, matchId: string, accessToken: string): Promise<string> {
    const head = new Uint8Array(await file.slice(0, 4096).arrayBuffer());
    const detected = sniffFileType(head);
    const extension = detected?.extension ?? guessExtensionFromMimeOrName(file.type, file.name);
    const objectPath = buildSafeStoragePath(userId, matchId, extension, crypto.randomUUID());

    if (mode === "video") {
      await new Promise<void>((resolve, reject) => {
        const upload = new tus.Upload(file, {
          endpoint: `${import.meta.env.VITE_SUPABASE_URL}/storage/v1/upload/resumable`,
          retryDelays: [0, 3000, 5000, 10000, 20000],
          uploadDataDuringCreation: true,
          removeFingerprintOnSuccess: true,
          headers: {
            authorization: `Bearer ${accessToken}`,
            apikey: import.meta.env.VITE_SUPABASE_ANON_KEY,
            "x-upsert": "true",
          },
          metadata: {
            bucketName: RAW_UPLOADS_BUCKET,
            objectName: objectPath,
            contentType: file.type || "application/octet-stream",
            cacheControl: "3600",
          },
          // Supabase Storage's TUS implementation requires this exact
          // chunk size.
          chunkSize: 6 * 1024 * 1024,
          onError: (err) => reject(err),
          onProgress: (bytesUploaded, bytesTotal) => {
            setUploadPct(Math.round((bytesUploaded / bytesTotal) * 100));
          },
          onSuccess: () => resolve(),
        });
        tusUploadRef.current = upload;

        // Part B — "do not restart the entire upload unnecessarily after
        // a transient failure": resume from wherever a previous attempt
        // for this exact file left off, rather than always starting at 0.
        upload.findPreviousUploads().then((previous) => {
          if (previous.length > 0) upload.resumeFromPreviousUpload(previous[0]);
          upload.start();
        });
      });
    } else {
      const { error: uploadErr } = await supabase.storage
        .from(RAW_UPLOADS_BUCKET)
        .upload(objectPath, file, { upsert: false, contentType: file.type || undefined });
      if (uploadErr) throw uploadErr;
      setUploadPct(100);
    }

    return objectPath;
  }

  async function handleSubmit() {
    if (!user || files.length === 0) return;
    setError(null);

    try {
      let prepared = preparedRef.current;

      if (!prepared) {
        // 1. Create the match row up front so we have an id to key storage
        // paths and job payloads off of.
        const { data: match, error: matchErr } = await supabase
          .from("matches")
          .insert({
            user_id: user.id,
            title: title || (mode === "video" ? "Full match analysis" : "Screenshot analysis"),
            source_type: mode,
            status: "uploading",
          })
          .select()
          .single();
        if (matchErr || !match) throw matchErr ?? new Error("Failed to create match");
        prepared = { matchId: match.id, mode, results: [] };
        preparedRef.current = prepared;
      }

      if (prepared.results.length < files.length) {
        setPhase("uploading");
        setUploadPct(0);

        const { data: sessionData } = await supabase.auth.getSession();
        const accessToken = sessionData.session?.access_token;
        if (!accessToken) throw new Error("Your session has expired. Please sign in again.");

        // Resume from the first file that hasn't been uploaded yet on this
        // attempt — already-uploaded files (and their media rows) are left
        // untouched (Part B/S).
        for (let i = prepared.results.length; i < files.length; i++) {
          const file = files[i];
          const objectPath = await uploadOne(file, user.id, prepared.matchId, accessToken);

          const { data: mediaRow, error: mediaErr } = await supabase
            .from("media")
            .insert({
              match_id: prepared.matchId,
              user_id: user.id,
              type: mode,
              original_filename: sanitizeDisplayFilename(file.name),
              original_size_bytes: file.size,
              status: "uploaded",
              storage_reference: objectPath,
              is_temporary: mode === "video", // screenshots are kept; raw videos are temp (spec section 10)
            })
            .select()
            .single();
          if (mediaErr || !mediaRow) throw mediaErr ?? new Error("Failed to record uploaded media");

          prepared.results.push({ objectPath, mediaId: mediaRow.id as string });
        }
      }

      // 2. Hand off to the processing pipeline (shared with MatchHistory's
      // Retry action for an already-uploaded, previously-failed match).
      setPhase("enqueuing");
      const storageObjectPaths = prepared.results.map((r) => r.objectPath);
      const videoMediaId = mode === "video" ? prepared.results[0]?.mediaId ?? null : null;
      // 9C-1: forward the actual selected Team/Formation context, if any.
      // Analyze currently has no team/formation picker of its own (that
      // selection only exists locally within Formation.tsx, scoped to
      // that route, and isn't shared app-wide) — so there is nothing
      // real to reuse here yet. Per spec, that means explicit `null`,
      // never a fabricated/default selection.
      await enqueueAnalysis({
        matchId: prepared.matchId,
        mode,
        storageObjectPaths,
        mediaId: videoMediaId,
        teamId: null,
        formationId: null,
      });

      navigate(`/matches/${prepared.matchId}`);
    } catch (err) {
      setError((err as Error).message);
      const allUploaded = preparedRef.current !== null && preparedRef.current.results.length === files.length;
      setPhase(allUploaded ? "enqueue_error" : "upload_error");
    }
  }

  function submitLabel(): string {
    switch (phase) {
      case "validating":
        return "Checking file…";
      case "uploading":
        return `Uploading… ${uploadPct}%`;
      case "enqueuing":
        return "Starting analysis…";
      case "upload_error":
        return "Retry Upload";
      case "enqueue_error":
        return "Retry Analysis";
      default:
        return "Start Analysis";
    }
  }

  return (
    <div className="mx-auto max-w-xl">
      <h1 className="mb-6 text-2xl font-bold">New Analysis</h1>

      <div className="mb-6 flex gap-2">
        <button
          onClick={() => !busy && !hasPriorAttempt && setMode("screenshot")}
          disabled={busy || hasPriorAttempt}
          className={`flex-1 rounded-md border px-4 py-3 text-sm font-medium disabled:opacity-50 ${
            mode === "screenshot" ? "border-accent bg-accent/10 text-accent" : "border-pitch-700 text-slate-300"
          }`}
        >
          Screenshot(s)
        </button>
        <button
          onClick={() => !busy && !hasPriorAttempt && setMode("video")}
          disabled={busy || hasPriorAttempt}
          className={`flex-1 rounded-md border px-4 py-3 text-sm font-medium disabled:opacity-50 ${
            mode === "video" ? "border-accent bg-accent/10 text-accent" : "border-pitch-700 text-slate-300"
          }`}
        >
          Full Match Video
        </button>
      </div>

      <label className="mb-1 block text-sm text-slate-400">Match title (optional)</label>
      <input
        value={title}
        onChange={(e) => setTitle(e.target.value)}
        disabled={busy || hasPriorAttempt}
        placeholder={mode === "video" ? "e.g. vs. Liverpool — Division 2" : "e.g. Attacking sequence review"}
        className="mb-4 w-full rounded-md border border-pitch-700 bg-pitch-800 px-3 py-2 text-sm text-slate-100 disabled:opacity-50"
      />

      <label className="mb-1 block text-sm text-slate-400">
        {mode === "screenshot"
          ? `Upload one or more screenshots (max ${MAX_IMAGE_MB}MB each)`
          : `Upload full match video (max ${MAX_VIDEO_MB}MB)`}
      </label>
      <input
        type="file"
        accept={mode === "screenshot" ? "image/png,image/jpeg,image/webp" : "video/mp4,video/quicktime,video/webm"}
        multiple={mode === "screenshot"}
        onChange={handleFiles}
        disabled={busy || hasPriorAttempt}
        className="mb-4 w-full rounded-md border border-dashed border-pitch-700 bg-pitch-800 px-3 py-6 text-sm text-slate-400 disabled:opacity-50"
      />

      {files.length > 0 && (
        <ul className="mb-4 space-y-1 text-sm text-slate-400">
          {files.map((f, i) => (
            <li key={`${f.name}-${i}`} className="flex items-center justify-between">
              <span>
                {f.name} — {(f.size / (1024 * 1024)).toFixed(1)}MB
              </span>
              {preparedRef.current && i < preparedRef.current.results.length && (
                <span className="text-xs text-accent">Uploaded ✓</span>
              )}
            </li>
          ))}
        </ul>
      )}

      {error && <p className="mb-4 rounded-md bg-danger/10 px-3 py-2 text-sm text-danger">{error}</p>}

      {phase === "uploading" && (
        <div className="mb-4 h-2 w-full overflow-hidden rounded-full bg-pitch-800">
          <div className="h-full bg-accent transition-all" style={{ width: `${uploadPct}%` }} />
        </div>
      )}

      <div className="flex gap-2">
        <button
          onClick={handleSubmit}
          disabled={files.length === 0 || busy}
          className="flex-1 rounded-md bg-accent py-3 text-sm font-semibold text-pitch-950 hover:bg-accent-dim disabled:opacity-50"
        >
          {submitLabel()}
        </button>
        {(phase === "upload_error" || phase === "enqueue_error") && (
          <button
            onClick={resetAll}
            className="rounded-md border border-pitch-700 px-4 py-3 text-sm text-slate-300 hover:border-accent"
          >
            Start Over
          </button>
        )}
      </div>
    </div>
  );
}
