import { useEffect, useRef, useState } from "react";
import { useParams } from "react-router-dom";
import { supabase } from "../lib/supabaseClient";
import { TacticalPitch } from "../components/TacticalPitch";
import { PlayerPerformance } from "../components/PlayerPerformance";
import { VideoPlayer, type VideoPlayerHandle } from "../components/VideoPlayer";
import { EventTimeline } from "../components/EventTimeline";
import { useMatchVideo } from "../hooks/useMatchVideo";
import { useVideoClips } from "../hooks/useVideoClips";
import { useMatchSnapshot } from "../hooks/useMatchSnapshot";
import { HistoricalSnapshotPanel } from "../components/HistoricalSnapshotPanel";
import { resolveEventContextWindow } from "@efootball/shared";
import type { AnalysisEvent, Match, MatchStatistics, TacticalAnalysis } from "@efootball/shared";
import type { MatchPlayerStatistics, Player } from "@efootball/shared";

const SEVERITY_ICON: Record<string, string> = {
  excellent: "✅",
  good: "✅",
  minor_issue: "⚠️",
  mistake: "❌",
  critical_mistake: "❌",
};

function formatTimestamp(seconds: number | null): string {
  if (seconds == null) return "";
  const m = Math.floor(seconds / 60);
  const s = Math.round(seconds % 60);
  return `${m}:${s.toString().padStart(2, "0")}`;
}

export function MatchReport() {
  const { matchId } = useParams();
  const [match, setMatch] = useState<Match | null>(null);
  const [stats, setStats] = useState<MatchStatistics | null>(null);
  const [events, setEvents] = useState<AnalysisEvent[]>([]);
  const [tacticalByEvent, setTacticalByEvent] = useState<Record<string, TacticalAnalysis>>({});
  const [selectedEventId, setSelectedEventId] = useState<string | null>(null);
  const [playerStats, setPlayerStats] = useState<(MatchPlayerStatistics & { players: Player | null })[]>([]);
  const [loading, setLoading] = useState(true);

  // Batch 4 — real video (Part B/C): signed URL for the persisted,
  // processed match video, or `videoUrl: null` (never a placeholder) if
  // this match has no video (screenshot-only) or it isn't ready yet.
  const { videoUrl, loading: videoLoading } = useMatchVideo(matchId);
  const { getClipState, requestClip } = useVideoClips(matchId);
  // Batch 9D: read-only Historical Match Snapshot — see
  // apps/web/src/hooks/useMatchSnapshot.ts for the ownership/RLS
  // model. Fetched independently of the queries below; a failure or
  // absence here never affects the rest of this page.
  const { display: snapshotDisplay, loading: snapshotLoading } = useMatchSnapshot(matchId);

  const videoRef = useRef<VideoPlayerHandle | null>(null);
  const [videoDuration, setVideoDuration] = useState<number | null>(null);
  const [currentTime, setCurrentTime] = useState(0);

  useEffect(() => {
    if (!matchId) return;

    (async () => {
      const [{ data: matchRow }, { data: statsRow }, { data: eventRows }, { data: playerStatRows }] =
        await Promise.all([
          supabase.from("matches").select("*").eq("id", matchId).single(),
          supabase.from("match_statistics").select("*").eq("match_id", matchId).maybeSingle(),
          supabase
            .from("analysis_events")
            .select("*")
            .eq("match_id", matchId)
            .order("timestamp_seconds", { ascending: true }),
          // Batch 3.5: real per-player statistics for this match, joined
          // with the player identity row. Invalid rows (validation caught
          // an inconsistency the source itself couldn't resolve) are
          // excluded — see packages/shared/src/playerStatistics.ts.
          supabase
            .from("match_player_statistics")
            .select("*, players(*)")
            .eq("match_id", matchId)
            .eq("is_valid", true),
        ]);

      setMatch(matchRow ?? null);
      setStats(statsRow ?? null);
      setEvents(eventRows ?? []);
      setPlayerStats((playerStatRows as any) ?? []);
      setSelectedEventId(eventRows?.[0]?.id ?? null);

      if (eventRows && eventRows.length > 0) {
        const { data: tacticalRows } = await supabase
          .from("tactical_analysis")
          .select("*")
          .in(
            "event_id",
            eventRows.map((e) => e.id)
          );
        const map: Record<string, TacticalAnalysis> = {};
        tacticalRows?.forEach((t) => (map[t.event_id] = t));
        setTacticalByEvent(map);
      }

      setLoading(false);
    })();
  }, [matchId]);

  if (loading) return <div className="text-slate-400">Loading report…</div>;
  if (!match) return <div className="text-danger">Match not found.</div>;

  if (match.status !== "complete") {
    return (
      <div className="rounded-lg border border-pitch-700 bg-pitch-900 p-8 text-center">
        <div className="text-lg font-semibold">{match.title}</div>
        <div className="mt-2 text-accent">{match.status.replace(/_/g, " ")}…</div>
        {match.status === "error" && (
          <p className="mt-2 text-sm text-danger">{match.error_message ?? "Something went wrong."}</p>
        )}
      </div>
    );
  }

  const selectedEvent = events.find((e) => e.id === selectedEventId) ?? null;
  const selectedTactical = selectedEvent ? tacticalByEvent[selectedEvent.id] : null;
  // Prefer the video's own real, decoded duration once known; fall back
  // to matches.duration_seconds (persisted by processMatchVideo.ts) only
  // until the <video> element has loaded metadata. Never fabricated.
  const effectiveDuration = videoDuration ?? match.duration_seconds ?? null;

  const scoreRows: [string, number | null][] = stats
    ? [
        ["Passing", stats.passing_score],
        ["Dribbling", stats.dribbling_score],
        ["Attacking", stats.attacking_score],
        ["Defending", stats.defending_score],
        ["Positioning", stats.positioning_score],
        ["Decision Making", stats.decision_making_score],
      ]
    : [];

  // Part F — Watch Moment: seek the real player to this event's real
  // context window (persisted context_start/end, or a computed ±10s
  // fallback clamped to the real duration — see @efootball/shared's
  // resolveEventContextWindow). Never a hardcoded/random timestamp.
  function handleWatchMoment(event: AnalysisEvent) {
    const window = resolveEventContextWindow(event, effectiveDuration);
    if (!window || !videoRef.current) return;
    videoRef.current.seekAndPlay(window.start);
  }

  // Part E — clicking a timeline/list entry selects the event AND seeks
  // the video, rather than just opening a detail panel.
  function handleSelectEvent(eventId: string) {
    setSelectedEventId(eventId);
    const event = events.find((e) => e.id === eventId);
    if (event && videoRef.current) {
      const window = resolveEventContextWindow(event, effectiveDuration);
      if (window) videoRef.current.seekAndPlay(window.start);
    }
  }

  const clipState = selectedEvent ? getClipState(selectedEvent.id) : null;

  return (
    <div>
      <div className="mb-6">
        <h1 className="text-2xl font-bold">{match.title}</h1>
        <div className="mt-1 text-4xl font-extrabold text-accent">
          {match.overall_score != null ? Math.round(Number(match.overall_score)) : "—"}
        </div>
        <div className="text-xs text-slate-500">Overall Decision Score</div>
      </div>

      {scoreRows.length > 0 && (
        <div className="mb-8 grid grid-cols-2 gap-3 md:grid-cols-6">
          {scoreRows.map(([label, val]) => (
            <div key={label} className="rounded-lg border border-pitch-700 bg-pitch-900 p-3 text-center">
              <div className="text-xl font-bold">{val != null ? Math.round(Number(val)) : "—"}</div>
              <div className="text-[11px] text-slate-500">{label}</div>
            </div>
          ))}
        </div>
      )}

      {/* Batch 3.5: real individual player statistics, separate from the
          decision-event timeline below. */}
      <div className="mb-8">
        <PlayerPerformance rows={playerStats} />
      </div>

      {/* Batch 9D: read-only historical Team/Formation/Manager/Player
          context, exactly as it looked when this match was analyzed —
          never the current Library values (see HistoricalSnapshotPanel
          and useMatchSnapshot's own header comments). */}
      <div className="mb-8">
        <HistoricalSnapshotPanel display={snapshotDisplay} loading={snapshotLoading} />
      </div>

      {/* Batch 4 (Part C): real video player — no video state (screenshot-
          only matches, or video still processing) renders explicitly
          rather than a broken/empty player. */}
      <div className="mb-8">
        {videoLoading ? (
          <div className="rounded-lg border border-pitch-700 bg-pitch-900 p-6 text-center text-sm text-slate-500">
            Loading video…
          </div>
        ) : videoUrl ? (
          <VideoPlayer
            ref={videoRef}
            src={videoUrl}
            onDurationChange={setVideoDuration}
            onTimeUpdate={setCurrentTime}
          />
        ) : (
          <div className="rounded-lg border border-pitch-700 bg-pitch-900 p-6 text-center text-sm text-slate-500">
            No video available for this match.
          </div>
        )}
      </div>

      <div className="grid grid-cols-1 gap-6 lg:grid-cols-[minmax(0,320px)_1fr]">
        {/* Timeline (Part D/E) */}
        <div>
          <h2 className="mb-3 text-lg font-semibold">Timeline</h2>
          <EventTimeline
            events={events}
            durationSeconds={effectiveDuration}
            selectedEventId={selectedEventId}
            currentTimeSeconds={videoUrl ? currentTime : undefined}
            onSelectEvent={handleSelectEvent}
          />
        </div>

        {/* Detail: watch moment, generate clip, actual vs better, why */}
        <div>
          {selectedEvent ? (
            <div className="space-y-6">
              <div className="rounded-lg border border-pitch-700 bg-pitch-900 p-4">
                <div className="mb-1 text-sm text-slate-500">
                  {formatTimestamp(selectedEvent.timestamp_seconds)} · confidence:{" "}
                  {selectedEvent.confidence_level}
                </div>
                <div className="text-lg font-semibold">
                  {SEVERITY_ICON[selectedEvent.severity]} {selectedEvent.description}
                </div>
                <div className="mt-1 text-sm text-slate-400">Decision Score: {selectedEvent.decision_score}</div>

                {/* Part F vs Part I: Watch Moment = seek the existing video.
                    Generate Clip = create a persistent trimmed video. Kept
                    visually and functionally distinct so users don't
                    confuse the two (Part N). */}
                <div className="mt-3 flex flex-wrap gap-2">
                  {videoUrl && resolveEventContextWindow(selectedEvent, effectiveDuration) && (
                    <button
                      onClick={() => handleWatchMoment(selectedEvent)}
                      className="rounded-md bg-accent/10 px-3 py-1.5 text-sm font-medium text-accent"
                    >
                      ▶ Watch Moment
                    </button>
                  )}

                  {videoUrl && (
                    <GenerateClipButton
                      status={clipState?.status ?? "idle"}
                      clipUrl={clipState?.clipUrl ?? null}
                      error={clipState?.error ?? null}
                      onGenerate={() => requestClip(selectedEvent.id)}
                    />
                  )}
                </div>
              </div>

              {/* Batch 3.5 gap fix: statistics_evidence was already
                  generated (linkStatisticsEvidenceForMatch) and already
                  fetched here (the analysis_events select("*") above), but
                  never rendered. Real, already-persisted strings only —
                  never computed or invented here. Null/empty renders
                  nothing extra beyond the explicit fallback line below. */}
              {selectedEvent.statistics_evidence && selectedEvent.statistics_evidence.length > 0 ? (
                <div className="rounded-md border border-pitch-700 bg-pitch-900 p-3 text-sm">
                  <div className="mb-1 font-semibold text-accent">Statistics evidence</div>
                  <ul className="list-disc pl-5 text-slate-300">
                    {selectedEvent.statistics_evidence.map((line, i) => (
                      <li key={i}>{line}</li>
                    ))}
                  </ul>
                </div>
              ) : (
                <p className="text-xs text-slate-500">No statistics evidence available for this event.</p>
              )}

              {selectedTactical && (
                <div>
                  <h3 className="mb-2 text-sm font-semibold text-slate-300">What You Did</h3>
                  <TacticalPitch data={selectedTactical} variant="actual" />

                  <h3 className="mb-2 mt-4 text-sm font-semibold text-slate-300">Better Option</h3>
                  <TacticalPitch data={selectedTactical} variant="recommended" />

                  {selectedTactical.explanation && (
                    <div className="mt-4 rounded-md border border-pitch-700 bg-pitch-900 p-3 text-sm text-slate-300">
                      <span className="font-semibold text-accent">Why: </span>
                      {selectedTactical.explanation}
                    </div>
                  )}
                </div>
              )}

              {selectedEvent.better_option && (
                <div className="rounded-md border border-pitch-700 bg-pitch-900 p-3 text-sm">
                  <span className="font-semibold text-accent">Better option: </span>
                  {selectedEvent.better_option}
                </div>
              )}
              {selectedEvent.reasoning && (
                <div className="rounded-md border border-pitch-700 bg-pitch-900 p-3 text-sm text-slate-400">
                  {selectedEvent.reasoning}
                </div>
              )}
            </div>
          ) : (
            <p className="text-slate-500">Select a moment from the timeline.</p>
          )}
        </div>
      </div>
    </div>
  );
}

/** Part M — the four real lifecycle states, nothing UI-only/simulated. */
function GenerateClipButton({
  status,
  clipUrl,
  error,
  onGenerate,
}: {
  status: "idle" | "pending" | "processing" | "completed" | "failed";
  clipUrl: string | null;
  error: string | null;
  onGenerate: () => void;
}) {
  if (status === "completed" && clipUrl) {
    return (
      <a
        href={clipUrl}
        target="_blank"
        rel="noreferrer"
        className="rounded-md bg-emerald-500/10 px-3 py-1.5 text-sm font-medium text-emerald-400"
      >
        🎬 Watch Clip
      </a>
    );
  }
  if (status === "pending") {
    return (
      <button disabled className="rounded-md bg-pitch-700 px-3 py-1.5 text-sm font-medium text-slate-400">
        Preparing clip…
      </button>
    );
  }
  if (status === "processing") {
    return (
      <button disabled className="rounded-md bg-pitch-700 px-3 py-1.5 text-sm font-medium text-slate-400">
        Generating clip…
      </button>
    );
  }
  if (status === "failed") {
    return (
      <button
        onClick={onGenerate}
        className="rounded-md bg-danger/10 px-3 py-1.5 text-sm font-medium text-danger"
        title={error ?? undefined}
      >
        Generation failed — Retry
      </button>
    );
  }
  return (
    <button onClick={onGenerate} className="rounded-md border border-pitch-700 px-3 py-1.5 text-sm font-medium text-slate-300">
      Generate Clip
    </button>
  );
}
