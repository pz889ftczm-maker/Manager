import { useState } from "react";
import { useAuth } from "../hooks/useAuth";
import { supabase } from "../lib/supabaseClient";

export function Settings() {
  const { user, signOut } = useAuth();
  const [newPassword, setNewPassword] = useState("");
  const [status, setStatus] = useState<string | null>(null);

  async function handlePasswordChange(e: React.FormEvent) {
    e.preventDefault();
    const { error } = await supabase.auth.updateUser({ password: newPassword });
    setStatus(error ? error.message : "Password updated.");
    setNewPassword("");
  }

  return (
    <div className="mx-auto max-w-md">
      <h1 className="mb-6 text-2xl font-bold">Settings</h1>

      <div className="mb-8 rounded-lg border border-pitch-700 bg-pitch-900 p-4">
        <div className="text-xs uppercase tracking-wide text-slate-500">Account</div>
        <div className="mt-1 text-sm text-slate-300">{user?.email}</div>
      </div>

      <form onSubmit={handlePasswordChange} className="mb-8 rounded-lg border border-pitch-700 bg-pitch-900 p-4">
        <label className="mb-1 block text-sm text-slate-400">Change password</label>
        <input
          type="password"
          minLength={8}
          required
          value={newPassword}
          onChange={(e) => setNewPassword(e.target.value)}
          className="mb-3 w-full rounded-md border border-pitch-700 bg-pitch-800 px-3 py-2 text-sm text-slate-100"
        />
        <button type="submit" className="rounded-md bg-accent px-4 py-2 text-sm font-semibold text-pitch-950">
          Update password
        </button>
        {status && <p className="mt-2 text-sm text-slate-400">{status}</p>}
      </form>

      <button onClick={signOut} className="text-sm text-danger hover:underline">
        Log out
      </button>
    </div>
  );
}
