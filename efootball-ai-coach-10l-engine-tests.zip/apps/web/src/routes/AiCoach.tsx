import { useEffect, useRef, useState } from "react";
import { supabase } from "../lib/supabaseClient";
import { useAuth } from "../hooks/useAuth";
import type { AiCoachMessage } from "@efootball/shared";

const CITATION_MARKER_REGEX = /\{\{cite:[0-9a-fA-F-]{36}\}\}/g;

function stripCitationMarkers(content: string): string {
  return content.replace(CITATION_MARKER_REGEX, "").trim();
}

export function AiCoach() {
  const { user } = useAuth();
  const [messages, setMessages] = useState<AiCoachMessage[]>([]);
  const [input, setInput] = useState("");
  const [sending, setSending] = useState(false);
  const bottomRef = useRef<HTMLDivElement>(null);

  useEffect(() => {
    if (!user) return;
    supabase
      .from("ai_coach_messages")
      .select("*")
      .eq("user_id", user.id)
      .order("created_at", { ascending: true })
      .then(({ data }) => setMessages(data ?? []));
  }, [user]);

  useEffect(() => {
    bottomRef.current?.scrollIntoView({ behavior: "smooth" });
  }, [messages]);

  async function handleSend() {
    if (!input.trim() || !user) return;
    const userMessage = input.trim();
    setInput("");
    setSending(true);

    // Optimistically show the user's message.
    const optimistic: AiCoachMessage = {
      id: `temp-${Date.now()}`,
      user_id: user.id,
      match_id: null,
      role: "user",
      content: userMessage,
      referenced_event_ids: null,
      created_at: new Date().toISOString(),
    };
    setMessages((prev) => [...prev, optimistic]);

    try {
      // This must hit a server-side endpoint: it needs to (a) pull the
      // user's real match/event history with the service-role key to build
      // a grounded context summary, then (b) call AiProvider.chat(). The
      // browser only ever sees the reply, never the AI key.
      const { data: sessionData } = await supabase.auth.getSession();
      const res = await fetch(`${import.meta.env.VITE_SUPABASE_URL}/functions/v1/coach-chat`, {
        method: "POST",
        headers: {
          "Content-Type": "application/json",
          Authorization: `Bearer ${sessionData.session?.access_token}`,
        },
        body: JSON.stringify({ message: userMessage }),
      });
      if (!res.ok) throw new Error("Coach is unavailable right now.");
      const { userRow, assistantRow } = await res.json();

      setMessages((prev) => [...prev.filter((m) => m.id !== optimistic.id), userRow, assistantRow]);
    } catch (err) {
      setMessages((prev) => [
        ...prev,
        {
          id: `error-${Date.now()}`,
          user_id: user.id,
          match_id: null,
          role: "assistant",
          content: (err as Error).message,
          referenced_event_ids: null,
          created_at: new Date().toISOString(),
        },
      ]);
    } finally {
      setSending(false);
    }
  }

  return (
    <div className="flex h-[calc(100vh-8rem)] flex-col md:h-[calc(100vh-4rem)]">
      <h1 className="mb-4 text-2xl font-bold">AI Coach</h1>

      <div className="flex-1 space-y-3 overflow-y-auto rounded-lg border border-pitch-700 bg-pitch-900 p-4">
        {messages.length === 0 && (
          <p className="text-sm text-slate-500">
            Ask about your gameplay — e.g. "Why do I lose the ball so often?" or "What position suits me?"
            Answers are grounded in your analyzed matches.
          </p>
        )}
        {messages.map((m) => (
          <div key={m.id} className={`flex ${m.role === "user" ? "justify-end" : "justify-start"}`}>
            <div
              className={`max-w-[80%] rounded-lg px-4 py-2 text-sm ${
                m.role === "user" ? "bg-accent text-pitch-950" : "bg-pitch-800 text-slate-100"
              }`}
            >
              {/* The server already strips {{cite:UUID}} markers before storing
                  content (see supabase/functions/coach-chat/index.ts), but this
                  is a defensive second pass in case an older stored message still
                  has raw markers in it. */}
              {stripCitationMarkers(m.content)}
              {m.role === "assistant" && m.referenced_event_ids && m.referenced_event_ids.length > 0 && (
                <div className="mt-1 text-[11px] text-slate-400">
                  Referenced {m.referenced_event_ids.length} analyzed event
                  {m.referenced_event_ids.length === 1 ? "" : "s"} from your matches.
                </div>
              )}
            </div>
          </div>
        ))}
        <div ref={bottomRef} />
      </div>

      <div className="mt-3 flex gap-2">
        <input
          value={input}
          onChange={(e) => setInput(e.target.value)}
          onKeyDown={(e) => e.key === "Enter" && handleSend()}
          placeholder="Ask your coach…"
          className="flex-1 rounded-md border border-pitch-700 bg-pitch-800 px-3 py-2 text-sm text-slate-100 focus:border-accent focus:outline-none"
        />
        <button
          onClick={handleSend}
          disabled={sending || !input.trim()}
          className="rounded-md bg-accent px-4 py-2 text-sm font-semibold text-pitch-950 disabled:opacity-50"
        >
          Send
        </button>
      </div>
    </div>
  );
}
