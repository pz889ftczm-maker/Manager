import { supabase } from "./supabaseClient";
import type { ManagerLibrary } from "@efootball/shared";

// Batch 6B-4 — thin client wrapper around
// supabase/functions/manager-library-save (the only path that writes to
// manager_library — see that function's header comment) plus plain
// RLS-scoped reads for the list/edit views. Mirrors playerLibrary.ts's
// shape: resolve the current session token, call the Edge Function,
// surface its safe error message directly (the function itself never
// leaks internals — see internalErrorResponse in
// supabase/functions/_shared/helpers.ts).

export interface SaveManagerLibraryPayload {
  /** Present => update that row; absent => insert a new one. */
  id?: string;
  name: string | null;
  possession_rating: number | null;
  quick_counter_rating: number | null;
  long_ball_counter_rating: number | null;
  out_wide_rating: number | null;
  long_ball_rating: number | null;
  /** Omit this key entirely to leave an existing entry's manager image
   * untouched (see manager-library-save/index.ts's hasImagePathField).
   * Include it (even as null) to set/clear it — always included when
   * saving a brand-new entry from a fresh upload+extraction. */
  manager_image_path?: string | null;
}

export interface SaveManagerLibraryResult {
  manager: ManagerLibrary;
  /** True when this exact (name, ratings) variant already existed and
   * the save was recognized as an accidental duplicate — the returned
   * `manager` is the pre-existing row, not a new one. */
  duplicate: boolean;
}

/**
 * Persists a reviewed manager_library entry. Never sends a user_id — the
 * Edge Function determines ownership from the caller's own session; this
 * only ever acts on the authenticated caller's own data (enforced
 * independently by RLS regardless).
 */
export async function saveManagerLibraryEntry(payload: SaveManagerLibraryPayload): Promise<SaveManagerLibraryResult> {
  const { data: sessionData } = await supabase.auth.getSession();
  const accessToken = sessionData.session?.access_token;
  if (!accessToken) throw new Error("Your session has expired. Please sign in again.");

  let res: Response;
  try {
    res = await fetch(`${import.meta.env.VITE_SUPABASE_URL}/functions/v1/manager-library-save`, {
      method: "POST",
      headers: {
        "Content-Type": "application/json",
        Authorization: `Bearer ${accessToken}`,
      },
      body: JSON.stringify(payload),
    });
  } catch {
    throw new Error("Could not reach the server. Check your connection and try again.");
  }

  let body: unknown;
  try {
    body = await res.json();
  } catch {
    body = null;
  }

  if (!res.ok) {
    const message =
      body && typeof body === "object" && typeof (body as { error?: unknown }).error === "string"
        ? (body as { error: string }).error
        : "Failed to save manager. Please try again.";
    throw new Error(message);
  }

  return body as SaveManagerLibraryResult;
}

/** Lists the caller's own saved Manager Library entries, most recently
 * updated first. RLS (manager_library_select_own) scopes this to the
 * caller's own rows — no server relay needed for a plain read, same
 * convention as listPlayerLibrary. */
export async function listManagerLibrary(): Promise<ManagerLibrary[]> {
  const { data, error } = await supabase
    .from("manager_library")
    .select("*")
    .order("updated_at", { ascending: false });
  if (error) throw error;
  return (data ?? []) as ManagerLibrary[];
}

/** Fetches a single saved entry for the Edit flow. Returns null if it
 * doesn't exist or isn't the caller's own (RLS makes those
 * indistinguishable from here, which is correct — never confirm/deny
 * another user's data). */
export async function getManagerLibraryEntry(id: string): Promise<ManagerLibrary | null> {
  const { data, error } = await supabase.from("manager_library").select("*").eq("id", id).maybeSingle();
  if (error) throw error;
  return (data as ManagerLibrary | null) ?? null;
}
