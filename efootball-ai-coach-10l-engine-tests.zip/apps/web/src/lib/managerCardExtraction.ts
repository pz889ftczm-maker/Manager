import { supabase } from "./supabaseClient";
import type { ManagerCardDraft } from "@efootball/shared";

// Batch 6B-4 — thin client wrapper around
// supabase/functions/manager-card-extract (Batch 6B-3). Mirrors
// playerCardExtraction.ts's shape: resolve the current session token,
// call the Edge Function, surface its safe error message directly (the
// function itself never leaks internals — see internalErrorResponse in
// supabase/functions/_shared/helpers.ts).

export interface ExtractManagerCardParams {
  /** Object path returned by uploadManagerImage() in managerImageStorage.ts. */
  objectPath: string;
}

export interface ExtractManagerCardResult {
  draft: ManagerCardDraft;
}

/**
 * Requests AI extraction of an already-uploaded manager-image. Returns
 * the extracted (validated, null-safe) draft only — this never saves
 * anything to manager_library. The Manager Review/Edit UI decides if/
 * when to persist the reviewed result via saveManagerLibraryEntry.
 */
export async function requestManagerCardExtraction(
  params: ExtractManagerCardParams
): Promise<ExtractManagerCardResult> {
  const { data: sessionData } = await supabase.auth.getSession();
  const accessToken = sessionData.session?.access_token;
  if (!accessToken) throw new Error("Your session has expired. Please sign in again.");

  let res: Response;
  try {
    res = await fetch(`${import.meta.env.VITE_SUPABASE_URL}/functions/v1/manager-card-extract`, {
      method: "POST",
      headers: {
        "Content-Type": "application/json",
        Authorization: `Bearer ${accessToken}`,
      },
      body: JSON.stringify(params),
    });
  } catch {
    throw new Error("Could not reach the server. Check your connection and try again.");
  }

  let body: unknown;
  try {
    body = await res.json();
  } catch {
    body = null;
  }

  if (!res.ok) {
    const message =
      body && typeof body === "object" && typeof (body as { error?: unknown }).error === "string"
        ? (body as { error: string }).error
        : "Failed to extract manager card. Please try again.";
    throw new Error(message);
  }

  return body as ExtractManagerCardResult;
}
