import { supabase } from "./supabaseClient";
import {
  DEFAULT_MAX_IMAGE_MB,
  buildSafeManagerImageStoragePath,
  guessExtensionFromMimeOrName,
  validateUpload,
} from "@efootball/shared";

// Batch 6B-2 — Manager Library image upload/storage foundation only.
// Mirrors apps/web/src/lib/playerCardStorage.ts (Batch 6A-2) exactly,
// applied to the private `manager-images` bucket instead of
// `player-cards`. Nothing in this file is wired into a route/page yet —
// no Manager Library UI, review/edit flow, or AI extraction exists yet
// (all explicitly out of scope for this batch); a later batch calls
// these from that UI, the same way playerCardStorage.ts's Batch 6A-2
// functions weren't wired into PlayerLibrary.tsx until Batch 6A-4.
//
// Client uploads directly to the private bucket using its own session
// (RLS-enforced by 0015_manager_images_storage.sql), no Edge Function
// relay needed for either the upload or reading it back — same
// convention as the player-card and screenshot upload paths.

const MANAGER_IMAGES_BUCKET = "manager-images";
// This batch's spec fixes the manager-images limit at 15MB — the
// manager-images Storage bucket (0015_manager_images_storage.sql) is the
// actual authoritative enforcement of that, not this constant. Reuses
// the same VITE_MAX_IMAGE_UPLOAD_MB knob playerCardStorage.ts reads
// (rather than inventing a second one), but clamped with Math.min so a
// misconfigured/raised env value can never let client-side validation
// accept something the bucket would reject anyway — this batch requires
// the client can't be configured above 15MB regardless of that env var.
const MAX_MANAGER_IMAGE_MB = Math.min(Number(import.meta.env.VITE_MAX_IMAGE_UPLOAD_MB ?? DEFAULT_MAX_IMAGE_MB), 15);

export interface UploadedManagerImage {
  objectPath: string;
}

/**
 * Uploads one manager-image to the private manager-images bucket and
 * returns its SAFE, server-chosen object path — never derived from the
 * user-supplied filename (same convention as buildSafePlayerCardStoragePath
 * / uploadPlayerCardImage). Validates real file bytes (magic-byte sniff),
 * not just the browser-reported MIME type/extension.
 *
 * Deliberately does NOT touch manager_library — callers decide if/when to
 * attach the returned objectPath to a library row (no Manager Library
 * save flow exists yet — out of scope for this batch, same as
 * uploadPlayerCardImage before Batch 6A-4). If a caller's own follow-up
 * step fails after this resolves, call deleteManagerImage(objectPath,
 * userId) to avoid leaving an orphaned object.
 */
export async function uploadManagerImage(file: File, userId: string): Promise<UploadedManagerImage> {
  const head = new Uint8Array(await file.slice(0, 4096).arrayBuffer());
  const { valid, errors, detected } = validateUpload({
    expectedKind: "image",
    sizeBytes: file.size,
    maxImageMb: MAX_MANAGER_IMAGE_MB,
    headBytes: head,
  });
  if (!valid) throw new Error(errors.join(" "));

  const extension = detected?.extension ?? guessExtensionFromMimeOrName(file.type, file.name);
  const objectPath = buildSafeManagerImageStoragePath(userId, extension, crypto.randomUUID());

  // upsert:false — object names are random, so a collision should never
  // happen; false makes that an error instead of a silent overwrite.
  const { error } = await supabase.storage
    .from(MANAGER_IMAGES_BUCKET)
    .upload(objectPath, file, { upsert: false, contentType: detected?.mimeType ?? file.type ?? undefined });
  if (error) throw error;

  return { objectPath };
}

/**
 * Deletes a manager image the caller owns. Storage RLS
 * (0015_manager_images_storage.sql) independently enforces that a user
 * can only delete objects under their own uid prefix — the check here is
 * defense-in-depth so a caller can't even attempt a cross-user path.
 * Used both for an explicit "remove my manager image" action and for
 * cleaning up an orphan object after a failed follow-up step.
 */
export async function deleteManagerImage(objectPath: string, ownerId: string): Promise<void> {
  if (!objectPath.startsWith(`${ownerId}/`)) {
    throw new Error("Refusing to delete a manager image outside the caller's own storage prefix.");
  }
  const { error } = await supabase.storage.from(MANAGER_IMAGES_BUCKET).remove([objectPath]);
  if (error) throw error;
}

/**
 * Short-lived signed URL for displaying a private manager image (never a
 * public URL). Minted client-side — Supabase Storage checks the caller's
 * own JWT against the SELECT policy above, so this can only ever succeed
 * for the signed-in user's own objects. No server relay/Edge Function is
 * needed for this to stay secure. Same convention as
 * getPlayerCardSignedUrl.
 */
export async function getManagerImageSignedUrl(objectPath: string, expiresInSeconds = 3600): Promise<string> {
  const { data, error } = await supabase.storage
    .from(MANAGER_IMAGES_BUCKET)
    .createSignedUrl(objectPath, expiresInSeconds);
  if (error || !data) throw error ?? new Error("Failed to create signed URL for manager image.");
  return data.signedUrl;
}
