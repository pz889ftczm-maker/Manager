import { supabase } from "./supabaseClient";
import type { TeamMember } from "@efootball/shared";
import { validateTeamMemberInput, isUniqueViolation, TEAM_MEMBERS_UNIQUE_CONSTRAINT } from "@efootball/shared";

// Batch 7C — thin client wrapper around public.team_members
// (migration 0019_team_members.sql). Unlike playerLibrary.ts/
// managerLibrary.ts, this does NOT go through an Edge Function: those
// two exist because saving a library entry needs server-side field
// validation/sanitization of arbitrary AI-reviewed content
// (player-library-save/manager-library-save). A team_members row has no
// such content — it's just two ids — and 0019's RLS policies are
// already the complete authorization boundary (both ownership sides
// checked in Postgres itself), so a plain RLS-scoped client call is
// both sufficient and the simplest thing that's actually correct here.
// Every call below runs as the signed-in user via the shared anon-key
// `supabase` client (supabaseClient.ts) — no service-role key is ever
// used in this file, and no caller can pass a user_id (there isn't one
// to pass: team_members has none — see migration 0019's design notes).

/** True when `err` is the "this player is already on this team" unique
 * violation from team_members_team_player_uniq (spec section 6 —
 * "duplicate (team_id, player_id) must fail safely"), as opposed to
 * some other/unexpected error. */
export function isDuplicateTeamMember(err: unknown): boolean {
  return isUniqueViolation(err, TEAM_MEMBERS_UNIQUE_CONSTRAINT);
}

/** Lists the current roster (team_members rows) for one of the caller's
 * own teams, most recently added first. RLS (team_members_select_own)
 * scopes this to rows on a team the caller owns — a teamId the caller
 * doesn't own simply comes back empty, same "never confirm/deny another
 * user's data" convention as getPlayerLibraryEntry (playerLibrary.ts).
 * Returns the bare junction rows only (id/team_id/player_id/timestamps)
 * — join through player_id into player_library yourself (e.g. via
 * listPlayerLibrary) if you need card details; this file intentionally
 * never duplicates that data (spec section 4). */
export async function listTeamMembers(teamId: string): Promise<TeamMember[]> {
  const { data, error } = await supabase
    .from("team_members")
    .select("*")
    .eq("team_id", teamId)
    .order("created_at", { ascending: false });
  if (error) throw error;
  return (data ?? []) as TeamMember[];
}

export interface AddTeamMemberResult {
  member: TeamMember | null;
  /** True when this exact (team_id, player_id) pair was already a
   * member and the insert was recognized as an accidental duplicate
   * (spec section 6) rather than a new row being created. When true,
   * `member` is the pre-existing row if it could be looked up under
   * RLS, or null if not (e.g. it belongs to a since-changed ownership
   * state) — callers should treat `duplicate: true` itself as the
   * signal, not assume `member` is always populated. */
  duplicate: boolean;
}

/**
 * Adds one of the caller's own player_library entries to one of the
 * caller's own teams. Never sends a user_id (team_members has none —
 * see migration 0019); ownership of both the team and the player is
 * enforced independently by RLS (team_members_insert_own) regardless of
 * anything checked here. A duplicate add is reported back as
 * `duplicate: true` rather than throwing, so the UI can show "already
 * on this team" instead of a raw constraint-violation error (spec
 * section 6 — "Handle duplicate membership without crashing the UI" /
 * "Do not silently create duplicate rows").
 */
export async function addTeamMember(teamId: string, playerId: string): Promise<AddTeamMemberResult> {
  const { valid, errors } = validateTeamMemberInput({ team_id: teamId, player_id: playerId });
  if (!valid) {
    throw new Error(`Invalid team member: ${errors.join("; ")}`);
  }

  const { data, error } = await supabase
    .from("team_members")
    .insert({ team_id: teamId, player_id: playerId })
    .select("*")
    .single();

  if (error) {
    if (isDuplicateTeamMember(error)) {
      const existing = await supabase
        .from("team_members")
        .select("*")
        .eq("team_id", teamId)
        .eq("player_id", playerId)
        .maybeSingle();
      // A lookup failure here (e.g. RLS no longer permits it) still
      // reports the duplicate rather than throwing — the insert itself
      // unambiguously hit the duplicate constraint.
      return { member: (existing.data as TeamMember | null) ?? null, duplicate: true };
    }
    throw error;
  }

  return { member: data as TeamMember, duplicate: false };
}

/** Removes a player from a team by deleting its team_members row.
 * Deletes only the junction row — never the underlying team_library or
 * player_library record (spec section 9: "Removing a player from a
 * team only deletes the junction row"). RLS (team_members_delete_own)
 * requires the caller to own the team; removing a member does not
 * additionally require the caller to still own the player_library row
 * (see migration 0019's DELETE policy design note). Resolves silently
 * if `id` doesn't exist or isn't reachable under RLS — same
 * indistinguishable-404 convention used throughout this repo, since a
 * delete of something already gone/not-yours should be a no-op, not an
 * error. */
export async function removeTeamMember(id: string): Promise<void> {
  const { error } = await supabase.from("team_members").delete().eq("id", id);
  if (error) throw error;
}
