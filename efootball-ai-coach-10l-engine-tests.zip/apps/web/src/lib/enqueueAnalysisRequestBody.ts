import type { FootballType } from "@efootball/shared";

// Split out of enqueueAnalysis.ts (9C-1) so the teamId/formationId
// request-body-forwarding logic is a pure function with zero
// dependencies — importable and unit-testable (see
// test/enqueueAnalysis.test.ts) without pulling in the real Supabase
// browser client, which reads import.meta.env and is only meaningful
// inside a Vite build/dev server.

export interface EnqueueAnalysisParams {
  matchId: string;
  mode: "video" | "screenshot";
  storageObjectPaths: string[];
  mediaId?: string | null;
  /** 9C-1: forwarded to analysis-enqueue so the worker can attach the
   * match's team/formation context (see matches.team_id/formation_id,
   * migration 0028_matches_team_formation_context.sql). Optional —
   * omit or pass null when the caller has no team/formation selection
   * to attach; the Edge Function treats an absent teamId exactly like
   * every match analyzed before this existed. */
  teamId?: string | null;
  /** Must belong to teamId — ignored server-side (and rejected) without
   * a teamId alongside it. */
  formationId?: string | null;
  /** 10A: forwarded to analysis-enqueue so it can attach the match's
   * football context (matches.football_type/team_size, migration
   * 0029_football_match_context.sql). Optional — no caller in this
   * codebase supplies this yet (no football-type selection UI exists;
   * out of scope for 10A), but the field exists here so the client and
   * server request shapes stay in sync and a future caller has
   * exactly one, already-tested place to forward it from. team_size is
   * deliberately not a parameter here at all — see
   * validateFootballTypeInput's own header comment
   * (packages/shared/src/footballMatchContext.ts) for why it is always
   * derived server-side instead. */
  footballType?: FootballType | null;
}

/** Builds the exact JSON body enqueueAnalysis() sends to
 * analysis-enqueue. teamId/formationId/footballType are all normalized
 * to `null` (never omitted from the object) when not provided,
 * matching what analysis-enqueue's optional-field checks expect. */
export function buildAnalysisEnqueueRequestBody(params: EnqueueAnalysisParams) {
  return {
    matchId: params.matchId,
    mode: params.mode,
    storageObjectPaths: params.storageObjectPaths,
    mediaId: params.mediaId ?? null,
    teamId: params.teamId ?? null,
    formationId: params.formationId ?? null,
    footballType: params.footballType ?? null,
  };
}
