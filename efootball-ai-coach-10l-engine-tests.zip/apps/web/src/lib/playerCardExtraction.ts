import { supabase } from "./supabaseClient";
import type { PlayerCardDraft } from "@efootball/shared";

// Batch 6A-3 — thin client wrapper around
// supabase/functions/player-card-extract. Deliberately not wired into any
// route/page yet (no Review/Edit UI exists — that's a later batch,
// same scope note as apps/web/src/lib/playerCardStorage.ts's Batch 6A-2
// upload helpers). Mirrors enqueueAnalysis.ts's shape: resolve the
// current session token, call the Edge Function, surface its safe
// error message directly (the function itself never leaks internals —
// see internalErrorResponse in supabase/functions/_shared/helpers.ts).

export interface ExtractPlayerCardParams {
  /** Object path returned by uploadPlayerCardImage() in playerCardStorage.ts. */
  objectPath: string;
}

export interface ExtractPlayerCardResult {
  draft: PlayerCardDraft;
}

/**
 * Requests AI extraction of an already-uploaded player-card image.
 * Returns the extracted (validated, null-safe) draft only — this never
 * saves anything to player_library. A future Review/Edit UI decides
 * if/when to persist the reviewed result.
 */
export async function requestPlayerCardExtraction(
  params: ExtractPlayerCardParams
): Promise<ExtractPlayerCardResult> {
  const { data: sessionData } = await supabase.auth.getSession();
  const accessToken = sessionData.session?.access_token;
  if (!accessToken) throw new Error("Your session has expired. Please sign in again.");

  let res: Response;
  try {
    res = await fetch(`${import.meta.env.VITE_SUPABASE_URL}/functions/v1/player-card-extract`, {
      method: "POST",
      headers: {
        "Content-Type": "application/json",
        Authorization: `Bearer ${accessToken}`,
      },
      body: JSON.stringify(params),
    });
  } catch {
    throw new Error("Could not reach the server. Check your connection and try again.");
  }

  let body: unknown;
  try {
    body = await res.json();
  } catch {
    body = null;
  }

  if (!res.ok) {
    const message =
      body && typeof body === "object" && typeof (body as { error?: unknown }).error === "string"
        ? (body as { error: string }).error
        : "Failed to extract player card. Please try again.";
    throw new Error(message);
  }

  return body as ExtractPlayerCardResult;
}
