import { supabase } from "./supabaseClient";
import type { TeamFormation, PositionsJson } from "@efootball/shared";
import {
  validateTeamFormationInput,
  validateTeamFormationFields,
  isDuplicateTeamFormationName,
  TEAM_FORMATION_NAME_UNIQUE_CONSTRAINT,
} from "@efootball/shared";

// Batch 8C — thin client wrapper around public.team_formations
// (migration 0021_team_formations.sql). Same reasoning as
// teamLibrary.ts/teamMembers.ts: this does NOT go through an Edge
// Function — a team_formations row is hand-authored (a name, a
// formation code, a layout the user placed) with no AI-reviewed
// content to sanitize, and 0021's RLS policies are already the
// complete authorization boundary (ownership derived through
// team_id -> team_library.user_id, checked in Postgres itself), so a
// plain RLS-scoped client call is both sufficient and the simplest
// thing that's actually correct here. Every call below runs as the
// signed-in user via the shared anon-key `supabase` client
// (supabaseClient.ts) — no service-role key is used, and no caller can
// pass a user_id (team_formations has none — see migration 0021's
// design notes).
//
// This file was the missing CRUD wrapper called out at the end of
// Batch 8B: 8A/8B built the schema + shared validation, but nothing in
// apps/web previously read or wrote team_formations rows.

/** True when `err` is the "this team already has a formation with this
 * name" unique violation from team_formations_team_name_uniq (spec
 * section 7), as opposed to some other/unexpected error. */
export function isDuplicateFormationName(err: unknown): boolean {
  return isDuplicateTeamFormationName(err);
}

/** Lists the caller's own saved formations for one team, most recently
 * updated first. RLS (team_formations_select_own) scopes this to a
 * team the caller owns — a teamId the caller doesn't own simply comes
 * back empty, same "never confirm/deny another user's data" convention
 * as listTeamMembers (teamMembers.ts). */
export async function listTeamFormations(teamId: string): Promise<TeamFormation[]> {
  const { data, error } = await supabase
    .from("team_formations")
    .select("*")
    .eq("team_id", teamId)
    .order("updated_at", { ascending: false });
  if (error) throw error;
  return (data ?? []) as TeamFormation[];
}

/** Fetches one of the caller's own formations by id, or null if it
 * doesn't exist or isn't reachable under RLS — same
 * indistinguishable-404 convention as getTeamLibraryEntry
 * (teamLibrary.ts), never a thrown "not found" the UI would have to
 * special-case. */
export async function getTeamFormation(id: string): Promise<TeamFormation | null> {
  const { data, error } = await supabase.from("team_formations").select("*").eq("id", id).maybeSingle();
  if (error) throw error;
  return (data as TeamFormation | null) ?? null;
}

export interface TeamFormationPayload {
  team_id: string;
  name: string;
  formation_code: string;
  positions: PositionsJson;
  tactical_instructions?: Record<string, unknown> | null;
}

export interface SaveTeamFormationResult {
  formation: TeamFormation;
  /** True when this exact (team_id, name) pair already existed and the
   * save was recognized as an accidental duplicate (spec section 7)
   * rather than a new row being created — the returned `formation` is
   * the pre-existing row, not a new one. Only ever true for a create;
   * renameTeamFormation surfaces the same constraint by throwing
   * instead, since an edit has no sensible "existing row" to fall back
   * to (the row being edited IS one side of the conflict). */
  duplicate: boolean;
}

/**
 * Creates a new formation for one of the caller's own teams. Never
 * sends a user_id (team_formations has none — see migration 0021);
 * ownership of the team is enforced independently by RLS
 * (team_formations_insert_own) regardless of anything checked here. A
 * duplicate name on the same team is reported back as
 * `duplicate: true` rather than throwing, so the UI can show "you
 * already have a formation with this name" instead of a raw
 * constraint-violation error (spec section 7 — same convention as
 * addTeamMember in teamMembers.ts).
 */
export async function createTeamFormation(payload: TeamFormationPayload): Promise<SaveTeamFormationResult> {
  const { valid, sanitized, errors } = validateTeamFormationInput({
    ...payload,
    tactical_instructions: payload.tactical_instructions ?? null,
  });
  if (!valid) {
    throw new Error(`Invalid formation: ${errors.join("; ")}`);
  }

  const { data, error } = await supabase.from("team_formations").insert(sanitized).select("*").single();

  if (error) {
    if (isDuplicateFormationName(error)) {
      const existing = await supabase
        .from("team_formations")
        .select("*")
        .eq("team_id", sanitized.team_id)
        .ilike("name", sanitized.name)
        .maybeSingle();
      // Same convention as createTeam (teamLibrary.ts): only report the
      // duplicate if the pre-existing row could actually be looked up
      // under RLS — never fabricate a fake row to return instead.
      if (existing.data) {
        return { formation: existing.data as TeamFormation, duplicate: true };
      }
    }
    throw error;
  }

  return { formation: data as TeamFormation, duplicate: false };
}

/**
 * Updates the name/formation_code/positions/tactical_instructions of
 * one of the caller's own formations — never repoints team_id (use
 * create + delete for that instead, so RLS's ownership checks always
 * see a complete, coherent team_id rather than a partial rewrite, same
 * convention as teamFormationPlayers.ts's updateFormationPlayerSlot
 * never changing formation_id/player_id). Fields not present in
 * `payload` are left untouched — a caller updating just `positions`
 * (e.g. after a drag) doesn't need to also resend name/formation_code.
 * Validated via validateTeamFormationFields (team-id-independent), not
 * validateTeamFormationInput, since team_id isn't part of this call.
 * RLS (team_formations_update_own) still requires the caller to own
 * the formation's team. A rename that collides with another of the
 * caller's formations on the same team throws (unlike create, there is
 * no sensible "existing row" to return instead — the row being edited
 * IS one side of the naming conflict) with isDuplicateFormationName
 * recognizing it, same as before.
 */
export async function updateTeamFormation(
  id: string,
  payload: Partial<Omit<TeamFormationPayload, "team_id">>
): Promise<TeamFormation> {
  const update: Record<string, unknown> = {};

  if (payload.name !== undefined || payload.formation_code !== undefined || payload.positions !== undefined || payload.tactical_instructions !== undefined) {
    const current = await getTeamFormation(id);
    if (!current) {
      throw new Error(`Formation ${id} not found`);
    }

    const { valid, sanitized, errors } = validateTeamFormationFields({
      name: payload.name ?? current.name,
      formation_code: payload.formation_code ?? current.formation_code,
      positions: payload.positions ?? current.positions,
      tactical_instructions:
        payload.tactical_instructions !== undefined ? payload.tactical_instructions : current.tactical_instructions,
    });
    if (!valid) {
      throw new Error(`Invalid formation: ${errors.join("; ")}`);
    }

    if (payload.name !== undefined) update.name = sanitized.name;
    if (payload.formation_code !== undefined) update.formation_code = sanitized.formation_code;
    if (payload.positions !== undefined) update.positions = sanitized.positions;
    if (payload.tactical_instructions !== undefined) update.tactical_instructions = sanitized.tactical_instructions;
  }

  const { data, error } = await supabase.from("team_formations").update(update).eq("id", id).select("*").single();
  if (error) throw error;
  return data as TeamFormation;
}

/** Deletes one of the caller's own formations. Cascades to its
 * team_formation_players assignment rows via migration 0022's
 * `on delete cascade` — never a separate delete call needed for those.
 * RLS (team_formations_delete_own) requires the caller to own the
 * team. Resolves silently if `id` doesn't exist or isn't reachable
 * under RLS — same indistinguishable-404 convention used throughout
 * this repo. */
export async function deleteTeamFormation(id: string): Promise<void> {
  const { error } = await supabase.from("team_formations").delete().eq("id", id);
  if (error) throw error;
}

export { TEAM_FORMATION_NAME_UNIQUE_CONSTRAINT };
