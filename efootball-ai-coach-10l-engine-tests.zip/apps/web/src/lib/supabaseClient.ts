import { createClient } from "@supabase/supabase-js";

// Only the anon key is ever used in browser code. RLS (see
// supabase/migrations/0002_rls.sql) is what actually keeps user data
// private — the anon key alone grants no special access.
const url = import.meta.env.VITE_SUPABASE_URL as string;
const anonKey = import.meta.env.VITE_SUPABASE_ANON_KEY as string;

if (!url || !anonKey) {
  // eslint-disable-next-line no-console
  console.error(
    "Missing VITE_SUPABASE_URL / VITE_SUPABASE_ANON_KEY. Copy .env.example to .env.local."
  );
}

export const supabase = createClient(url, anonKey);
