import { supabase } from "./supabaseClient";
import {
  DEFAULT_MAX_IMAGE_MB,
  buildSafeTeamImageStoragePath,
  guessExtensionFromMimeOrName,
  validateUpload,
} from "@efootball/shared";

// Batch 7B — Team Library image upload/storage foundation only.
// Mirrors apps/web/src/lib/managerImageStorage.ts (Batch 6B-2) exactly,
// applied to the private `team-images` bucket instead of
// `manager-images`. Nothing in this file is wired into a route/page yet —
// no Team UI, creation/edit flow, or image editor/cropper exists yet
// (all explicitly out of scope for this batch); a later batch calls
// these from that UI, the same way managerImageStorage.ts's Batch 6B-2
// functions weren't wired into ManagerLibrary.tsx until a later batch.
//
// Client uploads directly to the private bucket using its own session
// (RLS-enforced by 0017_team_images_storage.sql), no Edge Function relay
// needed for either the upload or reading it back — same convention as
// the player-card and manager-image upload paths.

const TEAM_IMAGES_BUCKET = "team-images";
// This batch's spec fixes the team-images limit at 15MB — the
// team-images Storage bucket (0017_team_images_storage.sql) is the
// actual authoritative enforcement of that, not this constant. Reuses
// the same VITE_MAX_IMAGE_UPLOAD_MB knob playerCardStorage.ts/
// managerImageStorage.ts read (rather than inventing a third one), but
// clamped with Math.min so a misconfigured/raised env value can never
// let client-side validation accept something the bucket would reject
// anyway — this batch requires the client can't be configured above
// 15MB regardless of that env var.
const MAX_TEAM_IMAGE_MB = Math.min(Number(import.meta.env.VITE_MAX_IMAGE_UPLOAD_MB ?? DEFAULT_MAX_IMAGE_MB), 15);

export interface UploadedTeamImage {
  objectPath: string;
}

/**
 * Uploads one team logo/image to the private team-images bucket and
 * returns its SAFE, server-chosen object path — never derived from the
 * user-supplied filename (same convention as
 * buildSafeManagerImageStoragePath / uploadManagerImage). Validates real
 * file bytes (magic-byte sniff), not just the browser-reported MIME
 * type/extension — file.type is never trusted alone.
 *
 * Deliberately does NOT touch team_library — callers decide if/when to
 * attach the returned objectPath to a library row's team_image_path
 * (0018_team_library_image_path.sql). If a caller's own follow-up step
 * fails after this resolves, call deleteTeamImage(objectPath, userId) to
 * avoid leaving an orphaned object.
 */
export async function uploadTeamImage(file: File, userId: string): Promise<UploadedTeamImage> {
  const head = new Uint8Array(await file.slice(0, 4096).arrayBuffer());
  const { valid, errors, detected } = validateUpload({
    expectedKind: "image",
    sizeBytes: file.size,
    maxImageMb: MAX_TEAM_IMAGE_MB,
    headBytes: head,
  });
  if (!valid) throw new Error(errors.join(" "));

  // Content type is derived from the detected/validated format first,
  // falling back to the browser-reported type and finally to undefined —
  // chained `??` only (no mixed `?? ||`), which is the only form that's
  // both valid JS/TS and does what's intended here (an empty string from
  // a missing file.type should NOT masquerade as "no value" the way `||`
  // would treat it; `??` correctly passes it through instead of hiding a
  // genuine, if unhelpful, value behind a silent fallback).
  const extension = detected?.extension ?? guessExtensionFromMimeOrName(file.type, file.name);
  const objectPath = buildSafeTeamImageStoragePath(userId, extension, crypto.randomUUID());
  const contentType = detected?.mimeType ?? file.type ?? undefined;

  // upsert:false — object names are random, so a collision should never
  // happen; false makes that an error instead of a silent overwrite.
  const { error } = await supabase.storage
    .from(TEAM_IMAGES_BUCKET)
    .upload(objectPath, file, { upsert: false, contentType });
  if (error) throw error;

  return { objectPath };
}

/**
 * Deletes a team image the caller owns. Storage RLS
 * (0017_team_images_storage.sql) independently enforces that a user can
 * only delete objects under their own uid prefix — the check here is
 * defense-in-depth so a caller can't even attempt a cross-user path.
 * Used both for an explicit "remove my team image" action and for
 * cleaning up an orphan object after a failed follow-up step.
 */
export async function deleteTeamImage(objectPath: string, ownerId: string): Promise<void> {
  if (!objectPath.startsWith(`${ownerId}/`)) {
    throw new Error("Refusing to delete a team image outside the caller's own storage prefix.");
  }
  const { error } = await supabase.storage.from(TEAM_IMAGES_BUCKET).remove([objectPath]);
  if (error) throw error;
}

/**
 * Short-lived signed URL for displaying a private team image (never a
 * public URL). Minted client-side — Supabase Storage checks the caller's
 * own JWT against the SELECT policy above, so this can only ever succeed
 * for the signed-in user's own objects. No server relay/Edge Function is
 * needed for this to stay secure. Same convention as
 * getManagerImageSignedUrl / getPlayerCardSignedUrl.
 */
export async function getTeamImageSignedUrl(objectPath: string, expiresInSeconds = 3600): Promise<string> {
  const { data, error } = await supabase.storage
    .from(TEAM_IMAGES_BUCKET)
    .createSignedUrl(objectPath, expiresInSeconds);
  if (error || !data) throw error ?? new Error("Failed to create signed URL for team image.");
  return data.signedUrl;
}
