import { supabase } from "./supabaseClient";
import { buildAnalysisEnqueueRequestBody } from "./enqueueAnalysisRequestBody";
import type { EnqueueAnalysisParams } from "./enqueueAnalysisRequestBody";

export type { EnqueueAnalysisParams };

/**
 * Calls supabase/functions/analysis-enqueue. Used by both Analyze.tsx
 * (first submission) and MatchHistory.tsx (Part R/S: "allow retry after
 * failure" — a retry is the exact same call with the SAME already-
 * uploaded object path(s), which the Edge Function's idempotent-enqueue
 * check (0009_production_hardening.sql's 'queued' status) safely accepts
 * even if a previous attempt partially got through.
 *
 * Throws with a message safe to show directly to the user — the Edge
 * Function itself never leaks internals (see internalErrorResponse in
 * supabase/functions/_shared/helpers.ts), so surfacing err.message here
 * is safe by construction rather than something this function has to
 * sanitize itself.
 */
export async function enqueueAnalysis(params: EnqueueAnalysisParams): Promise<void> {
  const { data: sessionData } = await supabase.auth.getSession();
  const accessToken = sessionData.session?.access_token;
  if (!accessToken) throw new Error("Your session has expired. Please sign in again.");

  let res: Response;
  try {
    res = await fetch(`${import.meta.env.VITE_SUPABASE_URL}/functions/v1/analysis-enqueue`, {
      method: "POST",
      headers: {
        "Content-Type": "application/json",
        Authorization: `Bearer ${accessToken}`,
      },
      body: JSON.stringify(buildAnalysisEnqueueRequestBody(params)),
    });
  } catch {
    // Part S — connection lost / request interrupted before a response
    // ever came back. The already-uploaded file and media row are
    // untouched either way, so this is always safe to retry.
    throw new Error("Could not reach the server. Check your connection and try again.");
  }

  if (!res.ok) {
    let message = "Failed to start analysis. Please try again.";
    try {
      const body = await res.json();
      if (typeof body?.error === "string") message = body.error;
    } catch {
      // non-JSON error body — fall back to the generic message above
    }
    throw new Error(message);
  }
}
