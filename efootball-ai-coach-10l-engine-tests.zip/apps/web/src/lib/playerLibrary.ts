import { supabase } from "./supabaseClient";
import type { PlayerLibrary } from "@efootball/shared";

// Batch 6A-4 — thin client wrapper around
// supabase/functions/player-library-save (the only path that writes to
// player_library — see that function's header comment) plus plain
// RLS-scoped reads for the list/edit views. Mirrors
// playerCardExtraction.ts's shape: resolve the current session token,
// call the Edge Function, surface its safe error message directly (the
// function itself never leaks internals — see internalErrorResponse in
// supabase/functions/_shared/helpers.ts).

export interface SavePlayerLibraryPayload {
  /** Present => update that row; absent => insert a new one. */
  id?: string;
  name: string | null;
  position: string | null;
  overall: number | null;
  playstyle: string | null;
  attributes: Record<string, number | string | null>;
  /** Omit this key entirely to leave an existing entry's card image
   * untouched (see player-library-save/index.ts's hasImagePathField).
   * Include it (even as null) to set/clear it — always included when
   * saving a brand-new entry from a fresh upload+extraction. */
  player_card_image_path?: string | null;
}

export interface SavePlayerLibraryResult {
  player: PlayerLibrary;
  /** True when this exact (name, position, overall) variant already
   * existed and the save was recognized as an accidental duplicate
   * (spec section 9) — the returned `player` is the pre-existing row,
   * not a new one. */
  duplicate: boolean;
}

/**
 * Persists a reviewed player_library entry. Never sends a user_id — the
 * Edge Function determines ownership from the caller's own session
 * (spec section 5); this only ever acts on the authenticated caller's
 * own data (enforced independently by RLS regardless).
 */
export async function savePlayerLibraryEntry(payload: SavePlayerLibraryPayload): Promise<SavePlayerLibraryResult> {
  const { data: sessionData } = await supabase.auth.getSession();
  const accessToken = sessionData.session?.access_token;
  if (!accessToken) throw new Error("Your session has expired. Please sign in again.");

  let res: Response;
  try {
    res = await fetch(`${import.meta.env.VITE_SUPABASE_URL}/functions/v1/player-library-save`, {
      method: "POST",
      headers: {
        "Content-Type": "application/json",
        Authorization: `Bearer ${accessToken}`,
      },
      body: JSON.stringify(payload),
    });
  } catch {
    throw new Error("Could not reach the server. Check your connection and try again.");
  }

  let body: unknown;
  try {
    body = await res.json();
  } catch {
    body = null;
  }

  if (!res.ok) {
    const message =
      body && typeof body === "object" && typeof (body as { error?: unknown }).error === "string"
        ? (body as { error: string }).error
        : "Failed to save player. Please try again.";
    throw new Error(message);
  }

  return body as SavePlayerLibraryResult;
}

/** Lists the caller's own saved Player Library entries, most recently
 * updated first. RLS (player_library_select_own) scopes this to the
 * caller's own rows — no server relay needed for a plain read, same
 * convention as Profile.tsx's direct .select(). */
export async function listPlayerLibrary(): Promise<PlayerLibrary[]> {
  const { data, error } = await supabase.from("player_library").select("*").order("updated_at", { ascending: false });
  if (error) throw error;
  return (data ?? []) as PlayerLibrary[];
}

/** Fetches a single saved entry for the Edit flow. Returns null if it
 * doesn't exist or isn't the caller's own (RLS makes those
 * indistinguishable from here, which is correct — never confirm/deny
 * another user's data). */
export async function getPlayerLibraryEntry(id: string): Promise<PlayerLibrary | null> {
  const { data, error } = await supabase.from("player_library").select("*").eq("id", id).maybeSingle();
  if (error) throw error;
  return (data as PlayerLibrary | null) ?? null;
}
