import { supabase } from "./supabaseClient";
import type { TeamLibrary } from "@efootball/shared";
import { validateTeamLibraryInput, isDuplicateTeamName } from "@efootball/shared";

// Batch 7E — thin client wrapper around public.team_library
// (migrations 0016_team_library.sql / 0018_team_library_image_path.sql /
// 0020_team_manager_assignment.sql). Unlike playerLibrary.ts/
// managerLibrary.ts, this does NOT go through an Edge Function: those
// two exist because saving a library entry needs server-side field
// validation/sanitization of arbitrary AI-reviewed content
// (player-library-save/manager-library-save). A team_library row is
// hand-authored by the user directly — there is no AI draft to review —
// and 0016/0018/0020's RLS policies plus their ownership triggers are
// already the complete authorization boundary (team_image_path/
// manager_id ownership enforced in Postgres itself), so a plain
// RLS-scoped client call is both sufficient and the simplest thing
// that's actually correct here, same reasoning as teamMembers.ts/
// teamManager.ts. Every call below runs as the signed-in user via the
// shared anon-key `supabase` client (supabaseClient.ts) — no
// service-role key is ever used in this file, and no caller can pass a
// user_id (ownership is derived from the session by RLS regardless of
// anything sent from here).

export interface TeamLibraryPayload {
  name: string;
  motto: string | null;
  description: string | null;
  founded_year: number | null;
  stadium: string | null;
  /** Omit this key entirely to leave an existing team's image
   * untouched. Include it (even as null) to set/clear it — always
   * included when creating a brand-new team. */
  team_image_path?: string | null;
  /** Omit this key entirely to leave an existing team's manager
   * assignment untouched (use assignTeamManager/clearTeamManager in
   * teamManager.ts for that instead). Include it (even as null) when
   * creating a brand-new team. */
  manager_id?: string | null;
}

export interface SaveTeamLibraryResult {
  team: TeamLibrary;
  /** True when this exact team name already existed for this user and
   * the save was recognized as an accidental duplicate (spec: "handle
   * duplicate team name" without crashing the UI) — the returned `team`
   * is the pre-existing row, not a new one. Only ever true for a
   * create, never for an edit of an existing row's own name. */
  duplicate: boolean;
}

/** Lists the caller's own saved Team Library entries, most recently
 * updated first. RLS (team_library_select_own) scopes this to the
 * caller's own rows — no server relay needed for a plain read, same
 * convention as listPlayerLibrary/listManagerLibrary. Never shows
 * another user's teams (RLS makes that structurally impossible, not
 * just a client-side filter). */
export async function listTeamLibrary(): Promise<TeamLibrary[]> {
  const { data, error } = await supabase.from("team_library").select("*").order("updated_at", { ascending: false });
  if (error) throw error;
  return (data ?? []) as TeamLibrary[];
}

/** Fetches a single saved team for the Detail/Edit flow. Returns null if
 * it doesn't exist or isn't the caller's own (RLS makes those
 * indistinguishable from here, which is correct — never confirm/deny
 * another user's data, same convention as getPlayerLibraryEntry/
 * getManagerLibraryEntry). */
export async function getTeamLibraryEntry(id: string): Promise<TeamLibrary | null> {
  const { data, error } = await supabase.from("team_library").select("*").eq("id", id).maybeSingle();
  if (error) throw error;
  return (data as TeamLibrary | null) ?? null;
}

/**
 * Creates a new team_library row for the signed-in user. Never sends a
 * user_id — RLS (team_library_insert_own) derives ownership from the
 * caller's own session and independently re-checks team_image_path/
 * manager_id ownership regardless of anything validated here. A
 * duplicate name is recovered as `duplicate: true` with the pre-existing
 * row rather than thrown as a raw constraint-violation error (spec
 * section 10 — "duplicate team name" must fail safely).
 */
export async function createTeam(payload: TeamLibraryPayload): Promise<SaveTeamLibraryResult> {
  const { valid, sanitized, errors } = validateTeamLibraryInput({
    name: payload.name,
    motto: payload.motto,
    description: payload.description,
    founded_year: payload.founded_year,
    stadium: payload.stadium,
    team_image_path: payload.team_image_path ?? null,
    manager_id: payload.manager_id ?? null,
  });
  if (!valid) {
    throw new Error(`Invalid team: ${errors.join("; ")}`);
  }

  const { data, error } = await supabase
    .from("team_library")
    .insert({
      name: sanitized.name,
      motto: sanitized.motto,
      description: sanitized.description,
      founded_year: sanitized.founded_year,
      stadium: sanitized.stadium,
      team_image_path: sanitized.team_image_path,
      manager_id: sanitized.manager_id,
    })
    .select("*")
    .single();

  if (error) {
    if (isDuplicateTeamName(error)) {
      const existing = await supabase
        .from("team_library")
        .select("*")
        .ilike("name", sanitized.name)
        .maybeSingle();
      if (existing.data) {
        return { team: existing.data as TeamLibrary, duplicate: true };
      }
    }
    throw error;
  }

  return { team: data as TeamLibrary, duplicate: false };
}

/**
 * Updates an existing team_library row the caller owns. Only the keys
 * present in `payload` are written — omit team_image_path/manager_id
 * entirely to leave them untouched (e.g. an edit that only changes the
 * name/description shouldn't clear the logo or manager assignment).
 * RLS (team_library_update_own) is the actual authorization boundary
 * regardless of anything validated here.
 */
export async function updateTeam(id: string, payload: Partial<TeamLibraryPayload>): Promise<SaveTeamLibraryResult> {
  const { valid, sanitized, errors } = validateTeamLibraryInput({
    name: payload.name,
    motto: payload.motto ?? null,
    description: payload.description ?? null,
    founded_year: payload.founded_year ?? null,
    stadium: payload.stadium ?? null,
    team_image_path: payload.team_image_path ?? null,
    manager_id: payload.manager_id ?? null,
  });
  if (!valid) {
    throw new Error(`Invalid team: ${errors.join("; ")}`);
  }

  const update: Record<string, unknown> = {
    name: sanitized.name,
    motto: sanitized.motto,
    description: sanitized.description,
    founded_year: sanitized.founded_year,
    stadium: sanitized.stadium,
  };
  if (Object.prototype.hasOwnProperty.call(payload, "team_image_path")) {
    update.team_image_path = sanitized.team_image_path;
  }
  if (Object.prototype.hasOwnProperty.call(payload, "manager_id")) {
    update.manager_id = sanitized.manager_id;
  }

  const { data, error } = await supabase.from("team_library").update(update).eq("id", id).select("*").single();

  if (error) {
    if (isDuplicateTeamName(error)) {
      const existing = await supabase
        .from("team_library")
        .select("*")
        .ilike("name", sanitized.name)
        .maybeSingle();
      if (existing.data) {
        return { team: existing.data as TeamLibrary, duplicate: true };
      }
    }
    throw error;
  }

  return { team: data as TeamLibrary, duplicate: false };
}

/** Deletes one of the caller's own teams. RLS (team_library_delete_own)
 * is the actual authorization boundary. team_members rows for this team
 * are removed automatically via ON DELETE CASCADE (migration 0019) —
 * the underlying player_library rows themselves are never touched. Any
 * manager_library row this team referenced is likewise left completely
 * untouched (there is no reverse cascade from team_library to either
 * library). Callers are responsible for cleaning up the team's own
 * image object (if any) via deleteTeamImage — this function only
 * removes the team_library row itself. Resolves silently if `id`
 * doesn't exist or isn't reachable under RLS, same
 * indistinguishable-404 convention used throughout this repo. */
export async function deleteTeam(id: string): Promise<void> {
  const { error } = await supabase.from("team_library").delete().eq("id", id);
  if (error) throw error;
}
