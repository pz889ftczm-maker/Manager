import { supabase } from "./supabaseClient";
import type { TeamFormationPreset, PositionsJson, TeamFormation } from "@efootball/shared";
import {
  validateTeamFormationPresetInput,
  validateTeamFormationPresetFields,
  isDuplicateFormationPresetName,
  TEAM_FORMATION_PRESET_NAME_UNIQUE_CONSTRAINT,
  assertSameTeamForPresetApply,
  isFormationPresetTeamMismatchError,
  FormationPresetTeamMismatchError,
} from "@efootball/shared";
import { getTeamFormation, updateTeamFormation } from "./teamFormations";
import { listFormationPlayers, removePlayerFromFormation, assignPlayerToFormation } from "./teamFormationPlayers";
import { listPresetPlayers, assignPresetPlayer } from "./teamFormationPresetPlayers";

// Batch 8D — thin client wrapper around public.team_formation_presets
// (migration 0024_team_formation_presets.sql), plus the two
// orchestration entry points a preset UI needs: saving the current
// Formation AS a preset, and applying a saved preset BACK onto the
// current Formation. Same reasoning as teamFormations.ts: this does
// NOT go through an Edge Function — a preset row is hand-authored
// (a name plus a copy of already-validated formation data) with no
// AI-reviewed content to sanitize, and 0024's RLS policies are already
// the complete authorization boundary. Every call below runs as the
// signed-in user via the shared anon-key `supabase` client — no
// service-role key is used, and no caller can pass a user_id
// (team_formation_presets has none — see migration 0024's design
// notes).
//
// Authorization logic is NOT duplicated here (spec section 9): every
// function below is a plain, RLS-scoped read/write, and Supabase RLS
// remains the authoritative check.
//
// PRESETS ARE INDEPENDENT OF THE FORMATION THEY WERE COPIED FROM/APPLIED
// TO (spec section 10/11 — "this is a COPY"): saveCurrentFormationAsPreset
// and applyFormationPreset below only ever read one side and write
// plain column values to the other — no foreign key or shared row ever
// links a team_formations row to a team_formation_presets row, so
// editing one structurally cannot mutate the other.

/** True when `err` is the "this team already has a preset with this
 * name" unique violation from team_formation_presets_team_name_uniq —
 * re-exported directly from the shared package (structural check, no
 * wrapping needed), same convention as isDuplicateFormationName in
 * teamFormations.ts. */
export { isDuplicateFormationPresetName };

/** Batch 8D quick fix — re-exported directly from the shared package
 * (structural check, no wrapping needed), same convention as
 * isDuplicateFormationPresetName above, so callers (e.g.
 * formationErrors.ts) never need to import from "@efootball/shared"
 * directly just to recognize this one error. */
export { isFormationPresetTeamMismatchError, FormationPresetTeamMismatchError };

/** Lists the caller's own saved presets for one team, most recently
 * updated first. RLS (team_formation_presets_select_own) scopes this
 * to a team the caller owns — a teamId the caller doesn't own simply
 * comes back empty. */
export async function listTeamFormationPresets(teamId: string): Promise<TeamFormationPreset[]> {
  const { data, error } = await supabase
    .from("team_formation_presets")
    .select("*")
    .eq("team_id", teamId)
    .order("updated_at", { ascending: false });
  if (error) throw error;
  return (data ?? []) as TeamFormationPreset[];
}

/** Fetches one of the caller's own presets by id, or null if it
 * doesn't exist or isn't reachable under RLS — same
 * indistinguishable-404 convention used throughout this repo. */
export async function getTeamFormationPreset(id: string): Promise<TeamFormationPreset | null> {
  const { data, error } = await supabase.from("team_formation_presets").select("*").eq("id", id).maybeSingle();
  if (error) throw error;
  return (data as TeamFormationPreset | null) ?? null;
}

export interface TeamFormationPresetPayload {
  team_id: string;
  name: string;
  formation_code: string;
  positions: PositionsJson;
  tactical_instructions?: Record<string, unknown> | null;
}

export interface SaveTeamFormationPresetResult {
  preset: TeamFormationPreset;
  /** True when this exact (team_id, name) pair already existed and the
   * save was recognized as an accidental duplicate rather than a new
   * row being created — the returned `preset` is the pre-existing row,
   * not a new one. */
  duplicate: boolean;
}

/**
 * Creates a new preset for one of the caller's own teams. Never sends
 * a user_id (team_formation_presets has none); ownership of the team
 * is enforced independently by RLS (team_formation_presets_insert_own)
 * regardless of anything checked here. A duplicate name on the same
 * team is reported back as `duplicate: true` rather than throwing, so
 * the UI can show "you already have a preset with this name" instead
 * of a raw constraint-violation error.
 */
export async function createTeamFormationPreset(
  payload: TeamFormationPresetPayload
): Promise<SaveTeamFormationPresetResult> {
  const { valid, sanitized, errors } = validateTeamFormationPresetInput({
    ...payload,
    tactical_instructions: payload.tactical_instructions ?? null,
  });
  if (!valid) {
    throw new Error(`Invalid formation preset: ${errors.join("; ")}`);
  }

  const { data, error } = await supabase.from("team_formation_presets").insert(sanitized).select("*").single();

  if (error) {
    if (isDuplicateFormationPresetName(error)) {
      const existing = await supabase
        .from("team_formation_presets")
        .select("*")
        .eq("team_id", sanitized.team_id)
        .ilike("name", sanitized.name)
        .maybeSingle();
      if (existing.data) {
        return { preset: existing.data as TeamFormationPreset, duplicate: true };
      }
    }
    throw error;
  }

  return { preset: data as TeamFormationPreset, duplicate: false };
}

/**
 * Updates the name/formation_code/positions/tactical_instructions of
 * one of the caller's own presets — never repoints team_id. Fields not
 * present in `payload` are left untouched, so a plain rename only ever
 * sends `{ name }`. Validated via validateTeamFormationPresetFields
 * (team-id-independent). RLS (team_formation_presets_update_own) still
 * requires the caller to own the preset's team. A rename that collides
 * with another of the caller's presets on the same team throws, with
 * isDuplicateFormationPresetName recognizing it.
 */
export async function updateTeamFormationPreset(
  id: string,
  payload: Partial<Omit<TeamFormationPresetPayload, "team_id">>
): Promise<TeamFormationPreset> {
  const update: Record<string, unknown> = {};

  if (
    payload.name !== undefined ||
    payload.formation_code !== undefined ||
    payload.positions !== undefined ||
    payload.tactical_instructions !== undefined
  ) {
    const current = await getTeamFormationPreset(id);
    if (!current) {
      throw new Error(`Formation preset ${id} not found`);
    }

    const { valid, sanitized, errors } = validateTeamFormationPresetFields({
      name: payload.name ?? current.name,
      formation_code: payload.formation_code ?? current.formation_code,
      positions: payload.positions ?? current.positions,
      tactical_instructions:
        payload.tactical_instructions !== undefined ? payload.tactical_instructions : current.tactical_instructions,
    });
    if (!valid) {
      throw new Error(`Invalid formation preset: ${errors.join("; ")}`);
    }

    if (payload.name !== undefined) update.name = sanitized.name;
    if (payload.formation_code !== undefined) update.formation_code = sanitized.formation_code;
    if (payload.positions !== undefined) update.positions = sanitized.positions;
    if (payload.tactical_instructions !== undefined) update.tactical_instructions = sanitized.tactical_instructions;
  }

  const { data, error } = await supabase.from("team_formation_presets").update(update).eq("id", id).select("*").single();
  if (error) throw error;
  return data as TeamFormationPreset;
}

/** Renames one of the caller's own presets — a thin convenience
 * wrapper over updateTeamFormationPreset for the one field the Preset
 * UI's "rename" action needs to send. */
export async function renameTeamFormationPreset(id: string, name: string): Promise<TeamFormationPreset> {
  return updateTeamFormationPreset(id, { name });
}

/** Deletes one of the caller's own presets. Cascades to its
 * team_formation_preset_players assignment rows via migration 0024's
 * `on delete cascade` — never a separate delete call needed for those.
 * RLS (team_formation_presets_delete_own) requires the caller to own
 * the team. Never touches the underlying team_formations row (spec
 * section 4 — "Do NOT delete the underlying team or player from
 * preset operations"). Resolves silently if `id` doesn't exist or
 * isn't reachable under RLS. */
export async function deleteTeamFormationPreset(id: string): Promise<void> {
  const { error } = await supabase.from("team_formation_presets").delete().eq("id", id);
  if (error) throw error;
}

// ============================================================
// Save current Formation as a preset (spec section 10)
// ============================================================

export interface SaveFormationAsPresetResult {
  preset: TeamFormationPreset;
  duplicate: boolean;
  /** Position slots whose player assignment could not be copied into
   * the new preset (e.g. an unexpected write failure) — the preset
   * itself is still created with everything else intact. Empty in the
   * ordinary case. */
  warnings: string[];
}

/**
 * Saves an existing, persisted team_formations row (and its current
 * player assignments) as a brand-new, independent
 * team_formation_presets row. This is a COPY (spec section 10,
 * repeated as "IMPORTANT"): after this call returns, editing the
 * Formation does not mutate the preset, and editing the preset does
 * not mutate the Formation — there is no foreign key or shared row
 * between them, only copied column values.
 *
 * If the exact (team_id, name) pair already exists, the pre-existing
 * preset row is returned with `duplicate: true` rather than creating a
 * second one or throwing — same convention as createTeamFormation.
 */
export async function saveFormationAsPreset(
  formationId: string,
  presetName: string
): Promise<SaveFormationAsPresetResult> {
  const formation = await getTeamFormation(formationId);
  if (!formation) {
    throw new Error(`Formation ${formationId} not found`);
  }

  const { preset, duplicate } = await createTeamFormationPreset({
    team_id: formation.team_id,
    name: presetName,
    formation_code: formation.formation_code,
    positions: formation.positions,
    tactical_instructions: formation.tactical_instructions,
  });

  // A duplicate save returns the PRE-EXISTING preset untouched — never
  // overwrite its player assignments with the current Formation's, or
  // a "save as preset" accidentally typed with a name that already
  // exists would silently clobber a different, unrelated preset.
  if (duplicate) {
    return { preset, duplicate: true, warnings: [] };
  }

  const assignments = await listFormationPlayers(formationId);
  const warnings: string[] = [];

  for (const row of assignments) {
    try {
      await assignPresetPlayer(preset.id, row.player_id, row.position_slot);
    } catch (err) {
      // The preset row itself is already safely created — a single
      // assignment failing to copy (e.g. a transient write error) is
      // surfaced as a warning, not an overall failure, so the rest of
      // the preset's assignments still get saved.
      warnings.push(`Could not copy the player in slot "${row.position_slot}" into the new preset.`);
      // eslint-disable-next-line no-console
      console.error(`[saveFormationAsPreset] failed to copy slot ${row.position_slot}`, err);
    }
  }

  return { preset, duplicate: false, warnings };
}

// ============================================================
// Apply a preset onto the current Formation (spec section 11)
// ============================================================

export interface ApplyFormationPresetResult {
  formation: TeamFormation;
  /** Position slots from the preset that could not be applied — most
   * commonly because the player assigned to that slot in the preset no
   * longer exists in player_library (spec section 12 — deleted
   * players are never fabricated; their assignment is just skipped).
   * Empty in the ordinary case. */
  warnings: string[];
}

/**
 * Applies one of the caller's own presets onto one of the caller's own
 * existing team_formations rows: copies formation_code/positions/
 * tactical_instructions onto the Formation, then replaces the
 * Formation's current player assignments with the preset's. Never
 * changes the Formation's team_id, never creates a new
 * team_formations row, and never mutates the preset itself (spec
 * section 11) — this only ever reads the preset and writes to the
 * Formation.
 *
 * Batch 8D quick fix: a preset may only ever be applied onto a
 * Formation belonging to the SAME team_id it was saved under. RLS
 * scopes each of `presetId`/`formationId` independently to teams the
 * caller owns, but a caller who owns more than one team could still
 * legally load a Team A preset and a Team B Formation in the same
 * request — RLS alone does not stop those two ids from being combined
 * here. Both rows are loaded FIRST and compared via
 * assertSameTeamForPresetApply BEFORE any write: on a mismatch this
 * throws a sanitized FormationPresetTeamMismatchError and returns
 * without updating the Formation, without deleting its existing player
 * assignments, and without inserting any preset player assignments —
 * the Formation, its assignments, and the preset are all left exactly
 * as they were.
 *
 * A preset player assignment referencing a player_id that's no longer
 * reachable (deleted from player_library, or no longer owned by the
 * caller) is skipped rather than fabricated into a fake player — see
 * spec section 12. In practice migration 0024's
 * `player_id references player_library(id) on delete cascade` already
 * removes a preset's assignment row the moment the underlying player
 * is deleted, so this mainly guards against the rarer case of an
 * unexpected write failure applying one particular slot; the rest of
 * the preset is still applied.
 */
export async function applyFormationPreset(
  presetId: string,
  formationId: string
): Promise<ApplyFormationPresetResult> {
  // 1) Load both rows FIRST — neither is mutated below until both are
  //    confirmed to exist (reachable under RLS) and to belong to the
  //    same team.
  const preset = await getTeamFormationPreset(presetId);
  if (!preset) {
    throw new Error(`Formation preset ${presetId} not found`);
  }

  const targetFormation = await getTeamFormation(formationId);
  if (!targetFormation) {
    throw new Error(`Formation ${formationId} not found`);
  }

  // 2) Cross-team guard — throws FormationPresetTeamMismatchError and
  //    returns before touching the Formation, its assignments, or the
  //    preset when preset.team_id !== formation.team_id (see the
  //    function doc above).
  assertSameTeamForPresetApply(preset, targetFormation);

  // 3) Copy the preset's formation_code/positions/tactical_instructions
  //    onto the current Formation. team_id and name are deliberately
  //    never touched here — updateTeamFormation's signature has no way
  //    to change team_id, and applying a preset's LAYOUT should not
  //    silently rename the Formation the user is looking at.
  const formation = await updateTeamFormation(formationId, {
    formation_code: preset.formation_code,
    positions: preset.positions,
    tactical_instructions: preset.tactical_instructions,
  });

  // 4) Replace the Formation's current player assignments entirely —
  //    clear what's there first, through the existing 8B data-access
  //    helper (removePlayerFromFormation), never a raw bulk delete.
  const currentAssignments = await listFormationPlayers(formationId);
  for (const row of currentAssignments) {
    await removePlayerFromFormation(row.id);
  }

  // 5) Re-create the assignments from the preset's copy, through the
  //    existing 8B data-access helper (assignPlayerToFormation). The
  //    Formation's slots were just cleared in step 4, so this never
  //    collides with team_formation_players_formation_slot_uniq/
  //    team_formation_players_formation_player_uniq under normal
  //    operation.
  const presetAssignments = await listPresetPlayers(presetId);
  const warnings: string[] = [];

  for (const row of presetAssignments) {
    try {
      await assignPlayerToFormation(formationId, row.player_id, row.position_slot);
    } catch (err) {
      // Never fabricate a replacement player (spec section 12) — skip
      // this one slot and keep applying the rest of the preset.
      warnings.push(`Skipped slot "${row.position_slot}" — its saved player is no longer available.`);
      // eslint-disable-next-line no-console
      console.error(`[applyFormationPreset] failed to apply slot ${row.position_slot}`, err);
    }
  }

  return { formation, warnings };
}

export { TEAM_FORMATION_PRESET_NAME_UNIQUE_CONSTRAINT };
