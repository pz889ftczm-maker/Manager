import { supabase } from "./supabaseClient";
import type { TeamFormationPresetPlayer } from "@efootball/shared";
import {
  validateTeamFormationPresetPlayerInput,
  isUniqueViolation,
  TEAM_FORMATION_PRESET_PLAYER_UNIQUE_CONSTRAINT,
  TEAM_FORMATION_PRESET_PLAYER_SLOT_UNIQUE_CONSTRAINT,
} from "@efootball/shared";

// Batch 8D — thin client wrapper around public.team_formation_preset_players
// (migration 0024_team_formation_presets.sql). Same reasoning as
// teamFormationPlayers.ts: this does NOT go through an Edge Function —
// a team_formation_preset_players row has no AI-reviewed content to
// sanitize, it's just two ids and a slot label, and 0024's RLS policies
// + its ownership-consistency trigger are already the complete
// authorization boundary. Every call below runs as the signed-in user
// via the shared anon-key `supabase` client — no service-role key is
// ever used here, and no caller can pass a user_id (there isn't one to
// pass — see migration 0024's design notes).
//
// Authorization logic is NOT duplicated here (spec section 9 — "Do not
// put authorization logic only in these helpers"): Supabase RLS remains
// the authoritative check on every call.

/** True when `err` is the "this player is already assigned in this
 * preset" unique violation. */
export function isDuplicateFormationPresetPlayer(err: unknown): boolean {
  return isUniqueViolation(err, TEAM_FORMATION_PRESET_PLAYER_UNIQUE_CONSTRAINT);
}

/** True when `err` is the "this slot is already occupied in this
 * preset" unique violation. */
export function isDuplicateFormationPresetSlot(err: unknown): boolean {
  return isUniqueViolation(err, TEAM_FORMATION_PRESET_PLAYER_SLOT_UNIQUE_CONSTRAINT);
}

/** Lists the current player assignments for one of the caller's own
 * presets. RLS (team_formation_preset_players_select_own) scopes this
 * to a preset on a team the caller owns — a presetId the caller
 * doesn't own simply comes back empty, same "never confirm/deny
 * another user's data" convention used throughout this repo. Returns
 * the bare assignment rows only — join through player_id into
 * player_library yourself if you need card details; this file
 * intentionally never duplicates that data. */
export async function listPresetPlayers(presetId: string): Promise<TeamFormationPresetPlayer[]> {
  const { data, error } = await supabase
    .from("team_formation_preset_players")
    .select("*")
    .eq("preset_id", presetId)
    .order("created_at", { ascending: true });
  if (error) throw error;
  return (data ?? []) as TeamFormationPresetPlayer[];
}

/**
 * Assigns one of the caller's own player_library entries to a slot in
 * one of the caller's own presets. Never sends a user_id (there isn't
 * one — see migration 0024); ownership of BOTH the preset (via its
 * team) and the player is enforced independently by RLS and, as
 * defense-in-depth, by check_team_formation_preset_players_ownership,
 * regardless of anything checked here.
 */
export async function assignPresetPlayer(
  presetId: string,
  playerId: string,
  positionSlot: string
): Promise<TeamFormationPresetPlayer> {
  const { valid, sanitized, errors } = validateTeamFormationPresetPlayerInput({
    preset_id: presetId,
    player_id: playerId,
    position_slot: positionSlot,
  });
  if (!valid) {
    throw new Error(`Invalid preset player assignment: ${errors.join("; ")}`);
  }

  const { data, error } = await supabase
    .from("team_formation_preset_players")
    .insert({
      preset_id: sanitized.preset_id,
      player_id: sanitized.player_id,
      position_slot: sanitized.position_slot,
    })
    .select("*")
    .single();
  if (error) throw error;
  return data as TeamFormationPresetPlayer;
}

/** Removes a preset player assignment by deleting its
 * team_formation_preset_players row. Deletes only the assignment row —
 * never the underlying team_formation_presets or player_library
 * record. RLS (team_formation_preset_players_delete_own) requires the
 * caller to own the preset (via its team). Resolves silently if `id`
 * doesn't exist or isn't reachable under RLS. */
export async function removePresetPlayer(id: string): Promise<void> {
  const { error } = await supabase.from("team_formation_preset_players").delete().eq("id", id);
  if (error) throw error;
}
