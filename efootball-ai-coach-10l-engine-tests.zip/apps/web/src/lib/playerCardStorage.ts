import { supabase } from "./supabaseClient";
import {
  DEFAULT_MAX_IMAGE_MB,
  buildSafePlayerCardStoragePath,
  guessExtensionFromMimeOrName,
  validateUpload,
} from "@efootball/shared";

// Batch 6A-2 — upload/storage foundation only. Nothing in this file is
// wired into a route/page yet (no player review/edit UI exists yet); a
// later batch calls these from that UI. Mirrors the existing screenshot
// upload path in apps/web/src/routes/Analyze.tsx: client uploads directly
// to a private bucket using its own session (RLS-enforced), no Edge
// Function relay needed for either the upload or reading it back.

const PLAYER_CARDS_BUCKET = "player-cards";
// Same limit/override convention as Analyze.tsx (VITE_MAX_IMAGE_UPLOAD_MB)
// — reused rather than inventing a second image-size knob for what is
// still just an image upload.
const MAX_PLAYER_CARD_MB = Number(import.meta.env.VITE_MAX_IMAGE_UPLOAD_MB ?? DEFAULT_MAX_IMAGE_MB);

export interface UploadedPlayerCardImage {
  objectPath: string;
}

/**
 * Uploads one player-card image to the private player-cards bucket and
 * returns its SAFE, server-chosen object path — never derived from the
 * user-supplied filename (same convention as buildSafeStoragePath /
 * Analyze.tsx's uploadOne). Validates real file bytes (magic-byte sniff),
 * not just the browser-reported MIME type/extension.
 *
 * Deliberately does NOT touch player_library — callers decide if/when to
 * attach the returned objectPath to a library row. If a caller's own
 * follow-up step fails after this resolves, call
 * deletePlayerCardImage(objectPath, userId) to avoid leaving an orphaned
 * object (spec section 9).
 */
export async function uploadPlayerCardImage(file: File, userId: string): Promise<UploadedPlayerCardImage> {
  const head = new Uint8Array(await file.slice(0, 4096).arrayBuffer());
  const { valid, errors, detected } = validateUpload({
    expectedKind: "image",
    sizeBytes: file.size,
    maxImageMb: MAX_PLAYER_CARD_MB,
    headBytes: head,
  });
  if (!valid) throw new Error(errors.join(" "));

  const extension = detected?.extension ?? guessExtensionFromMimeOrName(file.type, file.name);
  const objectPath = buildSafePlayerCardStoragePath(userId, extension, crypto.randomUUID());

  // upsert:false — object names are random, so a collision should never
  // happen; false makes that an error instead of a silent overwrite
  // (spec section 10: never accidentally overwrite an existing image).
  const { error } = await supabase.storage
    .from(PLAYER_CARDS_BUCKET)
    .upload(objectPath, file, { upsert: false, contentType: detected?.mimeType ?? file.type ?? undefined });
  if (error) throw error;

  return { objectPath };
}

/**
 * Deletes a player-card image the caller owns. Storage RLS
 * (0012_player_library_storage.sql) independently enforces that a user can
 * only delete objects under their own uid prefix — the check here is
 * defense-in-depth so a caller can't even attempt a cross-user path.
 * Used both for an explicit "remove my card image" action and for cleaning
 * up an orphan object after a failed follow-up step.
 */
export async function deletePlayerCardImage(objectPath: string, ownerId: string): Promise<void> {
  if (!objectPath.startsWith(`${ownerId}/`)) {
    throw new Error("Refusing to delete a player-card image outside the caller's own storage prefix.");
  }
  const { error } = await supabase.storage.from(PLAYER_CARDS_BUCKET).remove([objectPath]);
  if (error) throw error;
}

/**
 * Short-lived signed URL for displaying a private card image (spec section
 * 8: prefer short-lived signed URLs, never make the bucket public). Minted
 * client-side — Supabase Storage checks the caller's own JWT against the
 * SELECT policy above, so this can only ever succeed for the signed-in
 * user's own objects. No server relay/Edge Function is needed for this to
 * stay secure.
 */
export async function getPlayerCardSignedUrl(objectPath: string, expiresInSeconds = 3600): Promise<string> {
  const { data, error } = await supabase.storage
    .from(PLAYER_CARDS_BUCKET)
    .createSignedUrl(objectPath, expiresInSeconds);
  if (error || !data) throw error ?? new Error("Failed to create signed URL for player-card image.");
  return data.signedUrl;
}
