import { supabase } from "./supabaseClient";
import type { TeamFormationPlayer } from "@efootball/shared";
import {
  validateTeamFormationPlayerInput,
  isUniqueViolation,
  TEAM_FORMATION_PLAYER_UNIQUE_CONSTRAINT,
  planFormationSlotAssignment,
  type ExistingFormationAssignment,
} from "@efootball/shared";

// Batch 8B — thin client wrapper around public.team_formation_players
// (migration 0022_team_formation_players.sql). Same reasoning as
// teamMembers.ts: this does NOT go through an Edge Function — a
// team_formation_players row has no AI-reviewed content to sanitize,
// it's just two ids and a slot label, and 0022's RLS policies + its
// ownership-consistency trigger are already the complete authorization
// boundary (both the formation's and the player's ownership checked
// independently in Postgres itself), so a plain RLS-scoped client call
// is both sufficient and the simplest thing that's actually correct
// here. Every call below runs as the signed-in user via the shared
// anon-key `supabase` client (supabaseClient.ts) — no service-role key
// is ever used in this file, and no caller can pass a user_id (there
// isn't one to pass: team_formation_players has none — see migration
// 0022's design notes).
//
// NO UI here (spec section 10 — "Do NOT build UI yet") and no change to
// Formation.tsx — this file exists purely as the data-access layer a
// future batch's UI will call into.

/** True when `err` is the "this player is already assigned to this
 * formation" unique violation from
 * team_formation_players_formation_player_uniq (spec section 2 —
 * duplicate assignment must fail safely), as opposed to some other/
 * unexpected error. */
export function isDuplicateFormationPlayer(err: unknown): boolean {
  return isUniqueViolation(err, TEAM_FORMATION_PLAYER_UNIQUE_CONSTRAINT);
}

/** Lists the current player assignments for one of the caller's own
 * formations. RLS (team_formation_players_select_own) scopes this to a
 * formation on a team the caller owns — a formationId the caller
 * doesn't own simply comes back empty, same "never confirm/deny
 * another user's data" convention as listTeamMembers (teamMembers.ts).
 * Returns the bare assignment rows only (id/formation_id/player_id/
 * position_slot/timestamps) — join through player_id into
 * player_library yourself (e.g. via listPlayerLibrary) if you need card
 * details; this file intentionally never duplicates that data (spec
 * section 3/8). */
export async function listFormationPlayers(formationId: string): Promise<TeamFormationPlayer[]> {
  const { data, error } = await supabase
    .from("team_formation_players")
    .select("*")
    .eq("formation_id", formationId)
    .order("created_at", { ascending: true });
  if (error) throw error;
  return (data ?? []) as TeamFormationPlayer[];
}

export interface AssignPlayerToFormationResult {
  assignment: TeamFormationPlayer | null;
  /** True when this exact (formation_id, player_id) pair was already
   * assigned and the insert was recognized as an accidental duplicate
   * (spec section 2) rather than a new row being created. When true,
   * `assignment` is the pre-existing row if it could be looked up
   * under RLS, or null if not — callers should treat `duplicate: true`
   * itself as the signal, not assume `assignment` is always populated.
   */
  duplicate: boolean;
}

/**
 * Assigns one of the caller's own player_library entries to a slot in
 * one of the caller's own formations. Never sends a user_id
 * (team_formation_players has none — see migration 0022); ownership of
 * BOTH the formation (via its team) and the player is enforced
 * independently by RLS (team_formation_players_insert_own) and, as
 * defense-in-depth, by the check_team_formation_players_ownership
 * trigger, regardless of anything checked here. A duplicate assignment
 * is reported back as `duplicate: true` rather than throwing, so a
 * future UI can show "already assigned" instead of a raw
 * constraint-violation error (spec section 2 — same convention as
 * addTeamMember in teamMembers.ts).
 */
export async function assignPlayerToFormation(
  formationId: string,
  playerId: string,
  positionSlot: string
): Promise<AssignPlayerToFormationResult> {
  const { valid, sanitized, errors } = validateTeamFormationPlayerInput({
    formation_id: formationId,
    player_id: playerId,
    position_slot: positionSlot,
  });
  if (!valid) {
    throw new Error(`Invalid formation player assignment: ${errors.join("; ")}`);
  }

  const { data, error } = await supabase
    .from("team_formation_players")
    .insert({
      formation_id: sanitized.formation_id,
      player_id: sanitized.player_id,
      position_slot: sanitized.position_slot,
    })
    .select("*")
    .single();

  if (error) {
    if (isDuplicateFormationPlayer(error)) {
      const existing = await supabase
        .from("team_formation_players")
        .select("*")
        .eq("formation_id", sanitized.formation_id)
        .eq("player_id", sanitized.player_id)
        .maybeSingle();
      // A lookup failure here (e.g. RLS no longer permits it) still
      // reports the duplicate rather than throwing — the insert itself
      // unambiguously hit the duplicate constraint.
      return { assignment: (existing.data as TeamFormationPlayer | null) ?? null, duplicate: true };
    }
    throw error;
  }

  return { assignment: data as TeamFormationPlayer, duplicate: false };
}

/**
 * Moves an existing assignment to a different position_slot within the
 * same formation (e.g. re-slotting a player without removing and
 * re-adding them). Never changes formation_id/player_id — use
 * removePlayerFromFormation + assignPlayerToFormation for that instead,
 * so RLS's ownership checks always see a complete, coherent pair of
 * ids rather than a partial rewrite. RLS (team_formation_players_
 * update_own) and the ownership-consistency trigger both still apply.
 */
export async function updateFormationPlayerSlot(id: string, positionSlot: string): Promise<TeamFormationPlayer> {
  const slot = positionSlot.trim();
  if (slot.length === 0) {
    throw new Error("Invalid formation player assignment: position_slot: expected a non-empty string");
  }

  const { data, error } = await supabase
    .from("team_formation_players")
    .update({ position_slot: slot })
    .eq("id", id)
    .select("*")
    .single();
  if (error) throw error;
  return data as TeamFormationPlayer;
}

/** Removes a player assignment by deleting its team_formation_players
 * row. Deletes only the assignment row — never the underlying
 * team_formations or player_library record (spec section 12 — "Do not
 * delete the underlying player or formation from this table's
 * helpers"). RLS (team_formation_players_delete_own) requires the
 * caller to own the formation (via its team); removing an assignment
 * does not additionally require the caller to still own the
 * player_library row, same convention as removeTeamMember
 * (teamMembers.ts). Resolves silently if `id` doesn't exist or isn't
 * reachable under RLS — same indistinguishable-404 convention used
 * throughout this repo. */
export async function removePlayerFromFormation(id: string): Promise<void> {
  const { error } = await supabase.from("team_formation_players").delete().eq("id", id);
  if (error) throw error;
}

// ============================================================
// Slot-based assignment (Batch 8C)
// ============================================================
//
// assignPlayerToFormation above only ever inserts — calling it a
// second time for a player already in this formation just hits
// TEAM_FORMATION_PLAYER_UNIQUE_CONSTRAINT, and it never even considers
// team_formation_players_formation_slot_uniq (migration 0023) at all.
// A drag-and-drop Formation UI needs "put this player in this slot,
// whatever it takes" — move them if they're already elsewhere in the
// formation, bump whoever's currently in the target slot, or just
// insert if neither applies — without the caller having to work out
// that sequencing itself. assignPlayerToFormationSlot is that
// orchestration: it re-fetches the formation's current assignments,
// asks the pure planFormationSlotAssignment (teamFormationPlayers.ts,
// packages/shared) what steps are needed, and executes them against
// Supabase in the exact order the planner returns — which is always
// "clear the target slot's occupant first, then move/insert" so
// neither unique constraint is ever transiently violated.

export interface AssignPlayerToFormationSlotResult {
  /** The assignment row `playerId` now occupies (whether newly
   * inserted or moved there) — null only when the plan was a no-op
   * because the player was already exactly there, in which case the
   * caller's own already-loaded copy is still accurate and this
   * function doesn't re-fetch it. */
  assignment: TeamFormationPlayer | null;
  /** The assignment that was removed from the formation because it
   * occupied the target slot under a different player, or null if the
   * slot was free. Surfaced so a caller can tell the user "X was moved
   * off the pitch" rather than silently losing them — this function
   * never re-homes a displaced occupant anywhere itself. */
  displaced: ExistingFormationAssignment | null;
}

/**
 * Assigns `playerId` to `positionSlot` within `formationId`, moving
 * them off any other slot they currently occupy in the same formation
 * and displacing (removing) whoever currently occupies the target slot
 * if it's a different player — see planFormationSlotAssignment for the
 * exact rules. Ownership of both the formation (via its team) and the
 * player is still enforced independently by RLS and the
 * check_team_formation_players_ownership trigger on every step this
 * function runs, exactly as it is for assignPlayerToFormation; this
 * function adds sequencing on top, not a new authorization path.
 *
 * Re-fetches this formation's current assignments itself (rather than
 * trusting a caller-supplied list) so the plan is always computed
 * against what the database actually has right now — a caller with a
 * stale in-memory copy (e.g. after another tab made a change) can't
 * cause this function to skip a needed delete/move step.
 */
export async function assignPlayerToFormationSlot(
  formationId: string,
  playerId: string,
  positionSlot: string
): Promise<AssignPlayerToFormationSlotResult> {
  const { valid, sanitized, errors } = validateTeamFormationPlayerInput({
    formation_id: formationId,
    player_id: playerId,
    position_slot: positionSlot,
  });
  if (!valid) {
    throw new Error(`Invalid formation player assignment: ${errors.join("; ")}`);
  }

  const existing = await listFormationPlayers(sanitized.formation_id);
  const plan = planFormationSlotAssignment(existing, sanitized.player_id, sanitized.position_slot);

  let assignment: TeamFormationPlayer | null = null;

  for (const op of plan.operations) {
    if (op.type === "delete") {
      const { error } = await supabase.from("team_formation_players").delete().eq("id", op.id);
      if (error) throw error;
    } else if (op.type === "update_slot") {
      const { data, error } = await supabase
        .from("team_formation_players")
        .update({ position_slot: op.position_slot })
        .eq("id", op.id)
        .select("*")
        .single();
      if (error) throw error;
      assignment = data as TeamFormationPlayer;
    } else {
      const { data, error } = await supabase
        .from("team_formation_players")
        .insert({
          formation_id: sanitized.formation_id,
          player_id: op.player_id,
          position_slot: op.position_slot,
        })
        .select("*")
        .single();
      if (error) throw error;
      assignment = data as TeamFormationPlayer;
    }
  }

  // No-op plan (player already exactly in that slot) — the caller's
  // existing copy of that row is still accurate; nothing to return.
  if (plan.operations.length === 0) {
    assignment = existing.find((a) => a.player_id === sanitized.player_id) as TeamFormationPlayer | null;
  }

  return { assignment, displaced: plan.displaced };
}
