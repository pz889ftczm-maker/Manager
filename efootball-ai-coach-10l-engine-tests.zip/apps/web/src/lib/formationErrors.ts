import { isDuplicateFormationName } from "./teamFormations";
import { isDuplicateFormationPresetName, isFormationPresetTeamMismatchError } from "./teamFormationPresets";

// Batch 8C quick-fix — a small, dependency-free mapper from whatever
// Formation.tsx's calls into teamFormations.ts/teamFormationPlayers.ts
// threw (a raw PostgrestError, a plain Error from client-side
// validation, or anything else) to one of a fixed set of generic,
// actionable, user-facing strings.
//
// Nothing in this file ever forwards `err.message` (or any other part
// of a caught error) to the caller — that's the one thing the 8C audit
// flagged as missing: Formation.tsx was rendering
// `(err as Error).message` directly, which for a Supabase/Postgres
// error can include raw column/constraint/table names. The one
// exception that's still safe is the duplicate-name case, which is
// recognized structurally (isDuplicateFormationName checks the
// Postgres error code + constraint name, not its message text) rather
// than by reading anything the database said.
//
// The original error is still logged to the console for local
// debugging — this project has no server-side logging convention to
// hook into for a Vite/React SPA, so console.error is the "project
// convention" referred to by the spec here.
//
// Batch 8D quick fix: applyPreset's cross-team rejection
// (FormationPresetTeamMismatchError, teamFormationPresets.ts) is
// handled the same way as the duplicate-name cases below — recognized
// structurally (isFormationPresetTeamMismatchError is a plain
// `instanceof` check, not a read of err.message) and given its own
// specific, still-generic string, rather than falling through to the
// context's default message. It isn't logged as an unexpected error
// either: like a duplicate name, it's an expected, already-understood
// outcome of the guard in applyFormationPreset, not a surprise.

export type FormationErrorContext =
  | "save" // create or update a team_formations row
  | "loadFormations" // list/load a team's formation(s)
  | "loadAssignments" // list a formation's player assignments
  | "assign" // assign/move a player into a formation slot
  | "remove" // remove a player from a formation slot
  // Batch 8D — Formation Presets contexts.
  | "loadPresets" // list a team's saved presets
  | "savePreset" // create/rename a team_formation_presets row
  | "applyPreset" // apply a preset onto the current Formation
  | "deletePreset"; // delete a team_formation_presets row

const GENERIC_MESSAGES: Record<FormationErrorContext, string> = {
  save: "Unable to save formation.",
  loadFormations: "Unable to load formations.",
  loadAssignments: "Unable to load formations.",
  assign: "Unable to assign player.",
  remove: "Unable to assign player.",
  loadPresets: "Unable to load formation presets.",
  savePreset: "Unable to save formation preset.",
  applyPreset: "Unable to apply formation preset.",
  deletePreset: "Unable to delete formation preset.",
};

/**
 * Turns an error caught from a Formation-related call into a generic,
 * safe-to-display string. Always logs the real error to the console
 * first (except the duplicate-name case, which isn't an unexpected
 * error at all — it's an expected, already-understood outcome, so
 * nothing about it needs logging).
 */
export function mapFormationError(err: unknown, context: FormationErrorContext): string {
  if (context === "save" && isDuplicateFormationName(err)) {
    return "A formation with this name already exists.";
  }
  if (context === "savePreset" && isDuplicateFormationPresetName(err)) {
    return "A preset with this name already exists.";
  }
  if (context === "applyPreset" && isFormationPresetTeamMismatchError(err)) {
    return "Unable to apply this formation preset to the selected team.";
  }
  // eslint-disable-next-line no-console
  console.error(`[Formation:${context}]`, err);
  return GENERIC_MESSAGES[context];
}
