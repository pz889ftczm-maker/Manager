import { supabase } from "./supabaseClient";
import type { TeamLibrary } from "@efootball/shared";
import { validateManagerAssignmentInput } from "@efootball/shared";

// Batch 7D — thin client wrapper around team_library.manager_id
// (migration 0020_team_manager_assignment.sql). Same reasoning as
// teamMembers.ts for skipping an Edge Function: this is a single
// column update with no arbitrary reviewed content to sanitize, and
// 0020's RLS (team_library_insert_own/update_own, both re-checking
// manager_id ownership) plus its check_team_library_manager_ownership
// trigger already form the complete authorization boundary. Every call
// below runs as the signed-in user via the shared anon-key `supabase`
// client (supabaseClient.ts) — no service-role key is used here, and no
// caller can pass a user_id (ownership is derived from the session,
// same as every other helper in this repo).

/** Reads the current manager assignment for one of the caller's own
 * teams. Returns null if the team doesn't exist or isn't the caller's
 * own (RLS makes those indistinguishable from here, same
 * never-confirm/deny-another-user's-data convention as
 * getPlayerLibraryEntry). The returned `manager_id` may itself be null
 * — "no manager assigned" is a normal, valid state, not an error (spec
 * section 3). Callers who need the manager's own fields (name,
 * ratings, image) should look it up in manager_library via that id —
 * this never duplicates that data onto the team row. */
export async function getTeamManager(teamId: string): Promise<{ manager_id: string | null } | null> {
  const { data, error } = await supabase
    .from("team_library")
    .select("manager_id")
    .eq("id", teamId)
    .maybeSingle();
  if (error) throw error;
  return data as { manager_id: string | null } | null;
}

/**
 * Assigns one of the caller's own manager_library entries to one of the
 * caller's own teams (or reassigns it — this is a plain overwrite of
 * team_library.manager_id, not an add-if-absent). Ownership of both the
 * team and the manager is enforced independently by RLS
 * (team_library_update_own) and by check_team_library_manager_ownership
 * regardless of anything checked here. Throws the underlying
 * RLS/constraint error as-is on rejection (e.g. assigning a manager
 * that isn't the caller's own, or one that's since been deleted) —
 * callers should catch and show a friendly message rather than let it
 * crash the UI (spec section 8), the same way addTeamMember's caller is
 * expected to handle a rejected insert.
 */
export async function assignTeamManager(teamId: string, managerId: string): Promise<TeamLibrary> {
  const { valid, errors } = validateManagerAssignmentInput({ team_id: teamId, manager_id: managerId });
  if (!valid) {
    throw new Error(`Invalid manager assignment: ${errors.join("; ")}`);
  }

  const { data, error } = await supabase
    .from("team_library")
    .update({ manager_id: managerId })
    .eq("id", teamId)
    .select("*")
    .single();

  if (error) throw error;
  return data as TeamLibrary;
}

/** Clears a team's manager assignment (sets manager_id back to NULL) —
 * spec section 3/4: "User A clearing their manager" must always be
 * allowed for their own team, independent of whether the previously
 * assigned manager still exists or is still owned by them (e.g. it may
 * have already been ON DELETE SET NULL'd). */
export async function clearTeamManager(teamId: string): Promise<TeamLibrary> {
  const { valid, errors } = validateManagerAssignmentInput({ team_id: teamId, manager_id: null });
  if (!valid) {
    throw new Error(`Invalid team id: ${errors.join("; ")}`);
  }

  const { data, error } = await supabase
    .from("team_library")
    .update({ manager_id: null })
    .eq("id", teamId)
    .select("*")
    .single();

  if (error) throw error;
  return data as TeamLibrary;
}
