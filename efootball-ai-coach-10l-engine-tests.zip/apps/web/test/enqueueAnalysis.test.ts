// 9C-1 — framework-free, tsx-run test for enqueueAnalysis.ts's
// teamId/formationId forwarding. Same convention as
// packages/shared/test/*.test.ts and apps/worker/test/matchSnapshot.test.ts
// — Node's built-in `assert`, no test runner/framework.
//
// SCOPE NOTE: this only exercises buildAnalysisEnqueueRequestBody, the
// pure request-body builder enqueueAnalysis.ts calls right before its
// fetch() (imported from enqueueAnalysisRequestBody.ts, where the
// actual teamId/formationId forwarding logic lives — see that file's
// header comment). enqueueAnalysis() itself isn't invoked here because
// it pulls in the real Supabase browser client (./supabaseClient),
// which reads import.meta.env — only meaningful inside Vite, not this
// tsx/Node test runner.
//
// Run with:  npx tsx apps/web/test/enqueueAnalysis.test.ts
//        or: npm test --workspace=apps/web

import assert from "node:assert/strict";
import { buildAnalysisEnqueueRequestBody } from "../src/lib/enqueueAnalysisRequestBody.js";

let passed = 0;

function check(name: string, fn: () => void): void {
  try {
    fn();
    passed += 1;
    console.log(`  ok — ${name}`);
  } catch (err) {
    process.exitCode = 1;
    console.error(`  FAIL — ${name}`);
    console.error(err);
  }
}

console.log("buildAnalysisEnqueueRequestBody — teamId/formationId forwarding");

check("forwards a provided teamId and formationId", () => {
  const body = buildAnalysisEnqueueRequestBody({
    matchId: "match-1",
    mode: "video",
    storageObjectPaths: ["uid/match-1/file.mp4"],
    mediaId: "media-1",
    teamId: "team-1",
    formationId: "formation-1",
  });
  assert.equal(body.teamId, "team-1");
  assert.equal(body.formationId, "formation-1");
});

check("normalizes an omitted teamId/formationId to null (never undefined)", () => {
  const body = buildAnalysisEnqueueRequestBody({
    matchId: "match-2",
    mode: "screenshot",
    storageObjectPaths: ["uid/match-2/file.png"],
  });
  assert.equal(body.teamId, null);
  assert.equal(body.formationId, null);
  assert.ok("teamId" in body, "teamId key must be present, not omitted");
  assert.ok("formationId" in body, "formationId key must be present, not omitted");
});

check("normalizes an explicit null teamId/formationId to null", () => {
  const body = buildAnalysisEnqueueRequestBody({
    matchId: "match-3",
    mode: "video",
    storageObjectPaths: ["uid/match-3/file.mp4"],
    mediaId: "media-3",
    teamId: null,
    formationId: null,
  });
  assert.equal(body.teamId, null);
  assert.equal(body.formationId, null);
});

check("does not invent a teamId when only formationId is provided", () => {
  const body = buildAnalysisEnqueueRequestBody({
    matchId: "match-4",
    mode: "screenshot",
    storageObjectPaths: ["uid/match-4/file.png"],
    formationId: "formation-4",
  });
  assert.equal(body.teamId, null);
  assert.equal(body.formationId, "formation-4");
});

check("leaves matchId/mode/storageObjectPaths/mediaId untouched", () => {
  const body = buildAnalysisEnqueueRequestBody({
    matchId: "match-5",
    mode: "video",
    storageObjectPaths: ["uid/match-5/a.mp4", "uid/match-5/b.mp4"],
    mediaId: "media-5",
    teamId: "team-5",
    formationId: "formation-5",
  });
  assert.equal(body.matchId, "match-5");
  assert.equal(body.mode, "video");
  assert.deepEqual(body.storageObjectPaths, ["uid/match-5/a.mp4", "uid/match-5/b.mp4"]);
  assert.equal(body.mediaId, "media-5");
});

console.log("\nbuildAnalysisEnqueueRequestBody — 10A: footballType forwarding");

check("forwards a provided footballType", () => {
  const body = buildAnalysisEnqueueRequestBody({
    matchId: "match-6",
    mode: "video",
    storageObjectPaths: ["uid/match-6/file.mp4"],
    mediaId: "media-6",
    footballType: "efootball",
  });
  assert.equal(body.footballType, "efootball");
});

check("normalizes an omitted/explicit-null footballType to null (never undefined) — backward compatible", () => {
  const omitted = buildAnalysisEnqueueRequestBody({
    matchId: "match-7",
    mode: "screenshot",
    storageObjectPaths: ["uid/match-7/file.png"],
  });
  assert.equal(omitted.footballType, null);
  assert.ok("footballType" in omitted, "footballType key must be present, not omitted");

  const explicitNull = buildAnalysisEnqueueRequestBody({
    matchId: "match-8",
    mode: "screenshot",
    storageObjectPaths: ["uid/match-8/file.png"],
    footballType: null,
  });
  assert.equal(explicitNull.footballType, null);
});

console.log(`${passed} check(s) passed`);
