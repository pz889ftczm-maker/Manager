/** @type {import('tailwindcss').Config} */
export default {
  content: ["./index.html", "./src/**/*.{js,ts,jsx,tsx}"],
  darkMode: "class",
  theme: {
    extend: {
      colors: {
        pitch: {
          950: "#0a0f0d",
          900: "#0f1712",
          800: "#151f19",
          700: "#1e2b23",
        },
        accent: {
          DEFAULT: "#22c55e", // pitch green
          dim: "#16a34a",
        },
        warn: "#f59e0b",
        danger: "#ef4444",
      },
    },
  },
  plugins: [],
};
