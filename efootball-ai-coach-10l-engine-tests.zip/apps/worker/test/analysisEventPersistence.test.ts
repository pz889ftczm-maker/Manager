// Batch 10D fix — lightweight, framework-free tests proving
// validateAndPersistAnalysisEvent (apps/worker/src/analysisEventPersistence.ts)
// actually wires validateUnifiedFootballEventInput() into the worker's
// analysis_events write path. Same convention as matchSnapshot.test.ts /
// efootballContext.test.ts — no test runner/framework, Node's built-in
// `assert`, run via `tsx`, against a fake in-memory
// AnalysisEventPersistencePort — nothing here talks to a real
// Supabase/Postgres instance.
//
// Run with:  npx tsx apps/worker/test/analysisEventPersistence.test.ts
//        or: npm test --workspace=apps/worker
//
// SCOPE NOTE: this file proves the WIRING — that
// processMatchVideo.ts/processScreenshot.ts's shared call site resolves
// footballContext/ownership server-side and gates the upsert correctly on
// the result. validateUnifiedFootballEventInput's own exhaustive
// vocabulary/range/ownership logic is already covered by
// packages/shared/test/footballEvent.test.ts and is not re-verified
// line-by-line here.

import assert from "node:assert/strict";
import {
  validateAndPersistAnalysisEvent,
  validateAnalysisEventDraft,
  type AnalysisEventPersistencePort,
  type AnalysisEventOwnershipContext,
  type MomentExplanationPersistencePort,
  type TacticalAnalysisSnapshot,
} from "../src/analysisEventPersistence";
import type { FootballMatchContext, MomentExplanationInsertRow } from "@efootball/shared";

let passed = 0;

async function check(name: string, fn: () => Promise<void> | void): Promise<void> {
  try {
    await fn();
    passed += 1;
    console.log(`  ok — ${name}`);
  } catch (err) {
    process.exitCode = 1;
    console.error(`  FAIL — ${name}`);
    console.error(err);
  }
}

const MATCH_ID = "11111111-1111-1111-1111-111111111111";
const OTHER_MATCH_ID = "44444444-4444-4444-4444-444444444444";
const USER_ID = "22222222-2222-2222-2222-222222222222";
const PLAYER_ID = "33333333-3333-3333-3333-333333333333";
const OTHER_PLAYER_ID = "77777777-7777-7777-7777-777777777777";

const EFOOTBALL: FootballMatchContext = { football_type: "efootball", team_size: 11 };
const REAL_FOOTBALL: FootballMatchContext = { football_type: "real_football", team_size: 7 };

function baseDraft(overrides: Record<string, any> = {}): Record<string, any> {
  return {
    timestamp_seconds: 120.5,
    event_type: "bad_pass",
    category: "passing",
    severity: "mistake",
    confidence: 80,
    confidence_level: "likely",
    description: "Played a risky central pass into a double press.",
    decision_score: 20,
    better_option: null,
    reasoning: null,
    context_start_seconds: 118,
    context_end_seconds: 123,
    ...overrides,
  };
}

function baseEventFields(draft: Record<string, any>): Record<string, unknown> {
  const {
    timestamp_seconds,
    event_type,
    category,
    severity,
    decision_score,
    confidence,
    confidence_level,
    description,
    better_option,
    reasoning,
    context_start_seconds,
    context_end_seconds,
  } = draft;
  return {
    timestamp_seconds,
    event_type,
    category,
    severity,
    decision_score,
    confidence,
    confidence_level,
    description,
    better_option,
    reasoning,
    context_start_seconds,
    context_end_seconds,
  };
}

interface FakePort extends AnalysisEventPersistencePort {
  upsertCalls: Record<string, unknown>[];
}

function makeFakePort(): FakePort {
  const upsertCalls: Record<string, unknown>[] = [];
  let nextId = 1;
  return {
    upsertCalls,
    async upsertEvent(row) {
      upsertCalls.push(row);
      return { id: `event-${nextId++}`, created_at: "2026-01-01T00:00:00.000Z" };
    },
  };
}

/** Same FakePort as above, but always returns the SAME event id — used
 * by the 10J-2 idempotency check below to simulate a retried job whose
 * (match_id, dedupe_key) upsert resolves to the exact same, already-
 * existing analysis_events row (migration 0005) rather than a fresh
 * one, so the moment_explanations idempotency check is exercised
 * against a realistic repeated event_id. */
function makeFakePortWithFixedId(id: string): FakePort {
  const upsertCalls: Record<string, unknown>[] = [];
  return {
    upsertCalls,
    async upsertEvent(row) {
      upsertCalls.push(row);
      return { id, created_at: "2026-01-01T00:00:00.000Z" };
    },
  };
}

/** 10J-2 — in-memory fake for MomentExplanationPersistencePort. Mirrors
 * the real port's own INSERT ... ON CONFLICT (match_id, event_id) DO
 * NOTHING contract: a second insertIfAbsent call for a (match_id,
 * event_id) pair already recorded is a silent no-op, never an
 * overwrite. */
interface FakeMomentExplanationPort extends MomentExplanationPersistencePort {
  insertCalls: MomentExplanationInsertRow[];
}

function makeFakeMomentExplanationPort(): FakeMomentExplanationPort {
  const insertCalls: MomentExplanationInsertRow[] = [];
  const seen = new Set<string>();
  return {
    insertCalls,
    async insertIfAbsent(row) {
      const key = `${row.match_id}:${row.event_id}`;
      if (seen.has(key)) return;
      seen.add(key);
      insertCalls.push(row);
    },
  };
}

function makeThrowingMomentExplanationPort(): MomentExplanationPersistencePort {
  return {
    async insertIfAbsent() {
      throw new Error("simulated moment_explanations write failure");
    },
  };
}

/** 10K — a tactical_analysis draft (the exact shape
 * ai.generateTacticalAnalysis already returns) with exactly one candidate
 * in each of actual_positions/passing_lanes/open_spaces, so
 * buildEventTacticalContext's own "exactly one candidate" rule attaches
 * all three unambiguously. */
function baseTactical(overrides: Partial<TacticalAnalysisSnapshot> = {}): TacticalAnalysisSnapshot {
  return {
    actual_positions: [{ role: "CM", team: "user", pos: { x: 50, y: 60 } }],
    recommended_positions: null,
    passing_lanes: [{ from: { x: 50, y: 60 }, to: { x: 70, y: 80 }, quality: "good" }],
    open_spaces: [{ center: { x: 80, y: 85 }, radius: 10 }],
    pressure_zones: null,
    is_approximate: false,
    ...overrides,
  };
}

function ownership(overrides: Partial<AnalysisEventOwnershipContext> = {}): AnalysisEventOwnershipContext {
  return {
    matchId: MATCH_ID,
    userId: USER_ID,
    footballContext: EFOOTBALL,
    playerId: null,
    ...overrides,
  };
}

console.log("validateAndPersistAnalysisEvent — valid events persist");

await check("1. a valid eFootball-context event is validated and persisted", async () => {
  const port = makeFakePort();
  const draft = baseDraft();

  const result = await validateAndPersistAnalysisEvent(
    ownership({ footballContext: EFOOTBALL }),
    draft,
    baseEventFields(draft),
    port
  );

  assert.equal(result.valid, true);
  assert.equal(port.upsertCalls.length, 1);
  assert.equal(port.upsertCalls[0].match_id, MATCH_ID);
  assert.equal(port.upsertCalls[0].event_type, "bad_pass");
  if (result.valid) assert.equal(result.eventId, "event-1");
});

await check("2. a valid real-football-context event is validated and persisted", async () => {
  const port = makeFakePort();
  const draft = baseDraft();

  const result = await validateAndPersistAnalysisEvent(
    ownership({ footballContext: REAL_FOOTBALL }),
    draft,
    baseEventFields(draft),
    port
  );

  assert.equal(result.valid, true);
  assert.equal(port.upsertCalls.length, 1);
  assert.equal(port.upsertCalls[0].match_id, MATCH_ID);
});

console.log("\nvalidateAndPersistAnalysisEvent — invalid events are rejected, never persisted");

await check("3. an invalid unified event (eFootball-only field on a real_football match) is rejected and never upserted", async () => {
  const port = makeFakePort();
  // playstyle is an eFootball-only field (footballEvent.ts's
  // EFOOTBALL_ONLY_EVENT_KEYS) — carrying it on a real_football match must
  // fail validateUnifiedFootballEventInput's own gate.
  const draft = baseDraft({ playstyle: "Anchor Man" });

  const result = await validateAndPersistAnalysisEvent(
    ownership({ footballContext: REAL_FOOTBALL }),
    draft,
    baseEventFields(draft),
    port
  );

  assert.equal(result.valid, false);
  assert.equal(port.upsertCalls.length, 0);
  if (!result.valid) assert.ok(result.errors.length > 0);
});

await check("3b. a draft with an event_type outside the closed vocabulary is rejected and never upserted", async () => {
  const port = makeFakePort();
  const draft = baseDraft({ event_type: "not_a_real_event_type" });

  const result = await validateAndPersistAnalysisEvent(ownership(), draft, baseEventFields(draft), port);

  assert.equal(result.valid, false);
  assert.equal(port.upsertCalls.length, 0);
});

console.log("\nvalidateAndPersistAnalysisEvent — cross-match / cross-player ownership is rejected");

await check("4. a draft claiming a different match_id than the resolved ownership context is rejected and never upserted", async () => {
  const port = makeFakePort();
  // A draft should never carry its own match_id in normal operation (the
  // AI provider's DetectedEventDraft type has no such field) — this
  // simulates a malformed/tampered draft that does, to prove the ownership
  // check actually rejects a mismatch rather than silently trusting it.
  const draft = baseDraft({ match_id: OTHER_MATCH_ID });

  const result = await validateAndPersistAnalysisEvent(
    ownership({ matchId: MATCH_ID }),
    draft,
    baseEventFields(draft),
    port
  );

  assert.equal(result.valid, false);
  assert.equal(port.upsertCalls.length, 0);
});

await check("4b. a draft claiming a player_id that does not match the server-resolved player is rejected and never upserted", async () => {
  const port = makeFakePort();
  const draft = baseDraft({ player_id: OTHER_PLAYER_ID });

  const result = await validateAndPersistAnalysisEvent(
    ownership({ playerId: PLAYER_ID }),
    draft,
    baseEventFields(draft),
    port
  );

  assert.equal(result.valid, false);
  assert.equal(port.upsertCalls.length, 0);
});

await check(
  "4c. a draft claiming a player_id when no player was resolved for this request is rejected and never upserted",
  async () => {
    const port = makeFakePort();
    const draft = baseDraft({ player_id: OTHER_PLAYER_ID });

    const result = await validateAndPersistAnalysisEvent(
      ownership({ playerId: null }),
      draft,
      baseEventFields(draft),
      port
    );

    assert.equal(result.valid, false);
    assert.equal(port.upsertCalls.length, 0);
  }
);

await check(
  "4d. the persisted row's match_id/player_id always come from the server-resolved ownership context, never from the draft/eventFields",
  async () => {
    const port = makeFakePort();
    const draft = baseDraft();
    // Simulates eventFields carrying its own match_id/player_id (e.g. a
    // stray key in a loosely-typed draft) that must never win over the
    // server-resolved ownership values.
    const taintedEventFields = { ...baseEventFields(draft), match_id: OTHER_MATCH_ID, player_id: OTHER_PLAYER_ID };

    const result = await validateAndPersistAnalysisEvent(
      ownership({ matchId: MATCH_ID, playerId: PLAYER_ID }),
      draft,
      taintedEventFields,
      port
    );

    assert.equal(result.valid, true);
    assert.equal(port.upsertCalls.length, 1);
    assert.equal(port.upsertCalls[0].match_id, MATCH_ID);
    assert.equal(port.upsertCalls[0].player_id, PLAYER_ID);
  }
);

console.log("\nvalidateAndPersistAnalysisEvent — idempotency still works");

await check("5. retrying the same valid draft issues the same upsert request both times (dedupe_key/onConflict unchanged)", async () => {
  const port = makeFakePort();
  const draft = baseDraft();

  await validateAndPersistAnalysisEvent(ownership(), draft, baseEventFields(draft), port);
  await validateAndPersistAnalysisEvent(ownership(), draft, baseEventFields(draft), port);

  // This function never tracks "already persisted" state itself — exactly
  // like matchSnapshot.ts's own triggerMatchSnapshotOnCompletion — that is
  // deliberately left entirely to the real port's upsert
  // (onConflict: "match_id,dedupe_key", migration 0005). What this proves
  // is the contract this function DOES own: a retried job re-issues an
  // identical request both times, so the DB's own idempotent upsert is
  // what prevents a duplicate row, never a second/different request.
  assert.equal(port.upsertCalls.length, 2);
  assert.deepEqual(port.upsertCalls[0], port.upsertCalls[1]);
});

console.log("\nvalidateAndPersistAnalysisEvent — legacy NULL football_type remains supported");

await check("6. a legacy match with footballContext=null still validates and persists a normal event", async () => {
  const port = makeFakePort();
  const draft = baseDraft();

  const result = await validateAndPersistAnalysisEvent(
    ownership({ footballContext: null }),
    draft,
    baseEventFields(draft),
    port
  );

  assert.equal(result.valid, true);
  assert.equal(port.upsertCalls.length, 1);
});

await check("6b. a legacy match with footballContext=null still rejects an eFootball-only field (never defaulted to efootball)", async () => {
  const port = makeFakePort();
  const draft = baseDraft({ overall: 91 });

  const result = await validateAndPersistAnalysisEvent(
    ownership({ footballContext: null }),
    draft,
    baseEventFields(draft),
    port
  );

  assert.equal(result.valid, false);
  assert.equal(port.upsertCalls.length, 0);
});

console.log("\nvalidateAndPersistAnalysisEvent — decisionQuality (10G-3): evidence-gated, reuses 10G-1/10G-2 as-is");

await check(
  "7. a decision with a score and real evidence (reasoning) produces a non-null decisionQuality",
  async () => {
    const port = makeFakePort();
    const draft = baseDraft({ reasoning: "The double press was visible before the pass was played." });

    const result = await validateAndPersistAnalysisEvent(ownership(), draft, baseEventFields(draft), port);

    assert.equal(result.valid, true);
    if (result.valid) {
      assert.notEqual(result.decisionQuality, null);
      assert.equal(result.decisionQuality?.event_id, result.eventId);
      assert.equal(result.decisionQuality?.score, draft.decision_score);
    }
  }
);

await check(
  "7b. a decision with a score but no supporting evidence anywhere produces a null decisionQuality",
  async () => {
    const port = makeFakePort();
    // baseDraft()'s defaults already carry no evidence (reasoning: null,
    // better_option: null) and eventFields never carries statistics_evidence
    // in these tests — a score alone is never sufficient (10G-2).
    const draft = baseDraft();

    const result = await validateAndPersistAnalysisEvent(ownership(), draft, baseEventFields(draft), port);

    assert.equal(result.valid, true);
    if (result.valid) assert.equal(result.decisionQuality, null);
  }
);

await check(
  "7c. a better_option string with no supporting evidence (no reasoning, no other evidence) is not accepted — decisionQuality stays null rather than carrying an unevidenced better_option",
  async () => {
    const port = makeFakePort();
    const draft = baseDraft({
      better_option: "Pass to the underlapping fullback instead.",
      reasoning: null,
    });

    const result = await validateAndPersistAnalysisEvent(ownership(), draft, baseEventFields(draft), port);

    assert.equal(result.valid, true);
    if (result.valid) assert.equal(result.decisionQuality, null);
  }
);

console.log(
  "\nvalidateAndPersistAnalysisEvent — MomentExplanation persistence (10J-2): reuses 10H/10I/10J-1 as-is"
);

await check(
  "8. a successfully persisted event with sufficient evidence also persists a MomentExplanation row keyed on the same authoritative match_id/event_id",
  async () => {
    const port = makeFakePort();
    const mePort = makeFakeMomentExplanationPort();
    const draft = baseDraft({ reasoning: "The double press was visible before the pass was played." });

    const result = await validateAndPersistAnalysisEvent(
      ownership(),
      draft,
      baseEventFields(draft),
      port,
      mePort
    );

    assert.equal(result.valid, true);
    assert.equal(mePort.insertCalls.length, 1);
    if (result.valid) {
      assert.equal(mePort.insertCalls[0].match_id, MATCH_ID);
      assert.equal(mePort.insertCalls[0].event_id, result.eventId);
    }
    // football_type on the persisted row is the same server-resolved
    // context passed via `ownership`, never re-derived from `draft`.
    assert.equal(mePort.insertCalls[0].football_type, "efootball");
  }
);

await check(
  "8b. insufficient evidence still persists a row, but with has_sufficient_evidence:false and every evidence-gated field null (never NULL/skip the row itself)",
  async () => {
    const port = makeFakePort();
    const mePort = makeFakeMomentExplanationPort();
    // baseDraft()'s defaults carry no evidence anywhere (reasoning: null,
    // better_option: null) — same fixture as decisionQuality check 7b.
    const draft = baseDraft();

    const result = await validateAndPersistAnalysisEvent(
      ownership(),
      draft,
      baseEventFields(draft),
      port,
      mePort
    );

    assert.equal(result.valid, true);
    assert.equal(mePort.insertCalls.length, 1);
    const row = mePort.insertCalls[0];
    assert.equal(row.has_sufficient_evidence, false);
    assert.equal(row.better_option, null);
    assert.equal(row.why_better, null);
    assert.equal(row.actionable_improvement, null);
  }
);

await check(
  "8c. sufficient evidence for an evidenced better_option persists it (and its why_better) verbatim from 10H's own builder",
  async () => {
    const port = makeFakePort();
    const mePort = makeFakeMomentExplanationPort();
    const draft = baseDraft({
      reasoning: "The double press was visible before the pass was played.",
      better_option: "Pass to the underlapping fullback instead.",
    });

    const result = await validateAndPersistAnalysisEvent(
      ownership(),
      draft,
      baseEventFields(draft),
      port,
      mePort
    );

    assert.equal(result.valid, true);
    assert.equal(mePort.insertCalls.length, 1);
    const row = mePort.insertCalls[0];
    assert.equal(row.has_sufficient_evidence, true);
    assert.notEqual(row.better_option, null);
    assert.equal(row.better_option?.label, draft.better_option);
    assert.notEqual(row.why_better, null);
  }
);

await check(
  "9. retrying the same event (same authoritative event_id) never overwrites the already-persisted MomentExplanation — exactly one insert across two attempts",
  async () => {
    const port = makeFakePortWithFixedId("event-fixed-1");
    const mePort = makeFakeMomentExplanationPort();
    const draft = baseDraft({ reasoning: "The double press was visible before the pass was played." });

    await validateAndPersistAnalysisEvent(ownership(), draft, baseEventFields(draft), port, mePort);
    await validateAndPersistAnalysisEvent(ownership(), draft, baseEventFields(draft), port, mePort);

    assert.equal(mePort.insertCalls.length, 1);
  }
);

await check(
  "10. a MomentExplanation persistence failure never fails the analysis event result (still valid:true with the correct eventId/decisionQuality)",
  async () => {
    const port = makeFakePort();
    const throwingPort = makeThrowingMomentExplanationPort();
    const draft = baseDraft({ reasoning: "The double press was visible before the pass was played." });

    const result = await validateAndPersistAnalysisEvent(
      ownership(),
      draft,
      baseEventFields(draft),
      port,
      throwingPort
    );

    assert.equal(result.valid, true);
    if (result.valid) {
      assert.equal(result.eventId, "event-1");
      assert.notEqual(result.decisionQuality, null);
    }
  }
);

console.log(
  "\nvalidateAndPersistAnalysisEvent — 10K tactical/spatial context (10E/10F): attached to the SAME persisted MomentExplanation, never a duplicate write"
);

await check(
  "11. an event persisted with a tacticalAnalysis snapshot attaches positions/passing_lane/space, each sourced to the SAME persisted event_id",
  async () => {
    const port = makeFakePort();
    const mePort = makeFakeMomentExplanationPort();
    const draft = baseDraft({ reasoning: "The double press was visible before the pass was played." });

    const result = await validateAndPersistAnalysisEvent(
      ownership(),
      draft,
      baseEventFields(draft),
      port,
      mePort,
      baseTactical()
    );

    assert.equal(result.valid, true);
    assert.equal(mePort.insertCalls.length, 1);
    const row = mePort.insertCalls[0];
    assert.notEqual(row.positions, null);
    assert.equal(row.positions?.actual.role, "CM");
    assert.equal(row.positions?.actual.source.event_id, result.valid ? result.eventId : undefined);
    assert.notEqual(row.passing_lane, null);
    assert.equal(row.passing_lane?.source.event_id, result.valid ? result.eventId : undefined);
    assert.notEqual(row.space, null);
    assert.equal(row.space?.source.event_id, result.valid ? result.eventId : undefined);
  }
);

await check(
  "11b. two or more actual_positions candidates for this event's own tactical data never guesses which one — positions stays null while unambiguous passing_lane/space still attach",
  async () => {
    const port = makeFakePort();
    const mePort = makeFakeMomentExplanationPort();
    const draft = baseDraft({ reasoning: "The double press was visible before the pass was played." });
    const tactical = baseTactical({
      actual_positions: [
        { role: "CM", team: "user", pos: { x: 50, y: 60 } },
        { role: "ST", team: "user", pos: { x: 80, y: 90 } },
      ],
    });

    const result = await validateAndPersistAnalysisEvent(
      ownership(),
      draft,
      baseEventFields(draft),
      port,
      mePort,
      tactical
    );

    assert.equal(result.valid, true);
    const row = mePort.insertCalls[0];
    assert.equal(row.positions, null);
    assert.notEqual(row.passing_lane, null);
    assert.notEqual(row.space, null);
  }
);

await check(
  "11c. tactical/spatial context is attached independently of evidence sufficiency — insufficient evidence still nulls better_option/why_better/actionable_improvement while positions/passing_lane/space attach normally",
  async () => {
    const port = makeFakePort();
    const mePort = makeFakeMomentExplanationPort();
    // Same no-evidence fixture as check 8b — has_sufficient_evidence:false.
    const draft = baseDraft();

    const result = await validateAndPersistAnalysisEvent(
      ownership(),
      draft,
      baseEventFields(draft),
      port,
      mePort,
      baseTactical()
    );

    assert.equal(result.valid, true);
    const row = mePort.insertCalls[0];
    assert.equal(row.has_sufficient_evidence, false);
    assert.equal(row.better_option, null);
    assert.equal(row.why_better, null);
    assert.equal(row.actionable_improvement, null);
    // Never evidence-gated — attached regardless.
    assert.notEqual(row.positions, null);
    assert.notEqual(row.passing_lane, null);
    assert.notEqual(row.space, null);
  }
);

await check(
  "11d. omitting tacticalAnalysis entirely (the pre-10K call shape) still persists a row, with positions/passing_lane/space null exactly as before 10K",
  async () => {
    const port = makeFakePort();
    const mePort = makeFakeMomentExplanationPort();
    const draft = baseDraft({ reasoning: "The double press was visible before the pass was played." });

    const result = await validateAndPersistAnalysisEvent(ownership(), draft, baseEventFields(draft), port, mePort);

    assert.equal(result.valid, true);
    const row = mePort.insertCalls[0];
    assert.equal(row.positions, null);
    assert.equal(row.passing_lane, null);
    assert.equal(row.space, null);
  }
);

await check(
  "11e. football_type on the attached tactical context is the same server-resolved ownership context, never re-derived — eFootball/Real Football separation preserved",
  async () => {
    const port = makeFakePort();
    const mePort = makeFakeMomentExplanationPort();
    const draft = baseDraft({ reasoning: "The double press was visible before the pass was played." });

    const result = await validateAndPersistAnalysisEvent(
      ownership({ footballContext: REAL_FOOTBALL }),
      draft,
      baseEventFields(draft),
      port,
      mePort,
      baseTactical()
    );

    assert.equal(result.valid, true);
    const row = mePort.insertCalls[0];
    assert.equal(row.positions?.actual.football_type, "real_football");
    assert.equal(row.passing_lane?.football_type, "real_football");
    assert.equal(row.space?.football_type, "real_football");
  }
);

console.log(
  "\nvalidateAnalysisEventDraft (10K AI-call-ordering fix) — the same gate, callable before spending a tactical AI call, without persisting anything"
);

await check(
  "12. reports valid:false with the SAME errors validateAndPersistAnalysisEvent itself returns for a rejected draft, and never touches the persistence port",
  async () => {
    const port = makeFakePort();
    // Same fixture as check 3 — an eFootball-only field on a real_football match.
    const draft = baseDraft({ playstyle: "Anchor Man" });
    const draftOwnership = ownership({ footballContext: REAL_FOOTBALL });

    const preValidation = validateAnalysisEventDraft(draftOwnership, draft);
    const result = await validateAndPersistAnalysisEvent(draftOwnership, draft, baseEventFields(draft), port);

    assert.equal(preValidation.valid, false);
    assert.equal(result.valid, false);
    if (!preValidation.valid && !result.valid) {
      assert.deepEqual(preValidation.errors, result.errors);
    }
    assert.equal(port.upsertCalls.length, 0);
  }
);

await check(
  "12b. reports valid:true for a draft validateAndPersistAnalysisEvent goes on to persist — confirms a caller can safely gate an AI call on this before persistence ever runs",
  async () => {
    const port = makeFakePort();
    const draft = baseDraft();

    const preValidation = validateAnalysisEventDraft(ownership(), draft);
    assert.equal(preValidation.valid, true);
    // Pure check — no upsert happened just from calling it.
    assert.equal(port.upsertCalls.length, 0);

    const result = await validateAndPersistAnalysisEvent(ownership(), draft, baseEventFields(draft), port);
    assert.equal(result.valid, true);
  }
);

console.log(`\n${passed} check(s) passed`);
if (process.exitCode) {
  console.error("\nSome checks FAILED — see above.");
} else {
  console.log("All checks passed.");
}
