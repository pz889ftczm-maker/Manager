// Batch 10B — lightweight, framework-free tests for
// getEfootballMatchContext's own decision logic (ownership, gating,
// historical-first). Same convention as matchSnapshot.test.ts — no
// test runner/framework, Node's built-in `assert`, run via `tsx`.
//
// Run with:  npx tsx apps/worker/test/efootballContext.test.ts
//        or: npm test --workspace=apps/worker
//
// SCOPE NOTE: exercises ONLY this file's own decision logic against a
// fake, in-memory EfootballContextPort — nothing here talks to a real
// Supabase/Postgres instance. The actual assembly/gating/never-
// fabricate rules live in packages/shared/src/efootballMatchContext.ts
// (buildEfootballMatchContext), already covered by its own test file;
// this file only proves getEfootballMatchContext wires ownership +
// the historical-vs-live source selection correctly around it.

import assert from "node:assert/strict";
import {
  getEfootballMatchContext,
  EfootballContextOwnershipError,
  EfootballContextIntegrityError,
  assertEfootballLiveOwnership,
  type EfootballContextPort,
} from "../src/efootballContext";
import type { MatchSnapshot, MatchSnapshotPlayer, EfootballContextLiveSource } from "@efootball/shared";

let passed = 0;

async function check(name: string, fn: () => Promise<void> | void): Promise<void> {
  try {
    await fn();
    passed += 1;
    console.log(`  ok — ${name}`);
  } catch (err) {
    process.exitCode = 1;
    console.error(`  FAIL — ${name}`);
    console.error(err);
  }
}

const MATCH_ID = "11111111-1111-1111-1111-111111111111";
const USER_ID = "22222222-2222-2222-2222-222222222222";
const OTHER_USER_ID = "44444444-4444-4444-4444-444444444444";
const TEAM_ID = "33333333-3333-3333-3333-333333333333";
const FORMATION_ID = "55555555-5555-5555-5555-555555555555";

interface FakeMatch {
  user_id: string;
  football_type: string | null;
  team_size: number | null;
  team_id: string | null;
  formation_id: string | null;
}

interface FakePortConfig {
  match?: FakeMatch | null;
  snapshot?: { snapshot: MatchSnapshot; players: MatchSnapshotPlayer[] } | null;
  live?: EfootballContextLiveSource;
}

function makeFakePort(config: FakePortConfig): EfootballContextPort & {
  getSnapshotCalls: number;
  getLiveDataCalls: Array<{ teamId: string; formationId: string | null; userId: string }>;
} {
  let getSnapshotCalls = 0;
  const getLiveDataCalls: Array<{ teamId: string; formationId: string | null; userId: string }> = [];

  return {
    get getSnapshotCalls() {
      return getSnapshotCalls;
    },
    getLiveDataCalls,
    async getMatch() {
      return config.match ?? null;
    },
    async getSnapshot() {
      getSnapshotCalls += 1;
      return config.snapshot ?? null;
    },
    async getLiveData(args) {
      getLiveDataCalls.push(args);
      return config.live ?? { formation: null, manager: null, players: [] };
    },
  };
}

function makeSnapshot(): MatchSnapshot {
  return {
    id: "s1",
    user_id: USER_ID,
    match_id: MATCH_ID,
    team_id: TEAM_ID,
    formation_id: FORMATION_ID,
    manager_id: null,
    formation_code: "4-3-3",
    formation_name: "Attacking 4-3-3",
    positions: null,
    tactical_instructions: null,
    team_name: null,
    team_motto: null,
    team_description: null,
    team_founded_year: null,
    team_stadium: null,
    manager_name: null,
    manager_ratings: null,
    created_at: "2026-01-01T00:00:00Z",
  };
}

console.log("getEfootballMatchContext — ownership is enforced before any data is returned (spec item 10)");

await check("throws EfootballContextOwnershipError when the match belongs to a different user", async () => {
  const port = makeFakePort({
    match: { user_id: OTHER_USER_ID, football_type: "efootball", team_size: 11, team_id: TEAM_ID, formation_id: FORMATION_ID },
  });

  await assert.rejects(
    () => getEfootballMatchContext(MATCH_ID, USER_ID, port),
    (err: unknown) => err instanceof EfootballContextOwnershipError
  );
});

await check("does not read a snapshot or live data at all when ownership fails", async () => {
  const port = makeFakePort({
    match: { user_id: OTHER_USER_ID, football_type: "efootball", team_size: 11, team_id: TEAM_ID, formation_id: FORMATION_ID },
    snapshot: { snapshot: makeSnapshot(), players: [] },
  });

  await assert.rejects(() => getEfootballMatchContext(MATCH_ID, USER_ID, port));
  assert.equal(port.getSnapshotCalls, 0);
  assert.equal(port.getLiveDataCalls.length, 0);
});

console.log("\ngetEfootballMatchContext — real_football never receives eFootball context (spec item 8)");

await check("real_football match: unavailable, and no snapshot/live query is ever made", async () => {
  const port = makeFakePort({
    match: { user_id: USER_ID, football_type: "real_football", team_size: 7, team_id: TEAM_ID, formation_id: FORMATION_ID },
  });

  const result = await getEfootballMatchContext(MATCH_ID, USER_ID, port);

  assert.deepEqual(result, { available: false, reason: "not_efootball" });
  assert.equal(port.getSnapshotCalls, 0, "must not query match_snapshots for a real_football match");
  assert.equal(port.getLiveDataCalls.length, 0, "must not query live Team/Formation/Manager data for a real_football match");
});

console.log("\ngetEfootballMatchContext — legacy NULL football_type never defaults to eFootball (spec item 9)");

await check("football_type=null: unavailable with reason=unknown_football_type, no extra queries", async () => {
  const port = makeFakePort({
    match: { user_id: USER_ID, football_type: null, team_size: null, team_id: TEAM_ID, formation_id: FORMATION_ID },
  });

  const result = await getEfootballMatchContext(MATCH_ID, USER_ID, port);

  assert.deepEqual(result, { available: false, reason: "unknown_football_type" });
  assert.equal(port.getSnapshotCalls, 0);
  assert.equal(port.getLiveDataCalls.length, 0);
});

await check("match no longer exists: unavailable, reason=unknown_football_type", async () => {
  const port = makeFakePort({ match: null });
  const result = await getEfootballMatchContext(MATCH_ID, USER_ID, port);
  assert.deepEqual(result, { available: false, reason: "unknown_football_type" });
});

console.log("\ngetEfootballMatchContext — historical snapshot preferred when it exists (spec item 5)");

await check("eFootball match with an existing snapshot: uses it, and never queries live data", async () => {
  const port = makeFakePort({
    match: { user_id: USER_ID, football_type: "efootball", team_size: 11, team_id: TEAM_ID, formation_id: FORMATION_ID },
    snapshot: { snapshot: makeSnapshot(), players: [] },
  });

  const result = await getEfootballMatchContext(MATCH_ID, USER_ID, port);

  assert.equal(result.available, true);
  if (result.available) assert.equal(result.source, "historical_snapshot");
  assert.equal(port.getLiveDataCalls.length, 0, "must not read live data once a snapshot was found");
});

console.log("\ngetEfootballMatchContext — falls back to current data only when no snapshot exists (spec item 6)");

await check("eFootball match with no snapshot but a team_id: reads live data for that team/formation", async () => {
  const port = makeFakePort({
    match: { user_id: USER_ID, football_type: "efootball", team_size: 11, team_id: TEAM_ID, formation_id: FORMATION_ID },
    snapshot: null,
    live: {
      formation: null,
      manager: null,
      players: [{ position_slot: "st", player: { id: "p1", user_id: USER_ID, name: "Live Player", position: "ST", overall: 80, playstyle: null, player_card_image_path: null, attributes: null, metadata: null, created_at: "2026-01-01T00:00:00Z", updated_at: "2026-01-01T00:00:00Z" } }],
    },
  });

  const result = await getEfootballMatchContext(MATCH_ID, USER_ID, port);

  assert.equal(result.available, true);
  if (result.available) {
    assert.equal(result.source, "current_data");
    assert.equal(result.players[0]?.name, "Live Player");
  }
  assert.deepEqual(port.getLiveDataCalls, [{ teamId: TEAM_ID, formationId: FORMATION_ID, userId: USER_ID }]);
});

await check("eFootball match with no snapshot and no team_id: no_data, live data is never queried (spec section 4 — no fabricated Team)", async () => {
  const port = makeFakePort({
    match: { user_id: USER_ID, football_type: "efootball", team_size: 11, team_id: null, formation_id: null },
    snapshot: null,
  });

  const result = await getEfootballMatchContext(MATCH_ID, USER_ID, port);

  assert.deepEqual(result, { available: false, reason: "no_data" });
  assert.equal(port.getLiveDataCalls.length, 0);
});

console.log(
  "\nassertEfootballLiveOwnership — live-data defense-in-depth: service-role reads are explicitly ownership-checked before use"
);

const OTHER_TEAM_ID = "66666666-6666-6666-6666-666666666666";
const MANAGER_ID = "77777777-7777-7777-7777-777777777777";

function validOwnershipArgs(): Parameters<typeof assertEfootballLiveOwnership>[0] {
  return {
    userId: USER_ID,
    teamId: TEAM_ID,
    formationId: FORMATION_ID,
    team: { user_id: USER_ID, manager_id: MANAGER_ID },
    formation: { team_id: TEAM_ID },
    manager: { user_id: USER_ID },
    players: [{ player_library: { user_id: USER_ID } }, { player_library: { user_id: USER_ID } }],
  };
}

await check("match owned by User A + team owned by User B: rejected, never returns User B's team", () => {
  const args = validOwnershipArgs();
  args.team = { user_id: OTHER_USER_ID, manager_id: null };

  assert.throws(() => assertEfootballLiveOwnership(args), (err: unknown) => {
    if (!(err instanceof EfootballContextIntegrityError)) return false;
    assert.equal(err.reason, "team_ownership_invalid");
    return true;
  });
});

await check("team owned by User A + formation belongs to another team: rejected", () => {
  const args = validOwnershipArgs();
  args.formation = { team_id: OTHER_TEAM_ID };

  assert.throws(() => assertEfootballLiveOwnership(args), (err: unknown) => {
    if (!(err instanceof EfootballContextIntegrityError)) return false;
    assert.equal(err.reason, "formation_ownership_invalid");
    return true;
  });
});

await check("manager belongs to another user: rejected", () => {
  const args = validOwnershipArgs();
  args.manager = { user_id: OTHER_USER_ID };

  assert.throws(() => assertEfootballLiveOwnership(args), (err: unknown) => {
    if (!(err instanceof EfootballContextIntegrityError)) return false;
    assert.equal(err.reason, "manager_ownership_invalid");
    return true;
  });
});

await check("manager is missing entirely even though the team has a manager_id: rejected", () => {
  const args = validOwnershipArgs();
  args.manager = null;

  assert.throws(() => assertEfootballLiveOwnership(args), (err: unknown) => {
    if (!(err instanceof EfootballContextIntegrityError)) return false;
    assert.equal(err.reason, "manager_ownership_invalid");
    return true;
  });
});

await check("formation player references another user's Player Library row: rejected", () => {
  const args = validOwnershipArgs();
  args.players = [{ player_library: { user_id: USER_ID } }, { player_library: { user_id: OTHER_USER_ID } }];

  assert.throws(() => assertEfootballLiveOwnership(args), (err: unknown) => {
    if (!(err instanceof EfootballContextIntegrityError)) return false;
    assert.equal(err.reason, "player_ownership_invalid");
    return true;
  });
});

await check("formation player's referenced Player Library row no longer exists: rejected, not silently dropped", () => {
  const args = validOwnershipArgs();
  args.players = [{ player_library: { user_id: USER_ID } }, { player_library: null }];

  assert.throws(() => assertEfootballLiveOwnership(args), (err: unknown) => {
    if (!(err instanceof EfootballContextIntegrityError)) return false;
    assert.equal(err.reason, "player_ownership_invalid");
    return true;
  });
});

await check("valid same-user Team + Formation + Manager + Players: does not throw", () => {
  assert.doesNotThrow(() => assertEfootballLiveOwnership(validOwnershipArgs()));
});

await check("valid same-user Team with no formation selected and no manager assigned: does not throw", () => {
  assert.doesNotThrow(() =>
    assertEfootballLiveOwnership({
      userId: USER_ID,
      teamId: TEAM_ID,
      formationId: null,
      team: { user_id: USER_ID, manager_id: null },
      formation: null,
      manager: null,
      players: [],
    })
  );
});

console.log(
  "\ngetEfootballMatchContext — historical snapshot path is unaffected by the live-data ownership fix (spec item 5/11)"
);

await check(
  "eFootball match with an existing snapshot: still never calls getLiveData, so live ownership checks are never even reached",
  async () => {
    const port = makeFakePort({
      match: { user_id: USER_ID, football_type: "efootball", team_size: 11, team_id: TEAM_ID, formation_id: FORMATION_ID },
      snapshot: { snapshot: makeSnapshot(), players: [] },
    });

    const result = await getEfootballMatchContext(MATCH_ID, USER_ID, port);

    assert.equal(result.available, true);
    if (result.available) assert.equal(result.source, "historical_snapshot");
    assert.equal(port.getLiveDataCalls.length, 0, "must not query live Team/Formation/Manager/Player data once a snapshot was found");
  }
);

console.log(`\n${passed} check(s) passed`);
if (process.exitCode) {
  console.error("\nSome checks FAILED — see above.");
} else {
  console.log("All checks passed.");
}
