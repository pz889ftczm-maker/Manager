// Batch 10K — lightweight, framework-free tests for analysisEngine.ts.
// Same convention as matchSnapshot.test.ts / analysisEventPersistence.test.ts
// — no test runner/framework, Node's built-in `assert`, run via `tsx`,
// against a fake in-memory AnalysisEngineReadPort — nothing here talks to
// a real Supabase/Postgres instance.
//
// Run with:  npx tsx apps/worker/test/analysisEngine.test.ts
//        or: npm test --workspace=apps/worker
//
// SCOPE NOTE: these tests exercise ONLY this file's own composition/
// selection logic — never-fabricate candidate selection for
// buildEventTacticalContext, and the read-then-compose wiring for
// getFullMatchContextForMatch/logFullMatchContextOnCompletion. The
// internal rules of tacticalPosition.ts/passingLaneSpaceModel.ts/
// fullMatchContext.ts/momentExplanation.ts themselves are already covered
// by packages/shared/test/*.test.ts and are not re-verified line-by-line
// here.

import assert from "node:assert/strict";
import {
  buildEventTacticalContext,
  getFullMatchContextForMatch,
  logFullMatchContextOnCompletion,
  type AnalysisEngineReadPort,
  type TacticalAnalysisSnapshot,
} from "../src/analysisEngine";
import type { AnalysisEvent, FootballMatchContext, MomentExplanationRow } from "@efootball/shared";

let passed = 0;

async function check(name: string, fn: () => Promise<void> | void): Promise<void> {
  try {
    await fn();
    passed += 1;
    console.log(`  ok — ${name}`);
  } catch (err) {
    process.exitCode = 1;
    console.error(`  FAIL — ${name}`);
    console.error(err);
  }
}

const MATCH_ID = "11111111-1111-1111-1111-111111111111";
const EVENT_ID = "22222222-2222-2222-2222-222222222222";
const EVENT_ID_2 = "33333333-3333-3333-3333-333333333333";
const EFOOTBALL: FootballMatchContext = { football_type: "efootball", team_size: 11 };

function baseTactical(overrides: Partial<TacticalAnalysisSnapshot> = {}): TacticalAnalysisSnapshot {
  return {
    actual_positions: [{ role: "CM", team: "user", pos: { x: 50, y: 60 } }],
    recommended_positions: null,
    passing_lanes: [{ from: { x: 50, y: 60 }, to: { x: 70, y: 80 }, quality: "good" }],
    open_spaces: [{ center: { x: 80, y: 85 }, radius: 10 }],
    pressure_zones: null,
    is_approximate: false,
    ...overrides,
  };
}

console.log("buildEventTacticalContext — never fabricate or infer");

await check("1. no tacticalAnalysis supplied (null/undefined) yields {} — identical to pre-10K behavior", async () => {
  const ctxNull = buildEventTacticalContext(null, {
    footballType: "efootball",
    matchId: MATCH_ID,
    eventId: EVENT_ID,
    timestampSeconds: 120,
  });
  const ctxUndefined = buildEventTacticalContext(undefined, {
    footballType: "efootball",
    matchId: MATCH_ID,
    eventId: EVENT_ID,
    timestampSeconds: 120,
  });
  assert.deepEqual(ctxNull, {});
  assert.deepEqual(ctxUndefined, {});
});

await check(
  "2. exactly one candidate for each of positions/passingLane/space attaches all three, unambiguously",
  async () => {
    const context = buildEventTacticalContext(baseTactical(), {
      footballType: "efootball",
      matchId: MATCH_ID,
      eventId: EVENT_ID,
      timestampSeconds: 120,
    });

    assert.notEqual(context.positions, null);
    assert.equal(context.positions?.actual.role, "CM");
    assert.equal(context.positions?.actual.source.event_id, EVENT_ID);

    assert.notEqual(context.passingLane, null);
    assert.equal(context.passingLane?.quality, "good");
    assert.equal(context.passingLane?.source.event_id, EVENT_ID);

    assert.notEqual(context.space, null);
    assert.equal(context.space?.status, "open");
    assert.equal(context.space?.source.event_id, EVENT_ID);
  }
);

await check(
  "3. two or more actual_positions candidates (a whole-team formation snapshot) never guesses which one — positions stays null",
  async () => {
    const tactical = baseTactical({
      actual_positions: [
        { role: "CM", team: "user", pos: { x: 50, y: 60 } },
        { role: "ST", team: "user", pos: { x: 80, y: 90 } },
      ],
    });

    const context = buildEventTacticalContext(tactical, {
      footballType: "efootball",
      matchId: MATCH_ID,
      eventId: EVENT_ID,
      timestampSeconds: 120,
    });

    assert.equal(context.positions, null);
    // passingLane/space are unaffected — each field's own candidate count
    // is judged independently, never coupled to another field's ambiguity.
    assert.notEqual(context.passingLane, null);
    assert.notEqual(context.space, null);
  }
);

await check("4. zero candidates in an array (null column) leaves that field null, never fabricated", async () => {
  const tactical = baseTactical({ passing_lanes: null, open_spaces: null });

  const context = buildEventTacticalContext(tactical, {
    footballType: "efootball",
    matchId: MATCH_ID,
    eventId: EVENT_ID,
    timestampSeconds: 120,
  });

  assert.equal(context.passingLane, null);
  assert.equal(context.space, null);
  assert.notEqual(context.positions, null);
});

await check(
  "5. football_type/match_id are passed straight through onto the built values — no cross-type branching",
  async () => {
    const context = buildEventTacticalContext(baseTactical(), {
      footballType: "real_football",
      matchId: MATCH_ID,
      eventId: EVENT_ID,
      timestampSeconds: 45,
    });

    assert.equal(context.positions?.actual.football_type, "real_football");
    assert.equal(context.positions?.actual.match_id, MATCH_ID);
    assert.equal(context.passingLane?.football_type, "real_football");
    assert.equal(context.space?.football_type, "real_football");
  }
);

console.log("\ngetFullMatchContextForMatch — reuses 10D/10I/10J-1/10J-3 as-is, never re-derives a historical row");

function baseEventRow(overrides: Partial<AnalysisEvent> = {}): AnalysisEvent {
  return {
    id: EVENT_ID,
    match_id: MATCH_ID,
    timestamp_seconds: 100,
    event_type: "bad_pass",
    category: "passing",
    severity: "mistake",
    decision_score: 20,
    confidence: 80,
    confidence_level: "likely",
    description: "Played a risky central pass into a double press.",
    better_option: null,
    reasoning: null,
    before_frame_url: null,
    decision_frame_url: null,
    after_frame_url: null,
    context_start_seconds: 95,
    context_end_seconds: 105,
    created_at: "2026-01-01T00:00:00.000Z",
    player_id: null,
    statistics_evidence: null,
    ...overrides,
  };
}

function baseExplanationRow(overrides: Partial<MomentExplanationRow> = {}): MomentExplanationRow {
  return {
    id: "explanation-1",
    match_id: MATCH_ID,
    event_id: EVENT_ID,
    football_type: "efootball",
    timestamp_seconds: 100,
    player: null,
    what_happened: "Played a risky central pass into a double press.",
    why_it_happened: null,
    better_option: null,
    why_better: null,
    actionable_improvement: null,
    confidence: 80,
    evidence: null,
    // Deliberately TRUE here even though the underlying event carries no
    // evidence (reasoning: null) — this is the historical-precedence
    // probe: a persisted row must win verbatim over whatever a fresh
    // computation from the same event would produce (which would compute
    // has_sufficient_evidence: false for this fixture).
    has_sufficient_evidence: true,
    positions: null,
    passing_lane: null,
    space: null,
    created_at: "2026-01-01T00:00:01.000Z",
    ...overrides,
  };
}

function makeFakeReadPort(events: AnalysisEvent[], explanations: MomentExplanationRow[]): AnalysisEngineReadPort {
  return {
    async listAnalysisEvents() {
      return events;
    },
    async listMomentExplanations() {
      return explanations;
    },
  };
}

await check(
  "6. an event with a persisted moment_explanations row uses it verbatim — never recomputed from the event",
  async () => {
    const port = makeFakeReadPort([baseEventRow()], [baseExplanationRow()]);

    const context = await getFullMatchContextForMatch(MATCH_ID, EFOOTBALL, port);

    assert.equal(context.moments.length, 1);
    // A fresh computation of this same event (reasoning: null, no
    // statistics_evidence) would yield has_sufficient_evidence: false —
    // the persisted row's own `true` must win instead.
    assert.equal(context.moments[0].explanation.has_sufficient_evidence, true);
  }
);

await check(
  "7. an event with NO persisted row still gets a freshly computed explanation — never silently dropped",
  async () => {
    const port = makeFakeReadPort([baseEventRow()], []);

    const context = await getFullMatchContextForMatch(MATCH_ID, EFOOTBALL, port);

    assert.equal(context.moments.length, 1);
    assert.equal(context.moments[0].explanation.event_id, EVENT_ID);
    // Freshly computed from a no-evidence event -> insufficient evidence.
    assert.equal(context.moments[0].explanation.has_sufficient_evidence, false);
  }
);

await check(
  "8. an analysis_events row with an event_type outside the unified vocabulary is excluded, never crashes the composition",
  async () => {
    const port = makeFakeReadPort(
      [baseEventRow(), baseEventRow({ id: EVENT_ID_2, event_type: "not_a_real_event_type" })],
      []
    );

    const context = await getFullMatchContextForMatch(MATCH_ID, EFOOTBALL, port);

    assert.equal(context.moments.length, 1);
    assert.equal(context.moments[0].event.id, EVENT_ID);
  }
);

await check("9. chronological ordering is preserved across a mix of persisted and freshly computed moments", async () => {
  const earlier = baseEventRow({ id: EVENT_ID, timestamp_seconds: 50 });
  const later = baseEventRow({ id: EVENT_ID_2, timestamp_seconds: 150 });
  const port = makeFakeReadPort([later, earlier], [baseExplanationRow({ event_id: EVENT_ID })]);

  const context = await getFullMatchContextForMatch(MATCH_ID, EFOOTBALL, port);

  assert.equal(context.moments.length, 2);
  assert.equal(context.moments[0].event.id, EVENT_ID);
  assert.equal(context.moments[1].event.id, EVENT_ID_2);
});

console.log("\nlogFullMatchContextOnCompletion — best-effort, never throws");

await check("10. a read-port failure is logged and swallowed, never thrown", async () => {
  const throwingPort: AnalysisEngineReadPort = {
    async listAnalysisEvents() {
      throw new Error("simulated analysis_events read failure");
    },
    async listMomentExplanations() {
      return [];
    },
  };

  // Must resolve, not reject.
  await logFullMatchContextOnCompletion(MATCH_ID, EFOOTBALL, throwingPort);
});

console.log(`\n${passed} check(s) passed`);
if (process.exitCode) {
  console.error("\nSome checks FAILED — see above.");
} else {
  console.log("All checks passed.");
}
