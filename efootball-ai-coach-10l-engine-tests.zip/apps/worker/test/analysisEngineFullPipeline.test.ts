// Batch 10L — Engine Tests ONLY. Focused regression/integration tests
// for the COMPLETE 10A–10K analysis engine, exercised end to end
// through the same call shape processMatchVideo.ts's persistEvent /
// processScreenshot.ts's event loop actually use (see
// simulatePersistEvent below) — never through the job files themselves
// (both talk to supabaseAdmin/Storage directly with no injectable
// port, exactly as analysisEventPersistence.ts's own 10K header note
// already documents).
//
// SCOPE NOTE (what this file is FOR, and what it deliberately is NOT):
// every individual model/logic file already has its own exhaustive
// unit tests (packages/shared/test/*.test.ts), and analysisEngine.ts /
// analysisEventPersistence.ts already have focused integration tests
// of their own two integration points
// (apps/worker/test/analysisEngine.test.ts,
// apps/worker/test/analysisEventPersistence.test.ts). This file does
// NOT re-verify any of that internal logic line-by-line. Its only job
// is the thing none of those files exercise: a draft moving through
// the FULL chain —
//   validateAnalysisEventDraft (pre-check, no AI call for a doomed
//     draft) -> ai.generateTacticalAnalysis (10K ordering) ->
//     validateAndPersistAnalysisEvent (10D validate, 10D/10E/10F
//     buildEventTacticalContext, 10G-1/10G-2 DecisionQuality, 10J-2
//     persist MomentExplanation) -> getFullMatchContextForMatch (10D
//     re-read, 10J-1 momentExplanationsByEventId, 10J-3 persisted-
//     precedence reconstruction, 10I aggregate)
// — for BOTH football types, across multiple events in the same
// match, against a single shared in-memory store standing in for one
// Supabase Postgres instance serving multiple matches at once (so
// cross-match/cross-football-type leakage would actually be visible if
// it existed).
//
// Same framework-free convention as every other file in this package:
// Node's built-in `assert`, run via `tsx`, no real Supabase/Postgres
// instance, no real AI provider.
//
// Run with:  npx tsx apps/worker/test/analysisEngineFullPipeline.test.ts
//        or: npm test --workspace=apps/worker

import assert from "node:assert/strict";
import {
  validateAndPersistAnalysisEvent,
  validateAnalysisEventDraft,
  type AnalysisEventPersistencePort,
  type AnalysisEventOwnershipContext,
  type MomentExplanationPersistencePort,
  type TacticalAnalysisSnapshot,
} from "../src/analysisEventPersistence";
import {
  getFullMatchContextForMatch,
  type AnalysisEngineReadPort,
} from "../src/analysisEngine";
import type {
  AnalysisEvent,
  FootballMatchContext,
  MomentExplanationRow,
  MomentExplanationInsertRow,
} from "@efootball/shared";

let passed = 0;

async function check(name: string, fn: () => Promise<void> | void): Promise<void> {
  try {
    await fn();
    passed += 1;
    console.log(`  ok — ${name}`);
  } catch (err) {
    process.exitCode = 1;
    console.error(`  FAIL — ${name}`);
    console.error(err);
  }
}

// ============================================================
// Fixtures — same shapes/conventions as analysisEngine.test.ts /
// analysisEventPersistence.test.ts (deliberately not imported from
// those files — each test file stays independently readable/runnable,
// same existing convention across this package's own test suite).
// ============================================================

const MATCH_EFOOTBALL = "11111111-1111-1111-1111-111111111111";
const MATCH_REAL_FOOTBALL = "55555555-5555-5555-5555-555555555555";
const USER_ID = "22222222-2222-2222-2222-222222222222";
const OTHER_USER_ID = "66666666-6666-6666-6666-666666666666";

const EFOOTBALL: FootballMatchContext = { football_type: "efootball", team_size: 11 };
const REAL_FOOTBALL: FootballMatchContext = { football_type: "real_football", team_size: 7 };

function baseDraft(overrides: Record<string, any> = {}): Record<string, any> {
  return {
    timestamp_seconds: 120.5,
    event_type: "bad_pass",
    category: "passing",
    severity: "mistake",
    confidence: 80,
    confidence_level: "likely",
    description: "Played a risky central pass into a double press.",
    decision_score: 20,
    better_option: null,
    reasoning: null,
    context_start_seconds: 118,
    context_end_seconds: 123,
    ...overrides,
  };
}

function baseEventFields(draft: Record<string, any>): Record<string, unknown> {
  const {
    timestamp_seconds,
    event_type,
    category,
    severity,
    decision_score,
    confidence,
    confidence_level,
    description,
    better_option,
    reasoning,
    context_start_seconds,
    context_end_seconds,
  } = draft;
  return {
    timestamp_seconds,
    event_type,
    category,
    severity,
    decision_score,
    confidence,
    confidence_level,
    description,
    better_option,
    reasoning,
    context_start_seconds,
    context_end_seconds,
  };
}

/** Exactly one candidate per field (positions/passing_lane/space) — the
 * "never fabricate" rule's unambiguous case. */
function unambiguousTactical(overrides: Partial<TacticalAnalysisSnapshot> = {}): TacticalAnalysisSnapshot {
  return {
    actual_positions: [{ role: "CM", team: "user", pos: { x: 50, y: 60 } }],
    recommended_positions: null,
    passing_lanes: [{ from: { x: 50, y: 60 }, to: { x: 70, y: 80 }, quality: "good" }],
    open_spaces: [{ center: { x: 80, y: 85 }, radius: 10 }],
    pressure_zones: null,
    is_approximate: false,
    ...overrides,
  };
}

/** Two actual_positions candidates — the "never guess which one" case
 * (a tactical_analysis actual_positions array is a whole-team formation
 * snapshot with no player identity on its entries). */
function ambiguousTactical(): TacticalAnalysisSnapshot {
  return unambiguousTactical({
    actual_positions: [
      { role: "CM", team: "user", pos: { x: 50, y: 60 } },
      { role: "ST", team: "user", pos: { x: 80, y: 90 } },
    ],
  });
}

function ownership(overrides: Partial<AnalysisEventOwnershipContext> = {}): AnalysisEventOwnershipContext {
  return {
    matchId: MATCH_EFOOTBALL,
    userId: USER_ID,
    footballContext: EFOOTBALL,
    playerId: null,
    ...overrides,
  };
}

// ============================================================
// A single shared in-memory store standing in for one Postgres
// instance serving MULTIPLE matches — so a cross-match/cross-type
// leak in getFullMatchContextForMatch's own `WHERE match_id = ...`
// filtering (or an accidental default it should read from) would
// actually surface here, unlike a test scoped to one match only.
// ============================================================

interface SharedStore {
  events: AnalysisEvent[];
  explanations: MomentExplanationRow[];
}

function makeSharedStore(): SharedStore {
  return { events: [], explanations: [] };
}

/** Real analysis_events upsert is keyed on (match_id, dedupe_key)
 * (migration 0005) — this fake models that idempotency explicitly
 * (unlike the plain always-insert fakes in analysisEventPersistence.test.ts,
 * which test the CALL shape, not the end-to-end aggregate) so that
 * check 8/9 below can prove a retried job never produces a second
 * moment in the reconstructed FullMatchContext. */
function makeEventPersistencePort(
  store: SharedStore,
  matchId: string
): AnalysisEventPersistencePort & { upsertCalls: Record<string, unknown>[] } {
  const upsertCalls: Record<string, unknown>[] = [];
  let nextId = 1;
  return {
    upsertCalls,
    async upsertEvent(row) {
      upsertCalls.push(row);
      const dedupeKey = JSON.stringify([
        row.timestamp_seconds,
        row.event_type,
        row.context_start_seconds,
        row.context_end_seconds,
      ]);
      const existing = store.events.find(
        (e) => e.match_id === matchId && (e as any).__dedupe_key === dedupeKey
      );
      if (existing) return { id: existing.id, created_at: existing.created_at };

      const id = `event-${matchId}-${nextId++}`;
      const created_at = "2026-01-01T00:00:00.000Z";
      const fullRow: AnalysisEvent = {
        ...(row as Omit<AnalysisEvent, "id" | "created_at" | "statistics_evidence">),
        id,
        created_at,
        statistics_evidence: (row as { statistics_evidence?: string[] | null }).statistics_evidence ?? null,
      } as AnalysisEvent;
      (fullRow as any).__dedupe_key = dedupeKey;
      store.events.push(fullRow);
      return { id, created_at };
    },
  };
}

function makeMomentExplanationPort(
  store: SharedStore
): MomentExplanationPersistencePort & { insertCalls: MomentExplanationInsertRow[] } {
  const insertCalls: MomentExplanationInsertRow[] = [];
  const seen = new Set<string>();
  let nextId = 1;
  return {
    insertCalls,
    async insertIfAbsent(row) {
      const key = `${row.match_id}:${row.event_id}`;
      if (seen.has(key)) return; // INSERT ... ON CONFLICT DO NOTHING (0030)
      seen.add(key);
      insertCalls.push(row);
      store.explanations.push({
        ...row,
        id: `explanation-${nextId++}`,
        created_at: "2026-01-01T00:00:01.000Z",
      });
    },
  };
}

/** The SAME read port shape getFullMatchContextForMatch expects — reads
 * off the shared store, scoped to `matchId`, exactly like the real
 * Supabase-backed port's own `.eq("match_id", matchId)`. */
function makeReadPort(store: SharedStore): AnalysisEngineReadPort {
  return {
    async listAnalysisEvents(matchId) {
      return store.events.filter((e) => e.match_id === matchId);
    },
    async listMomentExplanations(matchId) {
      return store.explanations.filter((e) => e.match_id === matchId);
    },
  };
}

/** Fake AI provider — counts calls so "no duplicate AI tactical call"
 * can actually be asserted, and returns whatever TacticalAnalysisSnapshot
 * the test configures (mirrors ai.generateTacticalAnalysis's own
 * return shape). Never consulted for anything else — no model, no
 * network, exactly the "AI/PROVIDER BEHAVIOR UNCHANGED" contract
 * analysisEngine.ts's own header comment documents for this batch. */
function makeFakeAi(tactical: TacticalAnalysisSnapshot) {
  let calls = 0;
  return {
    get callCount() {
      return calls;
    },
    async generateTacticalAnalysis(): Promise<TacticalAnalysisSnapshot> {
      calls += 1;
      return tactical;
    },
  };
}

/**
 * Mirrors processMatchVideo.ts's persistEvent() / processScreenshot.ts's
 * event loop EXACTLY (see those files' own "10K AI-call-ordering fix"
 * comments): pre-validate BEFORE spending a tactical AI call, only call
 * the AI for a draft that will actually be accepted, then hand that
 * SAME already-computed result into validateAndPersistAnalysisEvent's
 * `tacticalAnalysis` param. This is the one piece of job-file behavior
 * this batch's own CLAUDE_STATE notes as untested at the job level
 * ("no job-level test exists ... verified by full-file read-through") —
 * reproducing it here (against the real, unmodified
 * validateAnalysisEventDraft/validateAndPersistAnalysisEvent functions)
 * is what makes this an actual "worker integration" test rather than
 * another unit test of either function in isolation.
 */
async function simulatePersistEvent(
  ownershipCtx: AnalysisEventOwnershipContext,
  draft: Record<string, any>,
  eventPort: AnalysisEventPersistencePort,
  mePort: MomentExplanationPersistencePort,
  ai: ReturnType<typeof makeFakeAi>
) {
  const pre = validateAnalysisEventDraft(ownershipCtx, draft);
  if (!pre.valid) {
    return { valid: false as const, errors: pre.errors };
  }
  const tactical = await ai.generateTacticalAnalysis();
  return validateAndPersistAnalysisEvent(
    ownershipCtx,
    draft,
    baseEventFields(draft),
    eventPort,
    mePort,
    tactical
  );
}

// ============================================================
// A. eFootball 11v11 — full pipeline, sufficient evidence
// (UnifiedFootballEvent, TacticalPosition, PassingLane/Space,
// DecisionQuality, MomentExplanation, FullMatchContext, persisted
// historical reconstruction, worker integration — all in one pass)
// ============================================================

console.log("A. eFootball 11v11 — full engine pipeline, sufficient evidence");

await check(
  "1. a valid eFootball event with real evidence flows end to end: exactly one AI call, DecisionQuality non-null, MomentExplanation persisted with tactical context attached, and reconstructed verbatim via getFullMatchContextForMatch",
  async () => {
    const store = makeSharedStore();
    const eventPort = makeEventPersistencePort(store, MATCH_EFOOTBALL);
    const mePort = makeMomentExplanationPort(store);
    const ai = makeFakeAi(unambiguousTactical());
    const draft = baseDraft({ reasoning: "The double press was visible before the pass was played." });

    const result = await simulatePersistEvent(ownership(), draft, eventPort, mePort, ai);

    // worker integration / no duplicate AI tactical call
    assert.equal(ai.callCount, 1);
    assert.equal(result.valid, true);
    if (!result.valid) return;

    // DecisionQuality + evidence gating (10G-1/10G-2)
    assert.notEqual(result.decisionQuality, null);
    assert.equal(result.decisionQuality?.event_id, result.eventId);

    // MomentExplanation (10H) persisted via 10J-2, tactical context (10E/10F) attached
    assert.equal(mePort.insertCalls.length, 1);
    const persistedExplanation = mePort.insertCalls[0];
    assert.equal(persistedExplanation.has_sufficient_evidence, true);
    assert.notEqual(persistedExplanation.positions, null);
    assert.notEqual(persistedExplanation.passing_lane, null);
    assert.notEqual(persistedExplanation.space, null);

    // FullMatchContext (10I) via persisted historical reconstruction (10J-3/10K)
    const fullContext = await getFullMatchContextForMatch(MATCH_EFOOTBALL, EFOOTBALL, makeReadPort(store));
    assert.equal(fullContext.football_type, "efootball");
    assert.equal(fullContext.team_size, 11);
    assert.equal(fullContext.moments.length, 1);
    const moment = fullContext.moments[0];
    assert.equal(moment.event.id, result.eventId);
    // UnifiedFootballEvent — unified categorization, football_type pass-through
    assert.equal(moment.event.event_type, "pass");
    assert.equal(moment.event.legacy_event_type, "bad_pass");
    assert.equal(moment.event.football_type, "efootball");
    // The persisted (historical) explanation wins verbatim — never recomputed.
    assert.equal(moment.explanation.has_sufficient_evidence, true);
    assert.notEqual(moment.explanation.positions, null);
    assert.equal(moment.explanation.positions?.actual.football_type, "efootball");
  }
);

// ============================================================
// B. Real Football 7v7 — full pipeline, sufficient evidence
// ============================================================

console.log("\nB. Real Football 7v7 — full engine pipeline, sufficient evidence");

await check(
  "2. a valid real_football event flows end to end with football_type/team_size correctly isolated to real_football throughout every layer",
  async () => {
    const store = makeSharedStore();
    const eventPort = makeEventPersistencePort(store, MATCH_REAL_FOOTBALL);
    const mePort = makeMomentExplanationPort(store);
    const ai = makeFakeAi(unambiguousTactical());
    const draft = baseDraft({ reasoning: "The double press was visible before the pass was played." });

    const result = await simulatePersistEvent(
      ownership({ matchId: MATCH_REAL_FOOTBALL, footballContext: REAL_FOOTBALL }),
      draft,
      eventPort,
      mePort,
      ai
    );

    assert.equal(ai.callCount, 1);
    assert.equal(result.valid, true);
    if (!result.valid) return;

    const row = mePort.insertCalls[0];
    assert.equal(row.football_type, "real_football");
    assert.equal(row.positions?.actual.football_type, "real_football");
    assert.equal(row.passing_lane?.football_type, "real_football");
    assert.equal(row.space?.football_type, "real_football");

    const fullContext = await getFullMatchContextForMatch(
      MATCH_REAL_FOOTBALL,
      REAL_FOOTBALL,
      makeReadPort(store)
    );
    assert.equal(fullContext.football_type, "real_football");
    assert.equal(fullContext.team_size, 7);
    assert.equal(fullContext.moments[0].event.football_type, "real_football");
    // getFullMatchContextForMatch never wires roster/team context (10K's own
    // "left to 10L+" scope note) — insufficient data stays null, never
    // fabricated, even for an otherwise fully-evidenced match.
    assert.equal(fullContext.efootball, null);
    assert.equal(fullContext.real_football, null);
  }
);

await check(
  "2b. an eFootball-only field on a real_football draft is rejected before any AI call or persistence — no cross-type contamination",
  async () => {
    const store = makeSharedStore();
    const eventPort = makeEventPersistencePort(store, MATCH_REAL_FOOTBALL);
    const mePort = makeMomentExplanationPort(store);
    const ai = makeFakeAi(unambiguousTactical());
    const draft = baseDraft({ playstyle: "Anchor Man" });

    const result = await simulatePersistEvent(
      ownership({ matchId: MATCH_REAL_FOOTBALL, footballContext: REAL_FOOTBALL }),
      draft,
      eventPort,
      mePort,
      ai
    );

    assert.equal(result.valid, false);
    assert.equal(ai.callCount, 0);
    assert.equal(eventPort.upsertCalls.length, 0);
    assert.equal(mePort.insertCalls.length, 0);
  }
);

// ============================================================
// C. Insufficient evidence -> NULL, across every layer at once
// ============================================================

console.log("\nC. insufficient evidence => NULL, propagated through the whole engine");

await check(
  "3. a score with no supporting evidence anywhere yields decisionQuality:null and a persisted MomentExplanation with has_sufficient_evidence:false / better_option:null, while unrelated tactical context still attaches (never evidence-gated) — and the aggregate reflects the same",
  async () => {
    const store = makeSharedStore();
    const eventPort = makeEventPersistencePort(store, MATCH_EFOOTBALL);
    const mePort = makeMomentExplanationPort(store);
    const ai = makeFakeAi(unambiguousTactical());
    // baseDraft()'s defaults carry no evidence anywhere (reasoning: null,
    // better_option: null) — a score alone is never sufficient (10G-2).
    const draft = baseDraft();

    const result = await simulatePersistEvent(ownership(), draft, eventPort, mePort, ai);

    assert.equal(result.valid, true);
    if (!result.valid) return;
    assert.equal(result.decisionQuality, null);

    const row = mePort.insertCalls[0];
    assert.equal(row.has_sufficient_evidence, false);
    assert.equal(row.better_option, null);
    assert.equal(row.why_better, null);
    assert.equal(row.actionable_improvement, null);
    // Never evidence-gated (momentExplanation.ts's own header contract).
    assert.notEqual(row.positions, null);
    assert.notEqual(row.passing_lane, null);
    assert.notEqual(row.space, null);

    const fullContext = await getFullMatchContextForMatch(MATCH_EFOOTBALL, EFOOTBALL, makeReadPort(store));
    assert.equal(fullContext.moments[0].explanation.has_sufficient_evidence, false);
    assert.equal(fullContext.moments[0].explanation.better_option, null);
  }
);

// ============================================================
// D. No fabricated data — ambiguous tactical candidates survive the
// full pipeline into the persisted row AND the reconstructed aggregate
// ============================================================

console.log("\nD. no fabricated data — ambiguous tactical candidates stay null end to end");

await check(
  "4. two actual_positions candidates for this event's own tactical data never guesses which one, all the way through to getFullMatchContextForMatch — positions stays null while unambiguous passing_lane/space still attach",
  async () => {
    const store = makeSharedStore();
    const eventPort = makeEventPersistencePort(store, MATCH_EFOOTBALL);
    const mePort = makeMomentExplanationPort(store);
    const ai = makeFakeAi(ambiguousTactical());
    const draft = baseDraft({ reasoning: "The double press was visible before the pass was played." });

    const result = await simulatePersistEvent(ownership(), draft, eventPort, mePort, ai);
    assert.equal(result.valid, true);

    const row = mePort.insertCalls[0];
    assert.equal(row.positions, null);
    assert.notEqual(row.passing_lane, null);
    assert.notEqual(row.space, null);

    const fullContext = await getFullMatchContextForMatch(MATCH_EFOOTBALL, EFOOTBALL, makeReadPort(store));
    assert.equal(fullContext.moments[0].explanation.positions, null);
    assert.notEqual(fullContext.moments[0].explanation.passing_lane, null);
  }
);

// ============================================================
// E. No duplicate AI tactical call
// ============================================================

console.log("\nE. no duplicate AI tactical call");

await check(
  "5. an invalid draft (cross-match ownership) never triggers the tactical AI call and persists nothing",
  async () => {
    const store = makeSharedStore();
    const eventPort = makeEventPersistencePort(store, MATCH_EFOOTBALL);
    const mePort = makeMomentExplanationPort(store);
    const ai = makeFakeAi(unambiguousTactical());
    const draft = baseDraft({ match_id: MATCH_REAL_FOOTBALL });

    const result = await simulatePersistEvent(ownership(), draft, eventPort, mePort, ai);

    assert.equal(result.valid, false);
    assert.equal(ai.callCount, 0);
    assert.equal(eventPort.upsertCalls.length, 0);
    assert.equal(mePort.insertCalls.length, 0);
  }
);

await check(
  "6. a valid draft triggers the tactical AI call exactly once per persistEvent invocation — never zero, never twice",
  async () => {
    const store = makeSharedStore();
    const eventPort = makeEventPersistencePort(store, MATCH_EFOOTBALL);
    const mePort = makeMomentExplanationPort(store);
    const ai = makeFakeAi(unambiguousTactical());
    const draft = baseDraft({ reasoning: "The double press was visible before the pass was played." });

    await simulatePersistEvent(ownership(), draft, eventPort, mePort, ai);

    assert.equal(ai.callCount, 1);
  }
);

// ============================================================
// F. ownership / idempotency at the full-pipeline level
// ============================================================

console.log("\nF. ownership / idempotency across the full pipeline");

await check(
  "7. cross-match isolation: match A's persisted event never appears when reconstructing match B's FullMatchContext, even though both live in the SAME shared store/read-port instance",
  async () => {
    const store = makeSharedStore();
    const aiA = makeFakeAi(unambiguousTactical());
    const aiB = makeFakeAi(unambiguousTactical());
    const draftA = baseDraft({ reasoning: "Match A evidence." });
    const draftB = baseDraft({ reasoning: "Match B evidence." });

    const resultA = await simulatePersistEvent(
      ownership({ matchId: MATCH_EFOOTBALL, footballContext: EFOOTBALL }),
      draftA,
      makeEventPersistencePort(store, MATCH_EFOOTBALL),
      makeMomentExplanationPort(store),
      aiA
    );
    const resultB = await simulatePersistEvent(
      ownership({ matchId: MATCH_REAL_FOOTBALL, footballContext: REAL_FOOTBALL }),
      draftB,
      makeEventPersistencePort(store, MATCH_REAL_FOOTBALL),
      makeMomentExplanationPort(store),
      aiB
    );

    assert.equal(resultA.valid, true);
    assert.equal(resultB.valid, true);

    const readPort = makeReadPort(store);
    const contextA = await getFullMatchContextForMatch(MATCH_EFOOTBALL, EFOOTBALL, readPort);
    const contextB = await getFullMatchContextForMatch(MATCH_REAL_FOOTBALL, REAL_FOOTBALL, readPort);

    assert.equal(contextA.moments.length, 1);
    assert.equal(contextB.moments.length, 1);
    assert.notEqual(contextA.moments[0].event.id, contextB.moments[0].event.id);
    assert.equal(contextA.moments[0].event.football_type, "efootball");
    assert.equal(contextB.moments[0].event.football_type, "real_football");
  }
);

await check(
  "8. retrying the identical valid draft (simulating a retried job whose upsert resolves to the same analysis_events row) never duplicates the persisted MomentExplanation nor the moment surfaced by getFullMatchContextForMatch",
  async () => {
    const store = makeSharedStore();
    const eventPort = makeEventPersistencePort(store, MATCH_EFOOTBALL);
    const mePort = makeMomentExplanationPort(store);
    const ai = makeFakeAi(unambiguousTactical());
    const draft = baseDraft({ reasoning: "The double press was visible before the pass was played." });

    const first = await simulatePersistEvent(ownership(), draft, eventPort, mePort, ai);
    const second = await simulatePersistEvent(ownership(), draft, eventPort, mePort, ai);

    assert.equal(first.valid, true);
    assert.equal(second.valid, true);
    if (first.valid && second.valid) {
      // The fake port's own dedupe-key match resolves both calls to the
      // same underlying row (mirrors migration 0005's real upsert).
      assert.equal(first.eventId, second.eventId);
    }
    // AI is still called once per job run (unavoidable at this layer —
    // see file header on job-level AI-call-count scope), but the
    // idempotent DB layer means only one analysis_events row and one
    // moment_explanations row ever exist for it.
    assert.equal(ai.callCount, 2);
    assert.equal(store.events.filter((e) => e.match_id === MATCH_EFOOTBALL).length, 1);
    assert.equal(mePort.insertCalls.length, 1);

    const fullContext = await getFullMatchContextForMatch(MATCH_EFOOTBALL, EFOOTBALL, makeReadPort(store));
    assert.equal(fullContext.moments.length, 1);
  }
);

// ============================================================
// G. eFootball / Real Football isolation, persisted historical
// reconstruction, and the complete 10A-10K engine aggregate together
// (multiple events, one match, mixed evidence/ambiguity)
// ============================================================

console.log(
  "\nG. FullMatchContext aggregate over multiple persisted moments — chronological ordering, historical precedence, and every prior scenario's guarantee holding simultaneously"
);

await check(
  "9. three events persisted in one eFootball match (fully evidenced, insufficient evidence, ambiguous tactical) reconstruct as one chronologically-ordered FullMatchContext with each moment's own guarantees intact, and a historical explanation is never recomputed on re-read",
  async () => {
    const store = makeSharedStore();
    // ONE shared eventPort/mePort across all three persist calls (so
    // event ids increment correctly, exactly like the real port's own
    // single Supabase table) — a fresh port per call would reset each
    // fake's own id counter and collide, which is a test-fixture
    // concern only, not an engine behavior being verified here.
    const eventPort = makeEventPersistencePort(store, MATCH_EFOOTBALL);
    const mePort = makeMomentExplanationPort(store);

    const evidencedDraft = baseDraft({
      timestamp_seconds: 50,
      context_start_seconds: 48,
      context_end_seconds: 55,
      reasoning: "The double press was visible before the pass was played.",
    });
    const insufficientDraft = baseDraft({
      timestamp_seconds: 150,
      context_start_seconds: 148,
      context_end_seconds: 155,
    });
    const ambiguousDraft = baseDraft({
      timestamp_seconds: 250,
      context_start_seconds: 248,
      context_end_seconds: 255,
      reasoning: "Cover was already broken before the pass.",
    });

    const evidencedResult = await simulatePersistEvent(
      ownership(),
      evidencedDraft,
      eventPort,
      mePort,
      makeFakeAi(unambiguousTactical())
    );
    const insufficientResult = await simulatePersistEvent(
      ownership(),
      insufficientDraft,
      eventPort,
      mePort,
      makeFakeAi(unambiguousTactical())
    );
    const ambiguousResult = await simulatePersistEvent(
      ownership(),
      ambiguousDraft,
      eventPort,
      mePort,
      makeFakeAi(ambiguousTactical())
    );

    assert.equal(evidencedResult.valid, true);
    assert.equal(insufficientResult.valid, true);
    assert.equal(ambiguousResult.valid, true);
    assert.equal(store.events.filter((e) => e.match_id === MATCH_EFOOTBALL).length, 3);
    assert.equal(store.explanations.filter((e) => e.match_id === MATCH_EFOOTBALL).length, 3);

    const readPort = makeReadPort(store);
    const fullContext = await getFullMatchContextForMatch(MATCH_EFOOTBALL, EFOOTBALL, readPort);

    assert.equal(fullContext.moments.length, 3);
    // Chronological ordering (10I), ascending by timestamp_seconds.
    assert.equal(fullContext.moments[0].event.timestamp_seconds, 50);
    assert.equal(fullContext.moments[1].event.timestamp_seconds, 150);
    assert.equal(fullContext.moments[2].event.timestamp_seconds, 250);

    const [evidencedMoment, insufficientMoment, ambiguousMoment] = fullContext.moments;
    assert.equal(evidencedMoment.explanation.has_sufficient_evidence, true);
    assert.notEqual(evidencedMoment.explanation.positions, null);

    assert.equal(insufficientMoment.explanation.has_sufficient_evidence, false);
    assert.equal(insufficientMoment.explanation.better_option, null);

    assert.equal(ambiguousMoment.explanation.positions, null);
    assert.notEqual(ambiguousMoment.explanation.passing_lane, null);

    // Persisted historical reconstruction: re-reading the SAME match a
    // second time (e.g. a later job run) reproduces the exact same
    // explanations verbatim — buildMomentExplanationFromUnifiedEvent is
    // never re-invoked for an event that already has a persisted row
    // (10J-3's own precedence rule), so nothing here can drift between
    // reads.
    const fullContextAgain = await getFullMatchContextForMatch(MATCH_EFOOTBALL, EFOOTBALL, readPort);
    assert.deepEqual(fullContextAgain, fullContext);
  }
);

console.log(`\n${passed} check(s) passed`);
if (process.exitCode) {
  console.error("\nSome checks FAILED — see above.");
} else {
  console.log("All checks passed.");
}
