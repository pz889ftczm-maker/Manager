// Batch 9C-1 — lightweight, framework-free tests for
// triggerMatchSnapshotOnCompletion's decision logic. Same convention as
// packages/shared/test/*.test.ts (no test runner/framework, Node's
// built-in `assert` module, run via `tsx`) — see this repo's existing
// tests for the pattern this file follows.
//
// Run with:  npx tsx apps/worker/test/matchSnapshot.test.ts
//        or: npm test --workspace=apps/worker
//
// SCOPE NOTE: these tests exercise ONLY this file's own decision logic
// (which match states qualify, that Team/Formation context is read
// directly off the match row and never inferred/fabricated, that a
// failure never throws) against a fake, in-memory MatchSnapshotPort —
// nothing here talks to a real Supabase/Postgres instance. The actual
// authorization boundary (match/team/formation/manager/player
// ownership, atomic creation, (match_id, team_id) idempotency) lives
// entirely in public.create_match_snapshot (migrations 0026/0027),
// already covered by that migration's own design/review, not
// re-verified by a live integration test here. Likewise, that
// matches.team_id/formation_id are only ever set via an
// ownership-checked write (supabase/functions/analysis-enqueue) is
// that function's own concern, not this worker-side file's — see
// migration 0028_matches_team_formation_context.sql's design notes.

import assert from "node:assert/strict";
import { triggerMatchSnapshotOnCompletion, type MatchSnapshotPort } from "../src/matchSnapshot";

let passed = 0;

async function check(name: string, fn: () => Promise<void> | void): Promise<void> {
  try {
    await fn();
    passed += 1;
    console.log(`  ok — ${name}`);
  } catch (err) {
    process.exitCode = 1;
    console.error(`  FAIL — ${name}`);
    console.error(err);
  }
}

const MATCH_ID = "11111111-1111-1111-1111-111111111111";
const USER_ID = "22222222-2222-2222-2222-222222222222";
const TEAM_ID = "33333333-3333-3333-3333-333333333333";
const FORMATION_ID = "55555555-5555-5555-5555-555555555555";

interface FakeMatch {
  status: string;
  is_demo: boolean;
  team_id: string | null;
  formation_id: string | null;
}

interface FakePortConfig {
  match?: FakeMatch | null;
  createSnapshotThrows?: unknown;
}

interface FakePort extends MatchSnapshotPort {
  createSnapshotCalls: Array<{ userId: string; matchId: string; teamId: string; formationId: string | null }>;
  getMatchCalls: number;
}

function makeFakePort(config: FakePortConfig): FakePort {
  const createSnapshotCalls: FakePort["createSnapshotCalls"] = [];
  let getMatchCalls = 0;

  return {
    createSnapshotCalls,
    get getMatchCalls() {
      return getMatchCalls;
    },
    async getMatch() {
      getMatchCalls += 1;
      return config.match ?? null;
    },
    async createSnapshot(args) {
      createSnapshotCalls.push(args);
      if (config.createSnapshotThrows !== undefined) {
        throw config.createSnapshotThrows;
      }
    },
  };
}

console.log("triggerMatchSnapshotOnCompletion — reads Team/Formation context directly off the match row");

await check(
  "multiple teams owned by the user: uses the team_id persisted on the match, not a guess from team count",
  async () => {
    // The user may own any number of other teams besides TEAM_ID — but
    // this file no longer has any way to even ask "how many teams does
    // this user own" (that lookup was the audit bug; it's gone). The
    // match row itself recorded TEAM_ID as the one it was analyzed with
    // (persisted by analysis-enqueue at enqueue time — migration 0028),
    // so that and only that is what gets used, regardless of how many
    // other team_library rows the user happens to have.
    const port = makeFakePort({
      match: { status: "complete", is_demo: false, team_id: TEAM_ID, formation_id: null },
    });

    await triggerMatchSnapshotOnCompletion(MATCH_ID, USER_ID, port);

    assert.equal(port.createSnapshotCalls.length, 1);
    assert.equal(port.createSnapshotCalls[0].teamId, TEAM_ID);
  }
);

await check("selected formation: uses the formation_id persisted on the match row", async () => {
  const port = makeFakePort({
    match: { status: "complete", is_demo: false, team_id: TEAM_ID, formation_id: FORMATION_ID },
  });

  await triggerMatchSnapshotOnCompletion(MATCH_ID, USER_ID, port);

  assert.equal(port.createSnapshotCalls.length, 1);
  assert.deepEqual(port.createSnapshotCalls[0], {
    userId: USER_ID,
    matchId: MATCH_ID,
    teamId: TEAM_ID,
    formationId: FORMATION_ID,
  });
});

await check("creates a snapshot with a null formationId when the match has a team but no formation selected", async () => {
  const port = makeFakePort({
    match: { status: "complete", is_demo: false, team_id: TEAM_ID, formation_id: null },
  });

  await triggerMatchSnapshotOnCompletion(MATCH_ID, USER_ID, port);

  assert.equal(port.createSnapshotCalls.length, 1);
  assert.equal(port.createSnapshotCalls[0].formationId, null);
});

console.log("triggerMatchSnapshotOnCompletion — NULL context is skipped, never fabricated");

await check("does not create a snapshot when the match has no team_id (NULL context)", async () => {
  const port = makeFakePort({
    match: { status: "complete", is_demo: false, team_id: null, formation_id: null },
  });

  await triggerMatchSnapshotOnCompletion(MATCH_ID, USER_ID, port);

  assert.equal(port.createSnapshotCalls.length, 0);
});

await check(
  "does not create a snapshot when team_id is null even if formation_id is somehow set",
  async () => {
    // Should never happen via the one real write path (analysis-enqueue
    // rejects formationId without teamId), but this file must not
    // invent a team just because a formation_id happens to be present —
    // team_id null is the only signal it trusts.
    const port = makeFakePort({
      match: { status: "complete", is_demo: false, team_id: null, formation_id: FORMATION_ID },
    });

    await triggerMatchSnapshotOnCompletion(MATCH_ID, USER_ID, port);

    assert.equal(port.createSnapshotCalls.length, 0);
  }
);

console.log("triggerMatchSnapshotOnCompletion — existing successful-analysis behavior remains intact");

await check("does not create a snapshot when the match status is 'error'", async () => {
  const port = makeFakePort({
    match: { status: "error", is_demo: false, team_id: TEAM_ID, formation_id: FORMATION_ID },
  });

  await triggerMatchSnapshotOnCompletion(MATCH_ID, USER_ID, port);

  assert.equal(port.createSnapshotCalls.length, 0);
});

await check("does not create a snapshot when the match is still in progress (not yet complete)", async () => {
  // 9E requirement 7 — explicitly includes "queued" alongside every
  // other non-complete status, so an analysis that was enqueued but
  // never actually started (or was effectively cancelled before the
  // worker picked it up) is covered by name, not just implied by "any
  // non-complete status".
  for (const status of [
    "queued",
    "uploading",
    "optimizing",
    "processing",
    "detecting_moments",
    "analyzing",
    "generating_report",
  ]) {
    const port = makeFakePort({
      match: { status, is_demo: false, team_id: TEAM_ID, formation_id: FORMATION_ID },
    });

    await triggerMatchSnapshotOnCompletion(MATCH_ID, USER_ID, port);

    assert.equal(port.createSnapshotCalls.length, 0, `expected no snapshot for status=${status}`);
  }
});

await check("does not create a snapshot for a demo/sample match, even if status is 'complete'", async () => {
  const port = makeFakePort({
    match: { status: "complete", is_demo: true, team_id: TEAM_ID, formation_id: FORMATION_ID },
  });

  await triggerMatchSnapshotOnCompletion(MATCH_ID, USER_ID, port);

  assert.equal(port.createSnapshotCalls.length, 0);
});

await check("does not create a snapshot when the match no longer exists", async () => {
  const port = makeFakePort({ match: null });

  await triggerMatchSnapshotOnCompletion(MATCH_ID, USER_ID, port);

  assert.equal(port.createSnapshotCalls.length, 0);
});

console.log("triggerMatchSnapshotOnCompletion — repeated completion is idempotent");

await check("calling twice for the same completed match issues the same createSnapshot request both times", async () => {
  const port = makeFakePort({
    match: { status: "complete", is_demo: false, team_id: TEAM_ID, formation_id: FORMATION_ID },
  });

  await triggerMatchSnapshotOnCompletion(MATCH_ID, USER_ID, port);
  await triggerMatchSnapshotOnCompletion(MATCH_ID, USER_ID, port);

  // This function itself never tracks "already created" state — that
  // is deliberately left entirely to create_match_snapshot's own
  // (match_id, team_id) unique index + `on conflict do nothing` (see
  // migrations 0025/0026/0027). What this test verifies is the
  // contract this function DOES own: a retried/re-run completion
  // issues an identical request both times, so the RPC's own
  // idempotency is what prevents a duplicate row — never a second,
  // different request that could confuse it.
  assert.equal(port.createSnapshotCalls.length, 2);
  assert.deepEqual(port.createSnapshotCalls[0], port.createSnapshotCalls[1]);
});

console.log("triggerMatchSnapshotOnCompletion — snapshot failure never fails the caller");

await check("resolves (does not throw) when createSnapshot itself fails", async () => {
  const port = makeFakePort({
    match: { status: "complete", is_demo: false, team_id: TEAM_ID, formation_id: FORMATION_ID },
    createSnapshotThrows: new Error("match_snapshot_create: team_not_found"),
  });

  await assert.doesNotReject(() => triggerMatchSnapshotOnCompletion(MATCH_ID, USER_ID, port));
  assert.equal(port.createSnapshotCalls.length, 1);
});

await check("resolves (does not throw) when reading match state itself fails", async () => {
  const port: MatchSnapshotPort = {
    async getMatch() {
      throw new Error("simulated transient database error");
    },
    async createSnapshot() {
      throw new Error("should never be called");
    },
  };

  await assert.doesNotReject(() => triggerMatchSnapshotOnCompletion(MATCH_ID, USER_ID, port));
});

console.log("\ntriggerMatchSnapshotOnCompletion — concurrent completion (9C-2 hardening)");

await check(
  "two concurrent calls for the same completed match both issue the identical createSnapshot request " +
    "(no cross-call state leaks between them, and neither request is mutated by the other running at the same time)",
  async () => {
    // Simulates two workers (or a retry racing the original run) both
    // reaching triggerMatchSnapshotOnCompletion for the same match at
    // the same time. This function itself holds no shared/module-level
    // state between calls (each call re-reads the match row and builds
    // its own request), so nothing here can race internally — the
    // actual duplicate-prevention is create_match_snapshot's own
    // (match_id, team_id) unique index + `on conflict do nothing`
    // (migrations 0025/0026/0027), exercised from the worker side by
    // asserting both concurrent calls still produce the exact same,
    // uncorrupted request.
    const port = makeFakePort({
      match: { status: "complete", is_demo: false, team_id: TEAM_ID, formation_id: FORMATION_ID },
    });

    await Promise.all([
      triggerMatchSnapshotOnCompletion(MATCH_ID, USER_ID, port),
      triggerMatchSnapshotOnCompletion(MATCH_ID, USER_ID, port),
    ]);

    assert.equal(port.createSnapshotCalls.length, 2);
    assert.deepEqual(port.createSnapshotCalls[0], port.createSnapshotCalls[1]);
    assert.equal(port.getMatchCalls, 2);
  }
);

await check(
  "concurrent completions for two DIFFERENT matches never cross-attach one match's team/formation context to the other " +
    "(9C-2 item 6 — no stale/incorrect context from another match)",
  async () => {
    const MATCH_ONE = "66666666-6666-6666-6666-666666666666";
    const MATCH_TWO = "77777777-7777-7777-7777-777777777777";
    const TEAM_ONE = "88888888-8888-8888-8888-888888888888";
    const TEAM_TWO = "99999999-9999-9999-9999-999999999999";

    // A single fake port instance is deliberately shared across both
    // concurrent calls below — it looks up the match by the matchId
    // its own getMatch(matchId) is invoked with, exactly like the real
    // Supabase-backed port does via `.eq("id", matchId)`. This proves
    // triggerMatchSnapshotOnCompletion itself never holds/reuses a
    // team_id or formation_id value across two different matchIds —
    // every call resolves its own context strictly from its own
    // matchId argument.
    const matchesById: Record<string, FakeMatch> = {
      [MATCH_ONE]: { status: "complete", is_demo: false, team_id: TEAM_ONE, formation_id: null },
      [MATCH_TWO]: { status: "complete", is_demo: false, team_id: TEAM_TWO, formation_id: null },
    };
    const calls: Array<{ userId: string; matchId: string; teamId: string; formationId: string | null }> = [];
    const port: MatchSnapshotPort = {
      async getMatch(matchId) {
        return matchesById[matchId] ?? null;
      },
      async createSnapshot(args) {
        calls.push(args);
      },
    };

    await Promise.all([
      triggerMatchSnapshotOnCompletion(MATCH_ONE, USER_ID, port),
      triggerMatchSnapshotOnCompletion(MATCH_TWO, USER_ID, port),
    ]);

    const forMatchOne = calls.find((c) => c.matchId === MATCH_ONE);
    const forMatchTwo = calls.find((c) => c.matchId === MATCH_TWO);
    assert.equal(forMatchOne?.teamId, TEAM_ONE);
    assert.equal(forMatchTwo?.teamId, TEAM_TWO);
  }
);

console.log("\ntriggerMatchSnapshotOnCompletion — retry after a prior failed attempt (9C-2 hardening)");

await check(
  "a retried completion after a transient createSnapshot failure issues a fresh, correct request and still cannot throw",
  async () => {
    // First attempt: the RPC call itself fails transiently (e.g. a
    // dropped connection) — already covered by the failure test above,
    // repeated here specifically to then immediately retry with the
    // SAME port/matchId and assert the retry behaves as a normal,
    // successful completion (9C-2 item 2 — "retry ... cannot create
    // duplicate snapshots"; the actual de-dup is create_match_snapshot's
    // own idempotent (match_id, team_id) handling, unchanged by this
    // file — this test only proves the worker-side retry path itself
    // reissues a clean, unmodified request rather than getting stuck in
    // a bad state after the first failure).
    let attempt = 0;
    const port: MatchSnapshotPort = {
      async getMatch() {
        return { status: "complete", is_demo: false, team_id: TEAM_ID, formation_id: FORMATION_ID };
      },
      createSnapshotCalls: [] as FakePort["createSnapshotCalls"],
      async createSnapshot(args) {
        (this as unknown as FakePort).createSnapshotCalls.push(args);
        attempt += 1;
        if (attempt === 1) throw new Error("simulated transient RPC failure");
      },
    } as FakePort;

    await triggerMatchSnapshotOnCompletion(MATCH_ID, USER_ID, port);
    await triggerMatchSnapshotOnCompletion(MATCH_ID, USER_ID, port);

    const fakePort = port as FakePort;
    assert.equal(fakePort.createSnapshotCalls.length, 2);
    assert.deepEqual(fakePort.createSnapshotCalls[0], fakePort.createSnapshotCalls[1]);
  }
);

console.log(`\n${passed} check(s) passed`);
if (process.exitCode) {
  console.error("\nSome checks FAILED — see above.");
} else {
  console.log("All checks passed.");
}
