import { createClient } from "@supabase/supabase-js";

// SERVICE ROLE KEY — server-only, bypasses RLS. This file must never be
// imported from apps/web. It exists only inside the worker process, which
// runs in a trusted environment (not the browser).
const url = process.env.SUPABASE_URL;
const serviceKey = process.env.SUPABASE_SERVICE_ROLE_KEY;

if (!url || !serviceKey) {
  throw new Error(
    "SUPABASE_URL and SUPABASE_SERVICE_ROLE_KEY must be set for the worker process."
  );
}

export const supabaseAdmin = createClient(url, serviceKey, {
  auth: { persistSession: false },
});
