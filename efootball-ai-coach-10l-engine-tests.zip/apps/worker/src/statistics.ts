import { aggregatePlayerProgress, computePositioningScore } from "@efootball/shared";
import type { ProgressEventRow, ProgressMatchRow, ProgressStatsRow } from "@efootball/shared";
import { supabaseAdmin } from "./supabaseClient";
import { fetchSelfPlayerStatsByMatch } from "./playerStatistics";

/**
 * Batch 3 — real match_statistics + player_progress write path.
 *
 * Both processMatchVideo.ts and processScreenshot.ts call
 * recomputeMatchStatistics(matchId), THEN set matches.status='complete'
 * for that match, THEN call recomputePlayerProgress(userId) — in that
 * exact order. recomputePlayerProgress only reads matches with
 * status='complete' (see below), so it must run after the status flip or
 * the match just analyzed is excluded from its own progress update
 * (Batch 3 bugfix — previously player_progress was recomputed before the
 * status flip and always missed the current match).
 *
 * Extracted here (rather than living only in processMatchVideo.ts as
 * before) so screenshot-analyzed matches contribute to player_progress
 * too — previously they didn't call recomputeMatchStatistics at all, so
 * screenshot-only users would never get skill_trends/positioning/etc.
 *
 * Idempotency (spec item 7): recomputeMatchStatistics upserts by
 * match_id (the table's primary key), and recomputePlayerProgress does a
 * FULL recompute from the user's current matches/match_statistics/
 * analysis_events rows rather than incrementing counters. Re-running
 * either function again for the same match/user — e.g. because a job was
 * retried — lands on exactly the same values, so nothing is double-counted.
 * Duplicate source rows are prevented upstream as of migration
 * 0005_analysis_events_idempotency.sql: analysis_events carries a generated
 * content fingerprint (dedupe_key) with a UNIQUE (match_id, dedupe_key)
 * constraint, and both worker jobs persist events with a conflict-safe upsert
 * on that key. So a retried job cannot inflate the event set these two
 * functions read from, and both stay deterministic across retries.
 */

export async function recomputeMatchStatistics(matchId: string): Promise<void> {
  const { data: events, error } = await supabaseAdmin
    .from("analysis_events")
    .select("category, event_type, decision_score, severity")
    .eq("match_id", matchId);

  if (error) throw error;
  if (!events || events.length === 0) return;

  const avgByCategory = (cat: string) => {
    const rows = events.filter((e) => e.category === cat && e.decision_score != null);
    if (rows.length === 0) return null;
    return rows.reduce((sum, r) => sum + Number(r.decision_score), 0) / rows.length;
  };

  const scoredEvents = events.filter((e) => e.decision_score != null);
  const overall = scoredEvents.length
    ? scoredEvents.reduce((s, e) => s + Number(e.decision_score), 0) / scoredEvents.length
    : null;

  // Fix for the audited bug: positioning_score used to just alias
  // avgByCategory("attacking"). It's now computed from the actual
  // positioning-related event_types (see POSITIONING_EVENT_TYPES in
  // packages/shared/src/progress.ts), spanning both the attacking and
  // defending categories, and is null (not a fake number) when there
  // isn't enough real evidence for this match.
  const positioning = computePositioningScore(events);

  const { error: upsertError } = await supabaseAdmin.from("match_statistics").upsert({
    match_id: matchId,
    passing_score: avgByCategory("passing"),
    dribbling_score: avgByCategory("dribbling"),
    attacking_score: avgByCategory("attacking"),
    defending_score: avgByCategory("defending"),
    positioning_score: positioning.score,
    decision_making_score: overall,
    good_decisions_count: events.filter((e) => ["excellent", "good"].includes(e.severity)).length,
    bad_decisions_count: events.filter((e) => ["mistake", "critical_mistake"].includes(e.severity)).length,
  });
  if (upsertError) throw upsertError;

  const { error: matchUpdateError } = await supabaseAdmin
    .from("matches")
    .update({ overall_score: overall })
    .eq("id", matchId);
  if (matchUpdateError) throw matchUpdateError;
}

/**
 * Real player_progress write path (previously read-only — no code ever
 * wrote to this table). Recomputes the whole row from this user's actual
 * analyzed match history and upserts it. Demo matches (is_demo=true) and
 * anything not yet status='complete' are excluded so they can never
 * contaminate real progress.
 */
export async function recomputePlayerProgress(userId: string): Promise<void> {
  const { data: matches, error: matchesError } = await supabaseAdmin
    .from("matches")
    .select("id, match_date, created_at, overall_score")
    .eq("user_id", userId)
    .eq("is_demo", false)
    .eq("status", "complete");
  if (matchesError) throw matchesError;

  const matchRows: ProgressMatchRow[] = matches ?? [];

  if (matchRows.length === 0) {
    // First-match / no-history-yet case: don't write a misleading row.
    // The Progress page already renders an explicit "analyze a few
    // matches" empty state when no player_progress row exists.
    return;
  }

  const matchIds = matchRows.map((m) => m.id);

  const { data: statsRows, error: statsError } = await supabaseAdmin
    .from("match_statistics")
    .select(
      "match_id, passing_score, dribbling_score, attacking_score, defending_score, positioning_score, decision_making_score, good_decisions_count, bad_decisions_count"
    )
    .in("match_id", matchIds);
  if (statsError) throw statsError;

  const { data: eventRows, error: eventsError } = await supabaseAdmin
    .from("analysis_events")
    .select("match_id, event_type, category, severity, decision_score")
    .in("match_id", matchIds);
  if (eventsError) throw eventsError;

  const statsByMatchId = new Map<string, ProgressStatsRow>();
  for (const row of statsRows ?? []) statsByMatchId.set(row.match_id, row as ProgressStatsRow);

  const events: ProgressEventRow[] = (eventRows ?? []) as ProgressEventRow[];

  // Batch 3.5 remaining-work item 1: the self player's REAL, validated,
  // non-demo, completed-match statistics — matchIds here already come
  // from the is_demo=false/status='complete' filter above, and
  // fetchSelfPlayerStatsByMatch further scopes to this exact userId and
  // is_valid=true rows, so no other user's or demo/incomplete-match
  // statistics can ever enter the aggregation.
  const playerStatsByMatchId = await fetchSelfPlayerStatsByMatch(userId, matchIds);

  const progress = aggregatePlayerProgress({ matches: matchRows, statsByMatchId, events, playerStatsByMatchId });

  const { error: upsertError } = await supabaseAdmin.from("player_progress").upsert({
    user_id: userId,
    matches_analyzed: progress.matches_analyzed,
    overall_trend: progress.overall_trend,
    skill_trends: progress.skill_trends,
    most_improved_skill: progress.most_improved_skill,
    biggest_weakness: progress.biggest_weakness,
    most_common_mistake: progress.most_common_mistake,
    recommended_position: progress.recommended_position,
    recommended_position_confidence: progress.recommended_position_confidence,
    recommended_position_evidence: progress.recommended_position_evidence,
    playstyle_tags: progress.playstyle_tags,
    playstyle_evidence: progress.playstyle_evidence,
    mistake_analysis: progress.mistake_analysis,
    possession_loss_total: progress.possession_loss_total,
    insufficient_data: progress.insufficient_data,
    player_stat_trends: progress.player_stat_trends,
    player_stat_trends_insufficient: progress.player_stat_trends_insufficient,
    updated_at: new Date().toISOString(),
  });
  if (upsertError) throw upsertError;
}
