// Batch 9C-1 — Automatic Historical Match Snapshot Creation on analysis
// completion.
//
// 9E AUDIT (no functional change): Phase 9E's own spec asked for
// exactly this feature — automatic snapshot creation at the correct
// completion point, using matches.team_id/formation_id verbatim, never
// inferred, reusing 9B's RPC, idempotent under retry/race, and
// failure-isolated from the analysis result. This file (together with
// its call sites in processMatchVideo.ts/processScreenshot.ts and 9B's
// own create_match_snapshot RPC) already satisfies every one of those
// requirements as of 9C-1/9C-2 — re-verified line-by-line for 9E and
// left untouched rather than re-implemented. The only 9E-motivated
// change in this whole batch is a small test-coverage addition (see
// apps/worker/test/matchSnapshot.test.ts's "queued" status case).
//
// 9A (0025_match_snapshots.sql) added the match_snapshots /
// match_snapshot_players schema with NO creation path at all. 9B
// (0026/0027 + supabase/functions/match-snapshot-create) added exactly
// one trusted, server-side creation path — the
// public.create_match_snapshot RPC, callable only by service_role, with
// its own atomic ownership checks and (match_id, team_id) idempotency.
// Both of 9A/9B's own design notes explicitly deferred "automatic
// snapshot creation" to a later phase (see 0025's "Out of scope for
// this migration" note). This file is that later phase, and ONLY that:
// it decides WHEN to call the existing 9B service after a match
// analysis finishes, using ONLY trusted server/database state. It adds
// no new schema, no new RPC, no new Edge Function, and does not touch
// 9B's own ownership/atomicity/idempotency logic at all.
//
// CALL SITE (spec item 1 — "find the existing authoritative server-side
// analysis completion flow"): apps/worker/src/jobs/processMatchVideo.ts
// and apps/worker/src/jobs/processScreenshot.ts are the only two places
// in this codebase that ever flip matches.status to 'complete' after a
// real analysis run (recomputeMatchStatistics -> status='complete' ->
// recomputePlayerProgress, in that order — see apps/worker/src/
// statistics.ts's own header comment). Both call
// triggerMatchSnapshotOnCompletion(matchId, userId) immediately after
// that sequence. Nothing else in this codebase creates a match
// snapshot automatically, and this file does not change either job's
// AI/video/statistics behavior in any other way.
//
// TRUSTED SERVER CONTEXT ONLY (spec item 3): this function takes only a
// matchId/userId (both already resolved server-side by the calling job
// from its own queue payload, itself already ownership-checked against
// the database at the top of that job — see processMatchVideo.ts/
// processScreenshot.ts's own "Part K" comments). It never reads a
// team_id/formation_id/player/manager value from a queue payload, HTTP
// request, or any other client-influenced input — every id it passes to
// create_match_snapshot is read fresh from the database, right here,
// immediately before use.
//
// RE-VERIFIES COMPLETION FROM THE DATABASE ITSELF (spec item 4 — "do
// not create snapshots for failed/cancelled/incomplete/demo matches"):
// rather than trusting the caller's own belief that analysis just
// succeeded, this function re-reads the authoritative matches row and
// only proceeds when status = 'complete' and is_demo = false. This is
// deliberate, cheap defense-in-depth: a future call site, a
// refactor, or a bug in the calling job's own control flow cannot make
// this create a snapshot for a match that was never really completed,
// because the check happens against the database's own current state,
// not the call site's assumption.
//
// TEAM/FORMATION CONTEXT: A REAL SOURCE OF TRUTH, NEVER GUESSED (9C-1
// AUDIT FIX): this file previously had no stored "this match used this
// team" link to read, and approximated one by only proceeding when the
// user's team_library contained EXACTLY ONE row — correct only by
// coincidence for a single-team user, and silently wrong (or silently
// skipped) for anyone who actually owns more than one team. THAT WAS
// THE AUDIT BUG this section now documents the fix for. The fix is
// migration 0028_matches_team_formation_context.sql: nullable
// matches.team_id (-> team_library) / matches.formation_id (->
// team_formations), populated by supabase/functions/analysis-enqueue's
// own server-side claim update at job-enqueue time — BEFORE analysis
// even starts, let alone completes — from a teamId/formationId the
// caller optionally supplies, which that function verifies ownership
// of first (same ownership-check-then-privileged-write pattern that
// function already uses for mediaId; see its own comments). This file
// itself never reads team_library/team_formations, never lists a
// user's teams, and never picks one: it reads match.team_id/
// match.formation_id straight off the already-verified, already-
// persisted match row (getMatch below) and uses exactly that value, or
// skips entirely when team_id is null (audit-fix items 5/6/7 — "do not
// infer Team from user-has-one-team", "do not fabricate Team/
// Formation", "read team_id/formation_id directly from the
// authoritative match row"). Existing matches (and any match whose
// caller simply didn't supply a teamId) keep team_id = formation_id =
// NULL from migration 0028's own additive, no-backfill design — this
// remains a fully valid state that safely skips snapshot creation
// (audit-fix item 9), never an error. A non-null team_id with a null
// formation_id is also fully valid and never blocks snapshot creation
// — create_match_snapshot (0026/0027) already treats a null
// formation_id as a fully valid, non-fabricated state.
//
// IDEMPOTENCY (spec item 6): entirely preserved, unchanged, from 9B.
// This file never checks "does a snapshot already exist" itself and
// never needs to — it always calls create_match_snapshot, and that
// RPC's own (match_id, team_id) unique index + `on conflict ... do
// nothing` handling (0025/0026/0027) is what makes a repeated call for
// the same match+team a safe no-op that returns the existing row
// rather than a duplicate. A retried/re-run completion (BullMQ retry,
// a job re-processing after a crash) therefore cannot create a second
// snapshot merely because this function runs again.
//
// SNAPSHOT FAILURE NEVER FAILS ANALYSIS (spec item 7): every branch of
// this function is wrapped so it can only ever log-and-return, never
// throw. Both call sites already await this function directly, with no
// surrounding try/catch of their own, precisely because it makes that
// contract itself — a caller does not need to guard against a
// snapshot failure turning a successful analysis run into a failed
// one. A raw failure (a real RPC/database error, as opposed to "no
// snapshot needed because context is ambiguous/absent") is logged with
// this repo's own existing convention: a `[matchSnapshot]`-tagged
// console.error carrying just the error's message, matching
// processMatchVideo.ts's/processScreenshot.ts's own catch-block style
// exactly (see either file's own trailing catch block).
//
// SCOPE (spec item 8): this file does not modify AI provider behavior,
// the video/screenshot pipelines themselves, Player/Manager/Team
// Library, Formation, or Preset code in any way — it only reads the
// team_id/formation_id already persisted onto the match row itself
// (see TEAM/FORMATION CONTEXT note above) and calls the existing
// create_match_snapshot RPC exactly as supabase/functions/
// match-snapshot-create/index.ts already does.

// NOTE: apps/worker/src/supabaseClient.ts is intentionally NOT imported
// at the top of this file (a static import is resolved/evaluated the
// moment this module loads, regardless of whether it's ever used) —
// see createSupabaseMatchSnapshotPort below, which loads it lazily via
// a dynamic import instead, only when actually constructing the real
// production port. This keeps importing this file (e.g. from a test
// that always supplies its own fake MatchSnapshotPort) from requiring
// apps/worker/src/supabaseClient.ts's own required environment
// variables (SUPABASE_URL / SUPABASE_SERVICE_ROLE_KEY) to be set.

/** Narrow, dependency-injectable view of exactly the operations this
 * module needs — real production code gets an implementation backed by
 * `supabaseAdmin` (see createSupabaseMatchSnapshotPort below); tests
 * supply a plain in-memory fake instead, so this file's own decision
 * logic (which match states qualify, how team/formation ambiguity is
 * resolved, that a failure never throws) can be exercised without a
 * real Supabase/Postgres instance — same "authorization/atomicity
 * lives in the database, this is just the trusted caller" boundary as
 * matchSnapshotCreation.ts's own pure helpers, just on the worker side
 * of that boundary instead of the Edge Function side. */
export interface MatchSnapshotPort {
  /** Reads the authoritative current state of a match row, including
   * the Team/Formation context already persisted onto it —
   * matches.team_id / matches.formation_id (migration 0028), written
   * only by analysis-enqueue's own server-side, ownership-checked
   * claim update (see header comment). Returns null if the match
   * somehow no longer exists (never happens for a job's own matchId in
   * practice, but handled rather than throwing a confusing error). */
  getMatch(matchId: string): Promise<{
    status: string;
    is_demo: boolean;
    team_id: string | null;
    formation_id: string | null;
  } | null>;
  /** Invokes the existing 9B service (public.create_match_snapshot)
   * exactly as supabase/functions/match-snapshot-create/index.ts
   * already does: service-role client, explicit p_user_id resolved
   * server-side, p_formation_id nullable. Throws on a genuine RPC
   * error — idempotency ("already exists") is NOT an error from this
   * RPC (see 0026/0027) and never throws here either. */
  createSnapshot(args: {
    userId: string;
    matchId: string;
    teamId: string;
    formationId: string | null;
  }): Promise<void>;
}

/** Real, production implementation of MatchSnapshotPort, backed by the
 * worker's own service-role client (apps/worker/src/supabaseClient.ts)
 * — the same trusted, RLS-bypassing client processMatchVideo.ts/
 * processScreenshot.ts already use for every other write in the
 * completion flow. Deliberately NOT constructed at module load time
 * (only inside triggerMatchSnapshotOnCompletion, and only when the
 * caller didn't supply its own port) so importing this file — e.g.
 * from a test that always supplies a fake port — never requires
 * apps/worker/src/supabaseClient.ts's own required environment
 * variables to be set. */
async function createSupabaseMatchSnapshotPort(): Promise<MatchSnapshotPort> {
  const { supabaseAdmin } = await import("./supabaseClient");
  return {
    async getMatch(matchId) {
      const { data, error } = await supabaseAdmin
        .from("matches")
        .select("status, is_demo, team_id, formation_id")
        .eq("id", matchId)
        .maybeSingle();
      if (error) throw error;
      if (!data) return null;
      return {
        status: data.status as string,
        is_demo: data.is_demo as boolean,
        team_id: (data.team_id as string | null) ?? null,
        formation_id: (data.formation_id as string | null) ?? null,
      };
    },
    async createSnapshot({ userId, matchId, teamId, formationId }) {
      const { error } = await supabaseAdmin.rpc("create_match_snapshot", {
        p_user_id: userId,
        p_match_id: matchId,
        p_team_id: teamId,
        p_formation_id: formationId,
      });
      if (error) throw error;
    },
  };
}

/**
 * Called once by each of processMatchVideo.ts / processScreenshot.ts,
 * immediately after a match's analysis has finished and its status has
 * already been flipped to 'complete' (spec item 2 — "after successful
 * analysis/statistics completion, call the existing 9B ... service").
 *
 * NEVER THROWS: every awaited step below is inside the single try
 * block, and the catch simply logs and returns — a failure here (a
 * transient DB error, an RPC ownership rejection, anything else)
 * cannot propagate to the calling job and therefore cannot turn an
 * otherwise-successful analysis run into a failed one (spec item 7).
 *
 * `port` defaults to the real Supabase-backed implementation; tests
 * pass a fake to exercise this function's decision logic in isolation
 * (spec item 9).
 */
export async function triggerMatchSnapshotOnCompletion(
  matchId: string,
  userId: string,
  port?: MatchSnapshotPort
): Promise<void> {
  try {
    const p = port ?? (await createSupabaseMatchSnapshotPort());

    // Re-read the authoritative row rather than trusting the caller's
    // own belief that analysis just succeeded (spec item 4). Any
    // status other than 'complete' — including 'error', or any
    // still-in-progress state — and any demo/sample match are both
    // simply skipped, not an error.
    const match = await p.getMatch(matchId);
    if (!match || match.status !== "complete" || match.is_demo) {
      return;
    }

    // Team/formation context: read directly off the authoritative
    // match row — matches.team_id / matches.formation_id, migration
    // 0028 — never inferred and never fabricated (9C-1 audit-fix items
    // 5/6/7; see header comment for the full rationale). A null
    // team_id means this match has no recorded Team context at all
    // (never had one supplied at enqueue time) — there is nothing
    // honest to attach a snapshot to, so it's skipped, exactly like
    // every match analyzed before this feature existed (item 9).
    if (!match.team_id) {
      return;
    }

    // formation_id may legitimately be null even when team_id is set
    // (no formation selected) — create_match_snapshot (0026/0027)
    // already treats a null formation_id as a fully valid,
    // non-fabricated state, so it's passed through as-is rather than
    // blocking snapshot creation.
    //
    // The existing 9B service is the only thing that actually writes
    // match_snapshots/match_snapshot_players — see this file's header
    // comment. Its own (match_id, team_id) idempotency (spec item 6)
    // and every ownership check (audit-fix item 8 — 9B remains the
    // final server-side security boundary) remain entirely untouched
    // here.
    await p.createSnapshot({ userId, matchId, teamId: match.team_id, formationId: match.formation_id });
  } catch (err) {
    // Same "log safely, never throw" convention as processMatchVideo.ts's
    // and processScreenshot.ts's own trailing catch blocks (spec item 7).
    console.error(`[matchSnapshot] failed to create snapshot for match ${matchId}:`, (err as Error)?.message ?? err);
  }
}
