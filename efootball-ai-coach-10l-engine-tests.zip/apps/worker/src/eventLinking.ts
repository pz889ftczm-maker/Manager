import { buildStatisticsEvidence, mergeStatRowsForEvidence, ALL_STAT_FIELDS } from "@efootball/shared";
import type { MatchPlayerStatisticsFields } from "@efootball/shared";
import { supabaseAdmin } from "./supabaseClient";
import { resolvePlayerId } from "./playerStatistics";

/**
 * Batch 3.5 remaining-work items 1 & 2 — connects analysis_events to the
 * player they belong to, and to the real statistics evidence that backs
 * them.
 *
 * Player identity (item 1): the ONLY player identity a gameplay
 * screenshot/video frame can reliably support without inventing something
 * is "this was the human user's own controlled player" — see migration
 * 0006's design notes. The AI provider is asked (see
 * packages/ai/src/providers/anthropicProvider.ts) to set
 * `involvesSelfPlayer: true` on a DetectedEventDraft only when that's
 * actually clear from the frames, never as a default. This module trusts
 * that flag and nothing else: if it's not `true`, the event's player_id is
 * left NULL, exactly as spec section 8 allows ("older events / events that
 * can't be tied to a specific identified player remain valid match-level
 * evidence on their own").
 *
 * Statistics evidence (item 2): once an event has a player_id, if that
 * player has any real, validated match_player_statistics for this same
 * match, a handful of the most relevant fields (see
 * packages/shared/src/playerStatistics.ts's buildStatisticsEvidence) are
 * cited as short strings on statistics_evidence. Never fabricated — only
 * fields that are non-null on an already-persisted, is_valid=true stats
 * row can appear.
 */

/**
 * Called once per persisted event, right after the analysis_events upsert,
 * from both processMatchVideo.ts and processScreenshot.ts. Returns the
 * resolved player_id (or null) so the caller can include it directly in
 * the same upsert/update instead of a second round trip when possible.
 */
export async function resolveEventSelfPlayerId(
  userId: string,
  involvesSelfPlayer: boolean | undefined
): Promise<string | null> {
  if (involvesSelfPlayer !== true) return null;
  // Reuses the exact same find-or-create logic that collapses repeated
  // "self, name unknown" detections onto one canonical row (see
  // playerStatistics.ts's resolvePlayerId / players_user_self_unnamed_uniq),
  // so an event's player_id always points at the same identity that
  // match_player_statistics rows for this user's own player use.
  return resolvePlayerId(userId, { playerName: null, isSelf: true, confidence: 0 });
}

/**
 * Full recompute of statistics_evidence for every player-linked event in a
 * match, run once near the end of each processing job (after both event
 * persistence AND player-statistics extraction have completed for that
 * job, so newly-extracted stats are visible). Deterministic given the
 * match's current analysis_events + match_player_statistics rows — safe to
 * call again on a retried job (spec item 11: idempotency).
 */
export async function linkStatisticsEvidenceForMatch(matchId: string): Promise<void> {
  const { data: events, error: eventsError } = await supabaseAdmin
    .from("analysis_events")
    .select("id, category, event_type, player_id")
    .eq("match_id", matchId)
    .not("player_id", "is", null);
  if (eventsError) throw eventsError;
  if (!events || events.length === 0) return;

  const playerIds = Array.from(new Set(events.map((e) => e.player_id as string)));

  const { data: statRows, error: statsError } = await supabaseAdmin
    .from("match_player_statistics")
    .select(["player_id", "confidence", "is_valid", ...ALL_STAT_FIELDS].join(","))
    .eq("match_id", matchId)
    .eq("is_valid", true)
    .in("player_id", playerIds);
  if (statsError) throw statsError;

  const rowsByPlayer = new Map<string, (MatchPlayerStatisticsFields & { confidence: number | null })[]>();
  for (const row of (statRows ?? []) as any[]) {
    const list = rowsByPlayer.get(row.player_id) ?? [];
    list.push(row);
    rowsByPlayer.set(row.player_id, list);
  }

  const mergedByPlayer = new Map<string, MatchPlayerStatisticsFields>();
  for (const [playerId, rows] of rowsByPlayer) {
    mergedByPlayer.set(playerId, mergeStatRowsForEvidence(rows));
  }

  for (const event of events) {
    const merged = event.player_id ? mergedByPlayer.get(event.player_id as string) : null;
    const evidence = buildStatisticsEvidence(event.category, event.event_type, merged);
    const { error: updateError } = await supabaseAdmin
      .from("analysis_events")
      .update({ statistics_evidence: evidence.length > 0 ? evidence : null })
      .eq("id", event.id);
    if (updateError) throw updateError;
  }
}
