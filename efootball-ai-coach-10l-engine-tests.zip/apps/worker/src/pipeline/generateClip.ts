import ffmpeg from "fluent-ffmpeg";

/**
 * Batch 4, Part 8 — trims the persisted match video (see
 * ../storage.ts::downloadProcessedVideo) down to a short clip around one
 * event. Re-encodes rather than stream-copying: a copy-trim can only cut on
 * a keyframe boundary, which would silently shift the clip away from the
 * exact requested start/end (and the source here is already a compressed
 * 720p H.264 MP4 from compressVideo.ts, so a second encode pass at the same
 * settings is cheap). Uses the identical codec/quality options as
 * compressVideo.ts so a clip looks consistent with the full match video it
 * was cut from, rather than inventing separate quality settings here.
 *
 * `-ss` is given as an INPUT option (seek before decode) for speed, with
 * `-t` (duration, not a second absolute timestamp) as an output option —
 * the standard ffmpeg accurate-seek pattern. Caller is responsible for
 * clamping startSeconds/endSeconds to the real video duration first (see
 * @efootball/shared's computeContextWindow / resolveEventContextWindow) —
 * this function trusts its inputs are already valid Part 19 output.
 */
export interface GenerateClipResult {
  outputPath: string;
  outputSizeBytes: number;
}

export function generateClip(
  inputPath: string,
  startSeconds: number,
  endSeconds: number,
  outputPath: string
): Promise<GenerateClipResult> {
  // Part L ("never construct commands from unsanitized input") —
  // generateVideoClip.ts already validates these are finite, in-range
  // numbers before calling this function; this is the last line of
  // defense at the actual ffmpeg-invocation boundary. fluent-ffmpeg's
  // option strings are split on whitespace into separate argv entries
  // (never passed through a shell), so a non-numeric value here couldn't
  // cause shell injection — but it could still inject an extra ffmpeg CLI
  // flag or crash the encoder, so reject it outright rather than letting
  // String(startSeconds) reach the command line.
  if (!Number.isFinite(startSeconds) || !Number.isFinite(endSeconds) || endSeconds <= startSeconds) {
    return Promise.reject(new Error(`generateClip received an invalid window [${startSeconds}, ${endSeconds}]`));
  }
  const durationSeconds = endSeconds - startSeconds;

  return new Promise((resolve, reject) => {
    ffmpeg(inputPath)
      .inputOptions([`-ss ${startSeconds}`])
      .outputOptions([`-t ${durationSeconds}`, "-preset veryfast", "-crf 23", "-movflags +faststart"])
      .videoCodec("libx264")
      .audioCodec("aac")
      .audioBitrate("96k")
      .on("error", (err) => reject(err))
      .on("end", async () => {
        const fs = await import("node:fs/promises");
        const stat = await fs.stat(outputPath);
        resolve({ outputPath, outputSizeBytes: stat.size });
      })
      .save(outputPath);
  });
}
