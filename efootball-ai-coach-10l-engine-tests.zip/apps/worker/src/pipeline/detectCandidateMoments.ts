import fs from "node:fs/promises";
import type { AiProvider } from "@efootball/ai";
import type { SampledFrame } from "./sampleFrames";
import { encodeFramesToBase64 } from "./encodeFrame";

/**
 * Spec section 11/12: scan the whole match cheaply BEFORE running full
 * decision analysis, so we only spend the expensive analyzeVideoContext()
 * call on timestamps that actually look interesting.
 *
 * Real implementation (previously a stub, see git history): groups index
 * frames into batches and asks the AI provider's cheap
 * `scanForCandidateMoments()` which of them show a notable football
 * decision. Batching keeps this affordable on a long match — a 90-minute
 * match sampled every 3s is 1800 frames, which at batchSize=20 is ~90
 * scan calls on a lightweight model instead of 1800 full analysis calls.
 */
export async function detectCandidateMoments(
  indexFrames: SampledFrame[],
  ai: AiProvider,
  batchSize = 20
): Promise<number[]> {
  const candidates: number[] = [];

  try {
    for (let i = 0; i < indexFrames.length; i += batchSize) {
      const batch = indexFrames.slice(i, i + batchSize);
      const encoded = await encodeFramesToBase64(batch);

      const flagged = await ai.scanForCandidateMoments({
        frames: encoded.map((f) => ({
          imageBase64: f.imageBase64,
          timestampSeconds: f.timestampSeconds,
        })),
      });

      for (const moment of flagged) candidates.push(moment.timestampSeconds);
    }
  } finally {
    // Housekeeping: index frames are only needed for detection, not for the
    // final analysis (context windows are re-extracted at higher density),
    // so clean them up immediately to keep disk usage bounded on long matches.
    await Promise.all(indexFrames.map((f) => fs.unlink(f.path).catch(() => {})));
  }

  // Dedup + sort — a batch boundary or overlapping context windows could
  // otherwise flag the same rough moment twice.
  return Array.from(new Set(candidates)).sort((a, b) => a - b);
}
