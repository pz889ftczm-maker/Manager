import fs from "node:fs/promises";

/**
 * B.1 fix: frames sampled by ffmpeg only ever exist as local paths on the
 * worker's disk (see sampleFrames.ts). Anthropic's hosted API can't reach
 * into the worker's filesystem, so those local paths must never be sent
 * as `imageUrl` — that only ever worked against a local/dev provider
 * stub that happened to read the filesystem itself. Read the file and
 * hand it over as `imageBase64` instead, which every AiProvider
 * implementation accepts (see GameplayFrame in packages/ai/src/provider.ts).
 */
export async function encodeFrameToBase64(localPath: string): Promise<string> {
  const buffer = await fs.readFile(localPath);
  return buffer.toString("base64");
}

export async function encodeFramesToBase64<T extends { path: string }>(
  frames: T[]
): Promise<(T & { imageBase64: string })[]> {
  return Promise.all(
    frames.map(async (frame) => ({
      ...frame,
      imageBase64: await encodeFrameToBase64(frame.path),
    }))
  );
}
