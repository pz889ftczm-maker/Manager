import ffmpeg from "fluent-ffmpeg";
import path from "node:path";
import fs from "node:fs/promises";

/**
 * Spec section 11: never send every frame to the AI. Instead sample at a
 * fixed interval across the whole match to build a low-cost "index" the
 * candidate-moment detector scans, and separately extract dense frames
 * only around timestamps that look interesting (see extractContextWindow).
 */
export interface SampledFrame {
  path: string;
  timestampSeconds: number;
}

export async function sampleFramesAcrossMatch(
  videoPath: string,
  durationSeconds: number,
  workDir: string,
  intervalSeconds = 3
): Promise<SampledFrame[]> {
  const outDir = path.join(workDir, "index-frames");
  await fs.mkdir(outDir, { recursive: true });

  const timestamps: number[] = [];
  for (let t = 0; t < durationSeconds; t += intervalSeconds) timestamps.push(t);

  return new Promise((resolve, reject) => {
    ffmpeg(videoPath)
      .on("error", reject)
      .on("end", () => {
        resolve(
          timestamps.map((t, i) => ({
            path: path.join(outDir, `frame_${String(i).padStart(5, "0")}.jpg`),
            timestampSeconds: t,
          }))
        );
      })
      .screenshots({
        timestamps,
        filename: "frame_%i.jpg",
        folder: outDir,
        size: "640x?",
      });
  });
}

/**
 * Spec section 14: for a candidate moment at `eventTimestamp`, extract a
 * denser burst of frames across [T-10s, T+10s] (clamped to match bounds)
 * for the AI to actually reason about before/during/after.
 */
export async function extractContextWindow(
  videoPath: string,
  eventTimestampSeconds: number,
  durationSeconds: number,
  workDir: string,
  windowSeconds = 10,
  fps = 1
): Promise<SampledFrame[]> {
  const start = Math.max(0, eventTimestampSeconds - windowSeconds);
  const end = Math.min(durationSeconds, eventTimestampSeconds + windowSeconds);
  const outDir = path.join(workDir, `context-${Math.round(eventTimestampSeconds)}`);
  await fs.mkdir(outDir, { recursive: true });

  const timestamps: number[] = [];
  for (let t = start; t <= end; t += 1 / fps) timestamps.push(Number(t.toFixed(2)));

  return new Promise((resolve, reject) => {
    ffmpeg(videoPath)
      .on("error", reject)
      .on("end", () => {
        resolve(
          timestamps.map((t, i) => ({
            path: path.join(outDir, `ctx_${String(i).padStart(4, "0")}.jpg`),
            timestampSeconds: t,
          }))
        );
      })
      .screenshots({
        timestamps,
        filename: "ctx_%i.jpg",
        folder: outDir,
        size: "960x?",
      });
  });
}
