import ffmpeg from "fluent-ffmpeg";
import path from "node:path";

/**
 * Spec section 9/26: automatically compress uploaded video toward ~720p
 * H.264 MP4 at a reasonable bitrate, without the user touching any settings.
 * This runs on the ORIGINAL video that was pulled from temporary storage,
 * and its output is what gets frame-sampled + analyzed. The original is
 * deleted after successful processing (see cleanup.ts).
 */
export interface CompressVideoResult {
  outputPath: string;
  outputSizeBytes: number;
  durationSeconds: number;
}

export function compressVideo(inputPath: string, workDir: string): Promise<CompressVideoResult> {
  const outputPath = path.join(workDir, "optimized.mp4");

  return new Promise((resolve, reject) => {
    ffmpeg(inputPath)
      .videoCodec("libx264")
      .size("?x720") // scale to 720p height, preserve aspect ratio
      .outputOptions([
        "-preset veryfast",
        "-crf 23", // reasonable quality/size tradeoff; tune per spec section 9
        "-movflags +faststart",
      ])
      .audioCodec("aac")
      .audioBitrate("96k")
      .on("error", (err) => reject(err))
      .on("end", async () => {
        const ffprobeInfo = await probeDuration(outputPath);
        const fs = await import("node:fs/promises");
        const stat = await fs.stat(outputPath);
        resolve({
          outputPath,
          outputSizeBytes: stat.size,
          durationSeconds: ffprobeInfo,
        });
      })
      .save(outputPath);
  });
}

function probeDuration(filePath: string): Promise<number> {
  return new Promise((resolve, reject) => {
    ffmpeg.ffprobe(filePath, (err, data) => {
      if (err) return reject(err);
      resolve(data.format.duration ?? 0);
    });
  });
}
