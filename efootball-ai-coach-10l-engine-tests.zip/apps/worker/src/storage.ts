import fs from "node:fs/promises";
import path from "node:path";
import { supabaseAdmin } from "./supabaseClient";

const RAW_BUCKET = process.env.STORAGE_BUCKET_RAW_UPLOADS ?? "raw-uploads";
const FRAMES_BUCKET = process.env.STORAGE_BUCKET_PROCESSED_FRAMES ?? "processed-frames";
// Batch 4 — see migration 0008_video_experience.sql for the RLS policies
// and the audit note on why these buckets didn't exist before this batch.
const MATCH_VIDEO_BUCKET = process.env.STORAGE_BUCKET_MATCH_VIDEOS ?? "match-videos";
const VIDEO_CLIP_BUCKET = process.env.STORAGE_BUCKET_VIDEO_CLIPS ?? "video-clips";

/** Uploads a local file to a private bucket at `{userId}/{matchId}/{filename}`
 * — this prefix convention is what the storage RLS policies in
 * 0002_rls.sql rely on. */
export async function uploadFrame(
  userId: string,
  matchId: string,
  localPath: string
): Promise<string> {
  const filename = path.basename(localPath);
  const objectPath = `${userId}/${matchId}/${filename}`;
  const fileBuffer = await fs.readFile(localPath);

  const { error } = await supabaseAdmin.storage
    .from(FRAMES_BUCKET)
    .upload(objectPath, fileBuffer, { contentType: "image/jpeg", upsert: true });

  if (error) throw error;
  return objectPath;
}

/** Signed URL, short-lived, used to hand the frame to the client or to
 * pass as `imageUrl` to the AI provider without making anything public.
 * Defaults to the processed-frames bucket (extracted video frames). */
export async function getSignedFrameUrl(objectPath: string, expiresInSeconds = 3600): Promise<string> {
  return getSignedUrl(FRAMES_BUCKET, objectPath, expiresInSeconds);
}

/** Signed URL for an object still sitting in the raw-uploads bucket —
 * this is what screenshots actually live in (Analyze.tsx uploads them
 * straight there and, unlike video, screenshots are never compressed/
 * copied into processed-frames). Audit fix (Batch 3.5): processScreenshot.ts
 * previously called getSignedFrameUrl() on a raw-uploads path, which signed
 * against the wrong bucket and would 404 for every screenshot analysis. */
export async function getSignedRawUploadUrl(objectPath: string, expiresInSeconds = 3600): Promise<string> {
  return getSignedUrl(RAW_BUCKET, objectPath, expiresInSeconds);
}

async function getSignedUrl(bucket: string, objectPath: string, expiresInSeconds: number): Promise<string> {
  const { data, error } = await supabaseAdmin.storage
    .from(bucket)
    .createSignedUrl(objectPath, expiresInSeconds);
  if (error || !data) throw error ?? new Error(`Failed to create signed URL in bucket ${bucket}`);
  return data.signedUrl;
}

export async function downloadRawUpload(objectPath: string, destLocalPath: string): Promise<void> {
  const { data, error } = await supabaseAdmin.storage.from(RAW_BUCKET).download(objectPath);
  if (error || !data) throw error ?? new Error("Failed to download raw upload");
  const buffer = Buffer.from(await data.arrayBuffer());
  await fs.writeFile(destLocalPath, buffer);
}

/** Spec section 10/26: delete the temporary raw video (and any local
 * scratch dir) only AFTER analysis has been persisted successfully. */
export async function deleteRawUpload(objectPath: string): Promise<void> {
  const { error } = await supabaseAdmin.storage.from(RAW_BUCKET).remove([objectPath]);
  if (error) throw error;
}

export async function cleanupLocalWorkDir(workDir: string): Promise<void> {
  await fs.rm(workDir, { recursive: true, force: true });
}

// ============================================================
// Batch 4 — persisted playable match video (fixes the gap documented at
// the top of migration 0008: the compressed video previously never left
// the worker's local scratch dir). Fixed filename per match so retries
// upsert the same object instead of accumulating orphaned copies.
// ============================================================

/** Uploads the ffmpeg-compressed match video so it survives past this job
 * — unlike the raw upload, this one is NOT deleted after processing. Path
 * follows the same `{userId}/{matchId}/{filename}` convention as the other
 * buckets so the existing RLS policy shape (0002_rls.sql /
 * 0008_video_experience.sql) applies unmodified. */
export async function uploadProcessedVideo(
  userId: string,
  matchId: string,
  localPath: string
): Promise<string> {
  const objectPath = `${userId}/${matchId}/optimized.mp4`;
  const fileBuffer = await fs.readFile(localPath);

  const { error } = await supabaseAdmin.storage
    .from(MATCH_VIDEO_BUCKET)
    .upload(objectPath, fileBuffer, { contentType: "video/mp4", upsert: true });

  if (error) throw error;
  return objectPath;
}

/** Used only by the clip-generation job, which needs the persisted match
 * video as its ffmpeg input — never the (already-deleted) raw upload. */
export async function downloadProcessedVideo(objectPath: string, destLocalPath: string): Promise<void> {
  const { data, error } = await supabaseAdmin.storage.from(MATCH_VIDEO_BUCKET).download(objectPath);
  if (error || !data) throw error ?? new Error("Failed to download processed match video");
  const buffer = Buffer.from(await data.arrayBuffer());
  await fs.writeFile(destLocalPath, buffer);
}

/** One clip per event, so a fixed `{eventId}.mp4` filename both keeps the
 * path predictable (Part 9) and makes re-generation idempotent at the
 * storage layer (upsert: true) — the video_clips row is still the source
 * of truth for idempotency (Part 12), this just avoids orphaned objects if
 * a row is ever regenerated with the same start/end after a manual retry. */
export async function uploadVideoClip(
  userId: string,
  matchId: string,
  eventId: string,
  localPath: string
): Promise<string> {
  const objectPath = `${userId}/${matchId}/${eventId}.mp4`;
  const fileBuffer = await fs.readFile(localPath);

  const { error } = await supabaseAdmin.storage
    .from(VIDEO_CLIP_BUCKET)
    .upload(objectPath, fileBuffer, { contentType: "video/mp4", upsert: true });

  if (error) throw error;
  return objectPath;
}
