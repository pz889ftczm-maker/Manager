import { Worker, Queue, UnrecoverableError, type Job } from "bullmq";
import IORedis from "ioredis";
import { processMatchVideo, type ProcessMatchVideoJobData } from "./jobs/processMatchVideo";
import { processScreenshot, type ProcessScreenshotJobData } from "./jobs/processScreenshot";
import { generateVideoClip, type GenerateVideoClipJobData } from "./jobs/generateVideoClip";
import { startInternalHttpServer } from "./httpServer";
import { sweepAbandonedUploads } from "./cleanup";
import { supabaseAdmin } from "./supabaseClient";

const connection = new IORedis(process.env.REDIS_URL ?? "redis://localhost:6379", {
  maxRetriesPerRequest: null,
});

export const VIDEO_QUEUE_NAME = "process-match-video";
export const SCREENSHOT_QUEUE_NAME = "process-screenshot";
export const CLIP_QUEUE_NAME = "generate-video-clip"; // Batch 4

// Batch 5 (Part K) — every job gets a bounded number of retries with
// exponential backoff so a transient failure (a network blip, a momentary
// AI-provider 429/5xx) recovers on its own instead of failing the whole
// match/clip outright, while a genuinely broken job still stops instead of
// retrying forever. Jobs that are broken for a PERMANENT reason (bad file
// type, ownership mismatch) throw bullmq's UnrecoverableError instead of a
// plain Error — see jobs/*.ts — which skips the remaining retries rather
// than burning through them on something that will never succeed.
// removeOnComplete/removeOnFail bound how much finished job history Redis
// holds, so a busy queue doesn't grow it unboundedly (Part K/V).
const defaultJobOptions = {
  attempts: 3,
  backoff: { type: "exponential" as const, delay: 5_000 },
  removeOnComplete: { age: 60 * 60 * 24, count: 1_000 },
  removeOnFail: { age: 60 * 60 * 24 * 7 },
};

// Exported so apps/web (server-side route / Edge Function) can enqueue jobs
// without duplicating queue config. Import from a server-only module.
export const videoQueue = new Queue<ProcessMatchVideoJobData>(VIDEO_QUEUE_NAME, { connection, defaultJobOptions });
export const screenshotQueue = new Queue<ProcessScreenshotJobData>(SCREENSHOT_QUEUE_NAME, {
  connection,
  defaultJobOptions,
});
export const clipQueue = new Queue<GenerateVideoClipJobData>(CLIP_QUEUE_NAME, { connection, defaultJobOptions });

// Batch 5 retry-state fix — single source of truth for TERMINAL failure
// bookkeeping (media.status='failed' / matches.status='error'). The job
// functions themselves (processMatchVideo.ts / processScreenshot.ts) now
// only log + rethrow on failure, on every attempt, so BullMQ's own
// retry/backoff can run uninterrupted. This listener is the only place
// that writes a terminal state, and only does so once BullMQ itself has
// decided there will be no further attempts for this job — never on an
// attempt that's about to be retried, so a transient failure can never
// leave the media row somewhere the next attempt's claim CAS can't see.
//
// "Terminal" here is defined to match BullMQ's own retry decision exactly:
//   - the thrown error is an UnrecoverableError (skips remaining retries
//     regardless of `attempts`), OR
//   - job.attemptsMade has reached the queue's configured `attempts`
// Anything else means BullMQ is about to retry this exact job, so this
// listener intentionally does nothing and leaves the row exactly as the
// in-progress attempt last left it.
function isTerminalFailure(job: Job | undefined, err: Error): boolean {
  if (!job) return false; // no job context (e.g. job data expired from Redis) — nothing to safely attribute this to
  if (err instanceof UnrecoverableError) return true;
  const configuredAttempts = job.opts?.attempts ?? 1;
  return job.attemptsMade >= configuredAttempts;
}

const videoWorker = new Worker<ProcessMatchVideoJobData>(
  VIDEO_QUEUE_NAME,
  async (job) => {
    console.log(`[worker] processing video job ${job.id} for match ${job.data.matchId}`);
    await processMatchVideo(job.data);
  },
  { connection, concurrency: 2 } // video jobs are heavy — keep concurrency low
);

videoWorker.on("failed", async (job, err) => {
  if (!job || !isTerminalFailure(job, err)) return; // no job context, or BullMQ will retry — leave media/match state untouched
  const { matchId, mediaId } = job.data;
  try {
    console.error(
      `[worker] video job ${job.id} terminally failed (attempt ${job.attemptsMade}/${
        job.opts?.attempts ?? 1
      }) for match ${matchId}, media ${mediaId}:`,
      err.message
    );
    await supabaseAdmin
      .from("matches")
      .update({ status: "error", error_message: err.message })
      .eq("id", matchId);
    // Only clears a row still sitting in a non-terminal state — never
    // overwrites a row that some other path already finalized (e.g. it
    // already reached 'processed'/'deleted_temp' before this failure was
    // reported, an unlikely but harmless race to guard against anyway).
    await supabaseAdmin
      .from("media")
      .update({ status: "failed" })
      .eq("id", mediaId)
      .in("status", ["uploaded", "optimizing"]);
  } catch (bookkeepingErr) {
    // Never let a failure in this bookkeeping itself become an unhandled
    // rejection that could crash the worker process — best-effort only.
    console.error(`[worker] failed to record terminal failure for video job ${job.id}:`, bookkeepingErr);
  }
});

const screenshotWorker = new Worker<ProcessScreenshotJobData>(
  SCREENSHOT_QUEUE_NAME,
  async (job) => {
    console.log(`[worker] processing screenshot job ${job.id} for match ${job.data.matchId}`);
    await processScreenshot(job.data);
  },
  { connection, concurrency: 5 }
);

screenshotWorker.on("failed", async (job, err) => {
  if (!job || !isTerminalFailure(job, err)) return; // no job context, or BullMQ will retry — leave media/match state untouched
  const { matchId } = job.data;
  try {
    console.error(
      `[worker] screenshot job ${job.id} terminally failed (attempt ${job.attemptsMade}/${
        job.opts?.attempts ?? 1
      }) for match ${matchId}:`,
      err.message
    );
    await supabaseAdmin
      .from("matches")
      .update({ status: "error", error_message: err.message })
      .eq("id", matchId);
    // Screenshot jobs claim a whole batch of media rows at once and have no
    // single mediaId in job.data — same targeting the removed per-attempt
    // catch-block write used (by matchId + still-non-terminal status), just
    // now gated on this job actually being terminal.
    await supabaseAdmin
      .from("media")
      .update({ status: "failed" })
      .eq("match_id", matchId)
      .in("status", ["uploaded", "optimizing"]);
  } catch (bookkeepingErr) {
    console.error(`[worker] failed to record terminal failure for screenshot job ${job.id}:`, bookkeepingErr);
  }
});

// Batch 4 — short trims of an already-compressed video; lighter than a
// full analysis job, so a higher concurrency than the video queue is safe.
const clipWorker = new Worker<GenerateVideoClipJobData>(
  CLIP_QUEUE_NAME,
  async (job) => {
    console.log(`[worker] generating clip job ${job.id} (clip ${job.data.clipId})`);
    await generateVideoClip(job.data);
  },
  { connection, concurrency: 3 }
);

// Batch 5 clip retry-state fix — same centralized-terminal-bookkeeping
// pattern as videoWorker/screenshotWorker above. generateVideoClip.ts now
// only logs + rethrows on failure so BullMQ's retry/backoff can run
// uninterrupted; this listener is the only place that writes
// video_clips.status='failed', and only once isTerminalFailure() confirms
// BullMQ itself has no attempts left for this job. On a retryable attempt
// this intentionally does nothing, leaving the row at 'processing' (set
// at the top of generateVideoClip's try block) exactly where the next
// attempt expects to find it.
clipWorker.on("failed", async (job, err) => {
  if (!job || !isTerminalFailure(job, err)) return; // no job context, or BullMQ will retry — leave video_clips row untouched
  const { clipId } = job.data;
  try {
    console.error(
      `[worker] clip job ${job.id} terminally failed (attempt ${job.attemptsMade}/${
        job.opts?.attempts ?? 1
      }) for clip ${clipId}:`,
      err.message
    );
    // Only clears a row still sitting in a non-terminal state — never
    // overwrites a row some other path already finalized (e.g. it
    // already reached 'completed' before this failure was reported).
    await supabaseAdmin
      .from("video_clips")
      .update({ status: "failed", error_message: err.message })
      .eq("id", clipId)
      .in("status", ["pending", "processing"]);
  } catch (bookkeepingErr) {
    // Never let a failure in this bookkeeping itself become an unhandled
    // rejection that could crash the worker process — best-effort only.
    console.error(`[worker] failed to record terminal failure for clip job ${job.id}:`, bookkeepingErr);
  }
});

startInternalHttpServer();
console.log("[worker] eFootball AI Coach worker started, listening for jobs...");

// Part N — abandoned-upload cleanup. No separate cron infrastructure
// exists in this project, so a periodic interval inside the already
// long-running worker process is the smallest safe mechanism that fits
// the current architecture. Runs once shortly after startup, then hourly.
// A failed sweep logs and waits for the next interval rather than
// crashing the worker — cleanup is best-effort, not load-bearing.
const CLEANUP_INTERVAL_MS = 60 * 60 * 1000;
function runCleanupSweep() {
  sweepAbandonedUploads().catch((err) => console.error("[worker] abandoned-upload sweep failed:", err));
}
setTimeout(runCleanupSweep, 60_000);
setInterval(runCleanupSweep, CLEANUP_INTERVAL_MS);
