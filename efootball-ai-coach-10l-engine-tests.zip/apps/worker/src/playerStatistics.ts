import {
  validatePlayerStatisticsDraft,
  hasAnyStatistic,
  mergeStatRowsForEvidence,
  ALL_STAT_FIELDS,
  type PlayerStatisticsDraft,
  type MatchPlayerStatisticsFields,
  type ProgressPlayerStatsRow,
} from "@efootball/shared";
import { supabaseAdmin } from "./supabaseClient";

/**
 * Batch 3.5 — turns a validated AI draft into real, traceable Supabase rows:
 *   players (find-or-create, spec section 16's "stable identity")
 *   match_player_statistics (spec section 2/3/5)
 *
 * Never inserts a stats row with zero real fields (spec section 6: don't
 * create placeholders) and never persists a draft with no evidence to
 * point to (media_id / source is always set).
 */

export interface PersistPlayerStatisticsResult {
  playerId: string;
  statsRowId: string | null; // null when there was nothing worth persisting
  validationErrors: string[];
}

/**
 * Find-or-create a player row for this user.
 *  - Named player: matched case-insensitively per user (players_user_name_uniq).
 *  - Unnamed self player: collapses to the one canonical per-user "self,
 *    name unknown" row (players_user_self_unnamed_uniq) instead of creating
 *    a new identity every match.
 *  - If a self player was previously unnamed and a name now appears, the
 *    name is attached to that same row rather than splitting the identity.
 */
export async function resolvePlayerId(userId: string, draft: PlayerStatisticsDraft): Promise<string> {
  const name = draft.playerName?.trim() || null;

  if (name) {
    const { data: existingByName } = await supabaseAdmin
      .from("players")
      .select("id, is_self")
      .eq("user_id", userId)
      .ilike("name", name)
      .maybeSingle();

    if (existingByName) {
      // If this identity was previously flagged self and this extraction
      // agrees, keep it; don't downgrade an established self-identity based
      // on a single draft's isSelf flag disagreeing.
      return existingByName.id;
    }

    // No named match. If this is a self-player and there's an existing
    // unnamed self row for this user, attach the newly-discovered name to
    // it instead of creating a second identity for the same human player.
    if (draft.isSelf) {
      const { data: unnamedSelf } = await supabaseAdmin
        .from("players")
        .select("id")
        .eq("user_id", userId)
        .eq("is_self", true)
        .is("name", null)
        .maybeSingle();

      if (unnamedSelf) {
        await supabaseAdmin.from("players").update({ name }).eq("id", unnamedSelf.id);
        return unnamedSelf.id;
      }
    }

    const { data: created, error } = await supabaseAdmin
      .from("players")
      .insert({ user_id: userId, name, is_self: draft.isSelf })
      .select("id")
      .single();
    if (error || !created) throw error ?? new Error("Failed to create player");
    return created.id;
  }

  // No name at all. Only the self player can be reliably deduplicated
  // without a name (players_user_self_unnamed_uniq); an unnamed non-self
  // player is a genuinely new, unidentifiable row each time.
  if (draft.isSelf) {
    const { data: existingSelf } = await supabaseAdmin
      .from("players")
      .select("id")
      .eq("user_id", userId)
      .eq("is_self", true)
      .is("name", null)
      .maybeSingle();
    if (existingSelf) return existingSelf.id;
  }

  const { data: created, error } = await supabaseAdmin
    .from("players")
    .insert({ user_id: userId, name: null, is_self: draft.isSelf })
    .select("id")
    .single();
  if (error || !created) throw error ?? new Error("Failed to create player");
  return created.id;
}

/**
 * Validates + persists one player's statistics draft for a match. Upserts
 * on (match_id, player_id, source) so a retried job refreshes the same
 * evidence row instead of duplicating it.
 *
 * Media traceability fix (Batch 3.5 remaining-work item 3): a single
 * upload can contain multiple distinct screenshots, and a stats extraction
 * pass can be run per-screenshot (see processScreenshot.ts). If the same
 * player already has a stats row for this (match_id, source) — e.g. one
 * screenshot showed their passing numbers and a second, different
 * screenshot showed their defending numbers — this MERGES the new
 * non-null fields onto the existing row instead of blindly overwriting it
 * (which would null out fields the first screenshot legitimately provided).
 * media_id is only kept as a single exact value when every field that has
 * ever contributed to this row came from the same media item; the moment a
 * second, different media item contributes real data, media_id is set to
 * NULL (per spec section 5: "if exact media attribution is impossible, do
 * NOT pretend it is exact") and extraction_metadata.contributing_media_ids
 * records the actual set for traceability instead.
 */
export async function persistPlayerStatistics(params: {
  userId: string;
  matchId: string;
  mediaId: string | null;
  source: "screenshot" | "structured_data" | "ai_confirmed" | "unavailable";
  draft: PlayerStatisticsDraft;
}): Promise<PersistPlayerStatisticsResult> {
  const { userId, matchId, mediaId, source, draft } = params;

  const playerId = await resolvePlayerId(userId, draft);

  const { sanitized, errors } = validatePlayerStatisticsDraft(draft as unknown as Record<string, unknown>);

  if (!hasAnyStatistic(sanitized)) {
    // Nothing real survived validation — don't write a placeholder row.
    return { playerId, statsRowId: null, validationErrors: errors };
  }

  // Look for an existing row for this exact (match, player, source) to
  // merge onto rather than overwrite. A plain upsert with a full-column
  // payload would null out any field the existing row had that this
  // particular draft didn't mention.
  const { data: existing } = await supabaseAdmin
    .from("match_player_statistics")
    .select("*")
    .eq("match_id", matchId)
    .eq("player_id", playerId)
    .eq("source", source)
    .maybeSingle();

  const row: Record<string, unknown> = {
    user_id: userId,
    match_id: matchId,
    player_id: playerId,
    source,
  };

  const mergedErrors = existing ? [...(existing.validation_errors ?? []), ...errors] : errors;

  let mediaIdToStore: string | null;
  let contributingMediaIds: string[];
  if (!existing) {
    mediaIdToStore = mediaId;
    contributingMediaIds = mediaId ? [mediaId] : [];
  } else {
    const priorContributing: string[] =
      (existing.extraction_metadata as Record<string, unknown> | null)?.contributing_media_ids as string[] | undefined
        ?? (existing.media_id ? [existing.media_id as string] : []);
    contributingMediaIds = mediaId && !priorContributing.includes(mediaId) ? [...priorContributing, mediaId] : priorContributing;
    // Only a single, exact media source can be claimed as media_id. As
    // soon as more than one distinct media item has contributed real
    // fields to this row, the exact source is genuinely ambiguous.
    mediaIdToStore = contributingMediaIds.length <= 1 ? (contributingMediaIds[0] ?? null) : null;
  }

  row.media_id = mediaIdToStore;
  row.confidence = Number.isFinite(draft.confidence)
    ? existing?.confidence != null
      ? Math.min(Number(existing.confidence), Number(draft.confidence))
      : draft.confidence
    : existing?.confidence ?? null;
  row.extraction_metadata = {
    ...(existing?.extraction_metadata as Record<string, unknown> | null),
    ...(draft.notes ? { notes: draft.notes } : {}),
    contributing_media_ids: contributingMediaIds,
  };
  row.is_valid = mergedErrors.length === 0;
  row.validation_errors = mergedErrors;

  for (const field of ALL_STAT_FIELDS) {
    const newValue = sanitized[field as keyof typeof sanitized] ?? null;
    const existingValue = existing ? (existing[field] as number | null | undefined) ?? null : null;
    // New real value wins (it's presumably the freshest read of this
    // field); otherwise keep whatever the row already had.
    row[field] = newValue ?? existingValue;
  }

  const { data: statsRow, error } = await supabaseAdmin
    .from("match_player_statistics")
    .upsert(row, { onConflict: "match_id,player_id,source" })
    .select("id")
    .single();
  if (error || !statsRow) throw error ?? new Error("Failed to persist match_player_statistics");

  return { playerId, statsRowId: statsRow.id, validationErrors: errors };
}

/**
 * Batch 3.5 remaining-work item 1 — fetches the authenticated user's own
 * ("self") player's REAL, validated match_player_statistics across a set
 * of real matches, merged per match across sources (screenshot /
 * structured_data / ai_confirmed — same merge rule as
 * linkStatisticsEvidenceForMatch in eventLinking.ts, via the shared
 * mergeStatRowsForEvidence helper: highest-confidence non-null value per
 * field wins, never inventing a value neither source provided).
 *
 * Only is_valid=true rows are considered. Returns an empty map (never
 * throws) when the user has no self-player row yet or no matchIds are
 * given — callers degrade to event-derived-only scoring in that case, per
 * packages/shared/src/progress.ts's AggregatePlayerProgressInput contract.
 */
export async function fetchSelfPlayerStatsByMatch(
  userId: string,
  matchIds: string[]
): Promise<Map<string, ProgressPlayerStatsRow>> {
  const result = new Map<string, ProgressPlayerStatsRow>();
  if (matchIds.length === 0) return result;

  const { data: selfPlayer, error: selfPlayerError } = await supabaseAdmin
    .from("players")
    .select("id")
    .eq("user_id", userId)
    .eq("is_self", true)
    .maybeSingle();
  if (selfPlayerError) throw selfPlayerError;
  if (!selfPlayer) return result;

  const { data: statRows, error: statsError } = await supabaseAdmin
    .from("match_player_statistics")
    .select(["match_id", "confidence", ...ALL_STAT_FIELDS].join(","))
    .eq("user_id", userId)
    .eq("player_id", selfPlayer.id)
    .eq("is_valid", true)
    .in("match_id", matchIds);
  if (statsError) throw statsError;

  const rowsByMatch = new Map<string, (MatchPlayerStatisticsFields & { confidence: number | null })[]>();
  for (const row of (statRows ?? []) as any[]) {
    const list = rowsByMatch.get(row.match_id) ?? [];
    list.push(row);
    rowsByMatch.set(row.match_id, list);
  }

  for (const [matchId, rows] of rowsByMatch) {
    const merged = mergeStatRowsForEvidence(rows);
    result.set(matchId, { match_id: matchId, ...merged } as ProgressPlayerStatsRow);
  }

  return result;
}
