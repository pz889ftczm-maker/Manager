import http from "node:http";
import crypto from "node:crypto";
import { videoQueue, screenshotQueue, clipQueue } from "./index";
import { sweepAbandonedUploads } from "./cleanup";

/**
 * Small internal HTTP surface so the web app's Edge Functions
 * (supabase/functions/analysis-enqueue, clip-request) can hand off work
 * without holding Redis credentials themselves. Protected by a shared
 * secret header — this port should NOT be publicly exposed; in
 * docker-compose it's only reachable from other containers on the same
 * network, and in production it should sit behind an internal network /
 * VPC, not the public internet.
 */
const INTERNAL_SECRET = process.env.WORKER_INTERNAL_SECRET ?? "";
const PORT = Number(process.env.WORKER_HTTP_PORT ?? 8787);

function readBody(req: http.IncomingMessage): Promise<string> {
  return new Promise((resolve, reject) => {
    let body = "";
    req.on("data", (chunk) => (body += chunk));
    req.on("end", () => resolve(body));
    req.on("error", reject);
  });
}

/** Constant-time shared-secret comparison (Part E/T hardening). A plain
 * `!==` short-circuits on the first differing byte, which — while a very
 * low-value target compared to the DB-level checks elsewhere in this
 * batch — is still a needless timing side-channel on an auth check that
 * costs nothing to close. Hashing both sides to a fixed-length digest
 * first avoids leaking the secret's length as well as its bytes. */
function safeEqual(a: string, b: string): boolean {
  const ah = crypto.createHash("sha256").update(a).digest();
  const bh = crypto.createHash("sha256").update(b).digest();
  return crypto.timingSafeEqual(ah, bh);
}

function isNonEmptyString(v: unknown): v is string {
  return typeof v === "string" && v.length > 0;
}

function isStringArray(v: unknown): v is string[] {
  return Array.isArray(v) && v.length > 0 && v.every((x) => typeof x === "string" && x.length > 0);
}

/** Minimal shape validation at the HTTP boundary (Part K: "do not trust
 * queue payload blindly"). This is intentionally shallow — it only
 * rejects obviously malformed requests fast, with a clear 400. The real
 * ownership/ffmpeg-safety checks (does this row actually belong to this
 * user, is the file actually a video, is the clip window in range) live
 * inside each job function itself (processMatchVideo.ts,
 * processScreenshot.ts, generateVideoClip.ts), since those need a DB
 * round-trip this HTTP layer shouldn't block the response on. */
function validateJobBody(route: "/jobs/video" | "/jobs/screenshot" | "/jobs/clip", body: unknown): string | null {
  if (typeof body !== "object" || body === null) return "request body must be a JSON object";
  const b = body as Record<string, unknown>;

  if (route === "/jobs/video") {
    if (!isNonEmptyString(b.matchId)) return "matchId is required";
    if (!isNonEmptyString(b.userId)) return "userId is required";
    if (!isNonEmptyString(b.mediaId)) return "mediaId is required";
    if (!isNonEmptyString(b.rawStorageObjectPath)) return "rawStorageObjectPath is required";
  } else if (route === "/jobs/screenshot") {
    if (!isNonEmptyString(b.matchId)) return "matchId is required";
    if (!isNonEmptyString(b.userId)) return "userId is required";
    if (!isStringArray(b.storageObjectPaths)) return "storageObjectPaths must be a non-empty array of strings";
  } else {
    if (!isNonEmptyString(b.clipId)) return "clipId is required";
    if (!isNonEmptyString(b.userId)) return "userId is required";
    if (!isNonEmptyString(b.matchId)) return "matchId is required";
    if (!isNonEmptyString(b.eventId)) return "eventId is required";
    if (!isNonEmptyString(b.videoObjectPath)) return "videoObjectPath is required";
    if (typeof b.startSeconds !== "number" || typeof b.endSeconds !== "number") {
      return "startSeconds/endSeconds must be numbers";
    }
  }
  return null;
}

export function startInternalHttpServer() {
  if (!INTERNAL_SECRET) {
    console.warn(
      "[worker] WORKER_INTERNAL_SECRET is not set — internal job-submission HTTP server will reject all requests."
    );
  }

  const server = http.createServer(async (req, res) => {
    const provided = req.headers["x-internal-secret"];
    if (typeof provided !== "string" || !INTERNAL_SECRET || !safeEqual(provided, INTERNAL_SECRET)) {
      res.writeHead(401).end("unauthorized");
      return;
    }

    try {
      if (req.method === "POST" && req.url === "/jobs/video") {
        const body = JSON.parse(await readBody(req));
        const validationError = validateJobBody("/jobs/video", body);
        if (validationError) {
          res.writeHead(400, { "Content-Type": "application/json" }).end(JSON.stringify({ error: validationError }));
          return;
        }
        await videoQueue.add("process-video", body);
        res.writeHead(202, { "Content-Type": "application/json" }).end(JSON.stringify({ queued: true }));
        return;
      }

      if (req.method === "POST" && req.url === "/jobs/screenshot") {
        const body = JSON.parse(await readBody(req));
        const validationError = validateJobBody("/jobs/screenshot", body);
        if (validationError) {
          res.writeHead(400, { "Content-Type": "application/json" }).end(JSON.stringify({ error: validationError }));
          return;
        }
        await screenshotQueue.add("process-screenshot", body);
        res.writeHead(202, { "Content-Type": "application/json" }).end(JSON.stringify({ queued: true }));
        return;
      }

      // Batch 4 — enqueued only by supabase/functions/clip-request, which
      // has already verified ownership and clamped start/end (Part 13).
      if (req.method === "POST" && req.url === "/jobs/clip") {
        const body = JSON.parse(await readBody(req));
        const validationError = validateJobBody("/jobs/clip", body);
        if (validationError) {
          res.writeHead(400, { "Content-Type": "application/json" }).end(JSON.stringify({ error: validationError }));
          return;
        }
        await clipQueue.add("generate-video-clip", body);
        res.writeHead(202, { "Content-Type": "application/json" }).end(JSON.stringify({ queued: true }));
        return;
      }

      // Batch 5 (Part N) — lets an operator trigger the abandoned-upload
      // sweep on demand (e.g. from a deploy hook) rather than waiting for
      // the hourly interval in index.ts. Same internal-secret guard as
      // every other route on this server; still idempotent/safe to call
      // as often as desired.
      if (req.method === "POST" && req.url === "/internal/cleanup") {
        const result = await sweepAbandonedUploads();
        res.writeHead(200, { "Content-Type": "application/json" }).end(JSON.stringify(result));
        return;
      }

      res.writeHead(404).end("not found");
    } catch (err) {
      // Part P — never forward internal error detail (stack traces,
      // absolute paths) through this internal API; full detail still goes
      // to the worker's own logs.
      console.error(`[worker] internal HTTP error on ${req.method} ${req.url}:`, err);
      res.writeHead(500, { "Content-Type": "application/json" }).end(JSON.stringify({ error: "internal error" }));
    }
  });

  server.listen(PORT, () => console.log(`[worker] internal job API listening on :${PORT}`));
}
