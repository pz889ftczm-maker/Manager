// Batch 10C — Real Football 7v7 Context: the server-side accessor that
// lets the analysis pipeline OBTAIN a RealFootballMatchContext for a
// match (spec section 8), backed by real Supabase reads. All of the
// actual assembly/gating/never-fabricate logic lives in
// packages/shared/src/realFootballMatchContext.ts's
// buildRealFootballMatchContext — this file's only job is (a) reading
// exactly the rows that function needs, (b) enforcing ownership before
// any of them are used, and (c) never reading more than the current
// match's own football_type actually requires.
//
// SAME PORT PATTERN AS apps/worker/src/efootballContext.ts (spec
// section 9 — server-side only, no client-supplied Team/Formation/
// Player ever trusted as historical truth): a narrow, dependency-
// injectable interface (RealFootballContextPort) with a real Supabase-
// service-role-backed implementation, and a public function
// (getRealFootballMatchContext) that a job/edge function calls with a
// matchId + the ALREADY-TRUSTED userId it resolved for itself —
// mirrored exactly, not reinvented.
//
// OWNERSHIP (spec section 9 — "Server-side only. Verify: authenticated
// user, match ownership, Team ownership, Formation ownership, player
// ownership where player records are read"): getRealFootballMatchContext
// reads the match row's own user_id and compares it against the
// caller-supplied userId BEFORE doing anything else with that row —
// including before even checking football_type. A mismatch throws
// (never silently returns an "unavailable" result that could be
// confused with "this match legitimately has no Real Football
// context").
//
// GATING SHORT-CIRCUIT (performance only, not a second copy of the
// gating rule — see efootballContext.ts's own header comment for the
// identical reasoning): the match row alone (already fetched for the
// ownership check) is enough to decide football_type via
// footballMatchContext.ts#readFootballMatchContext. When that's not
// "real_football" (efootball, or legacy NULL), this file returns
// immediately WITHOUT ever querying match_snapshots or any Team/
// Formation/Player table.
//
// LIVE-DATA OWNERSHIP (spec section 9): getLiveData's real, service-
// role-backed implementation (createSupabaseRealFootballContextPort
// below) reads team_library/team_formations/team_formation_players+
// player_library directly with a client that bypasses RLS entirely.
// assertRealFootballLiveOwnership re-verifies, itself, that the team/
// formation/every assigned player it just read actually belongs to the
// caller's own userId — same reasoning and same checks (minus manager,
// which Real Football context has no concept of at all — see
// realFootballMatchContext.ts's own header comment) as
// efootballContext.ts's own assertEfootballLiveOwnership. A mismatch
// throws RealFootballContextIntegrityError — never a fabricated/
// partial substitute and never another user's row.
//
// HISTORICAL-FIRST (spec section 2): match_snapshots is always read
// before any live Team/Formation/Player table, and — per
// buildRealFootballMatchContext's own contract — is used EXCLUSIVELY
// when found. getLiveData is only ever invoked when getSnapshot
// returned null.
//
// NO AI CALL, NO PIPELINE BEHAVIOR CHANGE (spec section 8 — "make only
// the smallest integration necessary"): this file makes no AI call and
// is not invoked from anywhere yet — it is exported and tested, ready
// for a later phase to call from the analysis pipeline, exactly like
// efootballContext.ts's own getEfootballMatchContext (Batch 10B) is
// still not invoked from anywhere in this codebase either. Adding a
// call site now, before anything actually consumes the result, would
// be an unrelated pipeline change outside this batch's scope.

import {
  readFootballMatchContext,
  buildRealFootballMatchContext,
  selectMatchSnapshotForMatch,
  type RealFootballMatchContextResult,
  type RealFootballContextLiveSource,
} from "@efootball/shared";
import type { MatchSnapshot, MatchSnapshotPlayer } from "@efootball/shared";

/** Narrow, dependency-injectable view of exactly the reads
 * getRealFootballMatchContext needs — same reasoning as
 * efootballContext.ts's own EfootballContextPort: tests supply a plain
 * in-memory fake so this file's own ownership/gating/historical-first
 * decision logic can be exercised without a real Supabase/Postgres
 * instance. */
export interface RealFootballContextPort {
  /** Reads the authoritative current state of a match row needed to
   * decide ownership, football_type, and which Formation to read live
   * data from if no snapshot exists. Returns null if the match no
   * longer exists. */
  getMatch(matchId: string): Promise<{
    user_id: string;
    football_type: string | null;
    team_size: number | null;
    team_id: string | null;
    formation_id: string | null;
  } | null>;
  /** Reads the most recent existing match_snapshots row for this match
   * (Batch 9A/9D — via selectMatchSnapshotForMatch, never re-derived
   * here) plus its match_snapshot_players rows. Returns null when this
   * match has no snapshot at all — a normal, expected state. */
  getSnapshot(
    matchId: string
  ): Promise<{ snapshot: MatchSnapshot; players: MatchSnapshotPlayer[] } | null>;
  /** Reads the CURRENT Formation/roster for a team, used only when
   * getSnapshot returned null (see file header comment).
   * `formationId` is null when the match has a team but no formation
   * selected — implementations must not fabricate one. `userId` is the
   * same already-trusted value getRealFootballMatchContext itself was
   * called with (never re-derived here) — a real implementation MUST
   * verify every row it reads actually belongs to this user before
   * returning it, since a service-role client bypasses RLS entirely
   * (see assertRealFootballLiveOwnership below), and must throw rather
   * than silently return another user's data or a fabricated
   * substitute. */
  getLiveData(args: { teamId: string; formationId: string | null; userId: string }): Promise<RealFootballContextLiveSource>;
}

/** Thrown by assertRealFootballLiveOwnership (used only by
 * createSupabaseRealFootballContextPort's own getLiveData below) when
 * a row the service-role client just read does NOT actually belong to
 * the requesting user — e.g. matches.team_id pointing at another
 * user's team_library row, matches.formation_id pointing at a
 * formation belonging to a different team, or a
 * team_formation_players assignment whose player_library row belongs
 * to someone else.
 *
 * This should never happen in ordinary operation (see
 * efootballContext.ts's own EfootballContextIntegrityError comment for
 * why) but is re-verified here anyway as defense-in-depth, mirroring
 * the same checks (minus manager) that file already performs.
 *
 * A distinct exported class (same convention as
 * RealFootballContextOwnershipError below) rather than a generic
 * Error, so a caller/test can recognize this specific failure without
 * string-matching a message. The message itself carries only a reason
 * code — never the mismatched row's own id or actual owner. */
export type RealFootballContextIntegrityReason =
  | "team_ownership_invalid"
  | "formation_ownership_invalid"
  | "player_ownership_invalid";

export class RealFootballContextIntegrityError extends Error {
  readonly reason: RealFootballContextIntegrityReason;
  constructor(reason: RealFootballContextIntegrityReason) {
    super(`real_football_context: live data failed an ownership/integrity check (${reason})`);
    this.name = "RealFootballContextIntegrityError";
    this.reason = reason;
  }
}

/**
 * The actual defense-in-depth check (see
 * RealFootballContextIntegrityError above for why it exists). Given
 * exactly the rows createSupabaseRealFootballContextPort's own
 * getLiveData just read — never a matchId/query of its own — this is
 * pure and dependency-free (same convention as
 * packages/shared/src/realFootballMatchContext.ts's own
 * buildRealFootballMatchContext), so it's directly testable with plain
 * fabricated rows, no Supabase/Postgres instance required.
 *
 * Throws RealFootballContextIntegrityError unless every one of the
 * following holds (spec section 9):
 *
 *   1. `team` (the team_library row for teamId) exists, and its own
 *      user_id equals `userId`.
 *   2. When `formationId` is not null, `formation` (the
 *      team_formations row for formationId) exists, and its own
 *      team_id equals `teamId` — never merely "some formation exists
 *      with this id", since a formation that exists but belongs to a
 *      DIFFERENT team is exactly the gap this check closes.
 *   3. When `formationId` is not null, every entry in `players` (one
 *      per team_formation_players row the caller already scoped to
 *      formationId with its own query) carries a `player_library` row
 *      whose user_id equals `userId`. A missing join (no such
 *      player_library row at all) is treated exactly like a mismatched
 *      one — rejecting the whole read, never silently narrowing to a
 *      partial player list.
 *
 * No manager check here — Real Football context has no manager concept
 * at all (see realFootballMatchContext.ts's own header comment), so
 * getLiveData below never reads manager_library in the first place.
 *
 * Never mutates or reads anything itself, and never returns a value —
 * the caller remains solely responsible for fetching these rows and
 * for propagating this throw rather than swallowing it.
 */
export function assertRealFootballLiveOwnership(args: {
  userId: string;
  teamId: string;
  formationId: string | null;
  team: { user_id: string } | null;
  formation: { team_id: string } | null;
  players: ReadonlyArray<{ player_library: { user_id: string } | null }>;
}): void {
  const { userId, teamId, formationId, team, formation, players } = args;

  if (!team || team.user_id !== userId) {
    throw new RealFootballContextIntegrityError("team_ownership_invalid");
  }

  if (formationId !== null && (!formation || formation.team_id !== teamId)) {
    throw new RealFootballContextIntegrityError("formation_ownership_invalid");
  }

  if (formationId !== null) {
    for (const { player_library } of players) {
      if (!player_library || player_library.user_id !== userId) {
        throw new RealFootballContextIntegrityError("player_ownership_invalid");
      }
    }
  }
}

/** Real, production implementation of RealFootballContextPort, backed
 * by the worker's own service-role client — same lazy dynamic-import
 * pattern as efootballContext.ts's own
 * createSupabaseEfootballContextPort (so importing this file never
 * requires SUPABASE_URL/SUPABASE_SERVICE_ROLE_KEY to be set unless this
 * real port is actually constructed). */
async function createSupabaseRealFootballContextPort(): Promise<RealFootballContextPort> {
  const { supabaseAdmin } = await import("./supabaseClient");
  return {
    async getMatch(matchId) {
      const { data, error } = await supabaseAdmin
        .from("matches")
        .select("user_id, football_type, team_size, team_id, formation_id")
        .eq("id", matchId)
        .maybeSingle();
      if (error) throw error;
      if (!data) return null;
      return {
        user_id: data.user_id as string,
        football_type: (data.football_type as string | null) ?? null,
        team_size: (data.team_size as number | null) ?? null,
        team_id: (data.team_id as string | null) ?? null,
        formation_id: (data.formation_id as string | null) ?? null,
      };
    },
    async getSnapshot(matchId) {
      const { data: snapshotRows, error: snapshotError } = await supabaseAdmin
        .from("match_snapshots")
        .select("*")
        .eq("match_id", matchId);
      if (snapshotError) throw snapshotError;

      const snapshot = selectMatchSnapshotForMatch((snapshotRows as MatchSnapshot[]) ?? [], matchId);
      if (!snapshot) return null;

      const { data: playerRows, error: playersError } = await supabaseAdmin
        .from("match_snapshot_players")
        .select("*")
        .eq("snapshot_id", snapshot.id);
      if (playersError) throw playersError;

      return { snapshot, players: (playerRows as MatchSnapshotPlayer[]) ?? [] };
    },
    async getLiveData({ teamId, formationId, userId }) {
      const { data: teamRow, error: teamError } = await supabaseAdmin
        .from("team_library")
        .select("user_id")
        .eq("id", teamId)
        .maybeSingle();
      if (teamError) throw teamError;

      const team = teamRow ? { user_id: teamRow.user_id as string } : null;

      const formationPromise = formationId
        ? supabaseAdmin.from("team_formations").select("*").eq("id", formationId).maybeSingle()
        : Promise.resolve({ data: null, error: null });

      const playersPromise = formationId
        ? supabaseAdmin
            .from("team_formation_players")
            .select("position_slot, player_library(*)")
            .eq("formation_id", formationId)
        : Promise.resolve({ data: [], error: null });

      const [{ data: formationRow, error: formationError }, { data: playerRows, error: playersError }] =
        await Promise.all([formationPromise, playersPromise]);
      if (formationError) throw formationError;
      if (playersError) throw playersError;

      const players = (playerRows as { position_slot: string; player_library: unknown }[]) ?? [];

      // Defense-in-depth ownership/integrity check (see
      // assertRealFootballLiveOwnership above): this port uses the
      // service-role client, which bypasses RLS entirely, so every row
      // just read is verified against `userId`/`teamId` here — once,
      // before any of it is returned — rather than trusted as-is.
      assertRealFootballLiveOwnership({
        userId,
        teamId,
        formationId,
        team,
        formation: (formationRow as { team_id: string } | null) ?? null,
        players: players.map((row) => ({ player_library: row.player_library as { user_id: string } | null })),
      });

      return {
        formation: (formationRow as RealFootballContextLiveSource["formation"]) ?? null,
        players: players
          .filter((row) => row.player_library)
          .map((row) => ({
            position_slot: row.position_slot,
            player: row.player_library as RealFootballContextLiveSource["players"][number]["player"],
          })),
      };
    },
  };
}

/** Thrown when the match's own user_id does not match the caller-
 * supplied userId (spec section 9 — ownership must be verified before
 * any data is returned). Deliberately a distinct exported class rather
 * than a generic Error so a caller/test can recognize this specific
 * failure without string-matching a message. */
export class RealFootballContextOwnershipError extends Error {
  constructor(matchId: string) {
    super(`real_football_context: match ${matchId} does not belong to the requesting user`);
    this.name = "RealFootballContextOwnershipError";
  }
}

/**
 * Reads and assembles the RealFootballMatchContext for `matchId`, for
 * the pipeline (or a later Football Analysis Engine phase) to consume
 * (spec section 8). `userId` must already be a trusted, server-
 * resolved value — this function re-checks it against the match row's
 * own user_id but never resolves it itself from a request/session.
 *
 * Returns `{ available: false, reason: "unknown_football_type" }` when
 * the match itself no longer exists — same "absent context, not an
 * error" treatment football_type=NULL already gets, since there is
 * nothing to distinguish a deleted match from one that never had
 * football_type set.
 */
export async function getRealFootballMatchContext(
  matchId: string,
  userId: string,
  port?: RealFootballContextPort
): Promise<RealFootballMatchContextResult> {
  const p = port ?? (await createSupabaseRealFootballContextPort());

  const match = await p.getMatch(matchId);
  if (!match) {
    return { available: false, reason: "unknown_football_type" };
  }

  // Ownership FIRST (spec section 9) — before football_type is even
  // inspected, let alone any snapshot/live table is read.
  if (match.user_id !== userId) {
    throw new RealFootballContextOwnershipError(matchId);
  }

  const footballContext = readFootballMatchContext({
    football_type: match.football_type,
    team_size: match.team_size,
  });

  // Gating short-circuit: an efootball or legacy NULL match can never
  // have Real Football context, so don't spend a single extra query
  // finding that out — buildRealFootballMatchContext (given no
  // sources) returns exactly the same result this early return would,
  // so this is a pure performance short-circuit, not a second copy of
  // the gating rule.
  if (footballContext?.football_type !== "real_football") {
    return buildRealFootballMatchContext(footballContext, { snapshot: null, live: null });
  }

  const snapshot = await p.getSnapshot(matchId);
  if (snapshot) {
    return buildRealFootballMatchContext(footballContext, { snapshot, live: null });
  }

  // No snapshot yet — fall back to the CURRENT Formation/Player
  // Library data, but only if this match even has a team attached
  // (matches.team_id); otherwise there is nothing live to read either
  // (never fabricate a Team/Formation just because football_type is
  // "real_football").
  const live = match.team_id
    ? await p.getLiveData({ teamId: match.team_id, formationId: match.formation_id, userId })
    : null;
  return buildRealFootballMatchContext(footballContext, { snapshot: null, live });
}
