// Batch 5 (Part N) — abandoned-upload cleanup.
//
// A raw upload can be left behind in two independent ways:
//   1. Analyze.tsx finishes uploading the file, but the browser closes/
//      crashes before analysis-enqueue is ever called (or analysis-enqueue
//      itself fails before claiming the match) — the media row stays at
//      status='uploaded' and the raw object sits in the raw-uploads bucket
//      forever.
//   2. The match itself never gets past 'uploading'/'queued' for some
//      other reason (e.g. the worker crashed between the Edge Function's
//      atomic claim and this process actually picking the job up).
//
// This sweep looks for exactly those two shapes, using a generous TTL
// (ABANDONED_UPLOAD_TTL_HOURS) so a slow-but-legitimate upload/analysis
// in progress is never mistaken for abandoned. It is safely re-runnable —
// rows already cleaned up simply won't match the query on the next pass —
// and is scheduled on a periodic interval from index.ts (no separate cron
// infrastructure exists in this project yet, so this is the smallest safe
// mechanism that fits the current architecture, per the Batch 5 brief).
import { supabaseAdmin } from "./supabaseClient";

const RAW_BUCKET = process.env.STORAGE_BUCKET_RAW_UPLOADS ?? "raw-uploads";
const TTL_HOURS = Number(process.env.ABANDONED_UPLOAD_TTL_HOURS ?? "48");
const SWEEP_BATCH_LIMIT = 200; // bounded per run; the next interval picks up any remainder

// A media row is only "abandoned" if the match it belongs to is ALSO
// stuck — otherwise this would incorrectly sweep up, for example, a
// screenshot whose match is still actively 'analyzing' (media.status for
// screenshots doesn't flip to 'processed' until the whole match finishes
// — see processScreenshot.ts) or one that already completed successfully
// under a status naming this list doesn't recognize.
const STUCK_MATCH_STATUSES = new Set(["uploading", "queued", "error"]);

export interface CleanupResult {
  abandonedMediaRemoved: number;
  abandonedMatchesMarkedFailed: number;
}

interface StaleMediaRow {
  id: string;
  storage_reference: string | null;
  matches: { status: string } | { status: string }[] | null;
}

function matchStatusOf(row: StaleMediaRow): string | null {
  if (!row.matches) return null;
  return Array.isArray(row.matches) ? row.matches[0]?.status ?? null : row.matches.status;
}

/** Deletes the Storage object for an already-claimed ('cleanup_claimed')
 * row and finalizes it to 'failed'. Split out so both the normal
 * claim-then-delete path and the crash-recovery path (a row left at
 * 'cleanup_claimed' by a cleanup run that died between claiming and
 * finishing) go through the exact same delete+finalize logic. Idempotent:
 * safe to call again for a row that was already partially finalized by a
 * previous crashed attempt (a missing-object error from Storage is
 * expected and fine in that case). */
async function deleteAndFinalizeClaimed(mediaId: string, storageReference: string | null): Promise<void> {
  if (storageReference) {
    const { error: removeErr } = await supabaseAdmin.storage.from(RAW_BUCKET).remove([storageReference]);
    // Missing-object errors are fine here (already gone — e.g. a prior
    // crashed run got this far already). Any other error means the row is
    // claimed but the object may still exist; that's an orphaned-but-safe
    // Storage object (unreachable by any worker, since the row is no
    // longer 'uploaded'), which is a smaller problem than a wrongly
    // deleted file. Finalize the row regardless so it stops being
    // rediscovered as a recovery candidate forever.
    if (removeErr) console.warn(`[cleanup] could not remove storage object for media ${mediaId}:`, removeErr.message);
  }
  // Guarded so two concurrent cleanup runs recovering the same crashed
  // claim don't both log success — only one UPDATE actually affects a
  // row, but both are safe to attempt the (idempotent) Storage remove above.
  const { error: finalizeErr } = await supabaseAdmin
    .from("media")
    .update({ status: "failed" })
    .eq("id", mediaId)
    .eq("status", "cleanup_claimed");
  if (finalizeErr) throw finalizeErr;
}

/** Finds media rows still sitting at status='uploaded' older than the TTL
 * whose PARENT MATCH is also stuck (see STUCK_MATCH_STATUSES above),
 * claims them, deletes the underlying raw-uploads object, and finalizes
 * the row to 'failed' so it stops showing up in this sweep and doesn't
 * linger silently. Also recovers any row left at 'cleanup_claimed' by a
 * previous cleanup run that crashed between claiming and finishing. */
async function sweepAbandonedMedia(cutoffIso: string): Promise<number> {
  const { data: staleMedia, error } = await supabaseAdmin
    .from("media")
    .select("id, storage_reference, matches(status)")
    .eq("status", "uploaded")
    .lt("created_at", cutoffIso)
    .limit(SWEEP_BATCH_LIMIT);

  if (error) {
    console.error("[cleanup] failed to query abandoned media:", error.message);
    return 0;
  }

  const candidates = ((staleMedia as unknown as StaleMediaRow[] | null) ?? []).filter((row) => {
    const status = matchStatusOf(row);
    return status === null || STUCK_MATCH_STATUSES.has(status);
  });

  let removed = 0;

  for (const row of candidates) {
    try {
      // Atomic claim BEFORE touching Storage. This is the real ownership
      // handshake with processMatchVideo.ts / processScreenshot.ts: both
      // of those atomically claim FROM 'uploaded' too (into 'optimizing')
      // before their own first Storage access. Postgres serializes
      // concurrent UPDATEs on the same row, so whichever of {this claim,
      // a worker's claim} commits first wins, and the loser's WHERE
      // clause simply no longer matches — it affects zero rows and must
      // not touch Storage. Moving into a DISTINCT 'cleanup_claimed' state
      // (rather than straight to 'failed') means a crash after this claim
      // but before the delete below leaves an unambiguous, recoverable
      // trail — see the recovery pass further down — instead of a media
      // row silently marked 'failed' while its object still exists.
      const { data: claimed, error: claimErr } = await supabaseAdmin
        .from("media")
        .update({ status: "cleanup_claimed" })
        .eq("id", row.id)
        .eq("status", "uploaded")
        .select("id");
      if (claimErr) throw claimErr;
      if (!claimed || claimed.length === 0) {
        // Lost the race — a worker (or another cleanup run) already
        // claimed this row. Do NOT delete the Storage object.
        continue;
      }

      await deleteAndFinalizeClaimed(row.id, row.storage_reference);
      removed += 1;
    } catch (err) {
      console.error(`[cleanup] failed to clean up abandoned media ${row.id}:`, (err as Error).message);
    }
  }

  // Recovery pass: rows already claimed (by this process or a previous
  // one that crashed before finishing) get their delete+finalize retried.
  // These rows were only ever claimed after already being older than the
  // TTL cutoff, so filtering on the same cutoff here is correct and needs
  // no separate "claimed_at" column. Safe to run every sweep — once a row
  // is finalized it no longer matches status='cleanup_claimed' and drops
  // out of this query on the next pass.
  const { data: staleClaims, error: staleClaimsErr } = await supabaseAdmin
    .from("media")
    .select("id, storage_reference")
    .eq("status", "cleanup_claimed")
    .lt("created_at", cutoffIso)
    .limit(SWEEP_BATCH_LIMIT);
  if (staleClaimsErr) {
    console.error("[cleanup] failed to query stuck cleanup_claimed media:", staleClaimsErr.message);
  } else {
    for (const row of staleClaims ?? []) {
      try {
        await deleteAndFinalizeClaimed(row.id as string, row.storage_reference as string | null);
        removed += 1;
      } catch (err) {
        console.error(`[cleanup] failed to recover stuck cleanup_claimed media ${row.id}:`, (err as Error).message);
      }
    }
  }

  return removed;
}

/** Finds matches still stuck at 'uploading' or 'queued' older than the
 * TTL and marks them 'error' so the user sees a real, retryable state in
 * MatchHistory instead of an upload that silently never progresses.
 * Deliberately does not touch storage objects itself — sweepAbandonedMedia
 * (above) owns that, on its own independent check of the SAME stuck
 * statuses, since a match can be stuck without media ever having been
 * uploaded for it at all (e.g. the row was inserted but the browser tab
 * closed before the file finished uploading). */
async function sweepAbandonedMatches(cutoffIso: string): Promise<number> {
  const { data: updated, error } = await supabaseAdmin
    .from("matches")
    .update({ status: "error", error_message: "Upload timed out or was never processed. Please retry." })
    .in("status", ["uploading", "queued"])
    .lt("created_at", cutoffIso)
    .select("id");

  if (error) {
    console.error("[cleanup] failed to sweep abandoned matches:", error.message);
    return 0;
  }
  return updated?.length ?? 0;
}

export async function sweepAbandonedUploads(): Promise<CleanupResult> {
  const cutoffIso = new Date(Date.now() - TTL_HOURS * 60 * 60 * 1000).toISOString();
  const [abandonedMediaRemoved, abandonedMatchesMarkedFailed] = await Promise.all([
    sweepAbandonedMedia(cutoffIso),
    sweepAbandonedMatches(cutoffIso),
  ]);
  if (abandonedMediaRemoved > 0 || abandonedMatchesMarkedFailed > 0) {
    console.log(
      `[cleanup] swept ${abandonedMediaRemoved} abandoned media row(s), ${abandonedMatchesMarkedFailed} abandoned match(es)`
    );
  }
  return { abandonedMediaRemoved, abandonedMatchesMarkedFailed };
}
