import path from "node:path";
import fs from "node:fs/promises";
import { UnrecoverableError } from "bullmq";
import { supabaseAdmin } from "../supabaseClient";
import { generateClip } from "../pipeline/generateClip";
import { downloadProcessedVideo, uploadVideoClip, cleanupLocalWorkDir } from "../storage";

const WORK_ROOT = process.env.WORKER_TMP_DIR ?? "/tmp/efootball-processing";
// Part L ("avoid unbounded processing") — the ±10s default context window
// normally produces ~20s clips; this is generous headroom for a
// wider-than-default context_start/context_end while still bounding
// worst-case ffmpeg run time and output size.
const MAX_CLIP_DURATION_SECONDS = 120;

/**
 * Batch 4, Parts 8-13 — generates a short clip around one analyzed event
 * using the EXISTING ffmpeg/worker infrastructure (see generateClip.ts,
 * which reuses compressVideo.ts's exact encode settings). Ownership
 * (match/event/user all agree) and the start/end clamp are already verified
 * by supabase/functions/clip-request BEFORE this job is enqueued — that
 * Edge Function is the only caller of POST /jobs/clip (see httpServer.ts),
 * so this job trusts its input the same way processMatchVideo.ts trusts
 * analysis-enqueue's verified payload. clipId identifies an existing
 * video_clips row (status already 'pending') created by that function.
 */
export interface GenerateVideoClipJobData {
  clipId: string;
  userId: string;
  matchId: string;
  eventId: string;
  videoObjectPath: string; // media.storage_reference for the match's permanent video
  startSeconds: number;
  endSeconds: number;
}

export async function generateVideoClip(data: GenerateVideoClipJobData): Promise<void> {
  const { clipId, userId, matchId, eventId, videoObjectPath, startSeconds, endSeconds } = data;

  // Part K/L — "do not trust queue payload blindly" / "avoid unbounded
  // processing". clip-request already validates all of this before
  // enqueueing, but re-checking here means a future direct caller of
  // POST /jobs/clip (or a bug) can't make ffmpeg run on an out-of-range,
  // non-numeric window, or another user's video. Every one of these is a
  // permanent data problem, never transient — retrying the same bad
  // payload 3 times would never succeed, hence UnrecoverableError.
  if (typeof videoObjectPath !== "string" || !videoObjectPath.startsWith(`${userId}/`)) {
    throw new UnrecoverableError(`videoObjectPath does not belong to user ${userId}`);
  }
  if (
    !Number.isFinite(startSeconds) ||
    !Number.isFinite(endSeconds) ||
    startSeconds < 0 ||
    endSeconds <= startSeconds ||
    endSeconds - startSeconds > MAX_CLIP_DURATION_SECONDS
  ) {
    throw new UnrecoverableError(`invalid clip window [${startSeconds}, ${endSeconds}]`);
  }
  const { data: ownedClip, error: ownedClipErr } = await supabaseAdmin
    .from("video_clips")
    .select("id")
    .eq("id", clipId)
    .eq("user_id", userId)
    .eq("match_id", matchId)
    .eq("event_id", eventId)
    .maybeSingle();
  if (ownedClipErr) throw ownedClipErr; // transient DB error — safe to retry
  if (!ownedClip) throw new UnrecoverableError(`clip ${clipId} does not match the user/match/event in the job payload`);

  const workDir = path.join(WORK_ROOT, "clips", clipId);
  await fs.mkdir(workDir, { recursive: true });

  try {
    await supabaseAdmin.from("video_clips").update({ status: "processing" }).eq("id", clipId);

    const sourcePath = path.join(workDir, "source.mp4");
    await downloadProcessedVideo(videoObjectPath, sourcePath);

    const outputPath = path.join(workDir, "clip.mp4");
    await generateClip(sourcePath, startSeconds, endSeconds, outputPath);

    const objectPath = await uploadVideoClip(userId, matchId, eventId, outputPath);

    await supabaseAdmin
      .from("video_clips")
      .update({ status: "completed", storage_path: objectPath, error_message: null })
      .eq("id", clipId);
  } catch (err) {
    // Batch 5 retry-state fix (same pattern as processMatchVideo.ts /
    // processScreenshot.ts) — this used to unconditionally write
    // video_clips.status='failed' on every attempt, including ones BullMQ
    // was about to retry. That's the same class of bug fixed for
    // Match Video/Screenshot: a transient ffmpeg/storage/network error
    // would get permanently recorded as 'failed' before the retry even
    // ran, so a client polling status could see 'failed' and give up (or
    // the UI could offer a manual retry) while the job was still healthy
    // and about to succeed on attempt 2/3. Log + rethrow here on every
    // attempt; index.ts's clip worker "failed" listener is now the single
    // place that writes the terminal 'failed' status, and only once
    // BullMQ has confirmed there are no attempts left.
    console.error(`[worker] clip ${clipId} attempt failed:`, (err as Error).message);
    throw err;
  } finally {
    await cleanupLocalWorkDir(workDir);
  }
}
