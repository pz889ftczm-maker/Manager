import { UnrecoverableError } from "bullmq";
import { getAiProvider } from "@efootball/ai";
import { filterValidDetectedEventDrafts, sniffFileType } from "@efootball/shared";
import { supabaseAdmin } from "../supabaseClient";
import { getSignedRawUploadUrl } from "../storage";
import { recomputeMatchStatistics, recomputePlayerProgress } from "../statistics";
import { persistPlayerStatistics } from "../playerStatistics";
import { resolveEventSelfPlayerId, linkStatisticsEvidenceForMatch } from "../eventLinking";
import { triggerMatchSnapshotOnCompletion } from "../matchSnapshot";
import {
  validateAndPersistAnalysisEvent,
  validateAnalysisEventDraft,
  readFootballMatchContext,
  type FootballMatchContext,
} from "../analysisEventPersistence";
import { logFullMatchContextOnCompletion } from "../analysisEngine";

export interface ProcessScreenshotJobData {
  matchId: string;
  userId: string;
  /** Object paths of already-uploaded screenshots in the raw-uploads bucket. */
  storageObjectPaths: string[];
}

/** Fetches just the first few KB of a private object via a short-lived
 * signed URL + HTTP Range request and sniffs its real type from the bytes
 * (Part A, defense-in-depth — analysis-enqueue already did this before
 * handing off the job; re-checked here in case this endpoint is ever
 * reached another way). Never downloads/loads the whole image. */
async function sniffRemoteFileKind(signedUrl: string): Promise<"image" | "video" | null> {
  try {
    const res = await fetch(signedUrl, { headers: { Range: "bytes=0-4095" } });
    if (!res.ok && res.status !== 206) return null;
    const buf = new Uint8Array(await res.arrayBuffer());
    return sniffFileType(buf)?.kind ?? null;
  } catch {
    return null;
  }
}

/** Spec section 5: simpler than video — no compression/sampling needed,
 * just hand the screenshot(s) straight to the AI provider. */
export async function processScreenshot(data: ProcessScreenshotJobData): Promise<void> {
  const { matchId, userId, storageObjectPaths } = data;

  // Part K — "do not trust queue payload blindly" / "worker must not
  // process another user's media because of malformed job data". Same
  // reasoning as processMatchVideo.ts's ownership re-check. A mismatch
  // here is a data problem, never transient, so it's an
  // UnrecoverableError rather than something worth retrying 3 times.
  const ownPrefix = `${userId}/`;
  const badPath = storageObjectPaths.find((p) => typeof p !== "string" || !p.startsWith(ownPrefix));
  if (badPath !== undefined) {
    throw new UnrecoverableError(`storageObjectPaths must belong to user ${userId}`);
  }
  // Batch 10D fix: football_type/team_size are read off this SAME
  // already-ownership-checked row (no new query added) so the analysis
  // event validation gate below has a server-resolved FootballMatchContext
  // to check every persisted event against — never taken from queue
  // payload/draft/client input. A legacy match (football_type IS NULL)
  // yields footballContext = null via readFootballMatchContext, never
  // fabricated to "efootball" — see footballMatchContext.ts.
  const { data: ownedMatch, error: ownedMatchErr } = await supabaseAdmin
    .from("matches")
    .select("id, football_type, team_size")
    .eq("id", matchId)
    .eq("user_id", userId)
    .maybeSingle();
  if (ownedMatchErr) throw ownedMatchErr; // transient DB error — safe to retry
  if (!ownedMatch) throw new UnrecoverableError(`match ${matchId} does not belong to user ${userId}`);
  const footballContext: FootballMatchContext | null = readFootballMatchContext({
    football_type: (ownedMatch as { football_type: string | null }).football_type,
    team_size: (ownedMatch as { team_size: number | null }).team_size,
  });

  try {
    await supabaseAdmin.from("matches").update({ status: "analyzing" }).eq("id", matchId);

    // Map each storage path back to its media row so extracted statistics
    // can be traced to real evidence (spec section 5: media_id / source_type),
    // AND so each row can be claimed below before any Storage access.
    const { data: mediaRows } = await supabaseAdmin
      .from("media")
      .select("id, storage_reference")
      .eq("match_id", matchId)
      .in("storage_reference", storageObjectPaths);
    const mediaIdByPath = new Map((mediaRows ?? []).map((m) => [m.storage_reference as string, m.id as string]));
    const candidateMediaIds = [...mediaIdByPath.values()];

    // Concurrency fix (Batch 5): claim every media row for this batch
    // BEFORE any Storage access (signed URLs, sniffing, or the AI calls
    // that read them). Same handshake as processMatchVideo.ts — cleanup.ts
    // only ever claims a row FROM 'uploaded', so once this CAS succeeds
    // cleanup can never delete the underlying object out from under this
    // job. 'optimizing' is an allowed source state too, so a BullMQ retry
    // of this same job after a crash can re-enter cleanly. Only paths
    // whose media row was actually claimed are processed further — a path
    // that lost the race (or has no matching row) is dropped here, not
    // read from Storage.
    const claimedMediaIds = new Set<string>();
    if (candidateMediaIds.length > 0) {
      const { data: claimedRows, error: claimErr } = await supabaseAdmin
        .from("media")
        .update({ status: "optimizing" })
        .in("id", candidateMediaIds)
        .in("status", ["uploaded", "optimizing"])
        .select("id");
      if (claimErr) throw claimErr; // transient DB error — safe to retry
      for (const r of claimedRows ?? []) claimedMediaIds.add(r.id as string);
    }
    const claimedPaths = storageObjectPaths.filter((p) => {
      const mediaId = mediaIdByPath.get(p);
      return mediaId !== undefined && claimedMediaIds.has(mediaId);
    });
    if (claimedPaths.length === 0) {
      throw new UnrecoverableError(
        `none of this batch's media rows for match ${matchId} could be claimed for processing (already cleaned up or finalized)`
      );
    }

    // Audit fix (Batch 3.5): screenshots live in the raw-uploads bucket
    // (Analyze.tsx uploads them there and, unlike video, never moves/
    // compresses them into processed-frames) — getSignedFrameUrl signed
    // against the wrong bucket for these paths. See apps/worker/src/storage.ts.
    const signedUrlByPath = new Map<string, string>();
    for (const p of claimedPaths) {
      signedUrlByPath.set(p, await getSignedRawUploadUrl(p, 60 * 30));
    }

    // Part A (defense-in-depth) — drop anything that doesn't actually
    // sniff as an image from THIS batch rather than failing every other
    // legitimately-uploaded screenshot in the same match; its own media
    // row is marked 'failed' individually.
    const validPaths: string[] = [];
    for (const p of claimedPaths) {
      const kind = await sniffRemoteFileKind(signedUrlByPath.get(p)!);
      if (kind === "image") {
        validPaths.push(p);
      } else {
        console.warn(`[processScreenshot] rejecting ${p} for match ${matchId}: not a recognized image`);
        const badMediaId = mediaIdByPath.get(p);
        if (badMediaId) await supabaseAdmin.from("media").update({ status: "failed" }).eq("id", badMediaId);
      }
    }
    if (validPaths.length === 0) {
      throw new UnrecoverableError("None of the uploaded files are recognized image formats");
    }
    const signedUrls = validPaths.map((p) => signedUrlByPath.get(p)!);

    const ai = getAiProvider();
    const rawDrafts = await ai.analyzeScreenshot({
      frames: signedUrls.map((url) => ({ imageUrl: url })),
    });

    // D.2: never persist a draft the model returned in a shape we can't
    // trust — invalid event_type/category/severity/score, etc.
    const drafts = filterValidDetectedEventDrafts(rawDrafts, (draft, errors) => {
      console.warn(`[processScreenshot] dropping invalid event draft for match ${matchId}:`, errors, draft);
    });

    for (const draft of drafts) {
      // Idempotency (migration 0005): a retry of this same job re-detects the
      // same events, so persist with a conflict-safe upsert keyed on
      // (match_id, dedupe_key) instead of a plain INSERT. dedupe_key is a
      // generated content fingerprint, so re-running updates the existing row
      // rather than adding a duplicate that would double-count in
      // recomputeMatchStatistics / recomputePlayerProgress.
      //
      // Batch 3.5 remaining-work item 1, unchanged: only links to the self
      // player, and only when the model reliably flagged it (see
      // eventLinking.ts). involvesSelfPlayer isn't a real analysis_events
      // column, so it's pulled out of the draft before spreading the rest
      // into eventFields.
      const { involvesSelfPlayer, ...eventFields } = draft as Record<string, unknown> & {
        involvesSelfPlayer?: boolean;
      };
      const playerId = await resolveEventSelfPlayerId(userId, involvesSelfPlayer as boolean | undefined);

      // 10K AI-call-ordering fix: run the SAME validateUnifiedFootballEventInput
      // gate validateAndPersistAnalysisEvent runs internally (via
      // validateAnalysisEventDraft — see that function's own doc comment
      // in analysisEventPersistence.ts) BEFORE spending a
      // tactical-analysis AI call, so a draft that's going to be rejected
      // never triggers ai.generateTacticalAnalysis. Pre-check only:
      // validateAndPersistAnalysisEvent still runs the exact same
      // validation itself below (no persistence happens on this path
      // either way), so ownership/idempotency/retry behavior is unchanged.
      const preValidation = validateAnalysisEventDraft({ matchId, userId, footballContext, playerId }, draft);
      if (!preValidation.valid) {
        console.warn(
          `[processScreenshot] dropping event that failed unified validation for match ${matchId}:`,
          preValidation.errors,
          draft
        );
        continue;
      }

      // 10K: generate tactical/spatial analysis BEFORE persisting the
      // event, rather than after (its previous position, immediately
      // before the tactical_analysis upsert below) — see
      // processMatchVideo.ts's persistEvent for the full "never overwrite
      // a historical explanation" reasoning this reordering exists for.
      // AI/PROVIDER BEHAVIOR UNCHANGED: same call, same inputs, still
      // exactly once per event. Only reached now for a draft the
      // preValidation check above already confirmed will be accepted.
      const tactical = await ai.generateTacticalAnalysis(
        draft,
        signedUrls.map((url) => ({ imageUrl: url }))
      );

      // Batch 10D fix: validateAndPersistAnalysisEvent
      // (analysisEventPersistence.ts) now gates this upsert behind
      // validateUnifiedFootballEventInput — in addition to, never instead
      // of, filterValidDetectedEventDrafts' own validateDetectedEventDraft
      // check already run above — using a footballContext and ownership
      // resolved server-side (never from `draft`), and always wins over any
      // match_id/player_id `eventFields` might otherwise contain.
      const result = await validateAndPersistAnalysisEvent(
        { matchId, userId, footballContext, playerId },
        draft,
        eventFields,
        undefined,
        undefined,
        // 10K — see analysisEventPersistence.ts's own `tacticalAnalysis`
        // param doc comment.
        tactical
      );

      // Reject/skip the invalid event safely: logged (same convention as
      // the D.2 filterValidDetectedEventDrafts drop above), never thrown,
      // so one bad candidate event cannot corrupt/abort the rest of this
      // match's analysis — the loop simply moves on to the next draft.
      if (!result.valid) {
        console.warn(
          `[processScreenshot] dropping event that failed unified validation for match ${matchId}:`,
          result.errors,
          draft
        );
        continue;
      }

      // Same tactical_analysis upsert as before 10K — unchanged table,
      // shape, and onConflict — using the SAME `tactical` object already
      // computed above (no second AI call). 1:1 with the event (unique on
      // event_id), so a retry overwrites the diagram instead of stacking a
      // second one.
      await supabaseAdmin
        .from("tactical_analysis")
        .upsert({ event_id: result.eventId, ...tactical }, { onConflict: "event_id" });
    }

    // Batch 3.5 — real individual player statistics (spec sections 2/6/7).
    // Media traceability fix (remaining-work item 3): statistics extraction
    // is run ONE SCREENSHOT AT A TIME rather than batching every uploaded
    // screenshot into a single call. The old batched call had no way to
    // know which of several distinct screenshots a given extracted row
    // actually came from, so it fell back to blaming the first path for
    // everything — wrong the moment a user uploaded, say, a passing-stats
    // screenshot AND a defending-stats screenshot together. Per-screenshot
    // calls mean every persisted row's media_id is the literal screenshot
    // it was read from (persistPlayerStatistics merges multiple
    // screenshots' contributions to the same player rather than
    // overwriting, and only nulls media_id out if two DIFFERENT
    // screenshots genuinely both contributed real fields to one player).
    for (const storagePath of validPaths) {
      const mediaId = mediaIdByPath.get(storagePath) ?? null;
      const signedUrl = signedUrlByPath.get(storagePath);
      if (!signedUrl) continue;
      try {
        const statDrafts = await ai.extractPlayerStatistics({
          frames: [{ imageUrl: signedUrl }],
        });

        for (const draft of statDrafts) {
          if (!draft || typeof draft !== "object") continue;
          try {
            await persistPlayerStatistics({
              userId,
              matchId,
              mediaId,
              source: "screenshot",
              draft,
            });
          } catch (statErr) {
            console.warn(`[processScreenshot] failed to persist player statistics for match ${matchId}:`, statErr);
          }
        }
      } catch (extractErr) {
        // Statistics extraction is additive evidence, not required for the
        // core decision-event pipeline — a failure on one screenshot must
        // not fail the whole match analysis (spec section 24: gracefully
        // handle partial data), nor stop extraction on the remaining ones.
        console.warn(
          `[processScreenshot] player statistics extraction failed for match ${matchId}, media ${mediaId}:`,
          extractErr
        );
      }
    }

    // Batch 3.5 remaining-work item 2: now that both the decision events
    // (with player_id where reliable) and this match's real per-player
    // statistics have been persisted, cite the specific stat fields that
    // back each linked event. Safe to re-run on a retried job.
    await linkStatisticsEvidenceForMatch(matchId);

    // Previously this job never wrote match_statistics at all (only
    // processMatchVideo did), so screenshot-analyzed matches contributed
    // no passing/dribbling/positioning/etc. data to player_progress. Now
    // both jobs go through the same recompute path — see
    // apps/worker/src/statistics.ts. recomputeMatchStatistics also derives
    // overall_score from the real persisted events, so no need to
    // recompute it separately here from the in-memory drafts.
    await recomputeMatchStatistics(matchId);

    // Bugfix (Batch 3): same ordering fix as processMatchVideo.ts —
    // recomputePlayerProgress() only reads matches with status='complete',
    // so status must be flipped to complete BEFORE calling it, or this
    // match is excluded from its own player_progress update.
    await supabaseAdmin.from("matches").update({ status: "complete" }).eq("id", matchId);
    await recomputePlayerProgress(userId);

    // Batch 9C-1: attempt the (optional, best-effort) historical
    // snapshot only now that analysis has genuinely completed
    // successfully. See apps/worker/src/matchSnapshot.ts's own header
    // comment for the full design — this call can never throw, so a
    // snapshot failure (or simply no unambiguous team/formation
    // context to use) never affects this otherwise-successful job.
    await triggerMatchSnapshotOnCompletion(matchId, userId);

    // 10K — best-effort, read-only sanity check that this match's
    // persisted analysis_events + moment_explanations rows compose
    // cleanly into a FullMatchContext (10I, via 10J-3's persisted-
    // explanation-aware reconstruction). Same "never throws" contract as
    // triggerMatchSnapshotOnCompletion immediately above — see
    // analysisEngine.ts's own header comment. Writes nothing.
    await logFullMatchContextOnCompletion(matchId, footballContext);

    // Audit fix (Part I — "no impossible/stuck states"): screenshots'
    // media rows previously stayed at status='uploaded' forever, even for
    // a match that finished analysis successfully. Mark every screenshot
    // that actually contributed to this run as 'processed' now that the
    // match is complete.
    for (const p of validPaths) {
      const mediaId = mediaIdByPath.get(p);
      if (mediaId) await supabaseAdmin.from("media").update({ status: "processed" }).eq("id", mediaId);
    }
  } catch (err) {
    // Batch 5 retry-state fix (same bug/fix as processMatchVideo.ts): this
    // catch block used to unconditionally write matches.status='error' and
    // fail every not-yet-finished media row for this match on EVERY failed
    // attempt, including transient ones BullMQ was about to retry. Once a
    // row was marked 'failed', the claim CAS above (`.in("status",
    // ["uploaded","optimizing"])`) could no longer see it, so a retried
    // attempt would drop it from `claimedPaths` (or, if that was the only
    // media in the batch, throw "could not be claimed" instead of actually
    // retrying). Terminal bookkeeping now happens in exactly ONE place —
    // the Worker `failed` event listener in apps/worker/src/index.ts —
    // which only runs once BullMQ has actually decided there will be no
    // more attempts (UnrecoverableError, or attemptsMade has reached the
    // configured `attempts`). This handler's only remaining job on failure
    // is to log safely (never throws itself) and rethrow so BullMQ can see
    // the failure and decide whether to retry.
    console.error(
      `[processScreenshot] attempt failed for match ${matchId}:`,
      (err as Error)?.message ?? err
    );
    throw err;
  }
}
