import path from "node:path";
import fs from "node:fs/promises";
import { UnrecoverableError } from "bullmq";
import { getAiProvider } from "@efootball/ai";
import { filterValidDetectedEventDrafts, sniffFileType } from "@efootball/shared";
import { supabaseAdmin } from "../supabaseClient";
import { compressVideo } from "../pipeline/compressVideo";
import { sampleFramesAcrossMatch, extractContextWindow } from "../pipeline/sampleFrames";
import { detectCandidateMoments } from "../pipeline/detectCandidateMoments";
import { encodeFrameToBase64, encodeFramesToBase64 } from "../pipeline/encodeFrame";
import {
  downloadRawUpload,
  uploadFrame,
  getSignedFrameUrl,
  deleteRawUpload,
  cleanupLocalWorkDir,
  uploadProcessedVideo,
} from "../storage";
import { recomputeMatchStatistics, recomputePlayerProgress } from "../statistics";
import { resolveEventSelfPlayerId, linkStatisticsEvidenceForMatch } from "../eventLinking";
import { triggerMatchSnapshotOnCompletion } from "../matchSnapshot";
import {
  validateAndPersistAnalysisEvent,
  validateAnalysisEventDraft,
  readFootballMatchContext,
  type FootballMatchContext,
} from "../analysisEventPersistence";
import { logFullMatchContextOnCompletion } from "../analysisEngine";

const WORK_ROOT = process.env.WORKER_TMP_DIR ?? "/tmp/efootball-processing";

export interface ProcessMatchVideoJobData {
  matchId: string;
  mediaId: string;
  userId: string;
  rawStorageObjectPath: string;
}

/**
 * Full pipeline for spec sections 6-15 & 26:
 * download -> compress -> sample -> detect candidates -> analyze context
 * windows -> persist events + tactical data -> update match stats -> clean
 * up temp video. Each stage updates `matches.status` so the frontend can
 * show live progress (spec section 32).
 */
export async function processMatchVideo(data: ProcessMatchVideoJobData): Promise<void> {
  const { matchId, mediaId, userId, rawStorageObjectPath } = data;

  // Part K — "do not trust queue payload blindly" / "worker must not
  // process another user's media because of malformed job data". This
  // internal HTTP API is only ever called by analysis-enqueue after IT
  // already verified ownership, but re-checking here means a bug or a
  // future direct caller of this endpoint can't make the worker touch a
  // match/media row it doesn't actually own. A mismatch here is a data
  // problem, never a transient one, so it's an UnrecoverableError — no
  // point retrying the same bad payload 3 times. Deliberately does NOT
  // write to `matches`/`media` on this path: if userId doesn't actually
  // own matchId, writing an error onto that row would itself be touching
  // data that may not belong to the caller.
  if (typeof rawStorageObjectPath !== "string" || !rawStorageObjectPath.startsWith(`${userId}/`)) {
    throw new UnrecoverableError(`rawStorageObjectPath does not belong to userId ${userId}`);
  }
  // Batch 10D fix: football_type/team_size are read off this SAME
  // already-ownership-checked row (no new query added) so the analysis
  // event validation gate below has a server-resolved FootballMatchContext
  // to check every persisted event against — never taken from queue
  // payload/draft/client input. A legacy match (football_type IS NULL)
  // yields footballContext = null via readFootballMatchContext, never
  // fabricated to "efootball" — see footballMatchContext.ts.
  const { data: ownedMatch, error: ownedMatchErr } = await supabaseAdmin
    .from("matches")
    .select("id, football_type, team_size")
    .eq("id", matchId)
    .eq("user_id", userId)
    .maybeSingle();
  if (ownedMatchErr) throw ownedMatchErr; // transient DB error — safe to retry
  if (!ownedMatch) throw new UnrecoverableError(`match ${matchId} does not belong to user ${userId}`);
  const footballContext: FootballMatchContext | null = readFootballMatchContext({
    football_type: (ownedMatch as { football_type: string | null }).football_type,
    team_size: (ownedMatch as { team_size: number | null }).team_size,
  });

  const { data: ownedMedia, error: ownedMediaErr } = await supabaseAdmin
    .from("media")
    .select("id")
    .eq("id", mediaId)
    .eq("user_id", userId)
    .eq("match_id", matchId)
    .maybeSingle();
  if (ownedMediaErr) throw ownedMediaErr;
  if (!ownedMedia) throw new UnrecoverableError(`media ${mediaId} does not belong to user ${userId}/match ${matchId}`);

  const workDir = path.join(WORK_ROOT, matchId);
  await fs.mkdir(workDir, { recursive: true });

  try {
    await setMatchStatus(matchId, "optimizing");

    // Concurrency fix (Batch 5): claim the media row BEFORE touching
    // Storage at all. This is the real ownership handshake with
    // cleanup.ts — cleanup only ever claims a row FROM 'uploaded' (moving
    // it to 'cleanup_claimed'), so once this CAS succeeds, cleanup can
    // never win the race on this row and therefore can never delete the
    // Storage object out from under this job, no matter how the two are
    // interleaved. 'optimizing' is included in the allowed source states
    // (not just 'uploaded') so a BullMQ retry/stalled-job re-run of THIS
    // SAME job — after a worker crash mid-processing — can re-enter and
    // finish the work rather than being told it "lost" a race that was
    // actually just its own earlier attempt. If the update affects zero
    // rows, some other process already moved this media past 'uploaded'
    // (cleanup claimed/removed it, or it somehow already reached a
    // terminal state) — Storage must never be read in that case.
    const { data: claimedMedia, error: claimErr } = await supabaseAdmin
      .from("media")
      .update({ status: "optimizing" })
      .eq("id", mediaId)
      .in("status", ["uploaded", "optimizing"])
      .select("id");
    if (claimErr) throw claimErr; // transient DB error — safe to retry
    if (!claimedMedia || claimedMedia.length === 0) {
      throw new UnrecoverableError(
        `media ${mediaId} could not be claimed for processing (already cleaned up or finalized)`
      );
    }

    const rawPath = path.join(workDir, "raw_input");
    await downloadRawUpload(rawStorageObjectPath, rawPath);

    // Part A (defense-in-depth) — analysis-enqueue already sniffed this
    // object's bytes before handing off the job, but re-check the actual
    // downloaded file here too, in case this endpoint is ever reached by
    // something other than analysis-enqueue. A bad file is a permanent
    // problem for this job, not a transient one.
    const detected = sniffFileType(await readFileHead(rawPath, 4096));
    if (!detected || detected.kind !== "video") {
      await supabaseAdmin.from("media").update({ status: "failed" }).eq("id", mediaId);
      throw new UnrecoverableError("Uploaded file is not a recognized video format");
    }

    const { outputPath: optimizedPath, outputSizeBytes, durationSeconds } = await compressVideo(
      rawPath,
      workDir
    );
    await supabaseAdmin
      .from("media")
      .update({ status: "optimized", processed_size_bytes: outputSizeBytes })
      .eq("id", mediaId);
    await supabaseAdmin.from("matches").update({ duration_seconds: Math.round(durationSeconds) }).eq(
      "id",
      matchId
    );

    // Batch 4 audit fix: previously `optimizedPath` only ever lived in this
    // job's local scratch dir (deleted in the `finally` block below) and
    // was never uploaded anywhere, so no video byte survived a completed
    // job — see migration 0008_video_experience.sql's header comment.
    // Persisted here (as soon as it exists) rather than at the very end of
    // the pipeline, so a match still has its playable video even if a
    // later stage (detection/analysis) fails partway and needs a retry.
    await persistProcessedVideoMedia(matchId, userId, optimizedPath, outputSizeBytes);

    // Created up front (before detection) since detectCandidateMoments now
    // needs it too — the cheap scan pass and the full analysis pass both
    // go through the same AiProvider instance.
    const ai = getAiProvider();

    await setMatchStatus(matchId, "processing");
    const indexFrames = await sampleFramesAcrossMatch(optimizedPath, durationSeconds, workDir);

    await setMatchStatus(matchId, "detecting_moments");
    const candidateTimestamps = await detectCandidateMoments(indexFrames, ai);

    await setMatchStatus(matchId, "analyzing");

    for (const ts of candidateTimestamps) {
      const contextFrames = await extractContextWindow(optimizedPath, ts, durationSeconds, workDir);
      const contextStart = contextFrames[0]?.timestampSeconds ?? ts;
      const contextEnd = contextFrames[contextFrames.length - 1]?.timestampSeconds ?? ts;

      // B.1: hosted APIs can't read the worker's local filesystem, so
      // frames must be sent as base64, never as a local `imageUrl` path.
      const encodedContextFrames = await encodeFramesToBase64(contextFrames);

      const rawDrafts = await ai.analyzeVideoContext({
        frames: encodedContextFrames.map((f) => ({
          timestampSeconds: f.timestampSeconds,
          imageBase64: f.imageBase64,
        })),
        contextStartSeconds: contextStart,
        contextEndSeconds: contextEnd,
        eventTimestampSeconds: ts,
      });

      // D.2: never persist a draft the model returned in a shape we can't
      // trust — invalid event_type/category/severity/score, etc.
      const drafts = filterValidDetectedEventDrafts(rawDrafts, (draft, errors) => {
        console.warn(`[processMatchVideo] dropping invalid event draft for match ${matchId}:`, errors, draft);
      });

      for (const draft of drafts) {
        await persistEvent(matchId, userId, footballContext, draft, contextFrames, ai);
      }

      // Context frames are only needed transiently for this call + any
      // frame we chose to persist as before/decision/after above.
      await Promise.all(contextFrames.map((f) => fs.unlink(f.path).catch(() => {})));
    }

    // Batch 3.5 remaining-work item 1/2: video enriches whatever REAL
    // per-player statistics already exist for this match (typically from a
    // screenshot the user also uploaded) — it never fabricates new
    // numbers. Runs after every event in this match has been persisted
    // (and linked to the self player where reliable) so it sees the full
    // event set, and is safe to re-run on a retried job.
    await linkStatisticsEvidenceForMatch(matchId);

    await setMatchStatus(matchId, "generating_report");
    await recomputeMatchStatistics(matchId);

    // Bugfix (Batch 3): recomputePlayerProgress() only reads matches with
    // status='complete', so it must run AFTER this match's status flips to
    // complete — otherwise the match that was just analyzed is excluded
    // from its own player_progress update. match_statistics is persisted
    // first (recomputeMatchStatistics above), then status is set to
    // complete, then player_progress is recomputed so it sees this match.
    await setMatchStatus(matchId, "complete");
    // Real player_progress write path (spec item 1/7): recomputed from
    // this user's full real match history, not incremented, so retrying
    // this job is safe — see apps/worker/src/statistics.ts header comment.
    await recomputePlayerProgress(userId);

    // Batch 9C-1: attempt the (optional, best-effort) historical
    // snapshot only now that analysis has genuinely completed
    // successfully. See apps/worker/src/matchSnapshot.ts's own header
    // comment for the full design — this call can never throw, so a
    // snapshot failure (or simply no unambiguous team/formation
    // context to use) never affects this otherwise-successful job.
    await triggerMatchSnapshotOnCompletion(matchId, userId);

    // 10K — best-effort, read-only sanity check that this match's
    // persisted analysis_events + moment_explanations rows compose
    // cleanly into a FullMatchContext (10I, via 10J-3's persisted-
    // explanation-aware reconstruction). Same "never throws" contract as
    // triggerMatchSnapshotOnCompletion immediately above — see
    // analysisEngine.ts's own header comment. Writes nothing.
    await logFullMatchContextOnCompletion(matchId, footballContext);

    await supabaseAdmin
      .from("media")
      .update({ status: "processed", is_temporary: true })
      .eq("id", mediaId);

    // Spec section 10/26: only delete the temp video from storage AFTER
    // everything above succeeded — match_statistics, matches.status, and
    // player_progress are all durably written by this point.
    await deleteRawUpload(rawStorageObjectPath);
    await supabaseAdmin.from("media").update({ status: "deleted_temp" }).eq("id", mediaId);
  } catch (err) {
    // Batch 5 retry-state fix: this catch block used to unconditionally
    // write matches.status='error' and media.status='failed' on EVERY
    // failed attempt — including transient ones (a network blip, a
    // momentary AI-provider 5xx) that BullMQ was about to retry. That
    // permanently moved the media row out of the ['uploaded','optimizing']
    // states the claim CAS above accepts, so attempt 2 of what should have
    // been a routine retry immediately hit the "could not be claimed"
    // UnrecoverableError instead of continuing the job. Terminal
    // bookkeeping now happens in exactly ONE place — the Worker `failed`
    // event listener in apps/worker/src/index.ts — which only runs once
    // BullMQ has actually decided this job will not be retried again
    // (UnrecoverableError, or attemptsMade has reached the configured
    // `attempts`). This handler's only remaining job on failure is to log
    // safely (never throws itself) and rethrow so BullMQ can see the
    // failure and decide whether to retry.
    console.error(
      `[processMatchVideo] attempt failed for match ${matchId}, media ${mediaId}:`,
      (err as Error)?.message ?? err
    );
    throw err;
  } finally {
    await cleanupLocalWorkDir(workDir);
  }
}

async function setMatchStatus(matchId: string, status: string) {
  await supabaseAdmin.from("matches").update({ status }).eq("id", matchId);
}

/** Reads only the first `length` bytes of a file — used for magic-byte
 * sniffing so a multi-hundred-MB video is never fully loaded into memory
 * just to check its header. */
async function readFileHead(filePath: string, length: number): Promise<Uint8Array> {
  const handle = await fs.open(filePath, "r");
  try {
    const buffer = Buffer.alloc(length);
    const { bytesRead } = await handle.read(buffer, 0, length, 0);
    return buffer.subarray(0, bytesRead);
  } finally {
    await handle.close();
  }
}

/**
 * Batch 4 — uploads the compressed video and records it as a media row
 * distinct from the temporary raw-upload row (`is_temporary: false` is the
 * discriminator the frontend's useMatchVideo hook filters on). Uses a
 * manual select-then-insert/update rather than a DB-level upsert
 * constraint, matching the existing find-or-create style already used for
 * player identity (see apps/worker/src/playerStatistics.ts::resolvePlayerId)
 * — this keeps a retried job idempotent (fixed object path + upsert:true in
 * uploadProcessedVideo, and this update-in-place on the same row) without
 * needing a new partial-unique-index/on_conflict mechanism just for this.
 */
async function persistProcessedVideoMedia(
  matchId: string,
  userId: string,
  localOptimizedPath: string,
  outputSizeBytes: number
): Promise<void> {
  const objectPath = await uploadProcessedVideo(userId, matchId, localOptimizedPath);

  // Audit fix (Batch 4 verification): none of the three writes below used
  // to check `error`. A silently-failed DB write would let the pipeline
  // believe the processed-video row exists, proceed through the rest of
  // the job, and eventually call deleteRawUpload() on the ONLY remaining
  // copy of the video (see the O — Reliability checklist: "worker failure
  // does not silently mark success"). Every call here now throws on
  // `error`, which routes into processMatchVideo's outer `catch` and
  // correctly preserves the raw upload for retry.
  const { data: existing, error: selectError } = await supabaseAdmin
    .from("media")
    .select("id")
    .eq("match_id", matchId)
    .eq("type", "video")
    .eq("is_temporary", false)
    .maybeSingle();
  if (selectError) throw selectError;

  if (existing) {
    const { error: updateError } = await supabaseAdmin
      .from("media")
      .update({ status: "processed", storage_reference: objectPath, processed_size_bytes: outputSizeBytes })
      .eq("id", existing.id);
    if (updateError) throw updateError;
  } else {
    const { error: insertError } = await supabaseAdmin.from("media").insert({
      match_id: matchId,
      user_id: userId,
      type: "video",
      original_filename: "match-video.mp4",
      processed_size_bytes: outputSizeBytes,
      status: "processed",
      storage_reference: objectPath,
      is_temporary: false,
    });
    if (insertError) throw insertError;
  }
}

async function persistEvent(
  matchId: string,
  userId: string,
  footballContext: FootballMatchContext | null,
  draft: Record<string, any>, // DetectedEventDraft from @efootball/ai — loosened here to avoid a circular import; tighten by importing the type-only export if desired
  contextFrames: { path: string; timestampSeconds: number }[],
  ai: ReturnType<typeof getAiProvider>
) {
  // Idempotency (migration 0005): keyed on (match_id, dedupe_key), a stored
  // content fingerprint of the event (timestamp + context window + event_type +
  // category + severity + description). A retried job re-detects the same
  // moments, so this upsert refreshes those rows instead of inserting
  // duplicates that would double-count in match_statistics / player_progress.
  // Genuinely different events in the same match differ in at least one
  // fingerprinted field and therefore still insert as separate rows.
  //
  // Batch 3.5 remaining-work item 1, unchanged: only ever links to the self
  // player, and only when the model reliably flagged it — see eventLinking.ts.
  const playerId = await resolveEventSelfPlayerId(userId, draft.involvesSelfPlayer);

  // 10K AI-call-ordering fix: run the SAME validateUnifiedFootballEventInput
  // gate validateAndPersistAnalysisEvent runs internally (via
  // validateAnalysisEventDraft — see that function's own doc comment)
  // BEFORE spending a tactical-analysis AI call, so a draft that's going
  // to be rejected never triggers ai.generateTacticalAnalysis. This is a
  // pre-check only: validateAndPersistAnalysisEvent still runs the exact
  // same validation itself below (nothing here loosens or duplicates the
  // gate's decision logic, and no persistence happens on this path
  // either way), so ownership/idempotency/retry behavior is unchanged.
  const preValidation = validateAnalysisEventDraft({ matchId, userId, footballContext, playerId }, draft);
  if (!preValidation.valid) {
    console.warn(
      `[processMatchVideo] dropping event that failed unified validation for match ${matchId}:`,
      preValidation.errors,
      draft
    );
    return;
  }

  // 10K: tactical/spatial analysis is now generated HERE, before
  // validateAndPersistAnalysisEvent is called, rather than after (its
  // previous position, immediately before the tactical_analysis upsert
  // below) — moved up so that same already-computed data can be handed
  // to validateAndPersistAnalysisEvent and attached to the 10H
  // MomentExplanation it persists for this event (10J-2), which a
  // moment_explanations row can never be updated with after the fact
  // (INSERT ... ON CONFLICT DO NOTHING — see analysisEventPersistence.ts's
  // own 10J-2 header comment, "never overwrite a historical explanation").
  // AI/PROVIDER BEHAVIOR UNCHANGED: this is the exact same
  // ai.generateTacticalAnalysis(draft, tacticalFrames) call this file
  // already made — same inputs, same model, still exactly once per
  // event — only its position in the sequence moved earlier; contextFrames
  // are still alive at this point (not deleted until after persistEvent
  // returns, back in the caller's loop) so nothing about the frames
  // themselves changes either. Only reached now for a draft the
  // preValidation check above already confirmed will be accepted.
  const tacticalFrames = await Promise.all(
    contextFrames.map(async (f) => ({ imageBase64: await encodeFrameToBase64(f.path) }))
  );
  const tactical = await ai.generateTacticalAnalysis(draft, tacticalFrames);

  // Batch 10D fix: validateAndPersistAnalysisEvent (analysisEventPersistence.ts)
  // now gates this upsert behind validateUnifiedFootballEventInput — in
  // addition to, never instead of, filterValidDetectedEventDrafts' own
  // validateDetectedEventDraft check already run above this loop — using a
  // footballContext and ownership (including the playerId resolved just
  // above) resolved server-side, never from `draft`.
  const result = await validateAndPersistAnalysisEvent(
    { matchId, userId, footballContext, playerId },
    draft,
    {
      timestamp_seconds: draft.timestamp_seconds,
      event_type: draft.event_type,
      category: draft.category,
      severity: draft.severity,
      decision_score: draft.decision_score,
      confidence: draft.confidence,
      confidence_level: draft.confidence_level,
      description: draft.description,
      better_option: draft.better_option,
      reasoning: draft.reasoning,
      context_start_seconds: draft.context_start_seconds,
      context_end_seconds: draft.context_end_seconds,
    },
    undefined,
    undefined,
    // 10K — see analysisEventPersistence.ts's own `tacticalAnalysis` param
    // doc comment. `tactical` (TacticalAnalysisDraft) already structurally
    // satisfies TacticalAnalysisSnapshot — same fields this file already
    // spreads into the tactical_analysis upsert below.
    tactical
  );

  // Reject/skip the invalid event safely: logged (same convention as the
  // D.2 filterValidDetectedEventDrafts drop above), never thrown, so one
  // bad candidate moment cannot corrupt/abort the rest of this match's
  // analysis — the loop in processMatchVideo simply moves on.
  if (!result.valid) {
    console.warn(
      `[processMatchVideo] dropping event that failed unified validation for match ${matchId}:`,
      result.errors,
      draft
    );
    return;
  }
  const eventId = result.eventId;

  // Persist only the handful of frames actually referenced (spec section 27)
  // rather than every sampled context frame.
  const frameUploads = await Promise.all(
    [draft.beforeFrameIndex, draft.decisionFrameIndex, draft.afterFrameIndex].map(async (idx) => {
      if (idx == null || !contextFrames[idx]) return null;
      const objectPath = await uploadFrame(userId, matchId, contextFrames[idx].path);
      return getSignedFrameUrl(objectPath, 60 * 60 * 24 * 7); // 7 days; regenerate on view for longer-lived access
    })
  );

  await supabaseAdmin
    .from("analysis_events")
    .update({
      before_frame_url: frameUploads[0],
      decision_frame_url: frameUploads[1],
      after_frame_url: frameUploads[2],
    })
    .eq("id", eventId);

  // Same tactical_analysis upsert as before 10K — unchanged table, shape,
  // and onConflict — using the SAME `tactical` object already computed
  // above (no second AI call). 1:1 with the event (unique on event_id
  // since migration 0005) so retries refresh the diagram instead of
  // stacking duplicates.
  await supabaseAdmin.from("tactical_analysis").upsert(
    {
      event_id: eventId,
      ...tactical,
    },
    { onConflict: "event_id" }
  );
}

