// Batch 10D fix — wires the existing, already-well-tested
// validateUnifiedFootballEventInput() (packages/shared/src/footballEvent.ts)
// into the worker's ACTUAL analysis_events write path.
//
// AUDIT FINDING THIS FIXES: validateUnifiedFootballEventInput() existed and
// was thoroughly unit-tested (packages/shared/test/footballEvent.test.ts),
// but nothing on the worker's persistence path ever called it —
// processMatchVideo.ts's persistEvent() and processScreenshot.ts's own
// inline upsert both went straight from validateDetectedEventDraft's
// vocabulary/range check to `supabaseAdmin.from("analysis_events").upsert()`.
// This file is the one new call site both jobs now share.
//
// REUSE, NOT REPLACEMENT (spec — "reuse the existing
// validateUnifiedFootballEventInput()"):
//   * validateDetectedEventDraft (validation.ts, via
//     filterValidDetectedEventDrafts) is UNCHANGED and still runs first, in
//     both jobs, exactly as before this fix — this module's own gate only
//     ever runs on drafts that already passed it. validateUnifiedFootballEventInput
//     itself re-invokes validateDetectedEventDraft rather than duplicating
//     its checks (see footballEvent.ts), so nothing here re-implements that
//     logic a second time either.
//   * Persistence: still exactly the same `analysis_events` table and the
//     same (match_id, dedupe_key) idempotent upsert (migration 0005) both
//     jobs already used. This file does not add a second table or a second
//     upsert mechanism — it gives the one upsert both jobs already performed
//     a single shared call site, so the new validation gate has exactly one
//     place to live instead of two independently-maintained copies.
//
// SERVER-SIDE CONTEXT ONLY (spec — "resolve football context and ownership
// server-side; do NOT trust client-supplied football_type, user_id, or
// player ownership"):
//   * matchId/userId: always the SAME already-ownership-verified values each
//     job resolved at its own "Part K" check (top of processMatchVideo.ts /
//     processScreenshot.ts) — passed in via `ownership` below, never
//     re-derived from `draft`.
//   * footballContext: read via footballMatchContext.ts's own
//     readFootballMatchContext off the exact same `matches` row each job
//     already fetches for that same ownership check (football_type/
//     team_size simply added to that existing select — no new query added
//     by this fix). Never taken from `draft` — DetectedEventDraft has no
//     football_type field at all, and validateUnifiedFootballEventInput
//     itself rejects one if a loosely-typed draft somehow carried one
//     anyway.
//   * player ownership: `ownership.playerId` is resolved by the CALLER via
//     the existing, unchanged resolveEventSelfPlayerId (eventLinking.ts) —
//     itself always scoped to `ownership.userId`, never to any value read
//     from `draft`. It is deliberately not called from inside this file
//     (see "why player resolution stays a caller concern" below); this
//     module only ever consumes the already-resolved id. match_id/player_id
//     are always injected into the persisted row AFTER `eventFields` is
//     spread (see validateAndPersistAnalysisEvent below), so nothing
//     `eventFields`/`draft` might contain can ever override either value.
//
// WHY PLAYER RESOLUTION STAYS A CALLER CONCERN: resolveEventSelfPlayerId
// (and the find-or-create it delegates to, playerStatistics.ts's own
// resolvePlayerId) talks to `players`/`match_player_statistics` directly via
// the worker's real `supabaseAdmin` client, with no injectable seam of its
// own — that is unrelated, pre-existing worker code this 10D fix does not
// touch or re-architect. Keeping it a caller concern (exactly where it
// already lived in both jobs before this fix) means THIS file only ever
// depends on `@efootball/shared` (a small, dependency-free package) plus its
// own lazily-imported `supabaseClient` — never `eventLinking.ts` — so it
// stays importable, and its validate-then-persist DECISION logic stays
// testable via AnalysisEventPersistencePort below, without requiring a real
// Supabase/Postgres instance or SUPABASE_URL/SUPABASE_SERVICE_ROLE_KEY to be
// set (see apps/worker/test/analysisEventPersistence.test.ts).
//
// FAIL-SAFE ON INVALID (spec — "reject/skip the invalid event safely
// without corrupting the match analysis"): mirrors
// filterValidDetectedEventDrafts' own established convention — the caller
// logs a warning naming every validation error and moves on to the next
// candidate event; this module never throws for "the draft failed
// validation", only for a genuine database error from the upsert itself
// (unchanged from the pre-existing upsert calls this replaces), so BullMQ's
// existing retry behavior is untouched (spec — "keep existing retry/error
// behavior intact").
//
// LEGACY NULL football_type (spec — "do not break legacy events whose
// football_type is NULL"): readFootballMatchContext already returns null
// (never fabricated) for a match whose football_type column is NULL, and
// validateUnifiedFootballEventInput's own contract already treats a null
// footballContext as a fully valid "unknown, no eFootball-only fields
// allowed" state — no special-casing needed here.
//
// TESTABLE WITHOUT A REAL DATABASE (same Port convention as
// matchSnapshot.ts's MatchSnapshotPort / efootballContext.ts's
// EfootballContextPort): AnalysisEventPersistencePort is a narrow,
// dependency-injectable view of the one write this module performs, so
// apps/worker/test/analysisEventPersistence.test.ts can exercise the
// validate-then-persist decision logic with a plain in-memory fake instead
// of a real Supabase/Postgres instance.

import {
  validateUnifiedFootballEventInput,
  readFootballMatchContext,
  toUnifiedFootballEvent,
  buildDecisionQualityFromUnifiedEvent,
  evaluateDecisionQualityEvidence,
  buildMomentExplanationFromUnifiedEvent,
  toMomentExplanationInsertRow,
} from "@efootball/shared";
import type {
  FootballMatchContext,
  AnalysisEvent,
  DecisionQuality,
  UnifiedFootballEvent,
  MomentExplanationInsertRow,
  MomentExplanationContext,
} from "@efootball/shared";
// 10K — reused, not re-derived: builds the SAME event's tactical/spatial
// MomentExplanationContext from the tactical_analysis data the caller
// already generated (see analysisEngine.ts's own header comment for the
// full "never fabricate or infer" selection rule this applies).
import { buildEventTacticalContext, type TacticalAnalysisSnapshot } from "./analysisEngine";

export { readFootballMatchContext };
export type { FootballMatchContext, DecisionQuality };
export type { TacticalAnalysisSnapshot } from "./analysisEngine";

export interface AnalysisEventOwnershipContext {
  /** Already ownership-verified by the calling job — see either job's own
   * "Part K" comment. Never re-derived from `draft`. */
  matchId: string;
  userId: string;
  /** Read off the SAME matches row each job already fetches for its
   * ownership check (football_type/team_size) — straight from the
   * database, never client-supplied. `null` for a legacy match whose
   * football_type column is NULL. */
  footballContext: FootballMatchContext | null;
  /** Already resolved by the caller via resolveEventSelfPlayerId
   * (eventLinking.ts, unchanged) — always scoped to `userId`. See this
   * file's header comment ("why player resolution stays a caller
   * concern"). Never taken from `draft`/client input. */
  playerId: string | null;
}

/** Narrow, dependency-injectable view of exactly the write this module
 * performs. A real implementation is backed by `supabaseAdmin`
 * (createSupabaseAnalysisEventPersistencePort below); tests supply a plain
 * in-memory fake. */
export interface AnalysisEventPersistencePort {
  /** Upserts one analysis_events row keyed on (match_id, dedupe_key) — the
   * exact pre-existing idempotent upsert (migration 0005), untouched by
   * this file. Returns the persisted row's id and its real, persisted
   * `created_at` (the same column `.select()` already reads back from
   * the upsert below — not a new query) so callers never need to
   * fabricate a placeholder value for it. */
  upsertEvent(row: Record<string, unknown>): Promise<{ id: string; created_at: string }>;
}

/** Deliberately NOT imported statically at module load time (a static
 * import is resolved the moment this module loads, regardless of whether
 * it's ever used) — same reasoning, same lazy-dynamic-import pattern, as
 * matchSnapshot.ts's createSupabaseMatchSnapshotPort: importing this file
 * from a test that always supplies its own fake port must never require
 * apps/worker/src/supabaseClient.ts's own required environment variables
 * to be set. */
function createSupabaseAnalysisEventPersistencePort(): AnalysisEventPersistencePort {
  return {
    async upsertEvent(row) {
      const { supabaseAdmin } = await import("./supabaseClient");
      const { data, error } = await supabaseAdmin
        .from("analysis_events")
        .upsert(row, { onConflict: "match_id,dedupe_key" })
        .select()
        .single();
      if (error || !data) throw error ?? new Error("Failed to insert analysis event");
      return { id: data.id as string, created_at: data.created_at as string };
    },
  };
}

// 10J-2 — persists the existing 10H MomentExplanation (via 10J-1's own
// pure toMomentExplanationInsertRow builder) into the existing
// moment_explanations table (migration 0030) as part of this SAME
// analysis-event write path, immediately after the row above is
// upserted. REUSE, NOT REDESIGN:
//   * MomentExplanation itself is built exactly as 10H already
//     specifies — buildMomentExplanationFromUnifiedEvent, called on the
//     SAME `unifiedEvent` this function already derives for 10G-3's
//     decisionQuality below (never a second, independent
//     UnifiedFootballEvent derivation).
//   * The row shape and the "no match_id -> nothing valid to persist"
//     guard are exactly 10J-1's own toMomentExplanationInsertRow — this
//     file adds no field mapping of its own.
//   * football_type/match_id/event_id on the persisted row are exactly
//     the same server-resolved values already used above for
//     validation/decisionQuality (ownership.footballContext,
//     ownership.matchId, persisted.id) — never re-read from `draft`.
//   * INSUFFICIENT EVIDENCE -> NULL: buildMomentExplanationFromUnifiedEvent
//     itself already nulls every evidence-gated field
//     (better_option/why_better/actionable_improvement) when evidence is
//     insufficient (10H's own contract) — this file does not add a
//     second, looser gate; the row is still persisted (with
//     has_sufficient_evidence: false and those fields null), exactly
//     what migration 0030's own nullable-column design expects.
//   * NEVER OVERWRITE A HISTORICAL EXPLANATION / IDEMPOTENT UNDER RETRY:
//     the real port below inserts with
//     onConflict: "match_id,event_id", ignoreDuplicates: true — an
//     INSERT ... ON CONFLICT DO NOTHING against
//     moment_explanations_match_event_uniq (0030). A retried job that
//     re-runs this same event therefore leaves the first-ever persisted
//     explanation untouched rather than recomputing/overwriting it.
//   * PERSISTENCE FAILURE NEVER FAILS THE ANALYSIS: exactly the same
//     "wrap in try/catch, log, never throw" contract as
//     matchSnapshot.ts's triggerMatchSnapshotOnCompletion — a genuine
//     database error persisting the explanation is logged and swallowed
//     here, so it can never turn this function's own `valid: true`
//     result into a thrown error / failed job.
//   * NO AI CALLS, NO NEW TABLE, NO SNAPSHOT-BEHAVIOR CHANGE: this only
//     ever reads the already-built `unifiedEvent` and writes to the
//     already-existing moment_explanations table; matchSnapshot.ts and
//     match_snapshots are untouched.

/** Narrow, dependency-injectable view of exactly the write 10J-2 needs —
 * same Port convention as AnalysisEventPersistencePort above and
 * matchSnapshot.ts's own MatchSnapshotPort, so the persist-or-skip
 * decision logic here is testable with a plain in-memory fake instead of
 * a real Supabase/Postgres instance. */
export interface MomentExplanationPersistencePort {
  /** Inserts one moment_explanations row UNLESS one already exists for
   * this (match_id, event_id) — an INSERT ... ON CONFLICT DO NOTHING
   * against moment_explanations_match_event_uniq (0030), never an
   * UPDATE. Must not throw for "a row already existed" (that is the
   * expected, idempotent no-op outcome of a retry) — only for a genuine
   * database error. */
  insertIfAbsent(row: MomentExplanationInsertRow): Promise<void>;
}

/** Deliberately NOT imported statically at module load time — same lazy
 * dynamic-import reasoning as createSupabaseAnalysisEventPersistencePort
 * above and matchSnapshot.ts's own createSupabaseMatchSnapshotPort. */
function createSupabaseMomentExplanationPersistencePort(): MomentExplanationPersistencePort {
  return {
    async insertIfAbsent(row) {
      const { supabaseAdmin } = await import("./supabaseClient");
      const { error } = await supabaseAdmin
        .from("moment_explanations")
        .upsert(row, { onConflict: "match_id,event_id", ignoreDuplicates: true });
      if (error) throw error;
    },
  };
}

/**
 * Builds and persists the MomentExplanation for one already-built
 * UnifiedFootballEvent (see file header, 10J-2) — best-effort, never
 * throws. Skips persistence entirely (no error) when
 * toMomentExplanationInsertRow reports there is no valid row to build
 * (explanation.match_id === null, per 10J-1's own contract).
 *
 * `momentContext` (10K) is this SAME event's own tactical/spatial
 * MomentExplanationContext (see buildEventTacticalContext,
 * analysisEngine.ts) — `{}` (10H's own unchanged default) when the
 * caller supplied no tactical_analysis data for this event, exactly the
 * pre-10K behavior.
 */
async function persistMomentExplanationSafely(
  unifiedEvent: UnifiedFootballEvent,
  momentContext: MomentExplanationContext,
  port?: MomentExplanationPersistencePort
): Promise<void> {
  try {
    const explanation = buildMomentExplanationFromUnifiedEvent(unifiedEvent, momentContext);
    const row = toMomentExplanationInsertRow(explanation);
    if (row === null) return;

    const p = port ?? createSupabaseMomentExplanationPersistencePort();
    await p.insertIfAbsent(row);
  } catch (err) {
    // Same "log safely, never throw" convention as matchSnapshot.ts's own
    // trailing catch block (spec — "persistence failure must not falsely
    // mark analysis as failed").
    console.error(
      `[analysisEventPersistence] failed to persist moment explanation for event ${unifiedEvent.id}:`,
      (err as Error)?.message ?? err
    );
  }
}

export type ValidateAndPersistAnalysisEventResult =
  | {
      valid: true;
      playerId: string | null;
      eventId: string;
      /** 10G-3 — the same evidence-gated logic 10G-2 already built
       * (evaluateDecisionQualityEvidence), applied to the record 10G-1's
       * own builder (buildDecisionQualityFromUnifiedEvent) derives from
       * this persisted row. Never a second, independent derivation: this
       * is exactly `decisionQuality.ts`/`decisionQualityEvidence.ts`,
       * called with the row/context this function already has.
       * Non-null ONLY when evaluateDecisionQualityEvidence reports
       * `has_sufficient_evidence: true` for the built record — "sufficient
       * evidence -> DecisionQuality, insufficient evidence -> null" (spec).
       * Also null when the row's own event_type has no unified mapping
       * (toUnifiedFootballEvent's own defensive branch — nothing to build
       * a DecisionQuality record from). */
      decisionQuality: DecisionQuality | null;
    }
  | { valid: false; playerId: string | null; errors: string[] };

/**
 * 10K AI-call-ordering fix — the SAME validateUnifiedFootballEventInput
 * gate validateAndPersistAnalysisEvent runs internally (below), extracted
 * into its own pure, I/O-free, exported check. This lets a caller confirm
 * a draft is going to be accepted BEFORE spending an AI call
 * (ai.generateTacticalAnalysis) on it, without duplicating or
 * loosening the gate itself — validateAndPersistAnalysisEvent calls this
 * exact function too, so there is exactly one place this decision is
 * made, just two call sites for it.
 *
 * WHY THIS EXISTS: 10K moved ai.generateTacticalAnalysis(...) earlier in
 * both processMatchVideo.ts's persistEvent() and processScreenshot.ts's
 * event loop — before validateAndPersistAnalysisEvent — purely so its
 * result could be handed into validateAndPersistAnalysisEvent's own
 * `tacticalAnalysis` param (see that param's doc comment). That reorder
 * had an unintended side effect: a draft that validateAndPersistAnalysisEvent
 * was always going to reject now burned a tactical-analysis AI call
 * first, for nothing. Both jobs now call this function first and only
 * call generateTacticalAnalysis when it reports `valid: true` — the AI
 * call itself, validateAndPersistAnalysisEvent's own persistence/
 * ownership/idempotency/retry behavior, and the one-call-per-valid-event
 * invariant are all otherwise unchanged.
 */
export function validateAnalysisEventDraft(
  ownership: AnalysisEventOwnershipContext,
  draft: Record<string, any>
): { valid: true } | { valid: false; errors: string[] } {
  const validation = validateUnifiedFootballEventInput(draft, {
    footballContext: ownership.footballContext,
    ownership: {
      matchId: ownership.matchId,
      userId: ownership.userId,
      player: ownership.playerId ? { id: ownership.playerId, user_id: ownership.userId } : null,
    },
  });
  return validation.valid ? { valid: true } : { valid: false, errors: validation.errors };
}

/**
 * The one shared write-path gate for an analysis_events row — called by
 * both processMatchVideo.ts's persistEvent() and processScreenshot.ts's own
 * event loop immediately where each previously called
 * `supabaseAdmin.from("analysis_events").upsert(...)` directly.
 *
 * `eventFields` is the exact analysis_events column payload the caller
 * already builds (timestamp_seconds, event_type, category, severity,
 * decision_score, confidence, confidence_level, description, better_option,
 * reasoning, context_start_seconds, context_end_seconds, ...) — UNCHANGED
 * from what each job already wrote before this fix. `match_id` and
 * `player_id` must NOT be included in it: this function injects both
 * itself, server-side, spread in AFTER `eventFields` so nothing
 * `eventFields` might contain (accidentally or otherwise) can ever
 * override either value.
 *
 * `draft` is the raw (untrusted) AI-produced event draft, passed straight
 * to validateUnifiedFootballEventInput exactly as-is — used only for
 * validation, never for the persisted row's own field values (those come
 * from `eventFields`) and never to resolve player ownership (that is
 * `ownership.playerId`, already resolved by the caller).
 */
export async function validateAndPersistAnalysisEvent(
  ownership: AnalysisEventOwnershipContext,
  draft: Record<string, any>,
  eventFields: Record<string, unknown>,
  port?: AnalysisEventPersistencePort,
  momentExplanationPort?: MomentExplanationPersistencePort,
  /** 10K — this SAME event's own already-generated tactical_analysis
   * data (the exact object ai.generateTacticalAnalysis already returned
   * to the caller, before this file existed — see processMatchVideo.ts's
   * persistEvent / processScreenshot.ts for the call-site reordering that
   * makes it available here). Optional and additive: omitted (or null),
   * this function behaves exactly as it did before 10K —
   * buildEventTacticalContext itself already returns `{}` for that case,
   * so the persisted MomentExplanation's positions/passing_lane/space
   * stay null, unchanged. Never a second AI call — see analysisEngine.ts's
   * own header comment ("AI/PROVIDER BEHAVIOR UNCHANGED"). */
  tacticalAnalysis?: TacticalAnalysisSnapshot | null
): Promise<ValidateAndPersistAnalysisEventResult> {
  const p = port ?? createSupabaseAnalysisEventPersistencePort();

  // Batch 10D fix — the gate the audit found missing. Runs in addition to
  // (never instead of) validateDetectedEventDraft, which
  // filterValidDetectedEventDrafts already ran on `draft` before this
  // function is ever called. Delegates to validateAnalysisEventDraft
  // (above) so this decision is made in exactly one place, whether a
  // caller pre-checks it before an AI call or not.
  const validation = validateAnalysisEventDraft(ownership, draft);

  if (!validation.valid) {
    return { valid: false, playerId: ownership.playerId, errors: validation.errors };
  }

  const persisted = await p.upsertEvent({
    ...eventFields,
    match_id: ownership.matchId,
    player_id: ownership.playerId,
  });

  // 10G-3 — reuse 10G-1/10G-2's existing DecisionQuality/evidence logic
  // on this same persisted row, rather than re-deriving anything.
  //
  // Builds the exact row shape toUnifiedFootballEvent (10D) expects from
  // the values already established above: `eventFields` (unchanged from
  // what the caller already wrote), plus the same server-resolved
  // match_id/player_id injected into the upsert, plus the id/created_at
  // the upsert just returned. `created_at` is the row's own real,
  // persisted timestamp (AnalysisEventPersistencePort.upsertEvent's own
  // `.select()` already reads it back — no new query) — never a
  // fabricated placeholder.
  //
  // 10K fix (pre-existing defect surfaced while wiring this batch's own
  // integration tests, not a 10K behavior change): `eventFields` — from
  // either real call site (processMatchVideo.ts's persistEvent /
  // processScreenshot.ts) — has never included a `statistics_evidence`
  // key (that column is only populated afterwards, by
  // linkStatisticsEvidenceForMatch), so the spread above left
  // `persistedRow.statistics_evidence` genuinely `undefined` rather than
  // `AnalysisEvent`'s own declared `string[] | null` — the `as` cast
  // above only tells the type-checker to trust that shape, it doesn't
  // make it true at runtime. buildDecisionQualityFromUnifiedEvent's own
  // `event.evidence !== null && event.evidence.length > 0` then threw on
  // `undefined.length` for every event reaching this line — i.e. this
  // path could not run in practice before this fix. Explicitly
  // normalized to `null` (never fabricated) whenever `eventFields` did
  // not itself carry the key, matching what a fresh row genuinely has
  // before that later step ever runs.
  const persistedRow: AnalysisEvent = {
    ...(eventFields as Omit<AnalysisEvent, "id" | "match_id" | "player_id" | "created_at">),
    id: persisted.id,
    match_id: ownership.matchId,
    player_id: ownership.playerId,
    created_at: persisted.created_at,
    statistics_evidence:
      (eventFields as { statistics_evidence?: string[] | null }).statistics_evidence ?? null,
  };

  // toUnifiedFootballEvent returns null only when the row's own
  // event_type has no unified mapping (its own defensive branch) — there
  // is then nothing to build a DecisionQuality record from.
  const unifiedEvent = toUnifiedFootballEvent(persistedRow, ownership.footballContext);
  const decisionQualityRecord =
    unifiedEvent !== null ? buildDecisionQualityFromUnifiedEvent(unifiedEvent) : null;

  // Evidence-gated per 10G-2: sufficient evidence -> the DecisionQuality
  // record itself; insufficient evidence -> null. Never a partial/default
  // grade (see evaluateDecisionQualityEvidence's own doc comment).
  const decisionQuality =
    decisionQualityRecord !== null &&
    evaluateDecisionQualityEvidence(decisionQualityRecord).has_sufficient_evidence
      ? decisionQualityRecord
      : null;

  // 10J-2 — persist the existing 10H MomentExplanation for this SAME
  // unifiedEvent (see this file's own header comment above
  // ValidateAndPersistAnalysisEventResult for the full design). Best
  // effort: never throws, never overwrites a historical row, and is
  // skipped entirely when there is no unifiedEvent to build one from
  // (unmapped event_type — nothing to build an explanation from either).
  //
  // 10K — momentContext attaches this SAME event's own tactical/spatial
  // data (10E/10F), built via analysisEngine.ts's own
  // buildEventTacticalContext from the `tacticalAnalysis` snapshot the
  // caller optionally supplied above. `unifiedEvent.id`/`timestamp_seconds`
  // are reused verbatim (never re-derived) as the tactical context's own
  // eventId/timestampSeconds, and `ownership.footballContext`/
  // `ownership.matchId` are the exact same server-resolved values already
  // used for validation/decisionQuality above. When `tacticalAnalysis` is
  // omitted, buildEventTacticalContext returns `{}` — identical to the
  // pre-10K call (positions/passing_lane/space stay null).
  if (unifiedEvent !== null) {
    const momentContext = buildEventTacticalContext(tacticalAnalysis, {
      footballType: ownership.footballContext?.football_type ?? null,
      matchId: ownership.matchId,
      eventId: unifiedEvent.id,
      timestampSeconds: unifiedEvent.timestamp_seconds,
    });
    await persistMomentExplanationSafely(unifiedEvent, momentContext, momentExplanationPort);
  }

  return { valid: true, playerId: ownership.playerId, eventId: persisted.id, decisionQuality };
}
