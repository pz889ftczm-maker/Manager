// Batch 10B — eFootball Context: the server-side accessor that lets
// the analysis pipeline OBTAIN an EfootballMatchContext for a match
// (spec section 6), backed by real Supabase reads. All of the actual
// assembly/gating/never-fabricate logic lives in packages/shared/src/
// efootballMatchContext.ts's buildEfootballMatchContext — this file's
// only job is (a) reading exactly the rows that function needs,
// (b) enforcing ownership before any of them are used, and (c) never
// reading more than the current match's own football_type actually
// requires (spec section 5 — "avoid unnecessary database calls").
//
// SAME PORT PATTERN AS matchSnapshot.ts (spec section 7 — server-side
// only, no client-supplied Player/Manager/Formation ever trusted as
// historical truth): a narrow, dependency-injectable interface
// (EfootballContextPort) with a real Supabase-service-role-backed
// implementation, and a public function
// (getEfootballMatchContext) that a job/edge function calls with a
// matchId + the ALREADY-TRUSTED userId it resolved for itself (see
// matchSnapshot.ts's own header comment on why that value is never
// re-derived here) — mirrored exactly, not reinvented.
//
// OWNERSHIP (spec section 7 — "If a context builder accepts matchId,
// verify ownership before returning data"): getEfootballMatchContext
// reads the match row's own user_id and compares it against the
// caller-supplied userId BEFORE doing anything else with that row —
// including before even checking football_type. A mismatch throws
// (never silently returns an "unavailable" result that could be
// confused with "this match legitimately has no eFootball context"),
// exactly like a caller-side bug this file wants loud, not swallowed.
//
// GATING SHORT-CIRCUIT (spec section 5 — avoid unnecessary DB calls):
// the match row alone (already fetched for the ownership check) is
// enough to decide football_type via
// footballMatchContext.ts#readFootballMatchContext. When that's not
// "efootball" (real_football, or legacy NULL), this file returns
// immediately WITHOUT ever querying match_snapshots or any Team/
// Formation/Manager/Player table — there is nothing an eFootball-only
// context could show for that match regardless of what those tables
// contain.
//
// LIVE-DATA OWNERSHIP DEFENSE-IN-DEPTH (audit fix, no redesign): the
// ownership check above covers the match row itself, but
// getLiveData's real, service-role-backed implementation
// (createSupabaseEfootballContextPort below) reads team_library/
// team_formations/manager_library/team_formation_players+player_library
// directly with a client that bypasses RLS entirely — RLS is exactly
// what would normally stop a cross-user read of those tables. Rather
// than trust matches.team_id/formation_id to already be
// consistent, getLiveData now explicitly re-verifies, itself, that the
// team/formation/manager/every assigned player it just read actually
// belongs to the caller's own userId, via assertEfootballLiveOwnership
// (defined next to EfootballContextPort below) — the same four checks,
// same ordering, as public.create_match_snapshot's own SECURITY
// DEFINER ownership checks (migration 0026), just re-verified
// TypeScript-side since this read path has no such database-level
// boundary under it. A mismatch throws EfootballContextIntegrityError
// (same "loud, never silently swallowed" convention as
// EfootballContextOwnershipError above) — never a fabricated/partial
// substitute and never another user's row.
//
// HISTORICAL-FIRST (spec section 2): match_snapshots is always read
// before any live Team/Formation/Manager/Player table, and — per
// buildEfootballMatchContext's own contract — is used EXCLUSIVELY
// when found. getLiveData is only ever invoked when getSnapshot
// returned null.
//
// NO NEW AI CALL, NO PIPELINE BEHAVIOR CHANGE (spec section 6): this
// file makes no call into @efootball/ai and is not invoked from
// anywhere yet — it is exported, tested, and ready for a later phase
// (10C+, explicitly out of scope here) to call from
// processMatchVideo.ts/processScreenshot.ts or the AI provider layer.
// Adding that call site now, before anything actually consumes the
// result, would be exactly the "unnecessary database call" spec
// section 5 warns against for every match analyzed in the meantime.

import {
  readFootballMatchContext,
  buildEfootballMatchContext,
  selectMatchSnapshotForMatch,
  type EfootballMatchContextResult,
  type EfootballContextLiveSource,
} from "@efootball/shared";
import type { MatchSnapshot, MatchSnapshotPlayer } from "@efootball/shared";

/** Narrow, dependency-injectable view of exactly the reads
 * getEfootballMatchContext needs — same reasoning as
 * matchSnapshot.ts's own MatchSnapshotPort: tests supply a plain
 * in-memory fake so this file's own ownership/gating/historical-first
 * decision logic can be exercised without a real Supabase/Postgres
 * instance. */
export interface EfootballContextPort {
  /** Reads the authoritative current state of a match row needed to
   * decide ownership, football_type, and which Team/Formation to read
   * live data from if no snapshot exists. Returns null if the match no
   * longer exists. */
  getMatch(matchId: string): Promise<{
    user_id: string;
    football_type: string | null;
    team_size: number | null;
    team_id: string | null;
    formation_id: string | null;
  } | null>;
  /** Reads the most recent existing match_snapshots row for this match
   * (Batch 9A/9D — via selectMatchSnapshotForMatch, never re-derived
   * here) plus its match_snapshot_players rows. Returns null when this
   * match has no snapshot at all — a normal, expected state. */
  getSnapshot(
    matchId: string
  ): Promise<{ snapshot: MatchSnapshot; players: MatchSnapshotPlayer[] } | null>;
  /** Reads the CURRENT Formation/Manager/roster for a team, used only
   * when getSnapshot returned null (see file header comment).
   * `formationId` is null when the match has a team but no formation
   * selected — implementations must not fabricate one. `userId` is the
   * same already-trusted value getEfootballMatchContext itself was
   * called with (never re-derived here) — a real implementation MUST
   * verify every row it reads actually belongs to this user before
   * returning it, since a service-role client bypasses RLS entirely
   * (see assertEfootballLiveOwnership below), and must throw rather
   * than silently return another user's data or a fabricated
   * substitute. */
  getLiveData(args: { teamId: string; formationId: string | null; userId: string }): Promise<EfootballContextLiveSource>;
}

/** Thrown by assertEfootballLiveOwnership (used only by
 * createSupabaseEfootballContextPort's own getLiveData below) when a
 * row the service-role client just read does NOT actually belong to
 * the requesting user — e.g. matches.team_id pointing at another
 * user's team_library row, matches.formation_id pointing at a
 * formation belonging to a different team, a team's manager_id
 * pointing at another user's manager_library row, or a
 * team_formation_players assignment whose player_library row belongs
 * to someone else.
 *
 * This should never happen in ordinary operation — the
 * ownership-checked write path that populates matches.team_id/
 * formation_id (analysis-enqueue's own claim update) and the
 * ownership-consistency triggers on team_library/team_formations/
 * team_formation_players (migrations 0020/0022) already guarantee it
 * — but the client this file's real port uses is the service-role
 * client, which bypasses RLS (and therefore every RLS-enforced
 * ownership policy) entirely. This is re-verified here anyway as
 * defense-in-depth, mirroring the same four checks (and the same
 * ordering) public.create_match_snapshot's own SECURITY DEFINER
 * function already performs in migration 0026 — just re-implemented
 * TypeScript-side, since there is no SECURITY DEFINER boundary on this
 * particular read path.
 *
 * A distinct exported class (same convention as
 * EfootballContextOwnershipError below) rather than a generic Error,
 * so a caller/test can recognize this specific failure without
 * string-matching a message. The message itself carries only a reason
 * code — never the mismatched row's own id or actual owner — so no
 * internal database detail is ever exposed through it. */
export type EfootballContextIntegrityReason =
  | "team_ownership_invalid"
  | "formation_ownership_invalid"
  | "manager_ownership_invalid"
  | "player_ownership_invalid";

export class EfootballContextIntegrityError extends Error {
  readonly reason: EfootballContextIntegrityReason;
  constructor(reason: EfootballContextIntegrityReason) {
    super(`efootball_context: live data failed an ownership/integrity check (${reason})`);
    this.name = "EfootballContextIntegrityError";
    this.reason = reason;
  }
}

/**
 * The actual defense-in-depth check (see EfootballContextIntegrityError
 * above for why it exists). Given exactly the rows
 * createSupabaseEfootballContextPort's own getLiveData just read —
 * never a matchId/query of its own — this is pure and dependency-free
 * (same convention as packages/shared/src/efootballMatchContext.ts's
 * own buildEfootballMatchContext), so it's directly testable with
 * plain fabricated rows, no Supabase/Postgres instance required.
 *
 * Throws EfootballContextIntegrityError unless every one of the
 * following holds (spec — "the service-role-backed live-data accessor
 * must explicitly verify ownership because service-role queries
 * bypass RLS"):
 *
 *   1. `team` (the team_library row for teamId) exists, and its own
 *      user_id equals `userId`.
 *   2. When `formationId` is not null, `formation` (the
 *      team_formations row for formationId) exists, and its own
 *      team_id equals `teamId` — never merely "some formation exists
 *      with this id", since a formation that exists but belongs to a
 *      DIFFERENT team is exactly the gap this check closes.
 *   3. When `team.manager_id` is not null, `manager` (the
 *      manager_library row for that id) exists, and its own user_id
 *      equals `userId`.
 *   4. When `formationId` is not null, every entry in `players` (one
 *      per team_formation_players row the caller already scoped to
 *      formationId with its own query) carries a `player_library` row
 *      whose user_id equals `userId`. A missing join (no such
 *      player_library row at all) is treated exactly like a mismatched
 *      one — rejecting the whole read, never silently narrowing to a
 *      partial player list (never fabricate / never silently drop —
 *      same reasoning as create_match_snapshot's own
 *      v_total_assigned <> v_owned_assigned check in migration 0026).
 *
 * Never mutates or reads anything itself, and never returns a value —
 * the caller remains solely responsible for fetching these rows and
 * for propagating this throw rather than swallowing it.
 */
export function assertEfootballLiveOwnership(args: {
  userId: string;
  teamId: string;
  formationId: string | null;
  team: { user_id: string; manager_id: string | null } | null;
  formation: { team_id: string } | null;
  manager: { user_id: string } | null;
  players: ReadonlyArray<{ player_library: { user_id: string } | null }>;
}): void {
  const { userId, teamId, formationId, team, formation, manager, players } = args;

  if (!team || team.user_id !== userId) {
    throw new EfootballContextIntegrityError("team_ownership_invalid");
  }

  if (formationId !== null && (!formation || formation.team_id !== teamId)) {
    throw new EfootballContextIntegrityError("formation_ownership_invalid");
  }

  if (team.manager_id !== null && (!manager || manager.user_id !== userId)) {
    throw new EfootballContextIntegrityError("manager_ownership_invalid");
  }

  if (formationId !== null) {
    for (const { player_library } of players) {
      if (!player_library || player_library.user_id !== userId) {
        throw new EfootballContextIntegrityError("player_ownership_invalid");
      }
    }
  }
}

/** Real, production implementation of EfootballContextPort, backed by
 * the worker's own service-role client — same lazy dynamic-import
 * pattern as matchSnapshot.ts's own createSupabaseMatchSnapshotPort
 * (so importing this file never requires SUPABASE_URL/
 * SUPABASE_SERVICE_ROLE_KEY to be set unless this real port is
 * actually constructed). */
async function createSupabaseEfootballContextPort(): Promise<EfootballContextPort> {
  const { supabaseAdmin } = await import("./supabaseClient");
  return {
    async getMatch(matchId) {
      const { data, error } = await supabaseAdmin
        .from("matches")
        .select("user_id, football_type, team_size, team_id, formation_id")
        .eq("id", matchId)
        .maybeSingle();
      if (error) throw error;
      if (!data) return null;
      return {
        user_id: data.user_id as string,
        football_type: (data.football_type as string | null) ?? null,
        team_size: (data.team_size as number | null) ?? null,
        team_id: (data.team_id as string | null) ?? null,
        formation_id: (data.formation_id as string | null) ?? null,
      };
    },
    async getSnapshot(matchId) {
      const { data: snapshotRows, error: snapshotError } = await supabaseAdmin
        .from("match_snapshots")
        .select("*")
        .eq("match_id", matchId);
      if (snapshotError) throw snapshotError;

      const snapshot = selectMatchSnapshotForMatch((snapshotRows as MatchSnapshot[]) ?? [], matchId);
      if (!snapshot) return null;

      const { data: playerRows, error: playersError } = await supabaseAdmin
        .from("match_snapshot_players")
        .select("*")
        .eq("snapshot_id", snapshot.id);
      if (playersError) throw playersError;

      return { snapshot, players: (playerRows as MatchSnapshotPlayer[]) ?? [] };
    },
    async getLiveData({ teamId, formationId, userId }) {
      const { data: teamRow, error: teamError } = await supabaseAdmin
        .from("team_library")
        .select("user_id, manager_id")
        .eq("id", teamId)
        .maybeSingle();
      if (teamError) throw teamError;

      const team = teamRow
        ? { user_id: teamRow.user_id as string, manager_id: (teamRow.manager_id as string | null) ?? null }
        : null;
      const managerId = team?.manager_id ?? null;
      const managerPromise = managerId
        ? supabaseAdmin.from("manager_library").select("*").eq("id", managerId).maybeSingle()
        : Promise.resolve({ data: null, error: null });

      const formationPromise = formationId
        ? supabaseAdmin.from("team_formations").select("*").eq("id", formationId).maybeSingle()
        : Promise.resolve({ data: null, error: null });

      const playersPromise = formationId
        ? supabaseAdmin
            .from("team_formation_players")
            .select("position_slot, player_library(*)")
            .eq("formation_id", formationId)
        : Promise.resolve({ data: [], error: null });

      const [{ data: managerRow, error: managerError }, { data: formationRow, error: formationError }, { data: playerRows, error: playersError }] =
        await Promise.all([managerPromise, formationPromise, playersPromise]);
      if (managerError) throw managerError;
      if (formationError) throw formationError;
      if (playersError) throw playersError;

      const players = (playerRows as { position_slot: string; player_library: unknown }[]) ?? [];

      // Defense-in-depth ownership/integrity check (see
      // assertEfootballLiveOwnership above): this port uses the
      // service-role client, which bypasses RLS entirely, so every row
      // just read is verified against `userId`/`teamId` here — once,
      // before any of it is returned — rather than trusted as-is.
      assertEfootballLiveOwnership({
        userId,
        teamId,
        formationId,
        team,
        formation: (formationRow as { team_id: string } | null) ?? null,
        manager: (managerRow as { user_id: string } | null) ?? null,
        players: players.map((row) => ({ player_library: row.player_library as { user_id: string } | null })),
      });

      return {
        formation: (formationRow as EfootballContextLiveSource["formation"]) ?? null,
        manager: (managerRow as EfootballContextLiveSource["manager"]) ?? null,
        players: players
          .filter((row) => row.player_library)
          .map((row) => ({
            position_slot: row.position_slot,
            player: row.player_library as EfootballContextLiveSource["players"][number]["player"],
          })),
      };
    },
  };
}

/** Thrown when the match's own user_id does not match the caller-
 * supplied userId (spec section 7 — ownership must be verified before
 * any data is returned). Deliberately a distinct exported class rather
 * than a generic Error so a caller/test can recognize this specific
 * failure without string-matching a message. */
export class EfootballContextOwnershipError extends Error {
  constructor(matchId: string) {
    super(`efootball_context: match ${matchId} does not belong to the requesting user`);
    this.name = "EfootballContextOwnershipError";
  }
}

/**
 * Reads and assembles the EfootballMatchContext for `matchId`, for the
 * pipeline (or a later Football Analysis Engine phase) to consume
 * (spec section 6). `userId` must already be a trusted, server-
 * resolved value (exactly like matchSnapshot.ts's own
 * triggerMatchSnapshotOnCompletion contract) — this function re-checks
 * it against the match row's own user_id but never resolves it itself
 * from a request/session.
 *
 * Returns `{ available: false, reason: "unknown_football_type" }` when
 * the match itself no longer exists — same "absent context, not an
 * error" treatment football_type=NULL already gets, since there is
 * nothing to distinguish a deleted match from one that never had
 * football_type set.
 */
export async function getEfootballMatchContext(
  matchId: string,
  userId: string,
  port?: EfootballContextPort
): Promise<EfootballMatchContextResult> {
  const p = port ?? (await createSupabaseEfootballContextPort());

  const match = await p.getMatch(matchId);
  if (!match) {
    return { available: false, reason: "unknown_football_type" };
  }

  // Ownership FIRST (spec section 7) — before football_type is even
  // inspected, let alone any snapshot/live table is read.
  if (match.user_id !== userId) {
    throw new EfootballContextOwnershipError(matchId);
  }

  const footballContext = readFootballMatchContext({
    football_type: match.football_type,
    team_size: match.team_size,
  });

  // Gating short-circuit (spec section 5): a real_football or legacy
  // NULL match can never have eFootball context, so don't spend a
  // single extra query finding that out — buildEfootballMatchContext
  // (given no sources) returns exactly the same result this early
  // return would, so this is a pure performance short-circuit, not a
  // second copy of the gating rule.
  if (footballContext?.football_type !== "efootball") {
    return buildEfootballMatchContext(footballContext, { snapshot: null, live: null });
  }

  const snapshot = await p.getSnapshot(matchId);
  if (snapshot) {
    return buildEfootballMatchContext(footballContext, { snapshot, live: null });
  }

  // No snapshot yet — fall back to the CURRENT Team/Formation/Manager/
  // Player Library data, but only if this match even has a team
  // attached (matches.team_id, migration 0028); otherwise there is
  // nothing live to read either (spec section 4 — never fabricate a
  // Team/Formation just because football_type is "efootball").
  const live = match.team_id
    ? await p.getLiveData({ teamId: match.team_id, formationId: match.formation_id, userId })
    : null;
  return buildEfootballMatchContext(footballContext, { snapshot: null, live });
}
