// Batch 10K — Analysis Engine Integration ONLY. Connects the existing
// 10A–10J analysis models/logic to the existing worker analysis pipeline.
// This file adds NO new model, NO new database table, and NO new AI call
// — it only wires already-built, already-tested pieces together at the
// two points the spec calls out as still missing a real caller:
//
//   1. TacticalPosition (10E) / PassingLane / Space (10F) were never
//      actually attached to the MomentExplanation (10H) that
//      analysisEventPersistence.ts (10G-3/10J-2) already builds and
//      persists for every event — buildMomentExplanationFromUnifiedEvent
//      was always called with no context, so `positions`/`passing_lane`/
//      `space` were null on every persisted row (see that file's own
//      10J-2 "Out of scope" note). buildEventTacticalContext below closes
//      that gap using the SAME tactical_analysis data the worker already
//      generates via ai.generateTacticalAnalysis — no new AI call, no
//      second read of anything.
//   2. FullMatchContext (10I), and its persisted-explanation-aware
//      reconstruction (10J-3's buildFullMatchContextWithPersistedExplanations),
//      were pure functions with no real Supabase-backed caller anywhere
//      in this codebase (see fullMatchContext.ts's own 10J-3 header note
//      and momentExplanationPersistence.ts's own 10J-1 "Out of scope"
//      note — both explicitly deferred "an actual Supabase read
//      path/worker wiring" to a later batch). getFullMatchContextForMatch
//      / logFullMatchContextOnCompletion below are that wiring: a
//      read-only composition over the SAME analysis_events/
//      moment_explanations tables 10D/10J already read and write,
//      reusing 10J-1's own momentExplanationsByEventId row->model
//      builder rather than re-deriving one.
//
// REUSE, NOT REPLACEMENT / NO DUPLICATE MODELS (spec — "reuse
// UnifiedFootballEvent, TacticalPosition, PassingLane/Space,
// DecisionQuality + evidence logic, MomentExplanation, FullMatchContext;
// reuse existing persistence from 10J"): every function below is a thin
// composition over @efootball/shared's own exported builders —
// tacticalPositionStatesFromTacticalAnalysis (10E), passingLanesFromTacticalAnalysis
// / spacesFromTacticalAnalysis (10F), toUnifiedFootballEvent (10D),
// momentExplanationsByEventId (10J-1), buildFullMatchContextWithPersistedExplanations
// (10J-3). Nothing here redefines TacticalPosition, PassingLane, Space,
// DecisionQuality, MomentExplanation, or FullMatchContext, and nothing
// here re-implements 10G-1/10G-2's evidence-gating (buildMomentExplanationFromUnifiedEvent,
// called from analysisEventPersistence.ts exactly as it already was,
// still owns that).
//
// NEVER FABRICATE OR INFER (spec — the central rule of this batch):
// buildEventTacticalContext attaches a `positions`/`passingLane`/`space`
// value to a MomentExplanation ONLY when this event's own tactical_analysis
// data carries EXACTLY ONE candidate for that field. A tactical_analysis
// row's `actual_positions` array is a whole-team formation snapshot (one
// entry per player on the pitch), and its entries carry no player
// identity at all (see tacticalPosition.ts's own header comment —
// "tactical_analysis entries never carry a player reference"); with two
// or more candidates there is no evidence-based way to say WHICH one this
// specific moment's explanation is "about" without guessing, so this file
// applies no selection heuristic of its own and simply leaves the field
// null in that case — exactly the same "dropped rather than
// misattributed" contract momentExplanation.ts's own positionsMatchEvent
// already uses for a position sourced from a different event entirely.
// Zero candidates behaves identically to calling
// buildMomentExplanationFromUnifiedEvent with no context at all (10H's
// own, unchanged, default). This is a STRICTER rule than 10H's own
// event-id match check, never a looser one.
//
// EVIDENCE INSUFFICIENT -> NULL (spec): buildEventTacticalContext never
// looks at has_sufficient_evidence/DecisionQuality at all — positions/
// passing_lane/space are attached independently of evidence sufficiency,
// exactly as momentExplanation.ts's own header comment already documents
// (only better_option/why_better/actionable_improvement are evidence-
// gated). This file adds no second, looser or stricter evidence gate.
//
// PRESERVES EFOOTBALL / REAL FOOTBALL SEPARATION (spec) — WITHOUT
// cross-type branching: `footballType` is passed straight through from
// the caller's already-resolved FootballMatchContext (never re-derived,
// never inspected to change this file's own behavior), exactly the same
// convention every other 10-series file already follows.
//
// PRESERVES HISTORICAL SNAPSHOT PRECEDENCE (spec): getFullMatchContextForMatch
// never reads a MatchSnapshot or a live Team/Formation/Player row itself
// — it calls buildFullMatchContextWithPersistedExplanations with
// `efootball`/`realFootball` both omitted (null), which that function
// already treats as "no roster/team context supplied" (10I's own
// "insufficient data -> null" contract), never a fabricated value. Wiring
// actual roster/team context into this read path is unrelated to 10K's
// own "connect the existing 10A-10J analysis models/logic to the
// pipeline" scope and is left for a later batch (10L+).
//
// PRESERVES OWNERSHIP (spec): both new Supabase reads below are scoped to
// a single already-ownership-verified `matchId` — the exact same
// `ownership.matchId` value processMatchVideo.ts/processScreenshot.ts
// already resolved at their own "Part K" check before this file is ever
// called — never a client-supplied id. Like matchSnapshot.ts's own
// MatchSnapshotPort, this uses the worker's trusted service-role client
// (bypasses RLS by design, same as every other worker read/write); this
// file adds no new RLS policy and weakens none — analysis_events' and
// moment_explanations' own SELECT policies are untouched.
//
// PRESERVES IDEMPOTENCY (spec): buildEventTacticalContext is a pure,
// stateless function — it persists nothing itself. It only changes WHAT
// context is handed to the SAME persistMomentExplanationSafely
// (analysisEventPersistence.ts, 10J-2) call site that already owns the
// "insert once, never overwrite" contract (INSERT ... ON CONFLICT
// (match_id, event_id) DO NOTHING) — that contract is untouched here.
// getFullMatchContextForMatch/logFullMatchContextOnCompletion never write
// anything at all (read-only), so idempotency does not even apply to
// them.
//
// AI/PROVIDER BEHAVIOR UNCHANGED (spec): buildEventTacticalContext never
// calls an AI provider — it only re-shapes a TacticalAnalysisDraft the
// caller already obtained from ai.generateTacticalAnalysis (see
// processMatchVideo.ts's persistEvent / processScreenshot.ts, both
// updated by this batch only to pass that SAME already-computed object
// through to validateAndPersistAnalysisEvent — no second AI call is ever
// made for the same event).
//
// NO NEW DB TABLES (spec): getFullMatchContextForMatch reads the two
// tables that already exist for exactly this purpose (analysis_events,
// moment_explanations, migrations 0001/0030) and persists nothing.
// FullMatchContext itself continues to have no table of its own — 10I/
// 10J-1/10J-3's own "reconstruct, never persist" design is unchanged.
//
// NO SCOPE CREEP (explicitly out of scope for 10K, left to 10L+): no new
// HTTP/read API for FullMatchContext (logFullMatchContextOnCompletion is
// a best-effort internal completion hook, not a client-facing endpoint),
// no roster/team context wired into the read path (see "PRESERVES
// HISTORICAL SNAPSHOT PRECEDENCE" above), no Coach UI, no pipeline
// restructuring — the per-event loop and job stages in
// processMatchVideo.ts/processScreenshot.ts keep their existing shape;
// only the point at which an already-made AI call's result becomes
// available was moved earlier (see those files' own updated comments).

import {
  tacticalPositionStatesFromTacticalAnalysis,
  passingLanesFromTacticalAnalysis,
  spacesFromTacticalAnalysis,
  toUnifiedFootballEvent,
  momentExplanationsByEventId,
  buildFullMatchContextWithPersistedExplanations,
} from "@efootball/shared";
import type {
  FootballType,
  FootballMatchContext,
  AnalysisEvent,
  TacticalAnalysis,
  UnifiedFootballEvent,
  MomentExplanationContext,
  MomentExplanationRow,
  FullMatchContext,
} from "@efootball/shared";

// ============================================================
// 1. Per-event tactical/spatial context (10E/10F) -> MomentExplanationContext
// ============================================================

/** Exactly the tactical_analysis columns 10E/10F's own builders read —
 * the same shape ai.generateTacticalAnalysis already returns
 * (packages/ai's own TacticalAnalysisDraft = Omit<TacticalAnalysis, "id" |
 * "event_id" | "created_at">) and the same shape already spread into the
 * tactical_analysis upsert in both jobs. No new type is introduced on the
 * wire — this is a read-side Pick of the SAME table row shape
 * tacticalPosition.ts/passingLaneSpaceModel.ts already accept. */
export type TacticalAnalysisSnapshot = Pick<
  TacticalAnalysis,
  "actual_positions" | "recommended_positions" | "passing_lanes" | "open_spaces" | "pressure_zones" | "is_approximate"
>;

export interface EventTacticalContextInfo {
  footballType: FootballType | null;
  matchId: string | null;
  /** The analysis_events row this tactical_analysis data belongs to —
   * always this SAME event's own id (tactical_analysis is 1:1 with
   * analysis_events on event_id, migration 0001) — never a different
   * event's. */
  eventId: string;
  timestampSeconds: number | null;
}

/**
 * Builds the MomentExplanationContext (positions/passingLane/space) for
 * ONE event from that SAME event's own already-generated tactical
 * analysis data — see file header for the "exactly one candidate, else
 * null" selection rule this applies and why. `tacticalAnalysis` null/
 * undefined (no tactical data available for this event, e.g. the AI
 * provider returned nothing usable) yields `{}` — identical to calling
 * buildMomentExplanationFromUnifiedEvent with no context at all, i.e.
 * unchanged 10H behavior.
 */
export function buildEventTacticalContext(
  tacticalAnalysis: TacticalAnalysisSnapshot | null | undefined,
  context: EventTacticalContextInfo
): MomentExplanationContext {
  if (!tacticalAnalysis) return {};

  const row = { event_id: context.eventId, ...tacticalAnalysis };
  const builderContext = {
    footballType: context.footballType,
    matchId: context.matchId,
    timestampSeconds: context.timestampSeconds,
  };

  const positionStates = tacticalPositionStatesFromTacticalAnalysis(row, builderContext);
  const passingLanes = passingLanesFromTacticalAnalysis(row, builderContext);
  const spaces = spacesFromTacticalAnalysis(row, builderContext);

  return {
    positions: positionStates.length === 1 ? positionStates[0] : null,
    passingLane: passingLanes.length === 1 ? passingLanes[0] : null,
    space: spaces.length === 1 ? spaces[0] : null,
  };
}

// ============================================================
// 2. Persisted analysis_events + moment_explanations -> FullMatchContext
//    (10I, via 10J-3's persisted-explanation-aware reconstruction)
// ============================================================

/** Narrow, dependency-injectable view of exactly the two reads this
 * batch's FullMatchContext wiring needs — same Port convention as
 * analysisEventPersistence.ts's own AnalysisEventPersistencePort/
 * MomentExplanationPersistencePort and matchSnapshot.ts's own
 * MatchSnapshotPort, so the composition logic below is testable with a
 * plain in-memory fake instead of a real Supabase/Postgres instance. */
export interface AnalysisEngineReadPort {
  /** Every analysis_events row for this match (10D's own source table,
   * migration 0001/0005) — order is not assumed; getFullMatchContextForMatch
   * always re-sorts via buildFullMatchContextWithPersistedExplanations's
   * own chronological ordering (10I). */
  listAnalysisEvents(matchId: string): Promise<AnalysisEvent[]>;
  /** Every already-persisted moment_explanations row for this match
   * (10J-1/10J-2's own table, migration 0030). */
  listMomentExplanations(matchId: string): Promise<MomentExplanationRow[]>;
}

/** Deliberately NOT imported statically at module load time — same lazy
 * dynamic-import reasoning as analysisEventPersistence.ts's own two
 * createSupabase*Port functions and matchSnapshot.ts's own
 * createSupabaseMatchSnapshotPort: importing this file (e.g. from a test
 * that always supplies its own fake port) must never require
 * apps/worker/src/supabaseClient.ts's own required environment variables
 * to be set. */
function createSupabaseAnalysisEngineReadPort(): AnalysisEngineReadPort {
  return {
    async listAnalysisEvents(matchId) {
      const { supabaseAdmin } = await import("./supabaseClient");
      const { data, error } = await supabaseAdmin.from("analysis_events").select("*").eq("match_id", matchId);
      if (error) throw error;
      return (data ?? []) as AnalysisEvent[];
    },
    async listMomentExplanations(matchId) {
      const { supabaseAdmin } = await import("./supabaseClient");
      const { data, error } = await supabaseAdmin.from("moment_explanations").select("*").eq("match_id", matchId);
      if (error) throw error;
      return (data ?? []) as MomentExplanationRow[];
    },
  };
}

/**
 * Reconstructs the FullMatchContext (10I) for one match from its
 * already-persisted analysis_events + moment_explanations rows — the
 * actual Supabase-backed read path 10J-3's own header comment left as
 * "out of scope, left to a later batch". Reuses toUnifiedFootballEvent
 * (10D) to rebuild each UnifiedFootballEvent from its row (never
 * re-derived some other way), momentExplanationsByEventId (10J-1) to key
 * the persisted explanations by event_id, and
 * buildFullMatchContextWithPersistedExplanations (10J-3) for the actual
 * composition — a historical persisted explanation is therefore always
 * used verbatim, and only an event with no persisted row yet falls back
 * to a freshly computed one (10J-3's own precedence rule, unchanged).
 *
 * An analysis_events row whose own event_type has no unified mapping
 * (toUnifiedFootballEvent's own defensive branch) is simply excluded —
 * the same "nothing to build from" outcome persistMomentExplanationSafely
 * already treats as a no-op for that event elsewhere in this pipeline.
 *
 * `port` defaults to the real Supabase-backed implementation; tests pass
 * a fake to exercise this function's composition logic in isolation.
 */
export async function getFullMatchContextForMatch(
  matchId: string,
  footballContext: FootballMatchContext | null,
  port?: AnalysisEngineReadPort
): Promise<FullMatchContext> {
  const p = port ?? createSupabaseAnalysisEngineReadPort();

  const [eventRows, explanationRows] = await Promise.all([
    p.listAnalysisEvents(matchId),
    p.listMomentExplanations(matchId),
  ]);

  const events = eventRows
    .map((row) => toUnifiedFootballEvent(row, footballContext))
    .filter((event): event is UnifiedFootballEvent => event !== null);

  const explanations = momentExplanationsByEventId(explanationRows);

  return buildFullMatchContextWithPersistedExplanations({
    matchId,
    footballContext,
    events,
    explanations,
  });
}

/**
 * Called once by each of processMatchVideo.ts / processScreenshot.ts,
 * immediately after triggerMatchSnapshotOnCompletion — i.e. after a
 * match's analysis has genuinely finished and its status has already
 * been flipped to 'complete'. Best-effort, same "log safely, never
 * throw" contract as matchSnapshot.ts's own triggerMatchSnapshotOnCompletion:
 * this is a read-only sanity check that the persisted-explanation
 * reconstruction pipeline composes cleanly for this match's real data —
 * it writes nothing, so a failure here can never turn an otherwise-
 * successful analysis run into a failed one, and a successful call
 * changes no persisted state either (see file header — "NO SCOPE CREEP",
 * this is not a client-facing endpoint).
 */
export async function logFullMatchContextOnCompletion(
  matchId: string,
  footballContext: FootballMatchContext | null,
  port?: AnalysisEngineReadPort
): Promise<void> {
  try {
    const context = await getFullMatchContextForMatch(matchId, footballContext, port);
    console.log(`[analysisEngine] full match context reconstructed for match ${matchId}: ${context.moments.length} moment(s)`);
  } catch (err) {
    console.error(
      `[analysisEngine] failed to reconstruct full match context for match ${matchId}:`,
      (err as Error)?.message ?? err
    );
  }
}
