-- Run automatically by `supabase db reset`, or manually via `supabase db push` + psql.

-- ============================================================
-- PRIVATE STORAGE BUCKETS (spec section 5: never public)
-- ============================================================
insert into storage.buckets (id, name, public)
values ('raw-uploads', 'raw-uploads', false)
on conflict (id) do nothing;

insert into storage.buckets (id, name, public)
values ('processed-frames', 'processed-frames', false)
on conflict (id) do nothing;

-- Batch 4: persisted playable match video + generated event clips (see
-- migration 0008_video_experience.sql for the RLS policies that key off
-- these bucket ids and the audit note on why these didn't exist before).
insert into storage.buckets (id, name, public)
values ('match-videos', 'match-videos', false)
on conflict (id) do nothing;

insert into storage.buckets (id, name, public)
values ('video-clips', 'video-clips', false)
on conflict (id) do nothing;

-- Batch 6A-2: player-card library images (see migration
-- 0012_player_library_storage.sql for the RLS policies that key off this
-- bucket id). Client-uploaded directly, same as raw-uploads screenshots —
-- no worker/service-role involvement for this bucket.
--
-- Bucket creation (and its file_size_limit/allowed_mime_types hardening)
-- now also lives in migration 0013_player_cards_bucket.sql, which is what
-- actually runs against a real project (this file does not). The insert
-- below is kept for local `supabase db reset` compatibility; on conflict
-- do nothing means it's a harmless no-op once 0013 has already created
-- the row.
insert into storage.buckets (id, name, public)
values ('player-cards', 'player-cards', false)
on conflict (id) do nothing;

-- Batch 6B-2: manager-image library images (see migration
-- 0015_manager_images_storage.sql for the bucket hardening and RLS
-- policies that key off this bucket id). Client-uploaded directly, same
-- as player-cards — no worker/service-role involvement for this bucket.
-- Kept here only for local `supabase db reset` compatibility, same as
-- player-cards' entry above; 0015 is what actually runs against a real
-- project.
insert into storage.buckets (id, name, public)
values ('manager-images', 'manager-images', false)
on conflict (id) do nothing;

-- Batch 7B: team logo/image library images (see migration
-- 0017_team_images_storage.sql for the bucket hardening and RLS
-- policies that key off this bucket id). Client-uploaded directly, same
-- as player-cards/manager-images — no worker/service-role involvement
-- for this bucket. Kept here only for local `supabase db reset`
-- compatibility, same as the two entries above; 0017 is what actually
-- runs against a real project.
insert into storage.buckets (id, name, public)
values ('team-images', 'team-images', false)
on conflict (id) do nothing;


-- ============================================================
-- DEMO DATA (spec section 30)
-- ============================================================
-- Demo rows are seeded PER-USER the first time a user is created, via
-- this trigger, so they still pass through normal RLS instead of being a
-- special-cased public fixture. is_demo=true keeps them clearly separate
-- from real analysis (see apps/web/src/hooks/useDashboardData.ts).

create or replace function public.seed_demo_match_for_user()
returns trigger
language plpgsql
security definer set search_path = public
as $$
declare
  demo_match_id uuid;
  demo_event_id uuid;
begin
  insert into public.matches (user_id, title, source_type, status, overall_score, is_demo, duration_seconds)
  values (new.id, 'Demo: vs. Rivalcup FC', 'demo', 'complete', 71, true, 1980)
  returning id into demo_match_id;

  insert into public.match_statistics (
    match_id, passing_score, dribbling_score, attacking_score,
    defending_score, positioning_score, decision_making_score,
    good_decisions_count, bad_decisions_count
  ) values (demo_match_id, 74, 68, 70, 65, 72, 71, 9, 4);

  insert into public.analysis_events (
    match_id, timestamp_seconds, event_type, category, severity,
    decision_score, confidence, confidence_level, description,
    better_option, reasoning, context_start_seconds, context_end_seconds
  ) values (
    demo_match_id, 763, 'played_into_pressure', 'build_up', 'mistake',
    42, 88, 'confirmed',
    'Played a central pass directly into a double press near the halfway line.',
    'Switch the ball to the right side, which was open.',
    'The right flank had no defenders within 15 meters, while the center was congested with three opponents converging on the passing lane.',
    753, 773
  ) returning id into demo_event_id;

  insert into public.tactical_analysis (
    event_id, actual_positions, recommended_positions, passing_lanes,
    pressure_zones, open_spaces, is_approximate, explanation
  ) values (
    demo_event_id,
    '[{"role":"CMF","team":"user","pos":{"x":50,"y":45}},{"role":"OPP","team":"opponent","pos":{"x":48,"y":40}},{"role":"OPP","team":"opponent","pos":{"x":55,"y":42}}]'::jsonb,
    '[{"role":"CMF","team":"user","pos":{"x":50,"y":45}},{"role":"RWF","team":"user","pos":{"x":80,"y":48}}]'::jsonb,
    '[{"from":{"x":50,"y":45},"to":{"x":50,"y":30},"quality":"risky"},{"from":{"x":50,"y":45},"to":{"x":80,"y":48},"quality":"recommended"}]'::jsonb,
    '[{"center":{"x":50,"y":38},"radius":12,"intensity":0.8}]'::jsonb,
    '[{"center":{"x":80,"y":48},"radius":15}]'::jsonb,
    true,
    'Demo illustration — this is sample data, not a real analyzed decision.'
  );

  return new;
end;
$$;

drop trigger if exists on_profile_created_seed_demo on public.profiles;
create trigger on_profile_created_seed_demo
  after insert on public.profiles
  for each row execute procedure public.seed_demo_match_for_user();
