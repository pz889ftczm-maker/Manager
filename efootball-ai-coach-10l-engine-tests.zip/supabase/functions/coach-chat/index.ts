// Edge Function: POST /functions/v1/coach-chat
// Builds a grounded summary of the user's REAL analyzed matches/events,
// calls the AI Coach through the SAME provider abstraction/router used by
// the worker (packages/ai — getAiProvider()), and persists both the
// user's message and the assistant reply.
//
// BATCH 5.5C: previously this called the Anthropic API directly with a
// bare `fetch()`, bypassing packages/ai entirely — AI_PROVIDER=gemini had
// no effect here even though it fully controlled the worker's candidate
// scan / deep analysis. That bypass is now closed: this function imports
// packages/ai's getAiProvider() directly (see ../../../packages/ai and
// ./deno.json, which maps that workspace package plus its npm SDK deps —
// @anthropic-ai/sdk / @google/genai — for Deno). AI_PROVIDER=gemini now
// means the AI Coach also goes through ProviderRouter (Gemini primary,
// Anthropic fallback on rate_limit/timeout/transient only, max 2 provider
// attempts) exactly like the worker's candidate scan / deep analysis.
// AI_PROVIDER=anthropic remains a bare AnthropicProvider, unchanged.
//
// The system prompt / reliability rules / {{cite:UUID}} format now live in
// exactly one place per provider (packages/ai/src/providers/*.ts) instead
// of being duplicated a third time here — this file only builds grounded
// context, calls ai.chat(), and re-verifies citation ownership below.
// CITATION_REGEX below is used ONLY to strip the {{cite:...}} markers out
// of the text shown to the user; it must stay in sync with the same regex
// in packages/ai/src/providers/{anthropicProvider,geminiProvider}.ts if the
// citation format ever changes.
import {
  corsHeaders,
  getUserScopedClient,
  getServiceRoleClient,
  checkRateLimit,
  internalErrorResponse,
} from "../_shared/helpers.ts";
import { getAiProvider, isProviderRouterError, type CitableEvent } from "../../../packages/ai/src/index.ts";

const CITATION_REGEX = /\{\{cite:([0-9a-fA-F-]{36})\}\}/g;

// Batch 3.5: real individual player statistics grounding for the AI Coach
// (spec sections 19/20). Deliberately a small, dependency-free summary
// rather than importing @efootball/shared's PLAYER_STAT_CATEGORIES for
// just these six trend labels — unrelated to the AI provider call above.
const TREND_METRICS: { field: string; label: string }[] = [
  { field: "pass_completion_percentage", label: "pass completion %" },
  { field: "successful_dribbles", label: "successful dribbles" },
  { field: "duel_win_percentage", label: "duel win %" },
  { field: "possession_losses", label: "possession losses" },
  { field: "tackles", label: "tackles" },
  { field: "interceptions", label: "interceptions" },
];

function summarizeStatTrends(statsRows: Record<string, unknown>[]): {
  latest: Record<string, unknown> | null;
  trends: string[];
  insufficient: string[];
} {
  if (statsRows.length === 0) return { latest: null, trends: [], insufficient: TREND_METRICS.map((m) => m.label) };

  const latest = statsRows[statsRows.length - 1];
  const trends: string[] = [];
  const insufficient: string[] = [];

  for (const { field, label } of TREND_METRICS) {
    const values = statsRows
      .map((r) => r[field])
      .filter((v): v is number => typeof v === "number" && Number.isFinite(v));
    if (values.length < 2) {
      insufficient.push(label);
      continue;
    }
    const mid = Math.ceil(values.length / 2);
    const earlierAvg = values.slice(0, mid).reduce((s, v) => s + v, 0) / mid;
    const recentAvg = values.slice(mid).reduce((s, v) => s + v, 0) / Math.max(values.length - mid, 1);
    const delta = recentAvg - earlierAvg;
    const direction = Math.abs(delta) < 0.5 ? "stable" : delta > 0 ? "up" : "down";
    trends.push(
      `${label}: ${direction} (${earlierAvg.toFixed(1)} -> ${recentAvg.toFixed(1)} avg across ${values.length} matches with this stat recorded)`
    );
  }

  return { latest, trends, insufficient };
}

async function buildContextSummary(supabase: ReturnType<typeof getUserScopedClient>, userId: string) {
  const { data: matches } = await supabase
    .from("matches")
    .select("id, title, overall_score, created_at")
    .eq("user_id", userId)
    .eq("is_demo", false)
    .order("created_at", { ascending: false })
    .limit(10);

  if (!matches || matches.length === 0) {
    return {
      summary:
        "The user has no analyzed matches yet. Say so plainly and suggest they run their first analysis rather than giving generic advice.",
      citableEvents: [] as CitableEvent[],
    };
  }

  // player_progress is now a REAL write path (Batch 3) — surface the
  // evidence/confidence fields too, not just the labels, so the model can
  // be honest about how much history backs a claim instead of stating a
  // label with false confidence.
  const { data: progress } = await supabase.from("player_progress").select("*").eq("user_id", userId).maybeSingle();

  // Batch 3.5: real per-match individual statistics for the user's own
  // player, oldest-first, so the model can cite actual numbers/trends
  // ("your pass completion was 87%") instead of only category scores.
  const { data: selfPlayer } = await supabase
    .from("players")
    .select("id")
    .eq("user_id", userId)
    .eq("is_self", true)
    .maybeSingle();

  let statTrends: string[] = [];
  let statInsufficient: string[] = TREND_METRICS.map((m) => m.label);
  let latestStats: Record<string, unknown> | null = null;

  if (selfPlayer) {
    const { data: statRows } = await supabase
      .from("match_player_statistics")
      .select("*")
      .eq("player_id", selfPlayer.id)
      .in(
        "match_id",
        matches.map((m) => m.id)
      )
      .eq("is_valid", true)
      .order("created_at", { ascending: true });

    const summarized = summarizeStatTrends(statRows ?? []);
    statTrends = summarized.trends;
    statInsufficient = summarized.insufficient;
    latestStats = summarized.latest;
  }

  // id is required here (it wasn't selected before Batch 3) — without it
  // there is nothing for the model to put inside {{cite:...}}.
  const { data: recentEvents } = await supabase
    .from("analysis_events")
    .select("id, event_type, category, severity, decision_score, description, match_id")
    .in(
      "match_id",
      matches.map((m) => m.id)
    )
    .order("created_at", { ascending: false })
    .limit(40);

  const events = recentEvents ?? [];
  const citableEvents: CitableEvent[] = events.map((e) => ({
    id: e.id,
    summary: `[${e.category}/${e.event_type}, ${e.severity}] ${e.description}`,
  }));

  const summary = JSON.stringify(
    {
      matches: matches.map((m) => ({ id: m.id, title: m.title, overall_score: m.overall_score })),
      progress: progress
        ? {
            matches_analyzed: progress.matches_analyzed,
            most_improved_skill: progress.most_improved_skill,
            biggest_weakness: progress.biggest_weakness,
            most_common_mistake: progress.most_common_mistake,
            mistake_analysis: progress.mistake_analysis,
            recommended_position: progress.recommended_position,
            recommended_position_confidence: progress.recommended_position_confidence,
            playstyle_tags: progress.playstyle_tags,
            // Which of the above are NOT yet backed by enough real history —
            // the model must treat these as "not enough data" rather than
            // stating them confidently (see the reliability rule below).
            insufficient_data: progress.insufficient_data,
          }
        : null,
      recent_events: events,
      // Batch 3.5: real individual statistics evidence — only present
      // fields the user actually has 2+ matches of real data for go in
      // player_statistics_trends; everything else is explicitly listed in
      // player_statistics_insufficient_data so the model states "not
      // enough data" rather than inventing a trend.
      player_statistics_latest_match: latestStats,
      player_statistics_trends: statTrends,
      player_statistics_insufficient_data: statInsufficient,
    },
    null,
    2
  );

  return { summary, citableEvents };
}

Deno.serve(async (req: Request) => {
  if (req.method === "OPTIONS") return new Response("ok", { headers: corsHeaders });

  try {
    const { message } = await req.json();
    if (!message) return new Response("message is required", { status: 400, headers: corsHeaders });

    const supabase = getUserScopedClient(req);
    const {
      data: { user },
    } = await supabase.auth.getUser();
    if (!user) return new Response("unauthorized", { status: 401, headers: corsHeaders });

    // Part O — each message costs a real AI provider call; cap how many a
    // single user can send in a short window.
    const allowed = await checkRateLimit(supabase, user.id, "coach-chat", 20, 300);
    if (!allowed) {
      return new Response(JSON.stringify({ error: "Too many messages. Please wait a moment and try again." }), {
        status: 429,
        headers: corsHeaders,
      });
    }

    const { summary: contextSummary, citableEvents } = await buildContextSummary(supabase, user.id);

    const { data: recentMessages } = await supabase
      .from("ai_coach_messages")
      .select("role, content")
      .eq("user_id", user.id)
      .order("created_at", { ascending: false })
      .limit(10);

    const recentMessagesForAi = (recentMessages ?? [])
      .slice()
      .reverse()
      .map((m) => ({ role: m.role as "user" | "assistant", content: m.content as string }));

    // Batch 5.5C: the ONE call that used to bypass the router. getAiProvider()
    // returns a bare AnthropicProvider when AI_PROVIDER=anthropic, or a
    // ProviderRouter (Gemini primary, Anthropic fallback — see
    // packages/ai/src/providerRouter.ts) when AI_PROVIDER=gemini, exactly
    // like the worker's candidate scan / deep analysis calls. Each
    // provider's chat() implementation builds its own system prompt +
    // reliability rules + citable-events block internally (see
    // packages/ai/src/providers/{anthropicProvider,geminiProvider}.ts) and
    // already filters {{cite:UUID}} tokens in its reply down to ids present
    // in `citableEvents` — referencedEventIds below is that filtered set,
    // NOT yet a database-verified ownership guarantee (see below).
    let reply: string;
    let referencedCandidateIds: string[];
    try {
      const ai = getAiProvider();
      const result = await ai.chat({
        userMessage: message,
        userContextSummary: contextSummary,
        recentMessages: recentMessagesForAi,
        citableEvents,
      });
      reply = result.reply;
      referencedCandidateIds = result.referencedEventIds;
    } catch (err) {
      // Part P — log the real upstream error server-side, but never
      // forward provider internals (which can include request echoes) to
      // the client. isProviderRouterError() gives a safe, secret-free
      // summary (categories only) when BOTH providers failed; any other
      // thrown error (e.g. a single bare AnthropicProvider failure when
      // AI_PROVIDER=anthropic) is logged via its message only.
      if (isProviderRouterError(err)) {
        console.error(
          `[coach-chat] AI provider error: ${err.message} (primary=${err.primaryCategory}, fallback=${err.fallbackCategory})`
        );
      } else {
        console.error("[coach-chat] AI provider error", err instanceof Error ? err.message : err);
      }
      return new Response(JSON.stringify({ error: "The AI coach is temporarily unavailable. Please try again." }), {
        status: 502,
        headers: corsHeaders,
      });
    }

    // Batch 3: verify citation ownership at the DB level — never trust an
    // id just because the provider's own allow-list filtering passed it
    // through. Using the USER-SCOPED client here means RLS
    // (analysis_events_select_own, see 0002_rls.sql) is what actually
    // enforces "this event belongs to the authenticated user": if a cited
    // id doesn't belong to this user, RLS simply won't return it, so it
    // can never end up in referenced_event_ids below.
    let referencedEventIds: string[] = [];
    if (referencedCandidateIds.length > 0) {
      const { data: verifiedEvents } = await supabase
        .from("analysis_events")
        .select("id")
        .in("id", referencedCandidateIds);
      referencedEventIds = (verifiedEvents ?? []).map((e) => e.id);
    }

    // The stored/displayed message text should read naturally — strip the
    // {{cite:...}} markers rather than showing raw tokens to the user.
    // referenced_event_ids (verified above) is the machine-readable record
    // of what was actually cited; apps/web/src/routes/AiCoach.tsx can use
    // it later (e.g. to link back to the cited moment) without needing the
    // marker to remain in the visible text.
    const cleanedReply = reply.replace(CITATION_REGEX, "").replace(/[ \t]+\n/g, "\n").trim();

    // User's own message: inserted with their JWT, RLS-checked (role='user'
    // is the only role the client-scoped policy now permits — see
    // supabase/migrations/0003_ai_coach_messages_role_hardening.sql).
    const { data: userRow } = await supabase
      .from("ai_coach_messages")
      .insert({ user_id: user.id, role: "user", content: message })
      .select()
      .single();

    // Assistant's reply: RLS no longer allows role='assistant' via the
    // client-scoped client, by design, so this insert must go through the
    // service-role client instead. This is the only path that can ever
    // write an assistant-role row.
    const serviceRole = getServiceRoleClient();
    const { data: assistantRow } = await serviceRole
      .from("ai_coach_messages")
      .insert({
        user_id: user.id,
        role: "assistant",
        content: cleanedReply,
        referenced_event_ids: referencedEventIds.length > 0 ? referencedEventIds : null,
      })
      .select()
      .single();

    return new Response(JSON.stringify({ userRow, assistantRow }), {
      headers: { ...corsHeaders, "Content-Type": "application/json" },
    });
  } catch (err) {
    return internalErrorResponse("coach-chat", err);
  }
});
