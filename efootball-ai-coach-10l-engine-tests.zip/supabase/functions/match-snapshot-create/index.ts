// Edge Function: POST /functions/v1/match-snapshot-create
//
// Batch 9B — Historical Match Snapshot Creation SERVICE. This is the
// ONLY code path that creates a public.match_snapshots (+
// match_snapshot_players) row, and (audit fix) the ONLY caller in this
// codebase able to invoke public.create_match_snapshot at all —
// EXECUTE on that function is granted to service_role ONLY (migration
// 0027_match_snapshot_creation_server_only.sql), never to
// `authenticated`, precisely so a browser client cannot call the RPC
// directly and bypass this function's own rate limiting (spec section
// 2 — "Snapshot creation MUST happen server-side. Do NOT allow the
// browser/client to directly create snapshots."). This function
// remains a deliberately thin wrapper — auth -> rate limit -> validate
// request shape -> call the RPC -> map its result/error to a safe
// HTTP response. Every ownership check, every historical-field read,
// the atomic insert of both tables, and the idempotency/concurrency
// handling all live in that SQL function, not here (spec section 10 —
// atomicity requires the existing database architecture, not a
// client-side or Edge-Function-side multi-request "transaction"). See
// migrations 0026 and 0027's own header comments for the full design
// rationale.
//
// Body: { match_id: string, team_id: string, formation_id?: string | null }
// No other field is read from the body — spec section 3 ("Do NOT
// accept historical player names, stats, manager ratings, team
// metadata ... from the client") and spec item 6 of the audit fix
// ("Do NOT accept user_id from the request body"). The authenticated
// user id is resolved ONLY from the caller's own verified JWT via
// auth.getUser() below (using the user-scoped client, for
// authentication purposes only) — never read from, or trusted from,
// the request body.
//
// Response:
//   201 { snapshotId: string, created: true }  — a new snapshot was created
//   200 { snapshotId: string, created: false } — an identical (match_id, team_id)
//                                                  snapshot already existed
//
// TWO CLIENTS, TWO JOBS (audit fix — spec items 4/5): a user-scoped
// client (getUserScopedClient) is used ONLY to authenticate the caller
// via auth.getUser() and to run the existing Part O rate-limit check
// (check_and_record_rate_limit is itself granted to `authenticated`
// and scoped to the caller's own bucket, same as every other Library
// save Edge Function). The actual privileged write goes through a
// SEPARATE service-role client (getServiceRoleClient,
// supabase/functions/_shared/helpers.ts — this repo's own existing
// convention for a server-only operation, already used by
// clip-request/analysis-enqueue), because create_match_snapshot is no
// longer callable by `authenticated` at all after 0027. The
// authenticated user's id, resolved above from their own verified
// JWT, is passed explicitly as p_user_id — this is safe specifically
// BECAUSE only this trusted server-side code can reach the RPC in the
// first place (see 0027's own GRANTS design note for why a plain uuid
// parameter is safe here but would not have been safe to accept
// directly from `authenticated`).
import {
  corsHeaders,
  getUserScopedClient,
  getServiceRoleClient,
  checkRateLimit,
  internalErrorResponse,
} from "../_shared/helpers.ts";
import { validateMatchSnapshotCreateRequest, mapSnapshotCreationRpcError } from "../../../packages/shared/src/index.ts";

Deno.serve(async (req: Request) => {
  if (req.method === "OPTIONS") return new Response("ok", { headers: corsHeaders });

  try {
    let body: unknown;
    try {
      body = await req.json();
    } catch {
      return new Response(JSON.stringify({ error: "Invalid JSON body" }), { status: 400, headers: corsHeaders });
    }

    const supabase = getUserScopedClient(req);
    const {
      data: { user },
    } = await supabase.auth.getUser();
    if (!user) return new Response("unauthorized", { status: 401, headers: corsHeaders });

    // Same Part O convention as manager-library-save/player-library-save
    // — a snapshot creation is cheap for Postgres itself, but still
    // capped against a runaway client bug or abuse. Own bucket name so
    // this flow doesn't share quota with any Library save endpoint.
    const allowed = await checkRateLimit(supabase, user.id, "match-snapshot-create", 30, 300);
    if (!allowed) {
      return new Response(JSON.stringify({ error: "Too many snapshot requests. Please wait a moment and try again." }), {
        status: 429,
        headers: corsHeaders,
      });
    }

    // Pure shape validation ONLY — required/optional uuid fields.
    // Ownership (does this user actually own match_id/team_id/
    // formation_id) is entirely public.create_match_snapshot's job
    // below, never checked or assumed here.
    const { sanitized, errors } = validateMatchSnapshotCreateRequest(body);
    if (errors.length > 0) {
      console.warn(`[match-snapshot-create] rejected invalid request: ${errors.join("; ")}`);
      return new Response(
        JSON.stringify({ error: "Unable to create match snapshot because the selected configuration is invalid." }),
        { status: 400, headers: { ...corsHeaders, "Content-Type": "application/json" } }
      );
    }

    // The one and only write path: a single atomic, ownership-checked
    // RPC call. See migration 0026/0027's header comments for why this
    // must be one SQL function call rather than separate .from(...)
    // writes, and why it's invoked here via the SERVICE-ROLE client —
    // `supabase` (user-scoped, used only above for auth + rate limit)
    // has no EXECUTE privilege on this function as of 0027. p_user_id
    // is `user.id`, resolved above from the caller's own verified JWT
    // — never from the request body (audit fix item 6).
    const admin = getServiceRoleClient();
    const { data, error } = await admin.rpc("create_match_snapshot", {
      p_user_id: user.id,
      p_match_id: sanitized.match_id,
      p_team_id: sanitized.team_id,
      p_formation_id: sanitized.formation_id,
    });

    if (error) {
      // Never forward `error` itself (message/detail/hint/SQLSTATE) to
      // the client (spec section 17) — only ever one of a small set of
      // pre-written safe strings, chosen by pattern-matching the RPC's
      // own internal-only `match_snapshot_create: <code>` message. The
      // raw error is still logged server-side for debugging.
      console.error("[match-snapshot-create] RPC error", error);
      const { status, error: safeMessage } = mapSnapshotCreationRpcError(error);
      return new Response(JSON.stringify({ error: safeMessage }), {
        status,
        headers: { ...corsHeaders, "Content-Type": "application/json" },
      });
    }

    // create_match_snapshot returns table (id uuid, created boolean) —
    // supabase-js surfaces a table-returning RPC as an array of rows.
    const row = Array.isArray(data) ? data[0] : data;
    if (!row || typeof row.id !== "string") {
      // Unreachable in practice: the RPC either raises (handled above)
      // or returns exactly one row. Guarded anyway rather than
      // returning an undefined snapshotId.
      return internalErrorResponse("match-snapshot-create", new Error("create_match_snapshot returned no row"));
    }

    return new Response(JSON.stringify({ snapshotId: row.id, created: row.created === true }), {
      status: row.created === true ? 201 : 200,
      headers: { ...corsHeaders, "Content-Type": "application/json" },
    });
  } catch (err) {
    return internalErrorResponse("match-snapshot-create", err);
  }
});
