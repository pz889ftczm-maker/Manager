// Edge Function: POST /functions/v1/clip-request
// Called by apps/web/src/hooks/useVideoClips.ts when the user clicks
// "Generate Clip" on an event in MatchReport.tsx. Mirrors
// analysis-enqueue's shape: verify ownership server-side, then hand off
// to the worker's internal HTTP API — this function never touches
// Redis/ffmpeg itself, and the browser never talks to the worker
// directly (spec Part L).
//
// Body: { matchId: string, eventId: string }
// The client does NOT send start/end timestamps — per spec Part L
// ("server is authoritative"), this function computes the context
// window itself from the event's own persisted timestamp/context
// columns, the same way apps/web's Watch Moment button does client-side
// via @efootball/shared's resolveEventContextWindow. Edge Functions run
// on Deno and cannot import that Node workspace package directly (same
// constraint already documented at the top of coach-chat/index.ts and
// packages/shared/src/videoContext.ts) — so the pure clamp logic is
// duplicated inline below. Keep the two in sync if the clamp rule ever
// changes.
import {
  corsHeaders,
  getUserScopedClient,
  getServiceRoleClient,
  checkRateLimit,
  internalErrorResponse,
} from "../_shared/helpers.ts";

const DEFAULT_CONTEXT_SECONDS = 10;

function computeContextWindow(
  timestampSeconds: number | null | undefined,
  durationSeconds: number | null | undefined,
  beforeSeconds = DEFAULT_CONTEXT_SECONDS,
  afterSeconds = DEFAULT_CONTEXT_SECONDS
): { start: number; end: number } | null {
  if (timestampSeconds == null || !Number.isFinite(timestampSeconds) || timestampSeconds < 0) return null;
  if (durationSeconds == null || !Number.isFinite(durationSeconds) || durationSeconds <= 0) return null;
  if (timestampSeconds > durationSeconds) return null;

  const start = Math.max(0, timestampSeconds - beforeSeconds);
  const end = Math.min(durationSeconds, timestampSeconds + afterSeconds);
  if (!(start < end)) return null;

  return { start, end };
}

function resolveEventContextWindow(
  event: { timestamp_seconds: number | null; context_start_seconds: number | null; context_end_seconds: number | null },
  durationSeconds: number | null | undefined
): { start: number; end: number } | null {
  if (event.context_start_seconds != null && event.context_end_seconds != null) {
    const start = Math.max(0, event.context_start_seconds);
    const end =
      durationSeconds != null ? Math.min(durationSeconds, event.context_end_seconds) : event.context_end_seconds;
    if (start < end) return { start, end };
  }
  return computeContextWindow(event.timestamp_seconds, durationSeconds);
}

// numeric(8,2) columns — round the same way on both sides of the
// idempotency uniqueness check (Part K) so floating point noise never
// creates a spurious duplicate row for what's really the same window.
function round2(n: number): number {
  return Math.round(n * 100) / 100;
}

Deno.serve(async (req: Request) => {
  if (req.method === "OPTIONS") return new Response("ok", { headers: corsHeaders });

  try {
    const { matchId, eventId } = await req.json();
    if (!matchId || !eventId) {
      return new Response(JSON.stringify({ error: "matchId and eventId are required" }), {
        status: 400,
        headers: corsHeaders,
      });
    }

    const userClient = getUserScopedClient(req);
    const {
      data: { user },
    } = await userClient.auth.getUser();
    if (!user) return new Response("unauthorized", { status: 401, headers: corsHeaders });

    // Part O — clip generation runs real ffmpeg work, so cap how often one
    // user can request clips in a short window.
    const allowed = await checkRateLimit(userClient, user.id, "clip-request", 20, 300);
    if (!allowed) {
      return new Response(JSON.stringify({ error: "Too many clip requests. Please wait a few minutes and try again." }), {
        status: 429,
        headers: corsHeaders,
      });
    }

    // RLS on `matches` scopes this to the caller's own rows, so this
    // select doubles as the ownership check (same pattern as
    // analysis-enqueue). Also pulls duration_seconds for the clamp below.
    const { data: match, error: matchErr } = await userClient
      .from("matches")
      .select("id, user_id, duration_seconds, status")
      .eq("id", matchId)
      .single();
    if (matchErr || !match) return new Response("match not found", { status: 404, headers: corsHeaders });

    // Event must belong to this match — checked explicitly (not just via
    // RLS) so a mismatched matchId/eventId pair is rejected with a clear
    // error rather than an ownership-check side effect.
    const { data: event, error: eventErr } = await userClient
      .from("analysis_events")
      .select("id, match_id, timestamp_seconds, context_start_seconds, context_end_seconds")
      .eq("id", eventId)
      .single();
    if (eventErr || !event || event.match_id !== matchId) {
      return new Response(JSON.stringify({ error: "event does not belong to the specified match" }), {
        status: 403,
        headers: corsHeaders,
      });
    }

    // The permanent processed video (see migration 0008 / processMatchVideo.ts's
    // persistProcessedVideoMedia) — distinct from the temporary raw-upload
    // media row. No fake/placeholder path if this doesn't exist yet.
    const { data: videoMedia, error: mediaErr } = await userClient
      .from("media")
      .select("id, storage_reference, status")
      .eq("match_id", matchId)
      .eq("type", "video")
      .eq("is_temporary", false)
      .maybeSingle();
    if (mediaErr) throw mediaErr;
    if (!videoMedia || !videoMedia.storage_reference || videoMedia.status !== "processed") {
      return new Response(JSON.stringify({ error: "processed video is not available for this match yet" }), {
        status: 409,
        headers: corsHeaders,
      });
    }

    const window = resolveEventContextWindow(event, match.duration_seconds);
    if (!window) {
      return new Response(JSON.stringify({ error: "could not compute a valid clip window for this event" }), {
        status: 422,
        headers: corsHeaders,
      });
    }
    const startSeconds = round2(window.start);
    const endSeconds = round2(window.end);

    // Service-role client from here on: the video_clips insert policy
    // only allows a fresh 'pending' row with no storage_path (see
    // migration 0008), and retrying a 'failed' clip requires an UPDATE,
    // which has no client-scoped policy at all (by design — see the
    // migration's comment). Ownership was already verified above with
    // the user-scoped client, so this is safe.
    const admin = getServiceRoleClient();

    // Idempotency + concurrency (Part K; Batch 4 final hardening): same
    // user+match+event+start+end never gets a second row — INCLUDING when
    // two identical requests race each other. A plain SELECT-then-INSERT
    // has a TOCTOU gap: both requests can see "no row", then both attempt
    // INSERT, so one succeeds and the other throws on the UNIQUE
    // constraint (user_id, match_id, event_id, start_time, end_time),
    // which previously surfaced to the client as a bare 500.
    //
    // Fix: attempt the insert FIRST, atomically, as
    // INSERT ... ON CONFLICT (...) DO NOTHING (supabase-js: upsert with
    // ignoreDuplicates:true). Postgres's unique index resolves the race
    // itself, inside the single statement — whichever request loses gets
    // zero rows back (no error) instead of a constraint violation, and
    // falls through to the SAME "fetch the real row and branch on its
    // status" logic that already handled the "clip already exists" case
    // below, so both concurrent requests converge on the one row.
    //
    // ignoreDuplicates (DO NOTHING) is required here, NOT the default
    // merge-duplicates (DO UPDATE): a merge would let a losing request
    // stomp the winner's row back to status='pending'/storage_path=null,
    // clobbering an already in-flight or completed clip.
    const { data: newlyInserted, error: insertRaceErr } = await admin
      .from("video_clips")
      .upsert(
        {
          user_id: user.id,
          match_id: matchId,
          event_id: eventId,
          start_time: startSeconds,
          end_time: endSeconds,
          status: "pending",
        },
        { onConflict: "user_id,match_id,event_id,start_time,end_time", ignoreDuplicates: true }
      )
      .select("id")
      .maybeSingle();
    if (insertRaceErr) throw insertRaceErr;

    let clipId: string;
    let status: string;

    if (newlyInserted) {
      // Won the race (or no concurrent request existed): brand-new row,
      // already 'pending' — proceed straight to enqueueing below.
      clipId = newlyInserted.id;
      status = "pending";
    } else {
      // Lost the race, or the clip already existed from an earlier
      // request: look up the row that's actually there and branch on its
      // real status — identical to the original single-request behavior.
      const { data: existingClip, error: existingErr } = await admin
        .from("video_clips")
        .select("id, status, storage_path, error_message")
        .eq("user_id", user.id)
        .eq("match_id", matchId)
        .eq("event_id", eventId)
        .eq("start_time", startSeconds)
        .eq("end_time", endSeconds)
        .maybeSingle();
      if (existingErr) throw existingErr;
      if (!existingClip) {
        // Unreachable in practice: the upsert above just reported a
        // conflict against this exact key, so a row must exist. Guard
        // explicitly rather than continuing with an undefined clipId.
        throw new Error("video_clips row not found after a reported conflict");
      }

      clipId = existingClip.id;
      if (existingClip.status === "completed") {
        // Already generated — return as-is, do not re-enqueue or re-analyze.
        return new Response(
          JSON.stringify({ clipId, status: existingClip.status, startTime: startSeconds, endTime: endSeconds }),
          { status: 200, headers: { ...corsHeaders, "Content-Type": "application/json" } }
        );
      }
      if (existingClip.status === "pending" || existingClip.status === "processing") {
        // Already in flight — return current status, do not enqueue again.
        return new Response(
          JSON.stringify({ clipId, status: existingClip.status, startTime: startSeconds, endTime: endSeconds }),
          { status: 202, headers: { ...corsHeaders, "Content-Type": "application/json" } }
        );
      }
      // status === 'failed' — allow retry, but make the failed -> pending
      // transition itself atomic (Batch 4 final hardening, part 2 — closes
      // the remaining failed-retry race). Two concurrent requests can both
      // read status='failed' above, but the UPDATE is guarded with
      // `.eq("status", "failed")`, so only the request whose UPDATE runs
      // first actually matches the row; Postgres serializes the two
      // UPDATEs against the same row, so the second one finds status
      // already flipped to 'pending' and matches zero rows (no error).
      // .select().maybeSingle() turns that RETURNING result into a plain
      // "did I win?" check.
      const { data: retriedClip, error: retryErr } = await admin
        .from("video_clips")
        .update({ status: "pending", error_message: null })
        .eq("id", clipId)
        .eq("status", "failed")
        .select("id")
        .maybeSingle();
      if (retryErr) throw retryErr;

      if (!retriedClip) {
        // Lost the retry race: another concurrent request already moved
        // this row off 'failed' (normally on its way to being enqueued).
        // Do NOT enqueue a second worker job for the same clip — report
        // its current state instead, same shape as the "already in
        // flight" branch above.
        const { data: currentClip, error: currentErr } = await admin
          .from("video_clips")
          .select("id, status, storage_path, error_message")
          .eq("id", clipId)
          .maybeSingle();
        if (currentErr) throw currentErr;
        if (!currentClip) {
          // Unreachable in practice: this row existed moments ago (we
          // just read/updated it by id) and video_clips rows are never
          // deleted except via cascade from their parent match/event,
          // which would also invalidate this whole request. Guard anyway
          // rather than continuing with stale/undefined state.
          throw new Error("video_clips row not found after a reported conflict");
        }
        if (currentClip.status === "completed") {
          return new Response(
            JSON.stringify({ clipId, status: currentClip.status, startTime: startSeconds, endTime: endSeconds }),
            { status: 200, headers: { ...corsHeaders, "Content-Type": "application/json" } }
          );
        }
        // pending / processing (the expected case) / failed-again (a
        // vanishingly unlikely re-race) — someone else owns this retry
        // attempt; never enqueue from the losing request.
        return new Response(
          JSON.stringify({ clipId, status: currentClip.status, startTime: startSeconds, endTime: endSeconds }),
          { status: 202, headers: { ...corsHeaders, "Content-Type": "application/json" } }
        );
      }

      // Won the retry race — proceed to enqueue below.
      status = "pending";
    }

    const workerUrl = Deno.env.get("WORKER_INTERNAL_URL")!;
    const internalSecret = Deno.env.get("WORKER_INTERNAL_SECRET")!;

    const workerRes = await fetch(`${workerUrl}/jobs/clip`, {
      method: "POST",
      headers: { "Content-Type": "application/json", "x-internal-secret": internalSecret },
      body: JSON.stringify({
        clipId,
        userId: user.id,
        matchId,
        eventId,
        videoObjectPath: videoMedia.storage_reference,
        startSeconds,
        endSeconds,
      }),
    });

    if (!workerRes.ok) {
      // Don't leave the row silently stuck on 'pending' if enqueueing
      // itself failed — reflect the real state so the frontend can offer
      // a retry instead of polling forever.
      await admin.from("video_clips").update({ status: "failed", error_message: "Failed to enqueue clip job" }).eq(
        "id",
        clipId
      );
      return new Response(JSON.stringify({ error: "Failed to enqueue clip job" }), {
        status: 502,
        headers: corsHeaders,
      });
    }

    return new Response(JSON.stringify({ clipId, status, startTime: startSeconds, endTime: endSeconds }), {
      status: 202,
      headers: { ...corsHeaders, "Content-Type": "application/json" },
    });
  } catch (err) {
    return internalErrorResponse("clip-request", err);
  }
});
