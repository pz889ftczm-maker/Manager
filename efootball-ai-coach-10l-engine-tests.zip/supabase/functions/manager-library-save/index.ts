// Edge Function: POST /functions/v1/manager-library-save
//
// Batch 6B-4 — Manager Library: Review/Edit → Save persistence ONLY. This
// is the one and only code path in this batch that writes to
// public.manager_library. It takes a human-reviewed ManagerLibraryInput —
// NEVER a raw ManagerCardDraft (see packages/shared/src/managerLibrary.ts's
// header comment: "AI extraction is only a draft... Never silently save
// an AI draft") — and either INSERTs a new row or UPDATEs one the caller
// already owns.
//
// Mirrors player-library-save's shape (auth -> validate -> act) and
// clip-request's ownership-then-write pattern exactly, but deliberately
// does NOT use a service-role client anywhere: every read/write here
// goes through the CALLER'S OWN user-scoped client, so RLS
// (manager_library_select_own/insert_own/update_own/delete_own,
// migration 0014_manager_library.sql) is the actual, independent
// enforcement of "a user must never be able to create/update/delete
// another user's manager" — every check in this function is
// defense-in-depth on top of that, never a replacement for it.
//
// Body: {
//   id?: string,       // present => update that row (must be owned by the caller); absent => insert a new row
//   name: string | null,
//   possession_rating: number | null,
//   quick_counter_rating: number | null,
//   long_ball_counter_rating: number | null,
//   out_wide_rating: number | null,
//   long_ball_rating: number | null,
//   manager_image_path?: string | null,
//   // ^ OMIT this key entirely on an update to leave the row's existing
//   // manager image untouched (see hasImagePathField below). Always
//   // include it (even as null) on an insert.
// }
//
// Response: { manager: ManagerLibrary, duplicate: boolean }
import { corsHeaders, getUserScopedClient, checkRateLimit, internalErrorResponse } from "../_shared/helpers.ts";
import {
  validateManagerLibraryInput,
  isUniqueViolation,
  isPathOwnedByUser,
  MANAGER_LIBRARY_VARIANT_UNIQUE_CONSTRAINT,
} from "../../../packages/shared/src/index.ts";

const TABLE = "manager_library";

// deno-lint-ignore no-explicit-any
function eqOrIsNull(query: any, column: string, value: string | number | null) {
  return value === null ? query.is(column, null) : query.eq(column, value);
}

Deno.serve(async (req: Request) => {
  if (req.method === "OPTIONS") return new Response("ok", { headers: corsHeaders });

  try {
    let body: unknown;
    try {
      body = await req.json();
    } catch {
      return new Response(JSON.stringify({ error: "Invalid JSON body" }), { status: 400, headers: corsHeaders });
    }
    if (!body || typeof body !== "object" || Array.isArray(body)) {
      return new Response(JSON.stringify({ error: "Request body must be an object" }), {
        status: 400,
        headers: corsHeaders,
      });
    }
    const bodyRecord = body as Record<string, unknown>;
    const rawId = bodyRecord.id;
    const editingId = typeof rawId === "string" && rawId.length > 0 ? rawId : null;

    const supabase = getUserScopedClient(req);
    const {
      data: { user },
    } = await supabase.auth.getUser();
    if (!user) return new Response("unauthorized", { status: 401, headers: corsHeaders });

    // Same Part O convention as player-library-save/player-card-extract —
    // a plain DB write is cheap, but still capped against a runaway
    // client bug or abuse rather than left completely open. Separate
    // rate-limit bucket name from "player-library-save" so the two save
    // flows don't share one quota.
    const allowed = await checkRateLimit(supabase, user.id, "manager-library-save", 60, 300);
    if (!allowed) {
      return new Response(JSON.stringify({ error: "Too many save requests. Please wait a moment and try again." }), {
        status: 429,
        headers: corsHeaders,
      });
    }

    // Never trust client-only validation — this is the SAME shared
    // validator the Review/Edit UI runs for early feedback, re-run here
    // as the actual authority, against the raw, untrusted request body.
    //
    // An omitted/unknown field is valid (NULL/UNKNOWN), but a value the
    // caller explicitly supplied that fails validation (wrong type,
    // negative/non-integer rating, invalid image-path syntax, ...) must
    // REJECT the write entirely — never sanitize-and-continue. Nothing is
    // written to manager_library below this point when that happens.
    const { sanitized, errors } = validateManagerLibraryInput(body);
    if (errors.length > 0) {
      console.warn(`[manager-library-save] rejected invalid input: ${errors.join("; ")}`);
      // `errors` is produced entirely by validateManagerLibraryInput's own
      // field-level checks — never a stack trace, a Postgres error, or
      // any other internal detail — so it's safe to return as-is.
      return new Response(JSON.stringify({ error: "Invalid manager data.", details: errors }), {
        status: 400,
        headers: { ...corsHeaders, "Content-Type": "application/json" },
      });
    }

    // An image path, if any, must belong to the caller's own storage
    // prefix. RLS on storage.objects (storage_manager_images_owner_select,
    // migration 0015) already means a signed URL/download could never
    // succeed for someone else's object regardless, and
    // manager_library_image_path_owned_prefix (migration 0014) enforces
    // the same prefix again as a table CHECK constraint — this is a
    // third, early check so a mismatched path is rejected with a clear,
    // attributable error rather than only ever surfacing as an opaque
    // CHECK-constraint failure.
    if (sanitized.manager_image_path && !isPathOwnedByUser(sanitized.manager_image_path, user.id)) {
      return new Response(JSON.stringify({ error: "manager_image_path must belong to the authenticated user" }), {
        status: 403,
        headers: corsHeaders,
      });
    }

    const fields: Record<string, unknown> = {
      name: sanitized.name,
      possession_rating: sanitized.possession_rating,
      quick_counter_rating: sanitized.quick_counter_rating,
      long_ball_counter_rating: sanitized.long_ball_counter_rating,
      out_wide_rating: sanitized.out_wide_rating,
      long_ball_rating: sanitized.long_ball_rating,
    };

    // Whether the caller's raw body even mentioned manager_image_path at
    // all — distinct from it being present-but-null. Used only for
    // UPDATE below, so that editing a manager's other fields never
    // accidentally clears its already-saved image just because the edit
    // form didn't resend it.
    const hasImagePathField = Object.prototype.hasOwnProperty.call(bodyRecord, "manager_image_path");

    if (editingId) {
      // ------------------------------------------------------------
      // UPDATE an existing library entry. RLS
      // (manager_library_update_own) scopes this to auth.uid() =
      // user_id — a non-owned or nonexistent id simply matches zero
      // rows, which this function reports as 404 below rather than
      // ever confirming/denying that another user's row exists.
      //
      // No column here can ever touch matches/analysis_events/team
      // presets — manager_library has no such column and no such
      // foreign key (migration 0014's "HISTORICAL SAFETY" note) — so
      // this update structurally cannot modify or recalculate any
      // historical match data.
      // ------------------------------------------------------------
      const updatePayload: Record<string, unknown> = { ...fields };
      if (hasImagePathField) updatePayload.manager_image_path = sanitized.manager_image_path;

      const { data: updated, error: updateErr } = await supabase
        .from(TABLE)
        .update(updatePayload)
        .eq("id", editingId)
        .select()
        .maybeSingle();

      if (updateErr) {
        if (isUniqueViolation(updateErr, MANAGER_LIBRARY_VARIANT_UNIQUE_CONSTRAINT)) {
          return new Response(
            JSON.stringify({
              error: "You already have an identical manager (same name and ratings) saved.",
            }),
            { status: 409, headers: corsHeaders }
          );
        }
        throw updateErr;
      }
      if (!updated) {
        return new Response(JSON.stringify({ error: "Manager not found." }), { status: 404, headers: corsHeaders });
      }

      return new Response(JSON.stringify({ manager: updated, duplicate: false }), {
        status: 200,
        headers: { ...corsHeaders, "Content-Type": "application/json" },
      });
    }

    // ------------------------------------------------------------
    // INSERT a new library entry.
    // ------------------------------------------------------------
    const insertPayload: Record<string, unknown> = {
      ...fields,
      user_id: user.id, // never taken from the client — always the authenticated caller
      manager_image_path: sanitized.manager_image_path,
    };

    const { data: inserted, error: insertErr } = await supabase.from(TABLE).insert(insertPayload).select().single();

    if (!insertErr) {
      return new Response(JSON.stringify({ manager: inserted, duplicate: false }), {
        status: 201,
        headers: { ...corsHeaders, "Content-Type": "application/json" },
      });
    }

    // An accidental duplicate save (double-click, network retry) hits
    // manager_library_user_variant_uniq. Rather than surface that as an
    // error, look up and return the row that already exists so a
    // retried request converges on the same result the original one
    // produced, instead of failing or creating a second row. Only
    // attempted when the constraint that actually fired is this one
    // (never masks an unrelated error) and when name isn't null (the
    // partial index doesn't apply to null-named entries, so a genuine
    // insert error there is never a duplicate-variant conflict).
    if (isUniqueViolation(insertErr, MANAGER_LIBRARY_VARIANT_UNIQUE_CONSTRAINT) && sanitized.name !== null) {
      let existingQuery = supabase.from(TABLE).select().eq("user_id", user.id);
      existingQuery = eqOrIsNull(existingQuery, "possession_rating", sanitized.possession_rating);
      existingQuery = eqOrIsNull(existingQuery, "quick_counter_rating", sanitized.quick_counter_rating);
      existingQuery = eqOrIsNull(existingQuery, "long_ball_counter_rating", sanitized.long_ball_counter_rating);
      existingQuery = eqOrIsNull(existingQuery, "out_wide_rating", sanitized.out_wide_rating);
      existingQuery = eqOrIsNull(existingQuery, "long_ball_rating", sanitized.long_ball_rating);
      const { data: siblings, error: lookupErr } = await existingQuery;
      if (lookupErr) throw lookupErr;
      const nameLower = sanitized.name.toLowerCase();
      const existing = (siblings ?? []).find(
        (r: { name: string | null }) => r.name != null && r.name.toLowerCase() === nameLower
      );
      if (existing) {
        return new Response(JSON.stringify({ manager: existing, duplicate: true }), {
          status: 200,
          headers: { ...corsHeaders, "Content-Type": "application/json" },
        });
      }
      // Fell through without finding it (e.g. it was deleted between the
      // failed insert and this lookup) — fall through to the generic
      // error handling below rather than claiming a duplicate that
      // isn't actually there.
    }

    throw insertErr;
  } catch (err) {
    return internalErrorResponse("manager-library-save", err);
  }
});
