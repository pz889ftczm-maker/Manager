// Shared helpers for Supabase Edge Functions (Deno runtime).
import { createClient } from "jsr:@supabase/supabase-js@2";

export const corsHeaders = {
  "Access-Control-Allow-Origin": "*", // tighten to your actual web origin in production
  "Access-Control-Allow-Headers": "authorization, x-client-info, apikey, content-type",
};

/** Client scoped to the calling user's JWT — respects RLS, so it can only
 * ever see that user's own rows. Use this for any read/write that should
 * be permission-checked. */
export function getUserScopedClient(req: Request) {
  const authHeader = req.headers.get("Authorization") ?? "";
  return createClient(Deno.env.get("SUPABASE_URL")!, Deno.env.get("SUPABASE_ANON_KEY")!, {
    global: { headers: { Authorization: authHeader } },
  });
}

/** Service-role client — bypasses RLS. Only use for operations that must
 * cross a single user's data boundary (there shouldn't be many) or where
 * you've already verified ownership yourself. */
export function getServiceRoleClient() {
  return createClient(Deno.env.get("SUPABASE_URL")!, Deno.env.get("SUPABASE_SERVICE_ROLE_KEY")!, {
    auth: { persistSession: false },
  });
}

// ============================================================
// Batch 5 additions (Parts O, P, A/C)
// ============================================================

/** Postgres-backed sliding-window rate limiter (Part O) — calls the
 * check_and_record_rate_limit() function added in
 * 0009_production_hardening.sql. Returns true if the caller is under the
 * limit (and records the hit); false once the limit is reached for this
 * (userId, bucket) pair within the trailing windowSeconds. Fails OPEN
 * (returns true) on an unexpected RPC error so a transient DB hiccup
 * can't take the whole endpoint down — the error itself is still logged
 * server-side for visibility. */
export async function checkRateLimit(
  // deno-lint-ignore no-explicit-any
  supabase: any,
  userId: string,
  bucket: string,
  maxHits: number,
  windowSeconds: number
): Promise<boolean> {
  const { data, error } = await supabase.rpc("check_and_record_rate_limit", {
    p_user_id: userId,
    p_bucket: bucket,
    p_max_hits: maxHits,
    p_window_seconds: windowSeconds,
  });
  if (error) {
    console.error(`rate limit check failed for bucket=${bucket}`, error.message);
    return true;
  }
  return data === true;
}

/** Generic 500 response that never leaks internals (stack traces,
 * Postgres error text, internal file paths) to the client (Part P). Full
 * detail still goes to the function's own logs via console.error. */
export function internalErrorResponse(context: string, err: unknown): Response {
  console.error(`[${context}]`, err);
  return new Response(JSON.stringify({ error: "Internal error. Please try again." }), {
    status: 500,
    headers: corsHeaders,
  });
}

export type DetectedKind = "image" | "video";

function readAscii(bytes: Uint8Array, offset: number, length: number): string {
  if (bytes.length < offset + length) return "";
  let out = "";
  for (let i = 0; i < length; i++) out += String.fromCharCode(bytes[offset + i]);
  return out;
}

function bytesStartWith(bytes: Uint8Array, offset: number, seq: number[]): boolean {
  if (bytes.length < offset + seq.length) return false;
  for (let i = 0; i < seq.length; i++) if (bytes[offset + i] !== seq[i]) return false;
  return true;
}

/** Magic-byte sniffing, duplicated from packages/shared/src/
 * uploadValidation.ts's sniffFileType — Edge Functions run on Deno and
 * can't import a Node workspace package (same constraint already noted
 * for computeContextWindow in clip-request/index.ts). Keep the signature
 * list in sync with packages/shared if supported formats ever change. */
export function sniffKind(bytes: Uint8Array): DetectedKind | null {
  if (bytesStartWith(bytes, 0, [0xff, 0xd8, 0xff])) return "image"; // JPEG
  if (bytesStartWith(bytes, 0, [0x89, 0x50, 0x4e, 0x47, 0x0d, 0x0a, 0x1a, 0x0a])) return "image"; // PNG
  if (readAscii(bytes, 0, 4) === "RIFF" && readAscii(bytes, 8, 4) === "WEBP") return "image"; // WEBP
  if (bytesStartWith(bytes, 0, [0x1a, 0x45, 0xdf, 0xa3])) return "video"; // WEBM (EBML header)
  if (readAscii(bytes, 4, 4) === "ftyp") return "video"; // MP4 / MOV (ISO-BMFF)
  return null;
}

/** Downloads just the first few KB of a private storage object (via a
 * short-lived signed URL + HTTP Range request) and sniffs its real type
 * from the bytes — Part A: "Never trust only the browser-provided MIME
 * type" / "Do not rely only on filename extension". Also returns the
 * object's real size from Storage's own listing (the actual bytes stored,
 * not anything the browser could misreport) so callers can enforce a size
 * limit server-side (Part C). Uses the service-role client because this
 * runs AFTER the caller's ownership of objectPath has already been
 * verified by the caller. */
export async function inspectStorageObject(
  // deno-lint-ignore no-explicit-any
  admin: any,
  bucket: string,
  objectPath: string
): Promise<{ sizeBytes: number | null; kind: DetectedKind | null }> {
  const folder = objectPath.split("/").slice(0, -1).join("/");
  const filename = objectPath.split("/").pop() ?? "";

  const { data: listing } = await admin.storage.from(bucket).list(folder, { search: filename });
  // deno-lint-ignore no-explicit-any
  const sizeBytes = listing?.find((o: any) => o.name === filename)?.metadata?.size ?? null;

  const { data: signed } = await admin.storage.from(bucket).createSignedUrl(objectPath, 60);
  if (!signed?.signedUrl) return { sizeBytes, kind: null };

  const res = await fetch(signed.signedUrl, { headers: { Range: "bytes=0-4095" } });
  if (!res.ok && res.status !== 206) return { sizeBytes, kind: null };
  const buf = new Uint8Array(await res.arrayBuffer());
  return { sizeBytes, kind: sniffKind(buf) };
}
