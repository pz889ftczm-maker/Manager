// Edge Function: POST /functions/v1/player-card-extract
//
// Batch 6A-3 — AI player-card image extraction ONLY. Given the storage
// path of a player-card image the caller already uploaded to the private
// `player-cards` bucket (see apps/web/src/lib/playerCardStorage.ts,
// Batch 6A-2), this function:
//   1. verifies the caller owns that object,
//   2. downloads and re-validates the real bytes (never trusts the
//      client's claimed content type/extension),
//   3. sends the actual image bytes to the AI provider via the existing
//      packages/ai router (getAiProvider() — same abstraction coach-chat
//      uses, so AI_PROVIDER=gemini gets Gemini-primary/Anthropic-fallback
//      here too, with no extra retry loop of its own),
//   4. runs the result through validatePlayerCardDraft
//      (packages/shared/src/playerCard.ts) so nothing malformed/invented
//      reaches the caller,
//   5. returns the draft — and ONLY the draft. Nothing here writes to
//      player_library; a later batch's Review/Edit UI decides if/when to
//      persist (see the 6A-3 spec's explicit scope limits).
//
// Mirrors coach-chat/index.ts's shape (auth -> rate limit -> AI call via
// the shared router -> safe error handling) and analysis-enqueue's
// ownership-prefix check (a caller could otherwise ask the worker/AI to
// read another user's private object, since the service-role client used
// for the actual download bypasses RLS).
import {
  corsHeaders,
  getUserScopedClient,
  checkRateLimit,
  sniffKind,
  internalErrorResponse,
} from "../_shared/helpers.ts";
import { getAiProvider, isProviderRouterError } from "../../../packages/ai/src/index.ts";
import { validatePlayerCardDraft } from "../../../packages/shared/src/index.ts";

const PLAYER_CARDS_BUCKET = "player-cards";
// Same convention/env var as the rest of the repo (analysis-enqueue.ts,
// uploadValidation.ts's DEFAULT_MAX_IMAGE_MB) — not a new size knob.
const MAX_IMAGE_UPLOAD_MB = Number(Deno.env.get("MAX_IMAGE_UPLOAD_MB") ?? "15");

/**
 * Chunked base64 encode — a naive `String.fromCharCode(...bytes)` spread
 * can blow the call stack on a multi-MB image, so this feeds btoa() in
 * bounded chunks instead. No external encoding dependency added — the
 * repo's existing convention (see _shared/helpers.ts's own magic-byte
 * sniffing) is to write small self-contained Deno-side utilities rather
 * than pull in another import-map entry for something this small.
 */
function bytesToBase64(bytes: Uint8Array): string {
  const CHUNK_SIZE = 0x8000; // 32KB
  let binary = "";
  for (let i = 0; i < bytes.length; i += CHUNK_SIZE) {
    const chunk = bytes.subarray(i, i + CHUNK_SIZE);
    binary += String.fromCharCode(...chunk);
  }
  return btoa(binary);
}

Deno.serve(async (req: Request) => {
  if (req.method === "OPTIONS") return new Response("ok", { headers: corsHeaders });

  try {
    const { objectPath } = await req.json();
    if (typeof objectPath !== "string" || objectPath.length === 0) {
      return new Response(JSON.stringify({ error: "objectPath is required" }), {
        status: 400,
        headers: corsHeaders,
      });
    }

    const supabase = getUserScopedClient(req);
    const {
      data: { user },
    } = await supabase.auth.getUser();
    if (!user) return new Response("unauthorized", { status: 401, headers: corsHeaders });

    // Security (spec: "Only authenticated users may request extraction of
    // their own uploaded player-card object" / "Do not trust a
    // client-supplied user_id" / "Resolve the authenticated user
    // server-side"). The storage RLS policies added in
    // 0012_player_library_storage.sql already enforce the same
    // `{user_id}/...` ownership prefix at the Storage layer, and the
    // download below uses the USER-SCOPED client (not service-role), so
    // this check is defense-in-depth, not the only enforcement — same
    // belt-and-suspenders pattern as analysis-enqueue's unownedPath check.
    const ownPrefix = `${user.id}/`;
    if (!objectPath.startsWith(ownPrefix)) {
      return new Response(JSON.stringify({ error: "objectPath must belong to the authenticated user" }), {
        status: 403,
        headers: corsHeaders,
      });
    }

    // Part O convention (coach-chat/clip-request) — real AI vision calls
    // cost money and take time; cap how many a user can fire in a window.
    const allowed = await checkRateLimit(supabase, user.id, "player-card-extract", 15, 300);
    if (!allowed) {
      return new Response(
        JSON.stringify({ error: "Too many card extraction requests. Please wait a moment and try again." }),
        { status: 429, headers: corsHeaders }
      );
    }

    // Download the REAL object bytes with the caller's own JWT — Storage
    // RLS (storage_player_cards_owner_select) means this can only ever
    // succeed for the signed-in user's own objects, independent of the
    // prefix check above. No service-role client is used anywhere in this
    // function, so there is no path here that can read another user's
    // card image even if the prefix check above were ever bypassed.
    const { data: blob, error: downloadError } = await supabase.storage
      .from(PLAYER_CARDS_BUCKET)
      .download(objectPath);
    if (downloadError || !blob) {
      return new Response(JSON.stringify({ error: "Could not read the uploaded player-card image." }), {
        status: 404,
        headers: corsHeaders,
      });
    }

    const bytes = new Uint8Array(await blob.arrayBuffer());

    if (bytes.length === 0) {
      return new Response(JSON.stringify({ error: "Uploaded player-card image is empty." }), {
        status: 422,
        headers: corsHeaders,
      });
    }
    if (bytes.length > MAX_IMAGE_UPLOAD_MB * 1024 * 1024) {
      return new Response(
        JSON.stringify({ error: `Player-card image exceeds the ${MAX_IMAGE_UPLOAD_MB}MB limit.` }),
        { status: 422, headers: corsHeaders }
      );
    }

    // Never trust the client-reported content type / file extension —
    // same magic-byte sniff used everywhere else in this repo (Part A).
    // Images only for a player card; a video signature or unrecognized
    // bytes are rejected here rather than ever reaching the AI provider.
    const kind = sniffKind(bytes);
    if (kind !== "image") {
      return new Response(
        JSON.stringify({ error: "The uploaded object is not a recognized image (jpeg/png/webp)." }),
        { status: 422, headers: corsHeaders }
      );
    }

    // Vision requirement (spec): actual image bytes, base64-encoded —
    // never a local filesystem path, a fake URL, a filename, or a
    // client-generated description standing in for the image.
    const imageBase64 = bytesToBase64(bytes);

    let rawDraft: unknown;
    try {
      const ai = getAiProvider();
      rawDraft = await ai.extractPlayerCard({ frame: { imageBase64 } });
    } catch (err) {
      // Same safe-logging convention as coach-chat: a ProviderRouterError
      // gives a secret-free category summary; anything else is logged by
      // message only. Never forward provider internals to the client.
      if (isProviderRouterError(err)) {
        console.error(
          `[player-card-extract] AI provider error: ${err.message} (primary=${err.primaryCategory}, fallback=${err.fallbackCategory})`
        );
      } else {
        console.error("[player-card-extract] AI provider error", err instanceof Error ? err.message : err);
      }
      return new Response(
        JSON.stringify({ error: "AI player-card extraction is temporarily unavailable. Please try again." }),
        { status: 502, headers: corsHeaders }
      );
    }

    // Nothing the model returns is trusted until it passes through here —
    // same convention as validateDetectedEventDraft / validatePlayerStatisticsDraft.
    // Malformed/invented values are dropped to null (never guessed), and
    // this is what's returned — never the raw model output directly.
    const { sanitized, errors } = validatePlayerCardDraft(rawDraft);
    if (errors.length > 0) {
      console.error(`[player-card-extract] draft validation warnings: ${errors.join("; ")}`);
    }

    // Deliberately NOT written to player_library here (out of scope for
    // this batch) — the caller (later: Review/Edit UI) decides if/when to
    // save, and the object at objectPath is left exactly as the caller
    // uploaded it (no mutation, no move, no delete).
    return new Response(JSON.stringify({ draft: sanitized }), {
      headers: { ...corsHeaders, "Content-Type": "application/json" },
    });
  } catch (err) {
    return internalErrorResponse("player-card-extract", err);
  }
});
