// Edge Function: POST /functions/v1/analysis-enqueue
// Called by apps/web/src/routes/Analyze.tsx after the raw file is already
// uploaded to Storage. This function verifies the caller actually owns
// the match/media, validates the uploaded object is actually what it
// claims to be, then forwards the job to the worker's internal HTTP API
// — it never touches Redis or ffmpeg itself.
import {
  corsHeaders,
  getUserScopedClient,
  getServiceRoleClient,
  checkRateLimit,
  inspectStorageObject,
  internalErrorResponse,
} from "../_shared/helpers.ts";
import { validateFootballTypeInput, buildFootballMatchContext } from "../../../packages/shared/src/index.ts";

const MAX_VIDEO_UPLOAD_MB = Number(Deno.env.get("MAX_VIDEO_UPLOAD_MB") ?? "500");
const MAX_IMAGE_UPLOAD_MB = Number(Deno.env.get("MAX_IMAGE_UPLOAD_MB") ?? "15");
const RAW_UPLOADS_BUCKET = Deno.env.get("STORAGE_BUCKET_RAW_UPLOADS") ?? "raw-uploads";

Deno.serve(async (req: Request) => {
  if (req.method === "OPTIONS") return new Response("ok", { headers: corsHeaders });

  try {
    const { matchId, mode, storageObjectPaths, mediaId, teamId, formationId, footballType } = await req.json();
    if (!matchId || !mode || !Array.isArray(storageObjectPaths) || storageObjectPaths.length === 0) {
      return new Response(JSON.stringify({ error: "matchId, mode, storageObjectPaths are required" }), {
        status: 400,
        headers: corsHeaders,
      });
    }
    if (mode !== "video" && mode !== "screenshot") {
      return new Response(JSON.stringify({ error: "mode must be 'video' or 'screenshot'" }), {
        status: 400,
        headers: corsHeaders,
      });
    }
    if (mode === "video" && !mediaId) {
      return new Response(JSON.stringify({ error: "mediaId is required for video mode" }), {
        status: 400,
        headers: corsHeaders,
      });
    }
    // 9C-1: teamId/formationId are optional — most matches still have
    // none (spec item 9). When present they must be well-formed strings;
    // formationId with no teamId has no team to belong to, so it's
    // rejected up front rather than silently discarded.
    if (teamId !== undefined && teamId !== null && typeof teamId !== "string") {
      return new Response(JSON.stringify({ error: "teamId must be a string" }), { status: 400, headers: corsHeaders });
    }
    if (formationId !== undefined && formationId !== null && typeof formationId !== "string") {
      return new Response(JSON.stringify({ error: "formationId must be a string" }), {
        status: 400,
        headers: corsHeaders,
      });
    }
    if (formationId && !teamId) {
      return new Response(JSON.stringify({ error: "formationId requires teamId" }), {
        status: 400,
        headers: corsHeaders,
      });
    }
    // 10A: footballType is optional (spec section 2/9 — most existing
    // matches have no context at all, and that must keep working).
    // validateFootballTypeInput (packages/shared/src/
    // footballMatchContext.ts) is the ONE place this codebase decides
    // what a valid football_type is — never re-implemented here.
    // team_size is deliberately NEVER read from the request body: it is
    // always derived server-side from a validated footballType (see
    // that function's own header comment), so there is no way for a
    // client to submit a mismatched (football_type, team_size) pair.
    const footballTypeResult = validateFootballTypeInput(footballType);
    if (!footballTypeResult.valid) {
      return new Response(JSON.stringify({ error: footballTypeResult.errors.join("; ") }), {
        status: 400,
        headers: corsHeaders,
      });
    }

    const supabase = getUserScopedClient(req);
    const {
      data: { user },
    } = await supabase.auth.getUser();
    if (!user) return new Response("unauthorized", { status: 401, headers: corsHeaders });

    // Part O — rate limit expensive enqueue calls per user. Generous
    // enough for legitimate retries after a real failure, tight enough to
    // stop a scripted/duplicate-click flood of worker jobs.
    const allowed = await checkRateLimit(supabase, user.id, "analysis-enqueue", 8, 300);
    if (!allowed) {
      return new Response(
        JSON.stringify({ error: "Too many analysis requests. Please wait a few minutes and try again." }),
        { status: 429, headers: corsHeaders }
      );
    }

    // RLS on `matches` already scopes this to the caller's own rows — this
    // select doubles as the ownership check.
    const { data: match, error } = await supabase.from("matches").select("id, user_id").eq("id", matchId).single();
    if (error || !match) return new Response("match not found", { status: 404, headers: corsHeaders });

    // Security fix (audit finding E.2): storageObjectPaths come straight
    // from the request body. The worker downloads them with the
    // service-role client, which bypasses RLS entirely — so without this
    // check, a caller could supply another user's `{other_uid}/...` path
    // and have the worker process someone else's private raw upload.
    // The storage RLS convention (0002_rls.sql) requires every object path
    // to be prefixed with its owner's uid, so enforce that same prefix here.
    const ownPrefix = `${user.id}/`;
    const unownedPath = storageObjectPaths.find((p: unknown) => typeof p !== "string" || !p.startsWith(ownPrefix));
    if (unownedPath !== undefined) {
      return new Response(JSON.stringify({ error: "storageObjectPaths must belong to the authenticated user" }), {
        status: 403,
        headers: corsHeaders,
      });
    }

    // B.2: mediaId comes straight from the request body like
    // storageObjectPaths above — same class of risk, so it needs the same
    // ownership check before we let the worker (service-role, bypasses
    // RLS) touch that row via it.
    if (mode === "video") {
      const { data: mediaRow, error: mediaErr } = await supabase
        .from("media")
        .select("id, match_id, user_id")
        .eq("id", mediaId)
        .single();
      if (mediaErr || !mediaRow || mediaRow.user_id !== user.id || mediaRow.match_id !== matchId) {
        return new Response(JSON.stringify({ error: "mediaId must belong to the authenticated user's match" }), {
          status: 403,
          headers: corsHeaders,
        });
      }
    }

    // 9C-1 (audit fix) — teamId/formationId come straight from the
    // request body like mediaId above, so they get the same
    // ownership-check-before-privileged-write treatment: verified here
    // with the user-scoped client (RLS on team_library/team_formations
    // already restricts every result to the caller's own rows — see
    // 0016/0021), then persisted by the service-role claim update below.
    // This is the ONLY place in the codebase that ever writes
    // matches.team_id/formation_id (see migration
    // 0028_matches_team_formation_context.sql and apps/worker/src/
    // matchSnapshot.ts's own header comment) — an absent teamId simply
    // leaves both columns NULL, exactly like every match analyzed
    // before this existed. Never inferred, never fabricated.
    if (teamId) {
      const { data: teamRow, error: teamErr } = await supabase
        .from("team_library")
        .select("id")
        .eq("id", teamId)
        .single();
      if (teamErr || !teamRow) {
        return new Response(JSON.stringify({ error: "teamId must belong to the authenticated user" }), {
          status: 403,
          headers: corsHeaders,
        });
      }
    }
    if (formationId) {
      // Must belong to THIS team specifically (not just any of the
      // caller's own teams) — same relationship create_match_snapshot
      // (0026/0027) itself re-verifies at snapshot-creation time.
      const { data: formationRow, error: formationErr } = await supabase
        .from("team_formations")
        .select("id")
        .eq("id", formationId)
        .eq("team_id", teamId)
        .single();
      if (formationErr || !formationRow) {
        return new Response(JSON.stringify({ error: "formationId must belong to teamId" }), {
          status: 403,
          headers: corsHeaders,
        });
      }
    }

    // Part A/C — never trust the browser-supplied MIME type or filename
    // extension. Sniff the real bytes of every uploaded object and check
    // its actual stored size before this is ever allowed to reach the
    // worker queue. Uses the service-role client only because ownership of
    // every path was already verified above with the user-scoped client.
    const admin = getServiceRoleClient();
    const expectedKind = mode === "video" ? "video" : "image";
    const maxMb = mode === "video" ? MAX_VIDEO_UPLOAD_MB : MAX_IMAGE_UPLOAD_MB;
    const maxBytes = maxMb * 1024 * 1024;

    for (const objectPath of storageObjectPaths as string[]) {
      const { sizeBytes, kind } = await inspectStorageObject(admin, RAW_UPLOADS_BUCKET, objectPath);

      let rejectReason: string | null = null;
      if (kind === null) {
        rejectReason = "Unrecognized file — its contents don't match any supported image or video format.";
      } else if (kind !== expectedKind) {
        rejectReason = `Uploaded file is a ${kind}, which doesn't match the ${expectedKind} upload mode.`;
      } else if (sizeBytes === null || sizeBytes <= 0) {
        rejectReason = "Uploaded file could not be read from storage.";
      } else if (sizeBytes > maxBytes) {
        rejectReason = `File is ${(sizeBytes / (1024 * 1024)).toFixed(1)}MB, which exceeds the ${maxMb}MB limit.`;
      }

      if (rejectReason) {
        // Prevent malformed/invalid uploads from ever entering the worker
        // queue (Part A) and don't leave a fake-looking row behind
        // (Part R) — remove the bad object and mark the associated media
        // row failed rather than silently leaving it stuck at 'uploaded'.
        await admin.storage.from(RAW_UPLOADS_BUCKET).remove([objectPath]);
        if (mode === "video") {
          await admin.from("media").update({ status: "failed" }).eq("id", mediaId);
        }
        await admin
          .from("matches")
          .update({ status: "error", error_message: rejectReason })
          .eq("id", matchId)
          .in("status", ["uploading", "error"]);
        return new Response(JSON.stringify({ error: rejectReason }), { status: 422, headers: corsHeaders });
      }
    }

    // Part J — idempotent enqueue. Atomically claim the match by flipping
    // its status uploading|error -> queued. If zero rows are affected,
    // another request already claimed it (a duplicate click, a retried
    // network request, or it's simply already past this stage) — refuse
    // rather than handing the worker a second job for the same match.
    // Uses the service-role client because matches has no client-scoped
    // UPDATE policy as of 0009_production_hardening.sql (Part R/I) — that
    // removal is exactly what makes this atomic claim meaningful instead
    // of racy.
    // 9C-1: fold the already-verified teamId/formationId into this same
    // claim update so the Team/Formation context lands on the match row
    // atomically with (and strictly before — this runs before the
    // worker is ever invoked below) the transition into 'queued'. Only
    // included when the caller actually supplied a value, so a retry
    // that omits them never clobbers a value persisted by an earlier
    // attempt on this same match.
    const claimUpdate: Record<string, unknown> = { status: "queued", error_message: null };
    if (teamId) claimUpdate.team_id = teamId;
    if (formationId) claimUpdate.formation_id = formationId;
    // 10A: only written when the caller actually supplied a
    // footballType (same "omit means don't touch it" convention as
    // teamId/formationId above) — team_size is always the derived
    // value for that football_type, never a separately-trusted input.
    // migration 0029's own matches_football_context_valid CHECK is the
    // final, load-bearing guarantee that these two columns can never
    // land in an inconsistent state even if this application-level
    // derivation were ever bypassed.
    if (footballTypeResult.footballType) {
      const context = buildFootballMatchContext(footballTypeResult.footballType);
      claimUpdate.football_type = context.football_type;
      claimUpdate.team_size = context.team_size;
    }

    const { data: claimed, error: claimErr } = await admin
      .from("matches")
      .update(claimUpdate)
      .eq("id", matchId)
      .in("status", ["uploading", "error"])
      .select("id")
      .maybeSingle();

    if (claimErr) return internalErrorResponse("analysis-enqueue.claim", claimErr);
    if (!claimed) {
      return new Response(
        JSON.stringify({ error: "This match is already queued, processing, or complete." }),
        { status: 409, headers: corsHeaders }
      );
    }

    const workerUrl = Deno.env.get("WORKER_INTERNAL_URL")!;
    const internalSecret = Deno.env.get("WORKER_INTERNAL_SECRET")!;
    const jobRoute = mode === "video" ? "/jobs/video" : "/jobs/screenshot";

    const jobPayload =
      mode === "video"
        ? {
            matchId,
            userId: user.id,
            mediaId,
            rawStorageObjectPath: storageObjectPaths[0],
          }
        : { matchId, userId: user.id, storageObjectPaths };

    let workerRes: Response;
    try {
      workerRes = await fetch(`${workerUrl}${jobRoute}`, {
        method: "POST",
        headers: { "Content-Type": "application/json", "x-internal-secret": internalSecret },
        body: JSON.stringify(jobPayload),
      });
    } catch (fetchErr) {
      // Worker temporarily unreachable (Part S) — release the claim so a
      // retry isn't permanently blocked by the 409 check above.
      await admin.from("matches").update({ status: "error", error_message: "Worker unavailable. Please retry." }).eq("id", matchId);
      return internalErrorResponse("analysis-enqueue.worker-fetch", fetchErr);
    }

    if (!workerRes.ok) {
      // Same reasoning — don't leave the match stuck at 'queued' forever
      // if the worker rejected the hand-off.
      await admin.from("matches").update({ status: "error", error_message: "Failed to enqueue job. Please retry." }).eq("id", matchId);
      return new Response(JSON.stringify({ error: "Failed to enqueue job" }), {
        status: 502,
        headers: corsHeaders,
      });
    }

    return new Response(JSON.stringify({ queued: true }), {
      status: 202,
      headers: { ...corsHeaders, "Content-Type": "application/json" },
    });
  } catch (err) {
    return internalErrorResponse("analysis-enqueue", err);
  }
});
