// Edge Function: POST /functions/v1/manager-card-extract
//
// Batch 6B-3 — AI manager-card image extraction ONLY. Mirrors
// supabase/functions/player-card-extract/index.ts (Batch 6A-3) exactly,
// applied to the private `manager-images` bucket (Batch 6B-2:
// apps/web/src/lib/managerImageStorage.ts, 0015_manager_images_storage.sql)
// instead of `player-cards`. Given the storage path of a manager-image
// the caller already uploaded, this function:
//   1. verifies the caller owns that object,
//   2. downloads and re-validates the real bytes (never trusts the
//      client's claimed content type/extension),
//   3. sends the actual image bytes to the AI provider via the existing
//      packages/ai router (getAiProvider() — same abstraction
//      player-card-extract/coach-chat use, so AI_PROVIDER=gemini gets
//      Gemini-primary/Anthropic-fallback here too, with no extra retry
//      loop of its own),
//   4. runs the result through validateManagerCardDraft
//      (packages/shared/src/managerCard.ts) so nothing malformed/
//      invented reaches the caller,
//   5. returns the draft — and ONLY the draft. Nothing here writes to
//      manager_library; a later batch's (6B-4) Review/Edit UI decides
//      if/when to persist (see this batch's spec's explicit scope
//      limits: "DO NOT save the extracted result to manager_library
//      yet").
//
// Mirrors coach-chat/index.ts's and player-card-extract/index.ts's shape
// (auth -> ownership check -> rate limit -> AI call via the shared
// router -> safe error handling) and analysis-enqueue's ownership-prefix
// check (a caller could otherwise ask the AI provider to read another
// user's private object, since the service-role client isn't used for
// the download below — the USER-SCOPED client is, so Storage RLS is the
// primary enforcement and this is defense-in-depth).
import {
  corsHeaders,
  getUserScopedClient,
  checkRateLimit,
  sniffKind,
  internalErrorResponse,
} from "../_shared/helpers.ts";
import { getAiProvider, isProviderRouterError } from "../../../packages/ai/src/index.ts";
import { validateManagerCardDraft } from "../../../packages/shared/src/index.ts";

const MANAGER_IMAGES_BUCKET = "manager-images";
// Same convention/env var as player-card-extract and the rest of the
// repo (analysis-enqueue.ts, uploadValidation.ts's
// DEFAULT_MAX_IMAGE_MB) — not a new size knob. The manager-images bucket
// itself (0015_manager_images_storage.sql) independently caps uploads at
// 15MB; this is the same defense-in-depth re-check player-card-extract
// already does on its own bucket.
const MAX_IMAGE_UPLOAD_MB = Number(Deno.env.get("MAX_IMAGE_UPLOAD_MB") ?? "15");

/**
 * Chunked base64 encode — identical to player-card-extract/index.ts's
 * helper of the same name (a naive `String.fromCharCode(...bytes)`
 * spread can blow the call stack on a multi-MB image). Duplicated rather
 * than shared because Edge Functions can't import from each other's
 * directories any more easily than from packages/shared's Node-only
 * modules — same constraint documented throughout this repo's Deno
 * functions.
 */
function bytesToBase64(bytes: Uint8Array): string {
  const CHUNK_SIZE = 0x8000; // 32KB
  let binary = "";
  for (let i = 0; i < bytes.length; i += CHUNK_SIZE) {
    const chunk = bytes.subarray(i, i + CHUNK_SIZE);
    binary += String.fromCharCode(...chunk);
  }
  return btoa(binary);
}

Deno.serve(async (req: Request) => {
  if (req.method === "OPTIONS") return new Response("ok", { headers: corsHeaders });

  try {
    const { objectPath } = await req.json();
    if (typeof objectPath !== "string" || objectPath.length === 0) {
      return new Response(JSON.stringify({ error: "objectPath is required" }), {
        status: 400,
        headers: corsHeaders,
      });
    }

    const supabase = getUserScopedClient(req);
    const {
      data: { user },
    } = await supabase.auth.getUser();
    if (!user) return new Response("unauthorized", { status: 401, headers: corsHeaders });

    // Security (same reasoning as player-card-extract/index.ts): only an
    // authenticated user may request extraction of their own uploaded
    // manager-image object. Never trust a client-supplied user id;
    // resolve it server-side from the verified JWT above. The storage
    // RLS policies added in 0015_manager_images_storage.sql already
    // enforce the same `{user_id}/...` ownership prefix at the Storage
    // layer, and the download below uses the USER-SCOPED client (not
    // service-role), so this check is defense-in-depth, not the only
    // enforcement — same belt-and-suspenders pattern as
    // analysis-enqueue's unownedPath check / player-card-extract's
    // identical prefix check.
    const ownPrefix = `${user.id}/`;
    if (!objectPath.startsWith(ownPrefix)) {
      return new Response(JSON.stringify({ error: "objectPath must belong to the authenticated user" }), {
        status: 403,
        headers: corsHeaders,
      });
    }

    // Part O convention (coach-chat/clip-request/player-card-extract) —
    // real AI vision calls cost money and take time; cap how many a user
    // can fire in a window. Separate rate-limit bucket name from
    // "player-card-extract" so the two extraction flows don't share one
    // quota — same reasoning each existing AI-calling Edge Function gets
    // its own named bucket.
    const allowed = await checkRateLimit(supabase, user.id, "manager-card-extract", 15, 300);
    if (!allowed) {
      return new Response(
        JSON.stringify({ error: "Too many manager-card extraction requests. Please wait a moment and try again." }),
        { status: 429, headers: corsHeaders }
      );
    }

    // Download the REAL object bytes with the caller's own JWT — Storage
    // RLS (storage_manager_images_owner_select) means this can only ever
    // succeed for the signed-in user's own objects, independent of the
    // prefix check above. No service-role client is used anywhere in
    // this function, so there is no path here that can read another
    // user's manager-image even if the prefix check above were ever
    // bypassed.
    const { data: blob, error: downloadError } = await supabase.storage
      .from(MANAGER_IMAGES_BUCKET)
      .download(objectPath);
    if (downloadError || !blob) {
      return new Response(JSON.stringify({ error: "Could not read the uploaded manager image." }), {
        status: 404,
        headers: corsHeaders,
      });
    }

    const bytes = new Uint8Array(await blob.arrayBuffer());

    if (bytes.length === 0) {
      return new Response(JSON.stringify({ error: "Uploaded manager image is empty." }), {
        status: 422,
        headers: corsHeaders,
      });
    }
    if (bytes.length > MAX_IMAGE_UPLOAD_MB * 1024 * 1024) {
      return new Response(
        JSON.stringify({ error: `Manager image exceeds the ${MAX_IMAGE_UPLOAD_MB}MB limit.` }),
        { status: 422, headers: corsHeaders }
      );
    }

    // Never trust the client-reported content type / file extension —
    // same magic-byte sniff used everywhere else in this repo (Part A).
    // Images only for a manager card; a video signature or unrecognized
    // bytes are rejected here rather than ever reaching the AI provider.
    const kind = sniffKind(bytes);
    if (kind !== "image") {
      return new Response(
        JSON.stringify({ error: "The uploaded object is not a recognized image (jpeg/png/webp)." }),
        { status: 422, headers: corsHeaders }
      );
    }

    // Vision requirement (spec): actual image bytes, base64-encoded —
    // never a local filesystem path, a fake URL, a filename, or a
    // client-generated description standing in for the image.
    const imageBase64 = bytesToBase64(bytes);

    let rawDraft: unknown;
    try {
      const ai = getAiProvider();
      rawDraft = await ai.extractManagerCard({ frame: { imageBase64 } });
    } catch (err) {
      // Same safe-logging convention as coach-chat/player-card-extract: a
      // ProviderRouterError gives a secret-free category summary;
      // anything else is logged by message only. Never forward provider
      // internals to the client.
      if (isProviderRouterError(err)) {
        console.error(
          `[manager-card-extract] AI provider error: ${err.message} (primary=${err.primaryCategory}, fallback=${err.fallbackCategory})`
        );
      } else {
        console.error("[manager-card-extract] AI provider error", err instanceof Error ? err.message : err);
      }
      return new Response(
        JSON.stringify({ error: "AI manager-card extraction is temporarily unavailable. Please try again." }),
        { status: 502, headers: corsHeaders }
      );
    }

    // Nothing the model returns is trusted until it passes through here —
    // same convention as validatePlayerCardDraft / validateDetectedEventDraft.
    // Malformed/invented values are dropped to null (never guessed).
    // valid === false means at least one field didn't hold up (an
    // invalid type, an out-of-range confidence, a malformed
    // field_evidence entry, etc.) — this is a hard boundary, not a
    // warning: the caller never receives a partially-discarded draft as
    // if it were clean, and nothing is written to manager_library.
    const { valid, sanitized, errors } = validateManagerCardDraft(rawDraft);
    if (!valid) {
      console.error(`[manager-card-extract] draft validation failed: ${errors.join("; ")}`);
      return new Response(
        JSON.stringify({ error: "AI manager-card extraction did not produce a valid result. Please try again." }),
        { status: 422, headers: corsHeaders }
      );
    }

    // Deliberately NOT written to manager_library here (out of scope for
    // this batch) — the caller (later: 6B-4's Review/Edit UI) decides
    // if/when to save, and the object at objectPath is left exactly as
    // the caller uploaded it (no mutation, no move, no delete).
    return new Response(JSON.stringify({ draft: sanitized }), {
      headers: { ...corsHeaders, "Content-Type": "application/json" },
    });
  } catch (err) {
    return internalErrorResponse("manager-card-extract", err);
  }
});
