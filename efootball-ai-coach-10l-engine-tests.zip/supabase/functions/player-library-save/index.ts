// Edge Function: POST /functions/v1/player-library-save
//
// Batch 6A-4 — Player Library: Review/Edit → Save persistence ONLY. This
// is the one and only code path in this batch that writes to
// public.player_library. It takes a human-reviewed PlayerLibraryInput —
// NEVER a raw PlayerCardDraft (spec section 11 / see
// packages/shared/src/playerLibrary.ts's header comment: "AI extraction
// is only a draft... future AI extraction must NOT silently overwrite"
// a saved value) — and either INSERTs a new row or UPDATEs one the
// caller already owns.
//
// Mirrors player-card-extract's shape (auth -> validate -> act) and
// clip-request's ownership-then-write pattern, but deliberately does NOT
// use a service-role client anywhere: every read/write here goes through
// the CALLER'S OWN user-scoped client, so RLS
// (player_library_select_own/insert_own/update_own/delete_own, migration
// 0011_player_library.sql) is the actual, independent enforcement of "a
// user must never be able to create/update/delete another user's player"
// (spec section 5) — every check in this function is defense-in-depth on
// top of that, never a replacement for it.
//
// Body: {
//   id?: string,       // present => update that row (must be owned by the caller); absent => insert a new row
//   name: string | null,
//   position: string | null,
//   overall: number | null,
//   playstyle: string | null,
//   attributes: Record<string, number | string | null>,
//   player_card_image_path?: string | null,
//   // ^ OMIT this key entirely on an update to leave the row's existing
//   // card image untouched (see hasImagePathField below). Always include
//   // it (even as null) on an insert.
// }
//
// Response: { player: PlayerLibrary, duplicate: boolean }
import { corsHeaders, getUserScopedClient, checkRateLimit, internalErrorResponse } from "../_shared/helpers.ts";
import {
  validatePlayerLibraryInput,
  isUniqueViolation,
  isPathOwnedByUser,
  PLAYER_LIBRARY_VARIANT_UNIQUE_CONSTRAINT,
} from "../../../packages/shared/src/index.ts";

const TABLE = "player_library";

// deno-lint-ignore no-explicit-any
function eqOrIsNull(query: any, column: string, value: string | number | null) {
  return value === null ? query.is(column, null) : query.eq(column, value);
}

Deno.serve(async (req: Request) => {
  if (req.method === "OPTIONS") return new Response("ok", { headers: corsHeaders });

  try {
    let body: unknown;
    try {
      body = await req.json();
    } catch {
      return new Response(JSON.stringify({ error: "Invalid JSON body" }), { status: 400, headers: corsHeaders });
    }
    if (!body || typeof body !== "object" || Array.isArray(body)) {
      return new Response(JSON.stringify({ error: "Request body must be an object" }), {
        status: 400,
        headers: corsHeaders,
      });
    }
    const bodyRecord = body as Record<string, unknown>;
    const rawId = bodyRecord.id;
    const editingId = typeof rawId === "string" && rawId.length > 0 ? rawId : null;

    const supabase = getUserScopedClient(req);
    const {
      data: { user },
    } = await supabase.auth.getUser();
    if (!user) return new Response("unauthorized", { status: 401, headers: corsHeaders });

    // Part O convention (same as player-card-extract/clip-request) — a
    // plain DB write is cheap, but still capped against a runaway client
    // bug or abuse rather than left completely open.
    const allowed = await checkRateLimit(supabase, user.id, "player-library-save", 60, 300);
    if (!allowed) {
      return new Response(JSON.stringify({ error: "Too many save requests. Please wait a moment and try again." }), {
        status: 429,
        headers: corsHeaders,
      });
    }

    // Never trust client-only validation (spec section 17) — this is the
    // SAME shared validator the Review/Edit UI runs for early feedback,
    // re-run here as the actual authority, against the raw, untrusted
    // request body.
    //
    // 6A-4 QUICK FIX: an omitted/unknown field is valid (NULL/UNKNOWN,
    // spec section 2), but a value the caller explicitly supplied that
    // fails validation (wrong type, negative/non-integer overall,
    // invalid attribute shape, invalid image-path syntax, ...) must
    // REJECT the write entirely — never sanitize-and-continue. Nothing
    // is written to player_library below this point when that happens.
    const { sanitized, errors } = validatePlayerLibraryInput(body);
    if (errors.length > 0) {
      console.warn(`[player-library-save] rejected invalid input: ${errors.join("; ")}`);
      // `errors` is produced entirely by validatePlayerLibraryInput's own
      // field-level checks — never a stack trace, a Postgres error, or
      // any other internal detail — so it's safe to return as-is.
      return new Response(JSON.stringify({ error: "Invalid player data.", details: errors }), {
        status: 400,
        headers: { ...corsHeaders, "Content-Type": "application/json" },
      });
    }

    // Spec section 8 — an image path, if any, must belong to the
    // caller's own storage prefix. RLS on storage.objects
    // (storage_player_cards_owner_select, migration 0012) already means
    // a signed URL/download could never succeed for someone else's
    // object regardless, and player_library_image_path_owned_prefix
    // (migration 0011) enforces the same prefix again as a table CHECK
    // constraint — this is a third, early check so a mismatched path is
    // rejected with a clear, attributable error rather than only ever
    // surfacing as an opaque CHECK-constraint failure.
    if (sanitized.player_card_image_path && !isPathOwnedByUser(sanitized.player_card_image_path, user.id)) {
      return new Response(JSON.stringify({ error: "player_card_image_path must belong to the authenticated user" }), {
        status: 403,
        headers: corsHeaders,
      });
    }

    const fields: Record<string, unknown> = {
      name: sanitized.name,
      position: sanitized.position,
      overall: sanitized.overall,
      playstyle: sanitized.playstyle,
      attributes: sanitized.attributes,
    };

    // Whether the caller's raw body even mentioned player_card_image_path
    // at all — distinct from it being present-but-null. Used only for
    // UPDATE below, so that editing a player's other fields never
    // accidentally clears its already-saved card image just because the
    // edit form didn't resend it (spec section 12: "keep the uploaded
    // card image associated with the saved player").
    const hasImagePathField = Object.prototype.hasOwnProperty.call(bodyRecord, "player_card_image_path");

    if (editingId) {
      // ------------------------------------------------------------
      // UPDATE an existing library entry (spec section 10). RLS
      // (player_library_update_own) scopes this to auth.uid() =
      // user_id — a non-owned or nonexistent id simply matches zero
      // rows, which this function reports as 404 below rather than
      // ever confirming/denying that another user's row exists.
      //
      // No column here can ever touch matches/analysis_events/
      // match_player_statistics — player_library has no such column and
      // no such foreign key (migration 0011's "HISTORICAL SAFETY" note)
      // — so this update structurally cannot modify or recalculate any
      // historical match data (spec section 10).
      // ------------------------------------------------------------
      const updatePayload: Record<string, unknown> = { ...fields };
      if (hasImagePathField) updatePayload.player_card_image_path = sanitized.player_card_image_path;

      const { data: updated, error: updateErr } = await supabase
        .from(TABLE)
        .update(updatePayload)
        .eq("id", editingId)
        .select()
        .maybeSingle();

      if (updateErr) {
        if (isUniqueViolation(updateErr, PLAYER_LIBRARY_VARIANT_UNIQUE_CONSTRAINT)) {
          return new Response(
            JSON.stringify({
              error: "You already have an identical player card (same name, position, and overall) saved.",
            }),
            { status: 409, headers: corsHeaders }
          );
        }
        throw updateErr;
      }
      if (!updated) {
        return new Response(JSON.stringify({ error: "Player not found." }), { status: 404, headers: corsHeaders });
      }

      return new Response(JSON.stringify({ player: updated, duplicate: false }), {
        status: 200,
        headers: { ...corsHeaders, "Content-Type": "application/json" },
      });
    }

    // ------------------------------------------------------------
    // INSERT a new library entry.
    // ------------------------------------------------------------
    const insertPayload: Record<string, unknown> = {
      ...fields,
      user_id: user.id, // never taken from the client (spec section 5) — always the authenticated caller
      player_card_image_path: sanitized.player_card_image_path,
    };

    const { data: inserted, error: insertErr } = await supabase.from(TABLE).insert(insertPayload).select().single();

    if (!insertErr) {
      return new Response(JSON.stringify({ player: inserted, duplicate: false }), {
        status: 201,
        headers: { ...corsHeaders, "Content-Type": "application/json" },
      });
    }

    // Spec section 9 — an accidental duplicate save (double-click,
    // network retry) hits player_library_user_variant_uniq. Rather than
    // surface that as an error, look up and return the row that already
    // exists so a retried request converges on the same result the
    // original one produced, instead of failing or creating a second
    // row. Only attempted when the constraint that actually fired is
    // this one (never masks an unrelated error) and when name isn't
    // null (the partial index doesn't apply to null-named entries —
    // see playerLibraryVariantKey's doc comment — so a genuine insert
    // error there is never a duplicate-variant conflict).
    if (isUniqueViolation(insertErr, PLAYER_LIBRARY_VARIANT_UNIQUE_CONSTRAINT) && sanitized.name !== null) {
      let existingQuery = supabase.from(TABLE).select().eq("user_id", user.id);
      existingQuery = eqOrIsNull(existingQuery, "position", sanitized.position);
      existingQuery = eqOrIsNull(existingQuery, "overall", sanitized.overall);
      const { data: siblings, error: lookupErr } = await existingQuery;
      if (lookupErr) throw lookupErr;
      const nameLower = sanitized.name.toLowerCase();
      const existing = (siblings ?? []).find(
        (r: { name: string | null }) => r.name != null && r.name.toLowerCase() === nameLower
      );
      if (existing) {
        return new Response(JSON.stringify({ player: existing, duplicate: true }), {
          status: 200,
          headers: { ...corsHeaders, "Content-Type": "application/json" },
        });
      }
      // Fell through without finding it (e.g. it was deleted between the
      // failed insert and this lookup) — fall through to the generic
      // error handling below rather than claiming a duplicate that
      // isn't actually there.
    }

    throw insertErr;
  } catch (err) {
    return internalErrorResponse("player-library-save", err);
  }
});
