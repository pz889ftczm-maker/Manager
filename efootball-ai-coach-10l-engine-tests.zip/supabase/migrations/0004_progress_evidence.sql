-- Batch 3: real player_progress write path needs a place to persist the
-- *evidence* behind recommended_position / playstyle_tags / most_common_mistake
-- (confidence scores, supporting counts, insufficient-data flags), not just
-- the final labels. Rather than adding many narrow columns, this uses a
-- small number of jsonb columns that mirror the shape produced by
-- packages/shared/src/progress.ts::aggregatePlayerProgress — see that file
-- for the exact structure written here.

alter table public.player_progress
  add column if not exists recommended_position_confidence numeric(5,2),
  add column if not exists recommended_position_evidence jsonb,
  add column if not exists playstyle_evidence jsonb,
  add column if not exists mistake_analysis jsonb,
  add column if not exists possession_loss_total integer not null default 0,
  add column if not exists insufficient_data text[] not null default '{}';

comment on column public.player_progress.recommended_position_confidence is
  '0-100. Null when matches_analyzed is below the minimum sample size (see MIN_MATCHES_FOR_POSITION).';
comment on column public.player_progress.recommended_position_evidence is
  'Array of short strings citing the actual aggregated numbers that produced recommended_position.';
comment on column public.player_progress.playstyle_evidence is
  'Object keyed by playstyle tag -> short string citing the real stats/event counts that earned that tag.';
comment on column public.player_progress.mistake_analysis is
  '{ most_common: {event_type, occurrences, matches_count} | null, repeated: [{event_type, occurrences, matches_count}] }.
   "repeated" only includes mistake event_types seen in 2+ distinct real matches.';
comment on column public.player_progress.insufficient_data is
  'Which of the progress dimensions (positioning | trend | weakness | position | playstyle) do not yet
   have enough real analyzed history to compute reliably. Frontend/AI Coach should treat the
   corresponding field as "not enough data" rather than a confident answer.';
