-- Batch 4 — video experience (real player, Watch Moment, clip generation).
--
-- AUDIT FINDING (see also README.md "Documented stubs" and the comment on
-- MatchReport.tsx's old Watch button): processMatchVideo.ts compresses the
-- uploaded video with ffmpeg but only ever writes the result to a LOCAL
-- worker scratch dir, which is deleted in that job's `finally` block. The
-- original raw upload is then also deleted from `raw-uploads` once analysis
-- succeeds (by design — spec section 10/26/29, temp video cleanup). Net
-- effect: no video byte ever survives a completed analysis job today. There
-- is nothing to reuse for a video player — this migration adds the minimum
-- needed to persist ONE playable asset per video-analyzed match, without
-- touching how the raw temp video is handled.
--
-- Two new PRIVATE buckets (created in seed.sql, same as the existing two):
--   match-videos  — the ffmpeg-compressed, web-ready MP4 for a match.
--                   Kept indefinitely (not temporary) once written; this is
--                   what the player/Watch Moment/clip generation read from.
--   video-clips   — short trimmed MP4s generated on demand per event.
-- Both follow the exact `{user_id}/{match_id}/{filename}` path convention
-- already used by raw-uploads/processed-frames, so the browser can mint its
-- own short-lived signed URLs directly via supabase-js (same mechanism the
-- app already relies on elsewhere) — no new Edge Function needed just to
-- read them.
--
-- media rows: the permanent match-videos asset is a SEPARATE media row
-- (type='video', is_temporary=false, status='processed') from the existing
-- temporary raw-upload row (type='video', is_temporary=true) — see
-- processMatchVideo.ts. Keeping them as distinct rows means the existing
-- raw-upload lifecycle (optimizing -> optimized -> processed -> deleted_temp)
-- is completely unmodified; the frontend finds the playable asset with
-- `media.is_temporary = false`, which naturally returns nothing for matches
-- analyzed before this migration (they correctly show "video unavailable"
-- rather than a fabricated URL) or for demo/screenshot-only matches (which
-- never had a video row at all).

-- ------------------------------------------------------------------
-- 1. Storage RLS — owner-scoped read/write, identical pattern to the
--    existing raw-uploads / processed-frames policies in 0002_rls.sql.
-- ------------------------------------------------------------------
create policy "storage_match_videos_owner_rw"
  on storage.objects for all
  using (
    bucket_id = 'match-videos'
    and (storage.foldername(name))[1] = auth.uid()::text
  )
  with check (
    bucket_id = 'match-videos'
    and (storage.foldername(name))[1] = auth.uid()::text
  );

create policy "storage_video_clips_owner_rw"
  on storage.objects for all
  using (
    bucket_id = 'video-clips'
    and (storage.foldername(name))[1] = auth.uid()::text
  )
  with check (
    bucket_id = 'video-clips'
    and (storage.foldername(name))[1] = auth.uid()::text
  );

-- ------------------------------------------------------------------
-- 2. video_clips — tracks async clip-generation jobs (Part 8-12).
-- ------------------------------------------------------------------
create type video_clip_status as enum ('pending', 'processing', 'completed', 'failed');

create table public.video_clips (
  id uuid primary key default gen_random_uuid(),
  user_id uuid not null references auth.users(id) on delete cascade,
  match_id uuid not null references public.matches(id) on delete cascade,
  event_id uuid not null references public.analysis_events(id) on delete cascade,
  storage_path text, -- set only once status = 'completed'
  start_time numeric(8,2) not null check (start_time >= 0),
  end_time numeric(8,2) not null check (end_time > start_time),
  status video_clip_status not null default 'pending',
  error_message text,
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now(),

  -- Idempotency (Part 12): the same user+match+event+start+end never gets a
  -- second row — the clip-request Edge Function looks this up first and
  -- reuses/retries the existing row instead of inserting again.
  unique (user_id, match_id, event_id, start_time, end_time)
);

create index video_clips_match_id_idx on public.video_clips(match_id);
create index video_clips_event_id_idx on public.video_clips(event_id);
create index video_clips_user_id_idx on public.video_clips(user_id);

-- Defense-in-depth, same shape as check_match_player_statistics_ownership
-- in migration 0006: even though only the service-role worker/Edge
-- Function ever writes status transitions, verify the event actually
-- belongs to the match and the match actually belongs to user_id, so a
-- bug elsewhere can't silently create a clip record attributing one
-- user's video to another's event.
create or replace function public.check_video_clip_ownership()
returns trigger
language plpgsql
as $$
begin
  if not exists (select 1 from public.matches m where m.id = new.match_id and m.user_id = new.user_id) then
    raise exception 'video_clips.user_id does not match matches.user_id for match %', new.match_id;
  end if;
  if not exists (select 1 from public.analysis_events e where e.id = new.event_id and e.match_id = new.match_id) then
    raise exception 'video_clips.event_id does not belong to match %', new.match_id;
  end if;
  new.updated_at := now();
  return new;
end;
$$;

create trigger video_clips_ownership_check
  before insert or update on public.video_clips
  for each row execute procedure public.check_video_clip_ownership();

alter table public.video_clips enable row level security;

create policy "video_clips_select_own" on public.video_clips
  for select using (auth.uid() = user_id);

-- Clients may only ever create a fresh 'pending' request with no
-- storage_path — mirrors the ai_coach_messages_role_hardening precedent
-- (migration 0003): a client-scoped insert may not fabricate a
-- 'completed'/'failed' row or set storage_path itself (Part 10: "Do NOT
-- create fake completed records"). Actual status/storage_path transitions
-- are written by the worker via the service-role client, which bypasses
-- RLS by design, after it has actually generated the file.
create policy "video_clips_insert_own_pending" on public.video_clips
  for insert
  with check (auth.uid() = user_id and status = 'pending' and storage_path is null);

-- No client-scoped update/delete policy: retries go through the
-- clip-request Edge Function (which uses the service-role client after
-- re-verifying ownership itself), not a direct client UPDATE.

comment on table public.video_clips is
  'Batch 4: async video clip generation jobs. One row per distinct (user, match, event, start_time, end_time) — see the unique constraint for idempotency (Part 12). storage_path lives in the video-clips private bucket at {user_id}/{match_id}/{event_id}.mp4.';
