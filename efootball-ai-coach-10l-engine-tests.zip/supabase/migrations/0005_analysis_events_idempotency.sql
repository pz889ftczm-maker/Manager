-- Batch 3 bugfix: retry-safe analysis_events.
--
-- Problem
-- -------
-- processMatchVideo / processScreenshot inserted analysis_events with a plain
-- INSERT. If a job failed halfway (or was retried by the queue for any
-- reason), the second run re-inserted the SAME detected events for the same
-- match. Nothing in the schema stopped that, so a retried match ended up with
-- duplicated events, which inflated match_statistics counts/averages and — via
-- them — player_progress. (This was documented as a known caveat in
-- apps/worker/src/statistics.ts; this migration + the worker changes close it.)
--
-- Strategy
-- --------
-- The only deterministic identity an analysis event has is its own content:
-- the moment it happened plus what was detected there. There is no external
-- provider id to key on. So we derive a stored, immutable fingerprint column
-- (`dedupe_key`) from the event's defining fields and make (match_id,
-- dedupe_key) unique.
--
-- Fields in the fingerprint:
--   timestamp_seconds  -- when in the match (NULL for single screenshots)
--   context_start/end  -- which analysis window produced it
--   event_type         -- what happened
--   category           -- which skill area
--   severity           -- how bad/good
--   description        -- the model's specific text for this moment
--
-- Why legitimate distinct events cannot collide:
--   * Two different moments differ in timestamp_seconds (and/or their context
--     window), so they hash differently even with identical event_type.
--   * Two different findings at the SAME timestamp differ in at least
--     event_type / category / severity / description, so they hash differently.
--   * Only a byte-for-byte identical re-detection of the same moment in the
--     same match collapses — which is exactly what a retry produces.
-- Deliberately excluded from the fingerprint: decision_score, confidence,
-- confidence_level, reasoning, better_option, the *_frame_url columns and
-- created_at. Those are re-derived/re-uploaded per run and may wobble slightly
-- between attempts; including them would let a retry sneak past the constraint.
--
-- NULL handling: coalesce() to a sentinel inside the hash, so the key is always
-- NOT NULL and screenshot events (timestamp_seconds IS NULL) still dedupe.

-- ------------------------------------------------------------------
-- 1. Fingerprint helper + column
-- ------------------------------------------------------------------
-- The hashing lives in an IMMUTABLE function because a generated column may
-- only use immutable expressions, and Postgres conservatively treats the
-- inline numeric/enum -> text I/O casts as mutable.
create or replace function public.analysis_event_dedupe_key(
  p_timestamp_seconds numeric,
  p_context_start_seconds numeric,
  p_context_end_seconds numeric,
  p_event_type text,
  p_category text,
  p_severity event_severity,
  p_description text
)
returns text
language sql
immutable
parallel safe
as $$
  select md5(
    coalesce(p_timestamp_seconds::text, '~')     || '|' ||
    coalesce(p_context_start_seconds::text, '~') || '|' ||
    coalesce(p_context_end_seconds::text, '~')   || '|' ||
    coalesce(p_event_type, '~')                  || '|' ||
    coalesce(p_category, '~')                    || '|' ||
    coalesce(p_severity::text, '~')              || '|' ||
    md5(coalesce(p_description, '~'))
  )
$$;

comment on function public.analysis_event_dedupe_key is
  'Immutable content fingerprint for an analysis event; backs analysis_events.dedupe_key.';

alter table public.analysis_events
  add column if not exists dedupe_key text
  generated always as (
    public.analysis_event_dedupe_key(
      timestamp_seconds,
      context_start_seconds,
      context_end_seconds,
      event_type,
      category,
      severity,
      description
    )
  ) stored;

comment on column public.analysis_events.dedupe_key is
  'Deterministic content fingerprint of this event (timestamp + context window + event_type + category + severity + description). Together with match_id it forms the idempotency key used by the worker''s conflict-safe upsert, so retrying an analysis job cannot create duplicate events.';

-- ------------------------------------------------------------------
-- 2. Collapse pre-existing retry duplicates
-- ------------------------------------------------------------------
-- Only rows that are identical in every fingerprinted field within the same
-- match are removed, and the OLDEST row of each group is always kept, so no
-- legitimate (distinct) event is deleted. Their tactical_analysis rows are
-- equally duplicated and go with them via the existing ON DELETE CASCADE;
-- the kept event keeps its own tactical row.
delete from public.analysis_events e
using public.analysis_events keep
where e.match_id = keep.match_id
  and e.dedupe_key = keep.dedupe_key
  and (keep.created_at, keep.id) < (e.created_at, e.id);

-- ------------------------------------------------------------------
-- 3. Uniqueness
-- ------------------------------------------------------------------
-- A real UNIQUE CONSTRAINT (not just an index) so PostgREST/supabase-js can
-- target it with on_conflict=match_id,dedupe_key.
alter table public.analysis_events
  drop constraint if exists analysis_events_match_dedupe_key_uniq;
alter table public.analysis_events
  add constraint analysis_events_match_dedupe_key_uniq unique (match_id, dedupe_key);

-- ------------------------------------------------------------------
-- 4. Same problem one level down: tactical_analysis
-- ------------------------------------------------------------------
-- One event has exactly one tactical diagram, but it was inserted with a plain
-- INSERT too, so a retry stacked extra rows for the same event_id (and the
-- MatchReport page reads the first one it finds). Deduplicate keeping the
-- oldest, then enforce 1:1 so the worker can upsert on event_id.
delete from public.tactical_analysis t
using public.tactical_analysis keep
where t.event_id = keep.event_id
  and (keep.created_at, keep.id) < (t.created_at, t.id);

alter table public.tactical_analysis
  drop constraint if exists tactical_analysis_event_id_uniq;
alter table public.tactical_analysis
  add constraint tactical_analysis_event_id_uniq unique (event_id);

-- RLS is untouched by this migration: analysis_events / tactical_analysis keep
-- the exact policies from 0002_rls.sql (ownership is still derived through
-- matches.user_id), and the worker keeps writing with the service role.
