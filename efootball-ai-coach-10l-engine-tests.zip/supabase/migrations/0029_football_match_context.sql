-- Batch 10A — Football Match Context: the smallest schema change
-- needed to persist which kind of football a match is (eFootball
-- 11v11 vs Real Football 7v7) so a later Football Analysis Engine
-- phase (10B/10C, NOT implemented here) can read it back without
-- guessing. This migration adds exactly two columns to `matches` and
-- one cross-column CHECK constraint — no new table, no RLS change, no
-- new index (see design notes below for why).
--
-- Design notes
-- ------------
-- * NULLABLE, NO DEFAULT, BACKWARD COMPATIBLE (spec 10A section 2/9):
--   both columns are nullable with no default, so every existing
--   `matches` row remains valid immediately after this migration, with
--   football_type = team_size = NULL — the same "no context yet" shape
--   matches.team_id/formation_id already got from migration 0028. No
--   backfill is attempted: for a match analyzed before this feature
--   existed, there is no recorded fact anywhere about which kind of
--   football it was, and guessing one (e.g. "assume eFootball, since
--   that's what the app mostly does today") would be exactly the
--   fabrication packages/shared/src/footballMatchContext.ts's own
--   header comment explicitly forbids. NULL is the only honest value
--   for that history, and stays NULL forever unless a caller explicitly
--   supplies a football_type for that specific match later.
-- * football_type IS A PLAIN text COLUMN, NOT A NEW ENUM TYPE: mirrors
--   this repo's own existing convention for a small, closed string set
--   on `matches` (source_type, status — both 0001_schema.sql — are
--   plain text with a CHECK, not a Postgres enum type). A CHECK
--   constraint gets the same validation guarantee as an enum type
--   without the extra migration overhead of ALTER TYPE ... ADD VALUE
--   if a third football type is ever added later.
-- * CROSS-COLUMN CHECK, NULL EXPLICITLY ALLOWED (spec 10A section 2 —
--   "team_size should be derived/validated consistently with
--   football_type... If a CHECK constraint is used, ensure NULL
--   remains allowed for legacy rows"): matches_football_context_valid
--   below allows exactly three shapes — both columns NULL (legacy/no
--   context), ('efootball', 11), or ('real_football', 7). Every other
--   combination (an unrecognized football_type string, a mismatched
--   team_size, one column NULL and the other not) is rejected by
--   Postgres itself at the database layer — this is the real,
--   load-bearing enforcement of "team_size must stay consistent with
--   football_type", not merely a suggestion enforced by application
--   code. packages/shared/src/footballMatchContext.ts's own
--   teamSizeForFootballType is the single source of truth this CHECK's
--   two literal pairs were copied from — if that ever changes, this
--   CHECK must be updated in the same migration as this repo's own
--   "keep validators and constraints in sync" convention (see e.g.
--   0025's jsonb-shape checks mirroring teamFormations.ts's own).
-- * NO OWNERSHIP TRIGGER, NO NEW RLS (spec 10A section 5 — "context
--   must be validated server-side"): exactly like matches.team_id/
--   formation_id (0028), `matches` already has no client-side UPDATE
--   policy at all (0009_production_hardening.sql) — the only way
--   either new column is ever written is supabase/functions/
--   analysis-enqueue's own existing service-role claim update, which
--   validates any client-supplied football_type with
--   validateFootballTypeInput (packages/shared/src/
--   footballMatchContext.ts) BEFORE it ever reaches this column. No
--   RLS policy is added, changed, or weakened by this migration.
-- * NO INDEX (spec 10A section 2 — "add an appropriate index only if
--   genuinely useful"): no query in this batch (or anywhere else in
--   the current codebase) filters/joins on football_type or team_size
--   — 10A only adds the ability to persist and read this context back
--   by matches.id, which the existing primary key already serves.
--   10B/10C can add one later if a real query pattern needs it.
-- * REGRESSION (spec 10A section 9): this migration adds exactly two
--   nullable columns and one CHECK constraint to `matches`. It does
--   not touch any other column, any other table, any RLS policy, or
--   any existing row's data — every existing match keeps its existing
--   status/statistics/history/team_id/formation_id untouched, now
--   simply with football_type = team_size = NULL until
--   analysis-enqueue is given a football_type to persist for it.

alter table public.matches
  add column football_type text,
  add column team_size integer;

alter table public.matches
  add constraint matches_football_context_valid
  check (
    (football_type is null and team_size is null)
    or (football_type = 'efootball' and team_size = 11)
    or (football_type = 'real_football' and team_size = 7)
  );
