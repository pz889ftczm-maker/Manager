-- Batch 8B — Formation Player Assignment & Persistence. Adds the
-- player-assignment layer on top of the formation DATA MODEL from
-- Batch 8A (0021_team_formations.sql, left completely unchanged by
-- this migration). No Formation UI, no starting XI/bench, no presets,
-- no historical snapshots — all still out of scope, same as 8A.
--
-- Design notes
-- ------------
-- * NO user_id COLUMN (explicit spec requirement). Ownership is a
--   TWO-hop derivation, same shape as team_members (0019) but one link
--   longer on one side:
--     - via formation:  team_formation_players.formation_id
--                        -> team_formations.team_id -> team_library.user_id
--     - via player:     team_formation_players.player_id
--                        -> player_library.user_id
--   Every RLS policy below (and the ownership-consistency trigger)
--   proves ownership via `exists (select ... join ... where ...)`,
--   never by comparing to a `user_id` that doesn't exist on this table.
-- * FOREIGN KEYS: formation_id -> team_formations(id), player_id ->
--   player_library(id), both `on delete cascade` per spec section 12 —
--   deleting a formation or a player_library entry removes the
--   assignment row, but never the other way around (removing an
--   assignment only ever deletes this junction row; it cannot delete a
--   team_formations or player_library row, since there is no reverse
--   FK/trigger that could do that).
-- * UNIQUENESS: `unique (formation_id, player_id)` (spec section 2 —
--   "the same player MUST NOT be assigned twice to the same
--   formation"). Named explicitly
--   (team_formation_players_formation_player_uniq) rather than left to
--   Postgres's default constraint-naming, so application code
--   (packages/shared/src/teamFormationPlayers.ts) can reliably
--   recognize a unique-violation on this exact constraint via
--   isUniqueViolation (playerLibrary.ts) without depending on
--   Postgres's naming convention for an unnamed inline `unique (...)`
--   clause. The same player MAY appear in multiple different
--   formations (nothing here prevents that — the uniqueness is scoped
--   to one formation_id at a time), and a formation may hold any
--   number of players — spec section 2 explicitly forbids inventing an
--   artificial "11 players" cap or starting-XI/bench concept at this
--   layer, so no such limit is added.
-- * position_slot: plain, non-blank text — a stable slot identifier
--   that's expected to match one of the `id`s inside the owning
--   formation's team_formations.positions JSONB (spec section 3), but
--   that cross-reference is NOT enforced as a foreign key or CHECK
--   constraint here: positions lives inside a jsonb blob on a
--   different table, and validating "does this text equal one of the
--   keys/ids in that JSONB" at the database layer would require a
--   trigger re-parsing arbitrary, evolving jsonb shapes from 8A on
--   every insert/update — exactly the kind of brittle, over-eager
--   coupling both 8A's and this batch's specs repeatedly ask this
--   project to avoid. A blank/whitespace-only slot is still rejected
--   (constraint below); deeper "is this actually one of the formation's
--   slot ids" validation is left to the application layer, which is
--   free to check it against the same formation row it's already
--   loading.
-- * NO PLAYER DATA DUPLICATION (spec section 3): this table has
--   exactly six columns — id, formation_id, player_id, position_slot,
--   created_at, updated_at — and nothing else. Player name, stats,
--   attributes, and image path stay solely on player_library, and
--   layout coordinates (x/y) stay solely on
--   team_formations.positions — a reader joins through player_id/
--   formation_id to get either. This also means a later edit to a
--   player_library card, or to a formation's layout, is instantly
--   reflected for every assignment referencing it, with nothing here
--   to go stale.
-- * OWNERSHIP-CONSISTENCY TRIGGER (defense-in-depth, same convention as
--   check_team_members_ownership in 0019_team_members.sql): RLS's
--   `with check` clauses (below) are what actually stop a cross-user
--   insert/update via the browser, but per spec sections 4/5/11 a
--   second, independent check is added directly on the table itself.
--   This one couldn't compare against a `user_id` column (there isn't
--   one here) — instead it directly asserts that the team_formations
--   row (via its team_library owner) and the player_library row
--   referenced by a given team_formation_players row belong to the
--   SAME auth.users id, which is the actual invariant this whole batch
--   exists to protect. This still holds even for a hypothetical future
--   service-role write that bypassed RLS entirely (spec section 5 —
--   "reject cross-user relationships even if RLS is bypassed by a
--   privileged/internal path").
-- * HISTORICAL SAFETY: no column here references matches/
--   analysis_events/player_statistics/progress/snapshots/tournament
--   results/AI Coach, and nothing in this migration adds a column FROM
--   those tables back to this one. team_formation_players represents
--   the CURRENT assignment only, freely editable without touching any
--   historical record, by construction.
-- * NO starting XI / bench columns or concepts (spec sections 2/14) —
--   this table only records "player X is in slot Y of formation Z",
--   nothing about whether that slot is "starting" vs "bench" (that
--   distinction doesn't exist in this data model at all yet).
-- * DEMO DATA: no rows are inserted for this table anywhere (this
--   migration or supabase/seed.sql) — there is no demo/sample
--   assignment.
-- * 0021_team_formations.sql is NOT modified by this migration — it is
--   referenced only by foreign key, exactly as 8A left it.
-- * Out of scope for this batch (per spec): Formation UI,
--   drag-and-drop, starting XI, bench, player picker UI, formation
--   presets, historical snapshots, match references, AI Coach/Football
--   Analysis/Progress/Dashboard/Tournament changes. This migration adds
--   schema + RLS + the ownership trigger only.

-- ============================================================
-- TEAM FORMATION PLAYERS
-- ============================================================
create table public.team_formation_players (
  id uuid primary key default gen_random_uuid(),
  formation_id uuid not null references public.team_formations(id) on delete cascade,
  player_id uuid not null references public.player_library(id) on delete cascade,
  position_slot text not null,

  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now(),

  -- See "position_slot" design note above.
  constraint team_formation_players_position_slot_not_blank
    check (btrim(position_slot) <> ''),

  -- See "UNIQUENESS" design note above.
  constraint team_formation_players_formation_player_uniq unique (formation_id, player_id)
);

-- See "INDEXES" note (spec section 6): the unique constraint above
-- already indexes (formation_id, player_id), with formation_id as its
-- leading column, so no separate plain formation_id index is added
-- here — only player_id needs its own index (queries filtering by
-- player_id alone can't use a composite index whose leading column is
-- formation_id).
create index team_formation_players_player_id_idx on public.team_formation_players(player_id);

create or replace function public.touch_team_formation_players_updated_at()
returns trigger
language plpgsql
as $$
begin
  new.updated_at := now();
  return new;
end;
$$;

create trigger team_formation_players_touch_updated_at
  before update on public.team_formation_players
  for each row execute procedure public.touch_team_formation_players_updated_at();

-- See "OWNERSHIP-CONSISTENCY TRIGGER" design note above.
create or replace function public.check_team_formation_players_ownership()
returns trigger
language plpgsql
as $$
begin
  if not exists (
    select 1
    from public.team_formations f
    join public.team_library t on t.id = f.team_id
    join public.player_library p on p.user_id = t.user_id
    where f.id = new.formation_id
      and p.id = new.player_id
  ) then
    raise exception 'team_formation_players: formation % and player % do not belong to the same user', new.formation_id, new.player_id;
  end if;
  new.updated_at := now();
  return new;
end;
$$;

create trigger team_formation_players_ownership_check
  before insert or update on public.team_formation_players
  for each row execute procedure public.check_team_formation_players_ownership();

-- ============================================================
-- RLS
-- ============================================================
alter table public.team_formation_players enable row level security;

-- SELECT: only assignments belonging to one of the caller's own
-- formations are visible (spec section 4 — "the formation's team must
-- belong to auth.uid()").
create policy "team_formation_players_select_own" on public.team_formation_players
  for select using (
    exists (
      select 1 from public.team_formations f
      join public.team_library t on t.id = f.team_id
      where f.id = formation_id and t.user_id = auth.uid()
    )
  );

-- INSERT: BOTH the formation (via its owning team) AND the player must
-- belong to the caller (spec section 4 — both ownership sides
-- required, same two-sided shape as team_members_insert_own in 0019).
create policy "team_formation_players_insert_own" on public.team_formation_players
  for insert with check (
    exists (
      select 1 from public.team_formations f
      join public.team_library t on t.id = f.team_id
      where f.id = formation_id and t.user_id = auth.uid()
    )
    and exists (
      select 1 from public.player_library p
      where p.id = player_id and p.user_id = auth.uid()
    )
  );

-- UPDATE: same two-sided ownership conditions checked on both the
-- pre-update row (using) and the post-update row (with check) — so a
-- caller can't repoint an owned assignment's formation_id/player_id at
-- someone else's formation or player either (spec section 4 — "both
-- the existing/new formation ownership and existing/new player
-- ownership must belong to auth.uid()").
create policy "team_formation_players_update_own" on public.team_formation_players
  for update using (
    exists (
      select 1 from public.team_formations f
      join public.team_library t on t.id = f.team_id
      where f.id = formation_id and t.user_id = auth.uid()
    )
    and exists (
      select 1 from public.player_library p
      where p.id = player_id and p.user_id = auth.uid()
    )
  )
  with check (
    exists (
      select 1 from public.team_formations f
      join public.team_library t on t.id = f.team_id
      where f.id = formation_id and t.user_id = auth.uid()
    )
    and exists (
      select 1 from public.player_library p
      where p.id = player_id and p.user_id = auth.uid()
    )
  );

-- DELETE: only formation ownership is required (spec section 4 —
-- "the formation must belong to auth.uid()"), so a user can always
-- remove an assignment from their own formation regardless of whether
-- they still own the underlying player_library row (it could only have
-- been added while they owned it, since INSERT required both sides —
-- this just doesn't re-require the player side on removal, same
-- convention as team_members_delete_own in 0019).
create policy "team_formation_players_delete_own" on public.team_formation_players
  for delete using (
    exists (
      select 1 from public.team_formations f
      join public.team_library t on t.id = f.team_id
      where f.id = formation_id and t.user_id = auth.uid()
    )
  );

-- No service-role bypass is exposed to the browser: these are the only
-- policies on this table, all scoped to auth.uid() via
-- team_formations/team_library/player_library ownership. The service
-- role (worker) can still write this table server-side if a future
-- batch needs it to, but no browser-reachable path grants cross-user
-- access — and even a hypothetical service-role write that bypassed
-- RLS entirely would still be rejected by the ownership-consistency
-- trigger above.
