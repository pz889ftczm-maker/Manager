-- Batch 8D — Formation Presets. Adds a REUSABLE, editable formation
-- preset layer on top of the CURRENT-formation data model from 8A/8B/8C
-- (0021_team_formations.sql / 0022_team_formation_players.sql /
-- 0023_team_formation_players_slot_uniq.sql, all left completely
-- unchanged by this migration). No historical match snapshot, no
-- match_id, no AI Coach/Football Analysis/Progress/Dashboard/
-- Tournament changes — all of that is explicitly out of scope for this
-- batch and deferred to Phase 9 per the spec.
--
-- Design notes
-- ------------
-- * NO user_id COLUMN on either new table (explicit spec requirement,
--   same reasoning as team_formations/0021 and
--   team_formation_players/0022):
--     - team_formation_presets ownership is a single hop, identical in
--       shape to team_formations (0021): team_formation_presets.team_id
--       -> team_library.user_id. Exactly like 0021's own design notes
--       explain, RLS's own `using`/`with check` clauses below (each
--       just one `exists (... team_library ... user_id = auth.uid())`)
--       are already the complete ownership check, so no separate
--       ownership-consistency trigger is added for this table either.
--     - team_formation_preset_players ownership is a two-hop derivation,
--       identical in shape to team_formation_players (0022):
--         via preset:  team_formation_preset_players.preset_id
--                      -> team_formation_presets.team_id
--                      -> team_library.user_id
--         via player:  team_formation_preset_players.player_id
--                      -> player_library.user_id
--       Same as 0022, a defense-in-depth ownership-consistency trigger
--       IS added for this table (see
--       check_team_formation_preset_players_ownership below).
-- * A PRESET IS A REUSABLE CONFIGURATION, NOT A HISTORICAL SNAPSHOT
--   (spec section 1 "IMPORTANT" / section 16, repeated): nothing in
--   either table references matches/analysis_events/
--   player_statistics/progress/snapshots/tournament_results/AI Coach,
--   and no match_id/snapshot_id/created-from-match column exists
--   anywhere here. A preset is freely editable after creation and
--   independent of both the Formation it was copied from and any
--   Formation it is later applied to (spec sections 10/11 — this is
--   enforced at the APPLICATION layer, by always COPYING field values
--   rather than sharing any row/foreign key between team_formations and
--   team_formation_presets; there is deliberately no foreign key
--   between the two "current formation" and "preset" table families at
--   all, which is what makes that independence structurally true rather
--   than merely a convention the application layer has to remember).
-- * POSITIONS / TACTICAL_INSTRUCTIONS SHAPE: identical checks to
--   team_formations (0021) — positions is required jsonb, either an
--   object or an array (`jsonb_typeof(positions) in ('object',
--   'array')`); tactical_instructions is nullable jsonb, and when
--   present must be a jsonb object. Same "deliberately loose/
--   extensible, no eFootball-specific keys" reasoning as 0021 — the
--   deeper per-entry shape check (rejecting player_id/playerId/
--   player_name/playerName smuggled into a position entry) lives at the
--   application layer in packages/shared/src/teamFormations.ts's
--   existing validatePositions, REUSED as-is here rather than
--   reimplemented (spec section 8 — "reuse existing position validation
--   rather than creating a conflicting second implementation"); see
--   packages/shared/src/teamFormationPresets.ts.
-- * PLAYER-SLOT ASSIGNMENTS ARE NOT DUPLICATED PLAYER DATA (spec
--   section 2): team_formation_preset_players has exactly six columns
--   — id, preset_id, player_id, position_slot, created_at, updated_at —
--   mirroring team_formation_players (0022) exactly. Player name,
--   stats, attributes, and image path stay solely on player_library;
--   layout coordinates (x/y) stay solely on
--   team_formation_presets.positions. A reader joins through
--   player_id/preset_id to get either.
-- * position_slot is NOT enforced as a foreign key against the JSONB
--   `id`s inside team_formation_presets.positions, for the exact same
--   reason team_formation_players.position_slot isn't checked against
--   team_formations.positions in migration 0022 — that cross-reference
--   would require a trigger re-parsing arbitrary, evolving jsonb shapes
--   on every insert/update, which both 8A/8B/8C and this batch's specs
--   ask this project to avoid. A blank/whitespace-only slot is still
--   rejected at the database layer (constraint below).
-- * UNIQUENESS (spec section 2, mirroring 0022 + 0023 combined into one
--   migration since this is a single new table pair, not built across
--   two batches like team_formation_players was):
--     - UNIQUE(preset_id, player_id) — the same player cannot be
--       assigned twice within one preset (mirrors 0022's
--       team_formation_players_formation_player_uniq).
--     - UNIQUE(preset_id, position_slot) — a preset slot can hold at
--       most one player (mirrors 0023's
--       team_formation_players_formation_slot_uniq).
--   Both are named explicitly so application code
--   (packages/shared/src/teamFormationPresetPlayers.ts) can recognize
--   each exact violation via isUniqueViolation, same convention as
--   0022/0023. The same player MAY appear in different presets, and the
--   same preset name MAY exist on different teams — neither is
--   restricted here.
-- * DUPLICATE PRESET NAMES (spec section 6): `unique
--   (team_id, lower(name))`, named explicitly
--   (team_formation_presets_team_name_uniq) exactly like
--   team_formations_team_name_uniq (0021), for the same reason and with
--   the same "same name allowed across different teams, never within
--   the same team" semantics.
-- * INDEXES: the unique index on (team_id, lower(name)) already serves
--   team_id-only lookups on team_formation_presets (same reasoning as
--   0021), so no separate plain team_id index is added there. A
--   separate updated_at index IS added on team_formation_presets,
--   mirroring 0021's team_formations_updated_at_idx (most-recently-
--   updated-first listing, spec section 9's "list presets for team").
--   On team_formation_preset_players, the UNIQUE(preset_id, player_id)
--   index already covers preset_id-leading lookups, so a separate
--   player_id index is added (mirroring 0022's
--   team_formation_players_player_id_idx) since queries filtering by
--   player_id alone can't use a composite index whose leading column is
--   preset_id.
-- * CASCADE BEHAVIOR (spec section 4):
--     - team_formation_presets.team_id -> team_library(id)
--       ON DELETE CASCADE: deleting a team deletes its presets.
--     - team_formation_preset_players.preset_id ->
--       team_formation_presets(id) ON DELETE CASCADE: deleting a preset
--       deletes its player assignments.
--     - team_formation_preset_players.player_id -> player_library(id)
--       ON DELETE CASCADE: deleting a player_library row removes its
--       preset assignments.
--   None of these cascades ever run in the other direction — deleting a
--   preset or a preset-player row never deletes the underlying team or
--   player_library row (spec section 4/12 — "Do NOT delete the
--   underlying team or player from preset operations").
-- * DEMO DATA: no rows are inserted for either table anywhere (this
--   migration or supabase/seed.sql) — there is no demo/sample preset.
-- * Out of scope for this migration (per spec): Historical Match
--   Snapshot, match lineup history, match_id references, AI Coach/
--   Football Analysis/Progress/Dashboard/Tournament changes, automatic
--   tactical recommendations, automatic AI-generated presets,
--   eFootball-specific manager/player logic. This migration adds
--   schema + RLS + the one ownership-consistency trigger only.

-- ============================================================
-- TEAM FORMATION PRESETS
-- ============================================================
create table public.team_formation_presets (
  id uuid primary key default gen_random_uuid(),
  team_id uuid not null references public.team_library(id) on delete cascade,

  name text not null,
  formation_code text not null,
  positions jsonb not null,
  tactical_instructions jsonb,

  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now(),

  -- See "DUPLICATE PRESET NAMES" design note above.
  constraint team_formation_presets_name_not_blank
    check (btrim(name) <> ''),

  constraint team_formation_presets_formation_code_not_blank
    check (btrim(formation_code) <> ''),

  -- See "POSITIONS / TACTICAL_INSTRUCTIONS SHAPE" design note above.
  constraint team_formation_presets_positions_shape_valid
    check (jsonb_typeof(positions) in ('object', 'array')),

  constraint team_formation_presets_tactical_instructions_shape_valid
    check (tactical_instructions is null or jsonb_typeof(tactical_instructions) = 'object')
);

-- See "DUPLICATE PRESET NAMES" design note above.
create unique index team_formation_presets_team_name_uniq
  on public.team_formation_presets(team_id, lower(name));

-- See "INDEXES" design note above.
create index team_formation_presets_updated_at_idx on public.team_formation_presets(updated_at);

create or replace function public.touch_team_formation_presets_updated_at()
returns trigger
language plpgsql
as $$
begin
  new.updated_at := now();
  return new;
end;
$$;

create trigger team_formation_presets_touch_updated_at
  before update on public.team_formation_presets
  for each row execute procedure public.touch_team_formation_presets_updated_at();

-- ============================================================
-- RLS — team_formation_presets
-- ============================================================
alter table public.team_formation_presets enable row level security;

create policy "team_formation_presets_select_own" on public.team_formation_presets
  for select using (
    exists (
      select 1 from public.team_library t
      where t.id = team_id and t.user_id = auth.uid()
    )
  );

create policy "team_formation_presets_insert_own" on public.team_formation_presets
  for insert with check (
    exists (
      select 1 from public.team_library t
      where t.id = team_id and t.user_id = auth.uid()
    )
  );

create policy "team_formation_presets_update_own" on public.team_formation_presets
  for update using (
    exists (
      select 1 from public.team_library t
      where t.id = team_id and t.user_id = auth.uid()
    )
  )
  with check (
    exists (
      select 1 from public.team_library t
      where t.id = team_id and t.user_id = auth.uid()
    )
  );

create policy "team_formation_presets_delete_own" on public.team_formation_presets
  for delete using (
    exists (
      select 1 from public.team_library t
      where t.id = team_id and t.user_id = auth.uid()
    )
  );

-- No service-role bypass is exposed to the browser: these are the only
-- policies on this table, all scoped to auth.uid() via team_library
-- ownership — same convention as team_formations (0021).

-- ============================================================
-- TEAM FORMATION PRESET PLAYERS
-- ============================================================
create table public.team_formation_preset_players (
  id uuid primary key default gen_random_uuid(),
  preset_id uuid not null references public.team_formation_presets(id) on delete cascade,
  player_id uuid not null references public.player_library(id) on delete cascade,
  position_slot text not null,

  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now(),

  constraint team_formation_preset_players_position_slot_not_blank
    check (btrim(position_slot) <> ''),

  -- See "UNIQUENESS" design note above.
  constraint team_formation_preset_players_preset_player_uniq unique (preset_id, player_id),
  constraint team_formation_preset_players_preset_slot_uniq unique (preset_id, position_slot)
);

-- See "INDEXES" design note above.
create index team_formation_preset_players_player_id_idx
  on public.team_formation_preset_players(player_id);

create or replace function public.touch_team_formation_preset_players_updated_at()
returns trigger
language plpgsql
as $$
begin
  new.updated_at := now();
  return new;
end;
$$;

create trigger team_formation_preset_players_touch_updated_at
  before update on public.team_formation_preset_players
  for each row execute procedure public.touch_team_formation_preset_players_updated_at();

-- Defense-in-depth ownership-consistency trigger, mirroring
-- check_team_formation_players_ownership (0022) exactly, but through
-- team_formation_presets instead of team_formations.
create or replace function public.check_team_formation_preset_players_ownership()
returns trigger
language plpgsql
as $$
begin
  if not exists (
    select 1
    from public.team_formation_presets ps
    join public.team_library t on t.id = ps.team_id
    join public.player_library p on p.user_id = t.user_id
    where ps.id = new.preset_id
      and p.id = new.player_id
  ) then
    raise exception 'team_formation_preset_players: preset % and player % do not belong to the same user', new.preset_id, new.player_id;
  end if;
  new.updated_at := now();
  return new;
end;
$$;

create trigger team_formation_preset_players_ownership_check
  before insert or update on public.team_formation_preset_players
  for each row execute procedure public.check_team_formation_preset_players_ownership();

-- ============================================================
-- RLS — team_formation_preset_players
-- ============================================================
alter table public.team_formation_preset_players enable row level security;

create policy "team_formation_preset_players_select_own" on public.team_formation_preset_players
  for select using (
    exists (
      select 1 from public.team_formation_presets ps
      join public.team_library t on t.id = ps.team_id
      where ps.id = preset_id and t.user_id = auth.uid()
    )
  );

create policy "team_formation_preset_players_insert_own" on public.team_formation_preset_players
  for insert with check (
    exists (
      select 1 from public.team_formation_presets ps
      join public.team_library t on t.id = ps.team_id
      where ps.id = preset_id and t.user_id = auth.uid()
    )
    and exists (
      select 1 from public.player_library p
      where p.id = player_id and p.user_id = auth.uid()
    )
  );

create policy "team_formation_preset_players_update_own" on public.team_formation_preset_players
  for update using (
    exists (
      select 1 from public.team_formation_presets ps
      join public.team_library t on t.id = ps.team_id
      where ps.id = preset_id and t.user_id = auth.uid()
    )
    and exists (
      select 1 from public.player_library p
      where p.id = player_id and p.user_id = auth.uid()
    )
  )
  with check (
    exists (
      select 1 from public.team_formation_presets ps
      join public.team_library t on t.id = ps.team_id
      where ps.id = preset_id and t.user_id = auth.uid()
    )
    and exists (
      select 1 from public.player_library p
      where p.id = player_id and p.user_id = auth.uid()
    )
  );

create policy "team_formation_preset_players_delete_own" on public.team_formation_preset_players
  for delete using (
    exists (
      select 1 from public.team_formation_presets ps
      join public.team_library t on t.id = ps.team_id
      where ps.id = preset_id and t.user_id = auth.uid()
    )
  );

-- No service-role bypass is exposed to the browser: these are the only
-- policies on this table, all scoped to auth.uid() via
-- team_formation_presets/team_library/player_library ownership, and
-- even a hypothetical service-role write that bypassed RLS entirely
-- would still be rejected by the ownership-consistency trigger above —
-- same convention as team_formation_players (0022).
