-- Batch 3.5 remaining-work item 4 — extend player_progress with REAL
-- historical trends built from match_player_statistics (the user's own
-- "self" player), not just the analysis_events-derived category scores
-- already in skill_trends.
--
-- player_stat_trends shape:
-- {
--   "pass_completion_percentage": [{ "match_id": "...", "value": 87.0 }, ...],
--   "successful_dribbles": [...],
--   ...
-- }
-- One key per tracked field (see PLAYER_STAT_TREND_FIELDS in
-- packages/shared/src/progress.ts), oldest match first, real is_valid=true
-- values only. A field with fewer than 2 real data points across the
-- user's real/complete match history is omitted entirely rather than
-- shown as a one-point "trend" — see player_stat_trends_insufficient.
alter table public.player_progress
  add column if not exists player_stat_trends jsonb,
  add column if not exists player_stat_trends_insufficient text[] not null default '{}';

comment on column public.player_progress.player_stat_trends is
  'Real historical trends per individual match_player_statistics field for the user''s self player, across their real (non-demo) completed matches. Only fields with 2+ real data points are included — never fabricated or interpolated.';
comment on column public.player_progress.player_stat_trends_insufficient is
  'Tracked stat fields that do NOT yet have enough real match history (fewer than 2 data points) for a trend — the UI/AI Coach must say so rather than imply a trend exists.';
