-- Batch 7B — additive: team_image_path on team_library, plus storage
-- path ownership hardening, now that 0017_team_images_storage.sql gives
-- team logos somewhere to live.
--
-- 0016_team_library.sql (Batch 7A) deliberately shipped WITHOUT an image
-- column at all — "Team image/logo storage" was explicitly out of scope
-- for that batch. player_library (0011) and manager_library (0014), by
-- contrast, both included their image-path column from their very first
-- migration, ahead of their own storage batches (0012/0013, 0015). This
-- migration is what brings team_library to that same end state, one
-- batch later than the other two libraries — additive only, per this
-- batch's spec ("If adding this field: use an additive migration...
-- Ownership/path validation must remain enforced"). 0016 itself is not
-- edited.
--
-- Design notes
-- ------------
-- * `team_image_path text`, nullable, no default — a team may exist
--   indefinitely with no logo; NULL is preserved, nothing here ever
--   fabricates or auto-assigns a path (spec: "preserve NULL when no
--   image exists" / "do not automatically insert demo images").
-- * Same belt-and-suspenders CHECK constraints as
--   player_library_image_path_owned_prefix/no_traversal (0011) and
--   manager_library's equivalents (0014): even though team_library is
--   user-writable directly (not worker-only), the `{user_id}/...` prefix
--   and rejection of `..` sequences are enforced at the table level, not
--   just by Storage RLS on the bucket (0017) or by the client's own
--   buildSafeTeamImageStoragePath — so no future role/policy change on
--   either table could silently bypass it.
-- * The existing team_library_insert_own / team_library_update_own RLS
--   policies (0016) are recreated (drop-if-exists + create, same
--   mechanism 0009_production_hardening.sql already uses to tighten an
--   existing policy) with an added clause requiring team_image_path to
--   either be null or sit under the caller's own auth.uid() prefix —
--   mirroring player_library_insert_own/update_own (0011) and
--   manager_library's equivalents (0014) exactly. team_library_select_own
--   and team_library_delete_own are untouched: neither needs to inspect
--   team_image_path to do its job.
-- * This column stores a Storage object path/reference only — never
--   image bytes/base64 in Postgres — same convention as every other
--   image-path column in this repo.
-- * No FK to storage.objects is added (Supabase Storage objects aren't
--   referenced that way anywhere else in this repo either) — the CHECK
--   constraints below plus Storage's own RLS (0017) are what keep this
--   safe, same as player_library/manager_library.

alter table public.team_library
  add column team_image_path text;

alter table public.team_library
  add constraint team_library_image_path_owned_prefix
    check (
      team_image_path is null
      or team_image_path like (user_id::text || '/%')
    );

alter table public.team_library
  add constraint team_library_image_path_no_traversal
    check (team_image_path is null or team_image_path !~ '\.\.');

-- ============================================================
-- RLS — recreate insert/update to also enforce image-path ownership
-- ============================================================
drop policy if exists "team_library_insert_own" on public.team_library;
create policy "team_library_insert_own" on public.team_library
  for insert with check (
    auth.uid() = user_id
    and (
      team_image_path is null
      or team_image_path like (auth.uid()::text || '/%')
    )
  );

drop policy if exists "team_library_update_own" on public.team_library;
create policy "team_library_update_own" on public.team_library
  for update using (auth.uid() = user_id)
  with check (
    auth.uid() = user_id
    and (
      team_image_path is null
      or team_image_path like (auth.uid()::text || '/%')
    )
  );

-- team_library_select_own / team_library_delete_own (0016) are
-- untouched — unchanged from Batch 7A, per this batch's own instruction
-- to leave the existing table/RLS alone except where strictly required.
