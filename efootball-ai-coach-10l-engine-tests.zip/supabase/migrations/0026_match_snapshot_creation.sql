-- Batch 9B — Historical Match Snapshot Creation SERVICE only.
--
-- 9A (0025_match_snapshots.sql) added the match_snapshots /
-- match_snapshot_players schema + RLS, with NO client- or server-side
-- way to actually create a row yet (that migration's own design notes:
-- "NO CLIENT-SIDE INSERT POLICY EITHER... Creation is explicitly
-- deferred to a later, trusted server-side (Edge Function/worker,
-- service-role) workflow"). This migration adds exactly that workflow
-- and nothing else — no UI, no Football Analysis/AI Coach/Progress/
-- Dashboard integration (all explicitly out of scope, spec sections
-- 20/21).
--
-- Design notes
-- ------------
-- * WHY A SQL FUNCTION, NOT PLAIN EDGE-FUNCTION REST CALLS (spec
--   section 10 — "Snapshot creation must be atomic... Use the existing
--   database/server architecture to achieve transactional behavior."):
--   PostgREST (what supabase-js's .from(...) calls go through) has no
--   multi-table-write transaction — separate .insert() calls from an
--   Edge Function are separate HTTP requests/statements, exactly the
--   "snapshot row created + only some player rows created" partial
--   state spec section 10 forbids. This repo's existing convention for
--   an atomic, ownership-checked, server-only operation is a single
--   SECURITY DEFINER plpgsql function (public.check_and_record_rate_
--   limit, 0009) invoked via .rpc() — a single top-level statement, so
--   Postgres wraps the whole function body in one transaction: any
--   exception raised anywhere inside it (an ownership check, a
--   validation failure, an insert) rolls back every write the function
--   made, including ones earlier in the same call. That IS this
--   migration's atomicity guarantee — no explicit BEGIN/EXCEPTION
--   block is needed for it.
-- * SECURITY DEFINER + auth.uid() (spec sections 2/4 — "Do not trust
--   client-supplied user_id... Reject cross-user and cross-team
--   combinations"): unlike check_and_record_rate_limit (which accepts
--   p_user_id as a parameter, because the Edge Function itself already
--   resolved it via auth.getUser()), this function reads auth.uid()
--   ITSELF, directly, rather than accepting a user-id parameter at
--   all — auth.uid() still resolves correctly under SECURITY DEFINER
--   because it reads the request's JWT claims, not the function's
--   owning role. This removes even the possibility of a caller (Edge
--   Function bug, future call site) accidentally passing the wrong
--   id — there is no id parameter to pass. Every ownership check below
--   compares against this single, non-parameterized v_user_id.
-- * INPUT SURFACE (spec section 3 — "accept only the minimum required
--   identifiers... Do NOT accept historical player names, stats,
--   manager ratings, team metadata... from the client"): the function
--   takes exactly p_match_id, p_team_id (both required), and
--   p_formation_id (optional — see NULL SAFETY note below). No other
--   parameter exists; every historical field written to the two
--   tables below is read from team_library/team_formations/
--   manager_library/player_library/team_formation_players THIS
--   FUNCTION queries itself, never from a caller-supplied value.
-- * OWNERSHIP, verified in this order, every one independent of RLS
--   (this function runs SECURITY DEFINER, i.e. as the function's
--   owner, which bypasses RLS entirely — these checks are the ENTIRE
--   authorization boundary here, same defense-in-depth reasoning as
--   check_team_formation_players_ownership (0022) / check_team_
--   library_manager_ownership (0020), just load-bearing instead of
--   belt-and-suspenders since there's no RLS layer underneath this
--   particular write path at all):
--     1. p_match_id must reference a public.matches row with
--        user_id = v_user_id (spec section 4 — "authenticated user
--        owns match_id").
--     2. p_team_id must reference a public.team_library row with
--        user_id = v_user_id (spec section 4 — "authenticated user
--        owns team_id"). Its current row is read directly into
--        v_team for use below.
--     3. When p_formation_id is provided, it must reference a
--        public.team_formations row whose team_id = p_team_id exactly
--        (spec section 4 — "formation belongs to team_id"; section 9
--        — "If the requested formation_id is provided but does not
--        belong to the team, reject the request"). team_formations
--        has no user_id of its own (0021) — team_id is the entire
--        ownership chain, and p_team_id was already proven to belong
--        to v_user_id in step 2, so this transitively proves formation
--        ownership too without a second user_id comparison.
--     4. When v_team.manager_id is not null, it must reference a
--        public.manager_library row with user_id = v_user_id (spec
--        section 4 — "manager belongs to the same user if present").
--        In ordinary operation this can never fail — team_library's
--        own check_team_library_manager_ownership trigger (0020)
--        already guarantees team_library.manager_id always belongs to
--        team_library.user_id — but it's re-verified here anyway,
--        same "still holds even if an earlier layer were bypassed"
--        reasoning 0020/0022's own triggers use.
--     5. When p_formation_id is provided, EVERY team_formation_players
--        row for that formation must join to a player_library row
--        with user_id = v_user_id (spec section 4 — "every selected
--        player belongs to the same user"). Same "can't normally
--        fail" reasoning as step 4 — 0022's own check_team_formation_
--        players_ownership trigger already guarantees this at
--        assignment time — re-verified here as defense-in-depth,
--        by comparing a total-assigned count against an
--        owned-assigned count (see v_total_assigned/v_owned_assigned
--        below) rather than silently filtering: a mismatch RAISES,
--        it never just quietly drops the unowned row (spec section
--        16 — "Do not sanitize invalid values into fake defaults").
--   Any failure above raises a distinct, internal-only exception
--   message (never returned verbatim to the client — see ERROR
--   MAPPING note below) and the function returns nothing.
-- * NULL SAFETY (spec sections 7/8/9): p_formation_id may be null —
--   formation_code/formation_name/positions/tactical_instructions and
--   every match_snapshot_players row are then simply not populated/
--   inserted, never a fabricated formation. v_team.manager_id may be
--   null — manager_id/manager_name/manager_ratings on the snapshot are
--   then NULL, never a fake manager (spec section 7). Any individual
--   team/formation/manager/player field that is itself NULL in the
--   live row (e.g. a team with no motto) is copied through as NULL —
--   nothing here ever substitutes 0/''/a fabricated value for a NULL
--   source column (spec sections 7/8).
-- * READ CURRENT DATA / COPY, DO NOT REFERENCE (spec sections 5/6):
--   every historical column is populated from a value read from
--   team_library/team_formations/manager_library/player_library
--   inside this same function call, then written literally into
--   match_snapshots/match_snapshot_players — never a stored
--   generated column, never a view, never a value the caller
--   supplied directly. team_id/formation_id/manager_id/player_id
--   remain purely as provenance FKs (already nullable-on-delete per
--   0025) — nothing here or later ever re-reads them to reconstruct a
--   historical value.
-- * SOURCE OF PLAYER ASSIGNMENTS (spec section 14): player rows come
--   exclusively from public.team_formation_players joined through
--   p_formation_id — there is no other parameter or input path by
--   which a player could end up in this function's result at all.
-- * PLAYER ORDER (spec section 15): the INSERT ... SELECT ... ORDER BY
--   tfp.position_slot, p.id below gives Postgres a defined row source
--   order for the insert; the position_slot/player_id values
--   themselves remain on every inserted row regardless, so this exact
--   order is also trivially recoverable later by an ORDER BY on the
--   already-copied columns rather than relying on physical insert
--   order server-side.
-- * IDEMPOTENCY / ATOMICITY UNDER CONCURRENCY (spec sections 10/12):
--   mirrors clip-request/index.ts's own race-safe pattern (see that
--   file's extensive comment on the same problem) — a plain
--   SELECT-then-INSERT has a TOCTOU gap where two concurrent calls
--   both see "no existing snapshot" and both attempt to insert. Fixed
--   the same way: the INSERT itself is
--   `on conflict on constraint match_snapshots_match_team_uniq do
--   nothing returning id` — Postgres's own unique index (0025)
--   resolves the race atomically inside the single statement, and
--   whichever call loses gets zero rows back (not an error), then
--   falls through to re-select and return the winner's row exactly
--   like the pre-check branch does. No duplicate match_snapshots row,
--   and (because player insertion only ever runs after a *genuinely
--   new* v_new_id was obtained) no duplicate match_snapshot_players
--   rows either.
-- * VALIDATION (spec section 16): this function is the "server-built
--   snapshot" spec section 16 refers to — every value it writes was
--   just read from an authoritative table, and the writes are the
--   same INSERTs 0025's own CHECK constraints (positions/tactical_
--   instructions/manager_ratings jsonb shape, team_founded_year > 0,
--   attributes jsonb shape, overall >= 0) already validate at the
--   database level; a source row that somehow violated one of those
--   (impossible for team_library/team_formations/manager_library/
--   player_library today, since their own CHECK constraints are at
--   least as strict) would surface as a Postgres error from the
--   INSERT itself, which this migration does not attempt to catch or
--   soften into a fake default — it propagates up (see ERROR MAPPING
--   note) as a safe failure, never a sanitized/fabricated row.
-- * ERROR MAPPING (spec section 17 — "Never expose SQL errors...
--   Return safe errors"): every RAISE EXCEPTION message below uses a
--   fixed `match_snapshot_create: <short_code>` prefix precisely so
--   the Edge Function (supabase/functions/match-snapshot-create) can
--   pattern-match the SQLSTATE P0001 error's .message text against a
--   small known table (packages/shared/src/matchSnapshotCreation.ts's
--   mapSnapshotCreationRpcError) and return one of spec section 17's
--   own literal safe strings — the raw Postgres message text itself
--   is never returned to the client, only logged server-side by the
--   Edge Function (same internalErrorResponse-adjacent convention as
--   every other function in supabase/functions).
-- * SECURITY DEFINER GRANTS: same convention as check_and_record_
--   rate_limit (0009) — revoke from public, grant execute only to
--   authenticated and service_role. An anonymous caller can never
--   reach this function at all (and auth.uid() would be null for one
--   regardless, which is checked explicitly and rejected first).
-- * REGRESSION (spec section 20): this migration adds one new
--   function and its grants only. It does not alter match_snapshots/
--   match_snapshot_players, team_library, player_library,
--   manager_library, team_formations, team_formation_players, team_
--   formation_presets, or any RLS policy from any prior migration.
--   0025's "no client-side INSERT policy" remains completely intact —
--   this function bypasses RLS by running SECURITY DEFINER, exactly
--   the "future trusted server-side workflow" 0025's own design notes
--   already anticipated, not a loosening of that migration's policy.

create or replace function public.create_match_snapshot(
  p_match_id uuid,
  p_team_id uuid,
  p_formation_id uuid default null
)
returns table (id uuid, created boolean)
language plpgsql
security definer set search_path = public
as $$
declare
  v_user_id uuid := auth.uid();
  v_team public.team_library%rowtype;
  v_formation public.team_formations%rowtype;
  v_manager public.manager_library%rowtype;
  v_manager_ratings jsonb;
  v_existing_id uuid;
  v_new_id uuid;
  v_total_assigned integer;
  v_owned_assigned integer;
begin
  if v_user_id is null then
    raise exception 'match_snapshot_create: not_authenticated';
  end if;

  -- 1. Match ownership (spec section 4).
  if not exists (
    select 1 from public.matches m
    where m.id = p_match_id and m.user_id = v_user_id
  ) then
    raise exception 'match_snapshot_create: match_not_found';
  end if;

  -- 2. Team ownership (spec section 4) — also reads the current row
  -- for the historical copy below (spec section 5/6).
  select t.* into v_team
  from public.team_library t
  where t.id = p_team_id and t.user_id = v_user_id;
  if not found then
    raise exception 'match_snapshot_create: team_not_found';
  end if;

  -- 3. Formation ownership: must belong to THIS team (spec sections
  -- 4/9). Optional — see NULL SAFETY note above.
  if p_formation_id is not null then
    select f.* into v_formation
    from public.team_formations f
    where f.id = p_formation_id and f.team_id = p_team_id;
    if not found then
      raise exception 'match_snapshot_create: formation_not_found';
    end if;
  end if;

  -- 4. Manager ownership, only when the team actually has one (spec
  -- sections 4/7). Defense-in-depth — see design note above.
  if v_team.manager_id is not null then
    select m.* into v_manager
    from public.manager_library m
    where m.id = v_team.manager_id and m.user_id = v_user_id;
    if not found then
      raise exception 'match_snapshot_create: manager_ownership_invalid';
    end if;
    v_manager_ratings := jsonb_build_object(
      'possession_rating', v_manager.possession_rating,
      'quick_counter_rating', v_manager.quick_counter_rating,
      'long_ball_counter_rating', v_manager.long_ball_counter_rating,
      'out_wide_rating', v_manager.out_wide_rating,
      'long_ball_rating', v_manager.long_ball_rating
    );
  end if;

  -- 5. Every assigned player must belong to the same user (spec
  -- section 4). Defense-in-depth — see design note above. A mismatch
  -- REJECTS the whole request rather than silently dropping the
  -- unowned row (spec section 16).
  if p_formation_id is not null then
    select count(*) into v_total_assigned
    from public.team_formation_players tfp
    where tfp.formation_id = p_formation_id;

    select count(*) into v_owned_assigned
    from public.team_formation_players tfp
    join public.player_library p on p.id = tfp.player_id
    where tfp.formation_id = p_formation_id
      and p.user_id = v_user_id;

    if v_total_assigned <> v_owned_assigned then
      raise exception 'match_snapshot_create: player_ownership_invalid';
    end if;
  end if;

  -- Idempotency (spec sections 10/12): an exact repeat of this
  -- match+team pair already has a snapshot — return it as-is rather
  -- than creating a duplicate.
  select s.id into v_existing_id
  from public.match_snapshots s
  where s.match_id = p_match_id and s.team_id = p_team_id;
  if found then
    return query select v_existing_id, false;
    return;
  end if;

  -- Copy, do not reference (spec sections 1/2/6/14/15): every column
  -- below is a literal value read above, never a live reference.
  insert into public.match_snapshots (
    user_id, match_id, team_id, formation_id, manager_id,
    formation_code, formation_name, positions, tactical_instructions,
    team_name, team_motto, team_description, team_founded_year, team_stadium,
    manager_name, manager_ratings
  ) values (
    v_user_id, p_match_id, p_team_id, p_formation_id, v_team.manager_id,
    v_formation.formation_code, v_formation.name, v_formation.positions, v_formation.tactical_instructions,
    v_team.name, v_team.motto, v_team.description, v_team.founded_year, v_team.stadium,
    v_manager.name, v_manager_ratings
  )
  on conflict on constraint match_snapshots_match_team_uniq do nothing
  returning match_snapshots.id into v_new_id;

  if v_new_id is null then
    -- Lost a concurrent race against another request creating the
    -- same (match_id, team_id) snapshot between the pre-check above
    -- and this INSERT — converge on the winner's row (spec section
    -- 12), never error and never insert a second row.
    select s.id into v_existing_id
    from public.match_snapshots s
    where s.match_id = p_match_id and s.team_id = p_team_id;
    if not found then
      raise exception 'match_snapshot_create: snapshot_missing_after_conflict';
    end if;
    return query select v_existing_id, false;
    return;
  end if;

  -- Player assignments (spec sections 6/14/15): sourced only from
  -- team_formation_players joined through the now-verified formation,
  -- in deterministic (position_slot, player_id) order.
  if p_formation_id is not null then
    insert into public.match_snapshot_players (
      snapshot_id, player_id, player_name, position, overall, playstyle, attributes, position_slot
    )
    select
      v_new_id, p.id, p.name, p.position, p.overall, p.playstyle, p.attributes, tfp.position_slot
    from public.team_formation_players tfp
    join public.player_library p on p.id = tfp.player_id
    where tfp.formation_id = p_formation_id
    order by tfp.position_slot, p.id;
  end if;

  return query select v_new_id, true;
end;
$$;

comment on function public.create_match_snapshot(uuid, uuid, uuid) is
  'Batch 9B — atomic, server-side-only creation of an immutable match_snapshots (+ match_snapshot_players) row from a user''s CURRENT Team/Formation/Players/Manager configuration. SECURITY DEFINER so it is safely callable via the user-scoped client; every ownership check inside compares against auth.uid() itself (never a caller-supplied user id), and the whole body runs as one transaction so a failure at any step (ownership, ON CONFLICT resolution, player-ownership mismatch) rolls back every write the call made. Idempotent on (match_id, team_id) via match_snapshots_match_team_uniq (0025). See this migration''s own header comment for the full design rationale.';

revoke all on function public.create_match_snapshot(uuid, uuid, uuid) from public;
grant execute on function public.create_match_snapshot(uuid, uuid, uuid) to authenticated, service_role;
