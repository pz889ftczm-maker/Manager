-- Security fix (audit finding E.1):
-- ai_coach_messages_insert_own previously only checked auth.uid() = user_id,
-- with no restriction on `role`. Any authenticated user could call the
-- Supabase client directly and insert a row with role='assistant' under
-- their own user_id, bypassing the coach-chat Edge Function and forging
-- assistant turns that get fed back into their own coach's future context
-- (buildContextSummary / recentMessages in supabase/functions/coach-chat).
--
-- Fix: authenticated clients (RLS) may only ever insert role='user' rows.
-- The assistant's reply must be inserted by the coach-chat Edge Function
-- using the service-role client, which bypasses RLS by design.

drop policy if exists "ai_coach_messages_insert_own" on public.ai_coach_messages;

create policy "ai_coach_messages_insert_own_user_role"
  on public.ai_coach_messages
  for insert
  with check (auth.uid() = user_id and role = 'user');
