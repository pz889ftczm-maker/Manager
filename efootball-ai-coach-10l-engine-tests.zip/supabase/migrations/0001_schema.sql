-- eFootball AI Coach — core schema
-- Run via `supabase db push` or `supabase start` (auto-applies migrations).

create extension if not exists "pgcrypto";

-- ============================================================
-- PROFILES (1:1 with auth.users)
-- ============================================================
create table public.profiles (
  id uuid primary key references auth.users(id) on delete cascade,
  display_name text,
  avatar_url text,
  preferred_position text,
  created_at timestamptz not null default now()
);

-- Auto-create a profile row whenever a new auth user signs up.
create function public.handle_new_user()
returns trigger
language plpgsql
security definer set search_path = public
as $$
begin
  insert into public.profiles (id, display_name)
  values (new.id, coalesce(new.raw_user_meta_data ->> 'display_name', new.email));
  return new;
end;
$$;

create trigger on_auth_user_created
  after insert on auth.users
  for each row execute procedure public.handle_new_user();

-- ============================================================
-- MATCHES
-- ============================================================
create type match_source_type as enum ('screenshot', 'video', 'mixed', 'demo');
create type match_status as enum (
  'uploading', 'optimizing', 'processing', 'detecting_moments',
  'analyzing', 'generating_report', 'complete', 'error'
);

create table public.matches (
  id uuid primary key default gen_random_uuid(),
  user_id uuid not null references auth.users(id) on delete cascade,
  title text,
  match_date date,
  duration_seconds integer,
  source_type match_source_type not null default 'screenshot',
  status match_status not null default 'uploading',
  overall_score numeric(5,2),
  is_demo boolean not null default false,
  error_message text,
  created_at timestamptz not null default now()
);

create index matches_user_id_idx on public.matches(user_id);

-- ============================================================
-- MEDIA (uploaded screenshots / videos, incl. temp processing assets)
-- ============================================================
create type media_type as enum ('screenshot', 'video');
create type media_status as enum (
  'uploaded', 'optimizing', 'optimized', 'processed', 'failed', 'deleted_temp'
);

create table public.media (
  id uuid primary key default gen_random_uuid(),
  match_id uuid not null references public.matches(id) on delete cascade,
  user_id uuid not null references auth.users(id) on delete cascade,
  type media_type not null,
  original_filename text,
  original_size_bytes bigint,
  processed_size_bytes bigint,
  status media_status not null default 'uploaded',
  storage_reference text, -- path within a private Supabase Storage bucket
  is_temporary boolean not null default true, -- true for raw videos slated for cleanup
  created_at timestamptz not null default now(),
  expires_at timestamptz -- for temporary video assets; worker cleans up after this
);

create index media_match_id_idx on public.media(match_id);
create index media_user_id_idx on public.media(user_id);
create index media_expires_at_idx on public.media(expires_at) where is_temporary;

-- ============================================================
-- ANALYSIS EVENTS (one per detected decision/moment)
-- ============================================================
create type event_severity as enum ('excellent', 'good', 'minor_issue', 'mistake', 'critical_mistake');
create type confidence_level as enum ('confirmed', 'likely', 'uncertain');

create table public.analysis_events (
  id uuid primary key default gen_random_uuid(),
  match_id uuid not null references public.matches(id) on delete cascade,
  timestamp_seconds numeric(8,2), -- null for single-screenshot events
  event_type text not null, -- e.g. 'bad_pass', 'good_positioning', see packages/shared/eventTypes.ts
  category text not null,   -- 'passing' | 'dribbling' | 'attacking' | 'defending' | 'transition' | 'build_up'
  severity event_severity not null,
  decision_score numeric(5,2) check (decision_score between 0 and 100),
  confidence numeric(5,2) check (confidence between 0 and 100),
  confidence_level confidence_level not null default 'likely',
  description text not null,
  better_option text,
  reasoning text,
  before_frame_url text,
  decision_frame_url text,
  after_frame_url text,
  context_start_seconds numeric(8,2),
  context_end_seconds numeric(8,2),
  created_at timestamptz not null default now()
);

create index analysis_events_match_id_idx on public.analysis_events(match_id);
create index analysis_events_severity_idx on public.analysis_events(severity);

-- ============================================================
-- TACTICAL ANALYSIS (visual diagram data per event)
-- ============================================================
create table public.tactical_analysis (
  id uuid primary key default gen_random_uuid(),
  event_id uuid not null references public.analysis_events(id) on delete cascade,
  actual_positions jsonb,      -- [{ role, x, y, team }]
  recommended_positions jsonb, -- same shape, recommended alternative
  passing_lanes jsonb,         -- [{ from: {x,y}, to: {x,y}, quality }]
  movement_arrows jsonb,       -- [{ from: {x,y}, to: {x,y}, label }]
  pressure_zones jsonb,        -- [{ x, y, radius, intensity }]
  open_spaces jsonb,           -- [{ x, y, radius }]
  is_approximate boolean not null default true, -- true unless positions are clearly confirmed
  explanation text,
  created_at timestamptz not null default now()
);

create index tactical_analysis_event_id_idx on public.tactical_analysis(event_id);

-- ============================================================
-- MATCH STATISTICS (aggregate scores per match)
-- ============================================================
create table public.match_statistics (
  match_id uuid primary key references public.matches(id) on delete cascade,
  passing_score numeric(5,2),
  dribbling_score numeric(5,2),
  attacking_score numeric(5,2),
  defending_score numeric(5,2),
  positioning_score numeric(5,2),
  decision_making_score numeric(5,2),
  good_decisions_count integer default 0,
  bad_decisions_count integer default 0,
  updated_at timestamptz not null default now()
);

-- ============================================================
-- PLAYER PROGRESS (long-term aggregated trend, one row per user)
-- ============================================================
create table public.player_progress (
  user_id uuid primary key references auth.users(id) on delete cascade,
  matches_analyzed integer not null default 0,
  overall_trend jsonb,       -- [{ match_id, match_date, overall_score }]
  skill_trends jsonb,        -- { passing: [...], defending: [...], ... }
  most_improved_skill text,
  biggest_weakness text,
  most_common_mistake text,
  recommended_position text,
  playstyle_tags text[],     -- e.g. {possession_oriented, risk_taking}
  updated_at timestamptz not null default now()
);

-- ============================================================
-- AI COACH MESSAGES
-- ============================================================
create type coach_message_role as enum ('user', 'assistant');

create table public.ai_coach_messages (
  id uuid primary key default gen_random_uuid(),
  user_id uuid not null references auth.users(id) on delete cascade,
  match_id uuid references public.matches(id) on delete set null, -- optional context anchor
  role coach_message_role not null,
  content text not null,
  referenced_event_ids uuid[], -- analysis_events cited in this answer
  created_at timestamptz not null default now()
);

create index ai_coach_messages_user_id_idx on public.ai_coach_messages(user_id, created_at);
