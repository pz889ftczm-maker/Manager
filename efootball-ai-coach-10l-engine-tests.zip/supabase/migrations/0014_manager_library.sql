-- Batch 6B-1 — Manager Library: database + RLS foundation only.
--
-- Adds a single new table for a user's personal, reusable eFootball
-- manager library — the same "reusable source data the user curates
-- themselves (or, in a later batch, extracts from a screenshot)"
-- pattern as public.player_library (0011_player_library.sql), applied to
-- managers instead of players. This migration deliberately mirrors that
-- one's structure/conventions throughout rather than inventing new ones.
--
-- Design notes
-- ------------
-- * NULL-safety (spec's "IMPORTANT NULL RULE"): every rating column is
--   nullable, with no default. A manager entry may be saved with only a
--   name, only an image, or partial ratings — nothing here is ever
--   defaulted to 0 or invented. Same rule, same reasoning as
--   player_library's attributes/overall (0011) and
--   player_attributes (0006).
-- * Rating validation: `check (rating >= 0)` only, no upper bound — same
--   convention as player_library.overall (0011), which imposes no max
--   either. Nothing in this repo's existing schema establishes an
--   authoritative max for an eFootball rating, and the spec explicitly
--   says not to invent one.
-- * Ratings are fixed columns here (possession_rating,
--   quick_counter_rating, long_ball_counter_rating, out_wide_rating,
--   long_ball_rating), unlike player_library's open `attributes` jsonb —
--   because the spec enumerates this exact, fixed set of five manager
--   style ratings (and their later tactical-context purpose depends on
--   them being addressable columns, not arbitrary free-form keys). This
--   mirrors why match-analysis's player_attributes (0006) uses fixed
--   columns for its own fixed, spec-enumerated attribute set rather than
--   jsonb. `metadata` jsonb remains for any additional free-form data,
--   same role as player_library.metadata.
-- * `manager_image_path` stores a Storage object path/reference only —
--   never image bytes/base64 in Postgres — same convention as
--   player_library.player_card_image_path (0011). No bucket is created
--   and no upload path is wired in this batch (explicitly out of scope);
--   the path-format constraints below exist so that whichever future
--   batch adds the actual upload already has a schema that only accepts
--   the `{user_id}/{safe-random-filename}.{extension}` convention.
-- * Duplicate prevention: the unique index is on
--   (user_id, lower(name), possession_rating, quick_counter_rating,
--   long_ball_counter_rating, out_wide_rating, long_ball_rating) — this
--   blocks only an exact repeat add of what looks like the identical
--   manager (same name, same every rating), while still allowing any
--   distinct variant (spec: "Do NOT use name-only uniqueness if that
--   could prevent legitimate variants" — e.g. the same named manager
--   re-read with different/updated ratings is a different variant, not a
--   duplicate). Applies only when name is set, same as
--   player_library_user_variant_uniq (0011), since an unnamed entry has
--   nothing meaningful to deduplicate on. Deliberately excludes
--   manager_image_path from the key, same reasoning as player_library —
--   a duplicate re-upload of the same manager's ratings under a new
--   image path is still the same duplicate entry.
-- * HISTORICAL SAFETY: no column here references matches/analysis_events/
--   team presets, and nothing in this migration adds a column FROM those
--   tables back to this one. A library entry can be freely edited or
--   deleted without touching any historical match record, by
--   construction — there is currently no path by which it could. Per the
--   spec, a future Team Presets / Match Context feature will need to
--   snapshot these ratings at use-time rather than reference this table
--   live, so that editing a saved manager later cannot silently rewrite
--   historical match context — that snapshotting is NOT implemented
--   here.
-- * DEMO DATA: no rows are inserted for this table anywhere (this
--   migration or supabase/seed.sql) — there is no demo manager library.
-- * Out of scope for this batch (per spec): no storage bucket, no upload
--   code, no AI extraction, no review/edit UI, no Team Presets, no
--   formation persistence, no match snapshot tables. This migration adds
--   schema + RLS only.

-- ============================================================
-- MANAGER LIBRARY
-- ============================================================
create table public.manager_library (
  id uuid primary key default gen_random_uuid(),
  user_id uuid not null references auth.users(id) on delete cascade,

  name text,

  -- Manager tactical style ratings — every one nullable, see NULL-safety
  -- design note above. Non-negative only; no upper bound imposed.
  possession_rating integer check (possession_rating >= 0),
  quick_counter_rating integer check (quick_counter_rating >= 0),
  long_ball_counter_rating integer check (long_ball_counter_rating >= 0),
  out_wide_rating integer check (out_wide_rating >= 0),
  long_ball_rating integer check (long_ball_rating >= 0),

  manager_image_path text, -- Storage object path only, never image bytes; see path-format constraint below
  metadata jsonb,          -- optional additional free-form metadata

  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now(),

  -- Belt-and-suspenders (mirrors player_library_image_path_owned_prefix /
  -- player_library_image_path_no_traversal in 0011): even though this
  -- table is user-writable directly (not worker-only), enforce the
  -- `{user_id}/...` prefix and reject path traversal at the table level,
  -- not just in RLS below, so no future role/policy change can silently
  -- bypass it.
  constraint manager_library_image_path_owned_prefix
    check (
      manager_image_path is null
      or manager_image_path like (user_id::text || '/%')
    ),
  constraint manager_library_image_path_no_traversal
    check (manager_image_path is null or manager_image_path !~ '\.\.')
);

create index manager_library_user_id_idx on public.manager_library(user_id);

-- See "Duplicate prevention" design note above.
create unique index manager_library_user_variant_uniq
  on public.manager_library(
    user_id,
    lower(name),
    possession_rating,
    quick_counter_rating,
    long_ball_counter_rating,
    out_wide_rating,
    long_ball_rating
  )
  where name is not null;

-- Same trigger convention as touch_player_library_updated_at (0011).
create or replace function public.touch_manager_library_updated_at()
returns trigger
language plpgsql
as $$
begin
  new.updated_at := now();
  return new;
end;
$$;

create trigger manager_library_touch_updated_at
  before update on public.manager_library
  for each row execute procedure public.touch_manager_library_updated_at();

-- ============================================================
-- RLS
-- ============================================================
alter table public.manager_library enable row level security;

create policy "manager_library_select_own" on public.manager_library
  for select using (auth.uid() = user_id);

create policy "manager_library_insert_own" on public.manager_library
  for insert with check (
    auth.uid() = user_id
    and (
      manager_image_path is null
      or manager_image_path like (auth.uid()::text || '/%')
    )
  );

create policy "manager_library_update_own" on public.manager_library
  for update using (auth.uid() = user_id)
  with check (
    auth.uid() = user_id
    and (
      manager_image_path is null
      or manager_image_path like (auth.uid()::text || '/%')
    )
  );

create policy "manager_library_delete_own" on public.manager_library
  for delete using (auth.uid() = user_id);

-- No service-role bypass is exposed to the browser: these are the only
-- policies on this table, all scoped to auth.uid() = user_id, same as
-- player_library/players/player_progress/profiles. The service role
-- (worker) can still write this table server-side if a future batch
-- needs it to, but no browser-reachable path grants cross-user access.
