-- Batch 7B — Team Library: private storage + RLS for team logo/images.
--
-- Mirrors 0015_manager_images_storage.sql (which itself mirrors
-- 0012_player_library_storage.sql / 0013_player_cards_bucket.sql)
-- exactly, applied to a new `team-images` bucket instead of
-- `manager-images`. Combined into one migration (bucket + RLS together)
-- since both are new here, same reasoning as 0015 — there is no prior
-- bucket history to preserve for team-images the way 0012/0013 had to
-- for player-cards.
--
-- Path convention: `{user_id}/{safe-random-filename}.{extension}` — built
-- server-authoritatively by buildSafeTeamImageStoragePath
-- (packages/shared/src/uploadValidation.ts), never from a user-supplied
-- filename, so there is no client-controlled path component beyond the
-- user's own uid prefix (which these policies independently enforce
-- regardless of what the client claims).

-- ============================================================
-- BUCKET
-- ============================================================
-- `on conflict (id) do nothing` so this is a harmless no-op if the
-- bucket somehow already exists (same pattern as 0013/0015).
insert into storage.buckets (id, name, public)
values ('team-images', 'team-images', false)
on conflict (id) do nothing;

-- Explicit UPDATE (not folded into the INSERT) so this also takes effect
-- for a bucket that already existed without these settings — same
-- reasoning, and same forced `public = false` hardening, as 0013's
-- post-6A-3 security fix for player-cards and 0015's equivalent for
-- manager-images. This is NOT relied on to run only via
-- `on conflict ... do nothing` — the UPDATE always runs, unconditionally,
-- regardless of whether the INSERT above did anything (spec: "Do not
-- rely only on INSERT ... ON CONFLICT DO NOTHING"). 15MB / JPEG-PNG-WEBP
-- matches this batch's spec exactly and reuses the same
-- DEFAULT_MAX_IMAGE_MB convention already used everywhere else
-- (packages/shared/src/uploadValidation.ts) rather than inventing a new
-- size/format set for this bucket.
update storage.buckets
  set public = false,
      file_size_limit = 15 * 1024 * 1024,
      allowed_mime_types = array['image/jpeg', 'image/png', 'image/webp']
  where id = 'team-images';

-- ============================================================
-- STORAGE RLS
-- ============================================================
-- Deliberately THREE narrow policies (select/insert/delete), not one
-- `for all` and no update policy — same reasoning as
-- storage_player_cards_owner_* (0012) / storage_manager_images_owner_*
-- (0015): object names are random and the upload path always uses
-- upsert:false, so an object is immutable once created; the only way to
-- "replace" a team image is delete-then-reupload (a new random name).
-- Per this batch's own spec ("UPDATE is not required unless the existing
-- project storage convention requires it") — it doesn't; every other
-- image-library bucket in this repo omits it too. Ownership is the first
-- path segment matching the caller's own auth.uid(), same
-- `(storage.foldername(name))[1] = auth.uid()::text` convention as every
-- other private bucket in this repo (0002_rls.sql, 0012, 0015).
--
-- QUICK FIX (post-audit): each policy also explicitly rejects any object
-- name containing `..`, not just the ownership-prefix check above.
-- `(storage.foldername(name))[1] = auth.uid()::text` alone only pins the
-- FIRST path segment to the caller's own uid — it does not, by itself,
-- rule out a later `..` segment elsewhere in the same name (e.g.
-- `{uid}/../{other-uid}/x.png`, where the first segment still literally
-- equals the caller's own uid). `name !~ '\.\.'` closes that off at the
-- RLS layer directly, using the exact same regex-based no-traversal rule
-- already applied at the table level to team_image_path
-- (team_library_image_path_no_traversal, 0018) and to the analogous
-- player_library/manager_library columns (0011/0014) — applied here to
-- storage.objects.name itself, not just to the path string the client
-- later stores in a library row.
create policy "storage_team_images_owner_select"
  on storage.objects for select
  using (
    bucket_id = 'team-images'
    and (storage.foldername(name))[1] = auth.uid()::text
    and name !~ '\.\.'
  );

create policy "storage_team_images_owner_insert"
  on storage.objects for insert
  with check (
    bucket_id = 'team-images'
    and (storage.foldername(name))[1] = auth.uid()::text
    and name !~ '\.\.'
  );

create policy "storage_team_images_owner_delete"
  on storage.objects for delete
  using (
    bucket_id = 'team-images'
    and (storage.foldername(name))[1] = auth.uid()::text
    and name !~ '\.\.'
  );

-- No service-role bypass is exposed to the browser: these policies apply
-- to the authenticated role via the anon key + user JWT, same as every
-- other bucket in 0002_rls.sql/0012/0015. The service role (used only
-- server-side) continues to bypass RLS by design, but nothing in this
-- batch grants it — or any browser code — a new capability. No public
-- access is granted anywhere in this migration.
