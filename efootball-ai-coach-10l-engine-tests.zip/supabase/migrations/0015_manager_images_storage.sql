-- Batch 6B-2 — Manager Library: private storage + RLS for manager
-- images.
--
-- Mirrors 0012_player_library_storage.sql / 0013_player_cards_bucket.sql
-- exactly, applied to a new `manager-images` bucket instead of
-- `player-cards`. Combined into one migration (bucket + RLS together)
-- since both are new here — 0012/0013 were split only because the
-- player-cards bucket predated its own migration-managed creation (see
-- 0013's header comment); there is no such history to preserve for
-- manager-images.
--
-- Path convention: `{user_id}/{safe-random-filename}.{extension}` — built
-- server-authoritatively by buildSafeManagerImageStoragePath
-- (packages/shared/src/uploadValidation.ts), never from a user-supplied
-- filename, so there is no client-controlled path component beyond the
-- user's own uid prefix (which these policies independently enforce
-- regardless of what the client claims).
--
-- ============================================================
-- BUCKET
-- ============================================================
-- `on conflict (id) do nothing` so this is a harmless no-op if the
-- bucket somehow already exists (same pattern as 0013).
insert into storage.buckets (id, name, public)
values ('manager-images', 'manager-images', false)
on conflict (id) do nothing;

-- Explicit UPDATE (not folded into the INSERT) so this also takes effect
-- for a bucket that already existed without these settings — same
-- reasoning, and same forced `public = false` hardening, as 0013's
-- post-6A-3 security fix for player-cards. 15MB matches this batch's
-- spec exactly, and reuses the same DEFAULT_IMAGE_MB convention already
-- used everywhere else (packages/shared/src/uploadValidation.ts,
-- .env.example) rather than inventing a new size for this bucket.
update storage.buckets
  set public = false,
      file_size_limit = 15 * 1024 * 1024,
      allowed_mime_types = array['image/jpeg', 'image/png', 'image/webp']
  where id = 'manager-images';

-- ============================================================
-- STORAGE RLS
-- ============================================================
-- Deliberately THREE narrow policies (select/insert/delete), not one
-- `for all` and no update policy — same reasoning as
-- storage_player_cards_owner_* (0012): object names are random and the
-- upload path always uses upsert:false, so an object is immutable once
-- created; the only way to "replace" a manager image is
-- delete-then-reupload (a new random name). Ownership is the first path
-- segment matching the caller's own auth.uid(), same
-- `(storage.foldername(name))[1] = auth.uid()::text` convention as every
-- other private bucket in this repo (0002_rls.sql, 0012).
create policy "storage_manager_images_owner_select"
  on storage.objects for select
  using (
    bucket_id = 'manager-images'
    and (storage.foldername(name))[1] = auth.uid()::text
  );

create policy "storage_manager_images_owner_insert"
  on storage.objects for insert
  with check (
    bucket_id = 'manager-images'
    and (storage.foldername(name))[1] = auth.uid()::text
  );

create policy "storage_manager_images_owner_delete"
  on storage.objects for delete
  using (
    bucket_id = 'manager-images'
    and (storage.foldername(name))[1] = auth.uid()::text
  );

-- No service-role bypass is exposed to the browser: these policies apply
-- to the authenticated role via the anon key + user JWT, same as every
-- other bucket in 0002_rls.sql/0012. The service role (used only
-- server-side) continues to bypass RLS by design, but nothing in this
-- batch grants it — or any browser code — a new capability. No public
-- access is granted anywhere in this migration.
