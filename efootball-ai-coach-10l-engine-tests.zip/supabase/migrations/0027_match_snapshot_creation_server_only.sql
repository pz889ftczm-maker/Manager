-- Batch 9B (audit fix) — Historical Match Snapshot Creation SERVICE
-- must be server-side ONLY (spec section 2: "Snapshot creation MUST
-- happen server-side. Do NOT allow the browser/client to directly
-- create snapshots.").
--
-- ISSUE FOUND IN AUDIT: 0026_match_snapshot_creation.sql granted
-- EXECUTE on public.create_match_snapshot to the `authenticated` role
-- (same grant shape as public.check_and_record_rate_limit, 0009).
-- That was wrong for THIS function specifically: check_and_record_
-- rate_limit is safe for `authenticated` to call directly because it
-- can only ever record/check a hit for auth.uid()'s own bucket and
-- has no other effect, but create_match_snapshot performs the actual
-- privileged write this whole batch exists to gate behind
-- supabase/functions/match-snapshot-create's own rate limiting (spec
-- section 18) — granting it to `authenticated` let any signed-in
-- browser call `supabase.rpc('create_match_snapshot', ...)` directly,
-- creating real snapshot rows while completely bypassing that Edge
-- Function's checkRateLimit call (Part O convention used by every
-- other write-triggering RPC/Edge Function in this repo). This
-- migration closes that hole without touching anything else 9A/9B
-- already established.
--
-- Design notes
-- ------------
-- * DROP + RECREATE, NOT `create or replace` (Postgres identifies a
--   function by name AND parameter-type list; adding a parameter is a
--   different signature, not a replacement of the old one — `create
--   or replace` with a new parameter list would leave the old 3-arg
--   public.create_match_snapshot(uuid, uuid, uuid) function sitting
--   around alongside the new one, still reachable and still granted
--   to `authenticated` from 0026, which would silently defeat this
--   entire fix). The old 3-arg overload is explicitly dropped first.
-- * NEW SIGNATURE — p_user_id uuid AS THE FIRST, SERVER-SUPPLIED
--   PARAMETER, auth.uid() removed entirely: the fix's own spec item 7
--   ("Update the RPC signature so the trusted server-side call can
--   provide the authenticated user ID... but treat it only as
--   server-provided input") replaces the previous "read auth.uid()
--   directly inside the function" approach — which relied on the
--   caller's own JWT context still being attached to the request when
--   .rpc() runs. That's no longer the calling convention: the Edge
--   Function now calls this function with the SERVICE-ROLE client
--   (see match-snapshot-create/index.ts), which has no end-user JWT/
--   auth.uid() of its own at all. p_user_id is therefore not a
--   convenience — it is the ONLY way this function can know who the
--   caller is, which is exactly why EXECUTE must never be granted to
--   `authenticated`/anon (see GRANTS note below): unlike auth.uid()
--   (which a caller cannot forge — it's derived from a verified JWT
--   Postgres itself checked), a plain uuid PARAMETER can be set to
--   anything by whoever is allowed to call the function at all. Safety
--   here comes entirely from WHO is allowed to call it (service_role
--   only, i.e. only this repo's own trusted Edge Function code, which
--   always resolves p_user_id itself via auth.getUser() against the
--   caller's real JWT before ever constructing this RPC call — see
--   that function's own comments), never from the parameter type
--   itself. Every ownership check inside the function body is
--   unchanged from 0026 — only which variable holds "the caller's
--   user id" changed, from `auth.uid()` to `p_user_id`.
-- * GRANTS (spec items 1/2/3/11 — the actual fix): `revoke all ... from
--   public` (already true from 0026, restated here for a clean,
--   self-contained final state) and EXECUTE is granted to
--   `service_role` ONLY — explicitly NOT `authenticated`, and anon
--   never had it. `authenticated` cannot call this function via
--   .rpc() at all after this migration (PostgREST/Postgres reject it
--   with "permission denied for function", never a Postgres detail
--   leaked to the browser since the client never even reaches
--   application code that could echo one back). The ONLY remaining
--   caller in this codebase is supabase/functions/match-snapshot-
--   create/index.ts, updated in the same fix to build a service-role
--   client (getServiceRoleClient, supabase/functions/_shared/
--   helpers.ts — this repo's own existing convention for a
--   server-only privileged operation, already used by clip-request/
--   analysis-enqueue for their own service-role writes) rather than
--   the user-scoped one it used before.
-- * EVERYTHING ELSE IS UNCHANGED FROM 0026 (spec item 9/12): every
--   ownership check (match/team/formation/manager/player), the
--   idempotency `on conflict on constraint match_snapshots_match_
--   team_uniq do nothing` handling, the atomic single-transaction
--   behavior, NULL safety for an absent formation/manager, deterministic
--   (position_slot, player_id) player insert order, and the
--   `match_snapshot_create: <code>` error-message convention consumed
--   by packages/shared/src/matchSnapshotCreation.ts's
--   mapSnapshotCreationRpcError are copied verbatim from 0026's
--   function body — only the parameter list, the source of
--   v_user_id, and the grants changed.
-- * REGRESSION (spec item 12): this migration touches only
--   public.create_match_snapshot's signature/grants. It does not
--   alter match_snapshots/match_snapshot_players/team_library/
--   player_library/manager_library/team_formations/team_formation_
--   players or any RLS policy from any prior migration, and does not
--   touch check_and_record_rate_limit (0009) or any other existing
--   function.

drop function if exists public.create_match_snapshot(uuid, uuid, uuid);

create function public.create_match_snapshot(
  p_user_id uuid,
  p_match_id uuid,
  p_team_id uuid,
  p_formation_id uuid default null
)
returns table (id uuid, created boolean)
language plpgsql
security definer set search_path = public
as $$
declare
  v_team public.team_library%rowtype;
  v_formation public.team_formations%rowtype;
  v_manager public.manager_library%rowtype;
  v_manager_ratings jsonb;
  v_existing_id uuid;
  v_new_id uuid;
  v_total_assigned integer;
  v_owned_assigned integer;
begin
  if p_user_id is null then
    raise exception 'match_snapshot_create: not_authenticated';
  end if;

  -- 1. Match ownership (spec section 4).
  if not exists (
    select 1 from public.matches m
    where m.id = p_match_id and m.user_id = p_user_id
  ) then
    raise exception 'match_snapshot_create: match_not_found';
  end if;

  -- 2. Team ownership (spec section 4) — also reads the current row
  -- for the historical copy below (spec section 5/6).
  select t.* into v_team
  from public.team_library t
  where t.id = p_team_id and t.user_id = p_user_id;
  if not found then
    raise exception 'match_snapshot_create: team_not_found';
  end if;

  -- 3. Formation ownership: must belong to THIS team (spec sections
  -- 4/9). Optional — see 0026's NULL SAFETY design note.
  if p_formation_id is not null then
    select f.* into v_formation
    from public.team_formations f
    where f.id = p_formation_id and f.team_id = p_team_id;
    if not found then
      raise exception 'match_snapshot_create: formation_not_found';
    end if;
  end if;

  -- 4. Manager ownership, only when the team actually has one (spec
  -- sections 4/7). Defense-in-depth — see 0026's design note.
  if v_team.manager_id is not null then
    select m.* into v_manager
    from public.manager_library m
    where m.id = v_team.manager_id and m.user_id = p_user_id;
    if not found then
      raise exception 'match_snapshot_create: manager_ownership_invalid';
    end if;
    v_manager_ratings := jsonb_build_object(
      'possession_rating', v_manager.possession_rating,
      'quick_counter_rating', v_manager.quick_counter_rating,
      'long_ball_counter_rating', v_manager.long_ball_counter_rating,
      'out_wide_rating', v_manager.out_wide_rating,
      'long_ball_rating', v_manager.long_ball_rating
    );
  end if;

  -- 5. Every assigned player must belong to the same user (spec
  -- section 4). Defense-in-depth — see 0026's design note. A mismatch
  -- REJECTS the whole request rather than silently dropping the
  -- unowned row (spec section 16).
  if p_formation_id is not null then
    select count(*) into v_total_assigned
    from public.team_formation_players tfp
    where tfp.formation_id = p_formation_id;

    select count(*) into v_owned_assigned
    from public.team_formation_players tfp
    join public.player_library p on p.id = tfp.player_id
    where tfp.formation_id = p_formation_id
      and p.user_id = p_user_id;

    if v_total_assigned <> v_owned_assigned then
      raise exception 'match_snapshot_create: player_ownership_invalid';
    end if;
  end if;

  -- Idempotency (spec sections 10/12): an exact repeat of this
  -- match+team pair already has a snapshot — return it as-is rather
  -- than creating a duplicate.
  select s.id into v_existing_id
  from public.match_snapshots s
  where s.match_id = p_match_id and s.team_id = p_team_id;
  if found then
    return query select v_existing_id, false;
    return;
  end if;

  -- Copy, do not reference (spec sections 1/2/6/14/15): every column
  -- below is a literal value read above, never a live reference.
  insert into public.match_snapshots (
    user_id, match_id, team_id, formation_id, manager_id,
    formation_code, formation_name, positions, tactical_instructions,
    team_name, team_motto, team_description, team_founded_year, team_stadium,
    manager_name, manager_ratings
  ) values (
    p_user_id, p_match_id, p_team_id, p_formation_id, v_team.manager_id,
    v_formation.formation_code, v_formation.name, v_formation.positions, v_formation.tactical_instructions,
    v_team.name, v_team.motto, v_team.description, v_team.founded_year, v_team.stadium,
    v_manager.name, v_manager_ratings
  )
  on conflict on constraint match_snapshots_match_team_uniq do nothing
  returning match_snapshots.id into v_new_id;

  if v_new_id is null then
    -- Lost a concurrent race against another request creating the
    -- same (match_id, team_id) snapshot between the pre-check above
    -- and this INSERT — converge on the winner's row (spec section
    -- 12), never error and never insert a second row.
    select s.id into v_existing_id
    from public.match_snapshots s
    where s.match_id = p_match_id and s.team_id = p_team_id;
    if not found then
      raise exception 'match_snapshot_create: snapshot_missing_after_conflict';
    end if;
    return query select v_existing_id, false;
    return;
  end if;

  -- Player assignments (spec sections 6/14/15): sourced only from
  -- team_formation_players joined through the now-verified formation,
  -- in deterministic (position_slot, player_id) order.
  if p_formation_id is not null then
    insert into public.match_snapshot_players (
      snapshot_id, player_id, player_name, position, overall, playstyle, attributes, position_slot
    )
    select
      v_new_id, p.id, p.name, p.position, p.overall, p.playstyle, p.attributes, tfp.position_slot
    from public.team_formation_players tfp
    join public.player_library p on p.id = tfp.player_id
    where tfp.formation_id = p_formation_id
    order by tfp.position_slot, p.id;
  end if;

  return query select v_new_id, true;
end;
$$;

comment on function public.create_match_snapshot(uuid, uuid, uuid, uuid) is
  'Batch 9B (audit fix) — atomic, server-side-only creation of an immutable match_snapshots (+ match_snapshot_players) row from a user''s CURRENT Team/Formation/Players/Manager configuration. SERVICE-ROLE ONLY: p_user_id is server-supplied by the trusted match-snapshot-create Edge Function (resolved from the caller''s verified JWT via auth.getUser(), never taken from the request body) — this function no longer reads auth.uid() itself, since it is now only ever invoked via a service-role client with no end-user JWT context. Every ownership check inside compares against p_user_id exactly as the prior (auth.uid()-based) version did against auth.uid(); the whole body still runs as one transaction so a failure at any step rolls back every write the call made. Idempotent on (match_id, team_id) via match_snapshots_match_team_uniq (0025). See 0026''s and this migration''s own header comments for the full design rationale.';

-- See GRANTS design note above: this is the actual fix. `authenticated`
-- is deliberately NOT granted EXECUTE — only service_role (the trusted
-- Edge Function's own client) may ever call this function. anon was
-- never granted it and still isn't.
revoke all on function public.create_match_snapshot(uuid, uuid, uuid, uuid) from public;
grant execute on function public.create_match_snapshot(uuid, uuid, uuid, uuid) to service_role;
