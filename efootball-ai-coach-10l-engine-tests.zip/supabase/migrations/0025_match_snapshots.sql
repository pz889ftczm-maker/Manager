-- Batch 9A — Historical Match Snapshot DATA MODEL only. Schema + RLS.
-- No snapshot UI, no snapshot-creation workflow (client or worker), no
-- Football Analysis/AI Coach/Progress/Dashboard integration — all of
-- that is explicitly out of scope for this batch and deferred to later
-- Phase 9 batches per the spec.
--
-- Design notes
-- ------------
-- * PURPOSE: a match_snapshots row freezes what a user's Team/
--   Formation/Players/Manager/Player Library/Manager Library actually
--   looked like at the moment a match was analyzed. Unlike every other
--   table added so far this phase (team_library/player_library/
--   manager_library/team_formations/team_formation_players/
--   team_formation_presets/team_formation_preset_players), which are
--   all explicitly documented as CURRENT, live, freely-editable data,
--   this table's entire job is the opposite: values here must NEVER
--   change when the live Library rows they were copied from change,
--   and must NEVER disappear when those live rows are edited or
--   deleted (spec sections 1/14/15).
-- * HISTORICAL VALUES ARE COPIED, NOT REFERENCED (spec sections 1/2/14/
--   15): team_id/formation_id/manager_id are PROVENANCE ONLY — nullable
--   `on delete set null` foreign keys kept purely so a future UI can
--   link back to "the team as it is today", if it still exists. Every
--   actual historical fact (team_name, team_motto, team_description,
--   team_founded_year, team_stadium, formation_code, formation_name,
--   positions, tactical_instructions, manager_name, manager_ratings,
--   and — on match_snapshot_players — player_name/position/overall/
--   playstyle/attributes/position_slot) is stored directly as its own
--   column/jsonb value on the snapshot row itself. Reconstructing a
--   historical snapshot for display must be possible from these two
--   tables alone, with zero joins back to team_library/player_library/
--   manager_library/team_formations (spec section 15).
-- * NULL SAFETY (spec section 4, same rule as every other Library
--   table this phase): every historical/descriptive column is
--   nullable, with no default. An unknown value at snapshot-creation
--   time (a field the analyzed team/player/manager simply didn't have
--   set) stays NULL forever — never 0, never "", never a fabricated
--   name/rating/attribute. This migration adds no CHECK that requires
--   any of these columns to be non-null.
-- * IMMUTABILITY (spec section 5): once created, a snapshot (and its
--   player rows) must never be edited or deleted by the normal
--   application client. This is enforced structurally, not by
--   convention: neither table gets an UPDATE or DELETE policy of any
--   kind below (see RLS section) — with row level security enabled and
--   no matching policy, Postgres denies UPDATE/DELETE outright for any
--   role subject to RLS. No `updated_at` column or touch-trigger exists
--   on either table either, unlike literally every other table this
--   phase has added, precisely because there is nothing here that is
--   ever meant to be touched again after insert.
-- * NO CLIENT-SIDE INSERT POLICY EITHER (spec sections 5/7): this batch
--   deliberately does NOT add an INSERT policy for the authenticated
--   role on either table. Creation is explicitly deferred to a later,
--   trusted server-side (Edge Function/worker, service-role) workflow
--   per spec section 7 — until that workflow exists, this schema simply
--   has no browser-reachable way to create a row at all. The service
--   role bypasses RLS by default (this migration does NOT `force row
--   level security`), so a future trusted server-side workflow can
--   still insert here without requiring a policy change; a general
--   `authenticated`/anon INSERT policy is never added.
-- * RLS / OWNERSHIP (spec section 6): match_snapshots keeps a direct
--   `user_id` column (unlike team_formations/team_formation_players,
--   which derive ownership only through team_id/formation_id) because
--   the spec explicitly asks for `user_id = auth.uid()` as the
--   ownership check here — this mirrors matches.user_id/
--   ai_coach_messages.user_id (0001), which already use a direct
--   column rather than a derived join for their own SELECT policies.
--   match_snapshot_players deliberately has NO user_id column (spec
--   section 6 — "Do not add redundant user_id to
--   match_snapshot_players"); its SELECT policy derives ownership by
--   joining match_snapshot_players -> match_snapshots -> user_id,
--   exactly the one-hop-through-a-parent-row shape team_formations'
--   own policies already use for team_library.
-- * MATCH OWNERSHIP CONSISTENCY (spec section 9): `matches` already
--   carries its own direct `user_id` (0001_schema.sql) — unlike
--   team_formations, there is no need to inspect a different existing
--   ownership shape here. A snapshot's user_id MUST equal
--   matches.user_id for the match it references. RLS's own `using`
--   clause below only ever exposes a caller's OWN rows regardless, but
--   per spec section 9 ("do not trust client-supplied user_id" / "use
--   defense-in-depth") a second, independent check is added directly
--   on the table itself: check_match_snapshots_ownership, a BEFORE
--   INSERT OR UPDATE trigger, same convention as
--   check_team_members_ownership (0019) / check_team_formation_players_
--   ownership (0022) / check_team_library_manager_ownership (0020).
--   This still holds even for a hypothetical future service-role write
--   that bypassed RLS entirely — exactly the scenario this batch's
--   later server-side creation workflow (spec section 7) will run
--   under.
-- * DUPLICATE SNAPSHOTS (spec section 10): matches has no existing
--   column or relationship to team_library at all (inspected above —
--   0001_schema.sql's `matches` table stands alone), so nothing in the
--   current architecture limits a match to at most one associated
--   team, and nothing here invents such a limit either. Multiple
--   distinct team snapshots for the same match are therefore left
--   legitimately possible (e.g. re-analysis under a different team
--   context). What IS prevented is an ACCIDENTAL repeat snapshot of the
--   *same* match+team pair: a partial unique index on
--   (match_id, team_id) WHERE team_id IS NOT NULL. This still allows
--   any number of snapshots per match that have no team_id at all
--   (nothing meaningful to deduplicate those on), and any number of
--   *different* team_id snapshots per match — only an exact repeat of
--   one particular team against one particular match is blocked. Named
--   explicitly (match_snapshots_match_team_uniq) so future application
--   code can recognize this exact violation via isUniqueViolation
--   (playerLibrary.ts), same convention as every other named unique
--   index this phase has added.
-- * JSONB SHAPE CHECKS (spec section 8, "JSONB fields must have the
--   expected object/array shape where practical"): mirrors
--   team_formations' own jsonb_typeof checks (0021) — positions, when
--   present, must be a jsonb object or array (never a bare scalar);
--   tactical_instructions and manager_ratings, when present, must be
--   jsonb objects; match_snapshot_players.attributes, when present,
--   must be a jsonb object. All four are otherwise fully nullable, per
--   the NULL SAFETY note above — these checks only constrain the shape
--   of a value that IS present, never require one to exist.
-- * CONSISTENCY CONSTRAINTS (spec section 8): overall >= 0 (mirrors
--   player_library.overall's own check, 0011); team_founded_year > 0
--   (mirrors team_library.founded_year's own check, 0016) — no
--   invented upper bound on either, same reasoning as those two
--   originals. No maximum is imposed anywhere on player attributes,
--   manager ratings, or tactical instruction values (spec explicitly
--   prohibits inventing one here, same as the existing Library tables
--   already do for their own live versions of this data).
-- * INDEXES (spec section 11): user_id, match_id, team_id,
--   formation_id, created_at on match_snapshots; snapshot_id and
--   player_id on match_snapshot_players. match_id gets its own plain
--   index (not merged into the match_team unique index above) because
--   that index is PARTIAL (WHERE team_id IS NOT NULL) and so cannot
--   serve a plain "all snapshots for this match_id" lookup on rows
--   with a null team_id.
-- * HISTORICAL INDEPENDENCE / NO CURRENT-LIBRARY DEPENDENCY (spec
--   sections 14/15): every historical column here is populated once,
--   at insert time, by copying a value — never by a foreign-key join
--   evaluated at read time. Editing or deleting the source
--   team_library/player_library/manager_library/team_formations row
--   afterward cannot alter or erase what's stored here: team_id/
--   formation_id/manager_id/player_id are the ONLY columns with a
--   foreign key into a live Library table, all `on delete set null`,
--   and none of them is ever read to reconstruct a historical value —
--   they exist purely so a future UI can optionally link to "this
--   team/player/manager today, if it still exists".
-- * NO SERVICE-ROLE CREDENTIALS EXPOSED (spec section 7): this
--   migration adds no Storage bucket, no Edge Function, no API key/
--   secret of any kind — only schema, indexes, RLS, and the one
--   ownership trigger.
-- * REGRESSION (spec section 17): team_library/player_library/
--   manager_library/team_formations/team_formation_players/
--   team_formation_presets/team_formation_preset_players and every
--   pre-existing table are left completely untouched by this
--   migration — it only adds two new tables and their supporting
--   objects.
-- * DEMO DATA: no rows are inserted for either table anywhere (this
--   migration or supabase/seed.sql) — there is no demo/sample
--   snapshot.
-- * Out of scope for this migration (per spec): snapshot UI, snapshot
--   creation workflow (client or worker), automatic snapshot creation,
--   Football Analysis/AI Coach/Progress/Dashboard changes. This
--   migration adds schema + RLS + the one ownership-consistency
--   trigger only.

-- ============================================================
-- MATCH SNAPSHOTS
-- ============================================================
create table public.match_snapshots (
  id uuid primary key default gen_random_uuid(),
  user_id uuid not null references auth.users(id) on delete cascade,
  match_id uuid not null references public.matches(id) on delete cascade,

  -- Provenance/reference only — see "HISTORICAL VALUES ARE COPIED, NOT
  -- REFERENCED" design note above. Never read to reconstruct a
  -- historical value.
  team_id uuid references public.team_library(id) on delete set null,
  formation_id uuid references public.team_formations(id) on delete set null,
  manager_id uuid references public.manager_library(id) on delete set null,

  -- Historical formation snapshot — copied values, see design notes.
  formation_code text,
  formation_name text,
  positions jsonb,
  tactical_instructions jsonb,

  -- Historical team snapshot — copied values, see design notes.
  team_name text,
  team_motto text,
  team_description text,
  team_founded_year integer,
  team_stadium text,

  -- Historical manager snapshot — copied values, see design notes.
  manager_name text,
  manager_ratings jsonb,

  created_at timestamptz not null default now(),

  -- See "CONSISTENCY CONSTRAINTS" design note above.
  constraint match_snapshots_team_founded_year_valid
    check (team_founded_year is null or team_founded_year > 0),

  -- See "JSONB SHAPE CHECKS" design note above.
  constraint match_snapshots_positions_shape_valid
    check (positions is null or jsonb_typeof(positions) in ('object', 'array')),
  constraint match_snapshots_tactical_instructions_shape_valid
    check (tactical_instructions is null or jsonb_typeof(tactical_instructions) = 'object'),
  constraint match_snapshots_manager_ratings_shape_valid
    check (manager_ratings is null or jsonb_typeof(manager_ratings) = 'object')
);

-- See "DUPLICATE SNAPSHOTS" design note above.
create unique index match_snapshots_match_team_uniq
  on public.match_snapshots(match_id, team_id)
  where team_id is not null;

-- See "INDEXES" design note above.
create index match_snapshots_user_id_idx on public.match_snapshots(user_id);
create index match_snapshots_match_id_idx on public.match_snapshots(match_id);
create index match_snapshots_team_id_idx on public.match_snapshots(team_id);
create index match_snapshots_formation_id_idx on public.match_snapshots(formation_id);
create index match_snapshots_created_at_idx on public.match_snapshots(created_at);

-- See "MATCH OWNERSHIP CONSISTENCY" design note above.
create or replace function public.check_match_snapshots_ownership()
returns trigger
language plpgsql
as $$
begin
  if not exists (
    select 1
    from public.matches m
    where m.id = new.match_id
      and m.user_id = new.user_id
  ) then
    raise exception 'match_snapshots: user % does not match owner of match %', new.user_id, new.match_id;
  end if;
  return new;
end;
$$;

create trigger match_snapshots_ownership_check
  before insert or update on public.match_snapshots
  for each row execute procedure public.check_match_snapshots_ownership();

-- ============================================================
-- RLS
-- ============================================================
alter table public.match_snapshots enable row level security;

-- SELECT: only the caller's own snapshots (spec section 6 — "Use
-- user_id = auth.uid() for SELECT ownership").
create policy "match_snapshots_select_own" on public.match_snapshots
  for select using (auth.uid() = user_id);

-- See "NO CLIENT-SIDE INSERT POLICY EITHER" / "IMMUTABILITY" design
-- notes above: deliberately no INSERT/UPDATE/DELETE policy is created
-- for this table. With RLS enabled and no matching policy, every
-- non-service-role write is denied outright.

-- ============================================================
-- MATCH SNAPSHOT PLAYERS
-- ============================================================
create table public.match_snapshot_players (
  id uuid primary key default gen_random_uuid(),
  snapshot_id uuid not null references public.match_snapshots(id) on delete cascade,

  -- Provenance only — see "HISTORICAL VALUES ARE COPIED, NOT
  -- REFERENCED" design note above. Never read to reconstruct a
  -- historical value; deletion of the source player_library row must
  -- never erase (or even affect) the historical fields below.
  player_id uuid references public.player_library(id) on delete set null,

  -- Historical player snapshot — copied values, see design notes.
  player_name text,
  position text,
  overall integer,
  playstyle text,
  attributes jsonb,
  position_slot text,

  created_at timestamptz not null default now(),

  -- See "CONSISTENCY CONSTRAINTS" design note above.
  constraint match_snapshot_players_overall_valid
    check (overall is null or overall >= 0),

  -- See "JSONB SHAPE CHECKS" design note above.
  constraint match_snapshot_players_attributes_shape_valid
    check (attributes is null or jsonb_typeof(attributes) = 'object')
);

-- See "INDEXES" design note above.
create index match_snapshot_players_snapshot_id_idx on public.match_snapshot_players(snapshot_id);
create index match_snapshot_players_player_id_idx on public.match_snapshot_players(player_id);

-- ============================================================
-- RLS
-- ============================================================
alter table public.match_snapshot_players enable row level security;

-- SELECT: ownership derives entirely through the parent snapshot's
-- user_id (spec section 6 — "Snapshot-player SELECT must derive
-- ownership through match_snapshot_players -> match_snapshots ->
-- user_id. Do not add redundant user_id to match_snapshot_players.").
create policy "match_snapshot_players_select_own" on public.match_snapshot_players
  for select using (
    exists (
      select 1 from public.match_snapshots s
      where s.id = snapshot_id and s.user_id = auth.uid()
    )
  );

-- See "NO CLIENT-SIDE INSERT POLICY EITHER" / "IMMUTABILITY" design
-- notes above: deliberately no INSERT/UPDATE/DELETE policy is created
-- for this table either.

-- No service-role bypass is exposed to the browser: the only policies
-- on either table are the two SELECT policies above, scoped to
-- auth.uid() via a direct or one-hop-derived user_id. The service role
-- (a future trusted Edge Function/worker) can still write both tables
-- server-side without any policy change, since RLS is not forced for
-- that role — but no browser-reachable path grants cross-user access,
-- and no browser-reachable path can create, edit, or delete a snapshot
-- at all yet.
