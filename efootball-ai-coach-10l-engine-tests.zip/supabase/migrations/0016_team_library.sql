-- Batch 7A — Team Library: database + RLS foundation only.
--
-- Adds a single new table for a user's personal, reusable eFootball team
-- library — the same "reusable source data the user curates themselves"
-- pattern as public.player_library (0011) and public.manager_library
-- (0014), applied to teams instead of players/managers. This migration
-- mirrors that structure/conventions where they still fit, and departs
-- from them explicitly (and only) where this batch's own spec requires
-- it — see the notes below.
--
-- Design notes
-- ------------
-- * REQUIRED NAME (departure from player_library/manager_library): this
--   batch's spec states "name is required" for team_library, unlike the
--   other two libraries where name is optional. `name` is therefore
--   `not null`, plus a check constraint rejecting empty/whitespace-only
--   strings (spec: "name must not be empty/whitespace"). `motto`,
--   `description`, `founded_year`, and `stadium` remain fully nullable —
--   unknown values stay NULL, nothing is defaulted or invented, same
--   NULL-safety rule as every other library table in this repo.
-- * founded_year: `integer`, nullable, with a single check
--   (`founded_year > 0`) that rejects only clearly invalid values (zero,
--   negative). Per this batch's explicit spec ("DO NOT invent an
--   artificial maximum founded year" / "do not over-constrain real-world
--   team data"), no upper bound is imposed — a large or future year is
--   left valid rather than guessing at a cutoff this repo has no
--   authoritative source for.
-- * No image/logo column: unlike player_library.player_card_image_path
--   and manager_library.manager_image_path, this batch's spec explicitly
--   excludes "Team image/logo storage" ("DO NOT IMPLEMENT"). No storage
--   path column, bucket, or path-ownership check constraint is added
--   here; a future batch can add that column + its own RLS/path checks
--   the same way 0012/0015 layered storage onto 0011/0014.
-- * No jsonb attributes/metadata column: not part of this batch's field
--   list, and nothing in the spec calls for free-form structured data on
--   a team the way player_library.attributes does for a card. Omitted
--   rather than speculatively added.
-- * Duplicate prevention: the spec for this batch explicitly prefers a
--   plain case-insensitive uniqueness rule within the same user, in
--   contrast to player_library/manager_library's wider composite keys
--   (which exist there specifically to allow legitimate same-name
--   variants — different card rarity, different ratings). A team doesn't
--   have that kind of "variant" in this batch's field set, so the simpler
--   rule the spec asks for is used as-is: unique on (user_id,
--   lower(name)), with no partial-index WHERE clause needed since name
--   is NOT NULL here (unlike the other two libraries' `where name is not
--   null`). This blocks an accidental duplicate add of the same team
--   name for the same user while leaving another user entirely free to
--   use that same name (spec: "same team name can exist for different
--   users" / "Do NOT make `name` globally unique").
-- * HISTORICAL SAFETY: no column here references matches/analysis_events/
--   player statistics/manager_library/player_library/snapshots, and
--   nothing in this migration adds a column FROM those tables back to
--   this one. A team_library row can be freely edited or deleted without
--   touching any historical match record or other library, by
--   construction. Per the spec, future batches will handle team members,
--   manager assignment, formation, and historical snapshots — none of
--   that is implemented here.
-- * DEMO DATA: no rows are inserted for this table anywhere (this
--   migration or supabase/seed.sql) — there is no demo team library.
-- * Out of scope for this batch (per spec): team UI, team profile page,
--   image/logo storage, team members, player<->team or manager<->team
--   relationships, formation persistence, team presets, historical
--   snapshots, and any change to AI Coach / match analysis / Player
--   Library / Manager Library. This migration adds schema + RLS only.

-- ============================================================
-- TEAM LIBRARY
-- ============================================================
create table public.team_library (
  id uuid primary key default gen_random_uuid(),
  user_id uuid not null references auth.users(id) on delete cascade,

  name text not null,
  motto text,
  description text,
  founded_year integer,
  stadium text,

  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now(),

  -- See "REQUIRED NAME" design note above.
  constraint team_library_name_not_blank
    check (btrim(name) <> ''),

  -- See "founded_year" design note above: rejects only clearly invalid
  -- (non-positive) values, no invented upper bound.
  constraint team_library_founded_year_valid
    check (founded_year is null or founded_year > 0)
);

create index team_library_user_id_idx on public.team_library(user_id);
create index team_library_updated_at_idx on public.team_library(updated_at);

-- See "Duplicate prevention" design note above.
create unique index team_library_user_name_uniq
  on public.team_library(user_id, lower(name));

-- Same per-table trigger convention as touch_player_library_updated_at
-- (0011) / touch_manager_library_updated_at (0014).
create or replace function public.touch_team_library_updated_at()
returns trigger
language plpgsql
as $$
begin
  new.updated_at := now();
  return new;
end;
$$;

create trigger team_library_touch_updated_at
  before update on public.team_library
  for each row execute procedure public.touch_team_library_updated_at();

-- ============================================================
-- RLS
-- ============================================================
alter table public.team_library enable row level security;

create policy "team_library_select_own" on public.team_library
  for select using (auth.uid() = user_id);

-- "user_id must not be client-controlled for ownership": there is no
-- default on user_id, but this with-check rejects any insert where the
-- submitted user_id isn't the caller's own auth.uid() — same pattern as
-- every other user-owned table in this repo (0002/0006/0011/0014).
create policy "team_library_insert_own" on public.team_library
  for insert with check (auth.uid() = user_id);

create policy "team_library_update_own" on public.team_library
  for update using (auth.uid() = user_id)
  with check (auth.uid() = user_id);

create policy "team_library_delete_own" on public.team_library
  for delete using (auth.uid() = user_id);

-- No service-role bypass is exposed to the browser: these are the only
-- policies on this table, all scoped to auth.uid() = user_id, same as
-- player_library/manager_library/players/player_progress/profiles. The
-- service role (worker) can still write this table server-side if a
-- future batch needs it to, but no browser-reachable path grants
-- cross-user access.
