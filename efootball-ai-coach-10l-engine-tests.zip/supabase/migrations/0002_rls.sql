-- Row Level Security — every user can only touch their own rows.
-- Service role (used only by the worker / server functions) bypasses RLS by design.

alter table public.profiles enable row level security;
alter table public.matches enable row level security;
alter table public.media enable row level security;
alter table public.analysis_events enable row level security;
alter table public.tactical_analysis enable row level security;
alter table public.match_statistics enable row level security;
alter table public.player_progress enable row level security;
alter table public.ai_coach_messages enable row level security;

-- ---------------- profiles ----------------
create policy "profiles_select_own" on public.profiles
  for select using (auth.uid() = id);
create policy "profiles_update_own" on public.profiles
  for update using (auth.uid() = id);

-- ---------------- matches ----------------
create policy "matches_select_own" on public.matches
  for select using (auth.uid() = user_id);
create policy "matches_insert_own" on public.matches
  for insert with check (auth.uid() = user_id);
create policy "matches_update_own" on public.matches
  for update using (auth.uid() = user_id);
create policy "matches_delete_own" on public.matches
  for delete using (auth.uid() = user_id);

-- ---------------- media ----------------
create policy "media_select_own" on public.media
  for select using (auth.uid() = user_id);
create policy "media_insert_own" on public.media
  for insert with check (auth.uid() = user_id);
create policy "media_update_own" on public.media
  for update using (auth.uid() = user_id);
create policy "media_delete_own" on public.media
  for delete using (auth.uid() = user_id);

-- ---------------- analysis_events ----------------
-- No user_id column directly; scope through the parent match.
create policy "analysis_events_select_own" on public.analysis_events
  for select using (
    exists (select 1 from public.matches m where m.id = match_id and m.user_id = auth.uid())
  );
create policy "analysis_events_insert_own" on public.analysis_events
  for insert with check (
    exists (select 1 from public.matches m where m.id = match_id and m.user_id = auth.uid())
  );
create policy "analysis_events_update_own" on public.analysis_events
  for update using (
    exists (select 1 from public.matches m where m.id = match_id and m.user_id = auth.uid())
  );
create policy "analysis_events_delete_own" on public.analysis_events
  for delete using (
    exists (select 1 from public.matches m where m.id = match_id and m.user_id = auth.uid())
  );

-- ---------------- tactical_analysis ----------------
create policy "tactical_analysis_select_own" on public.tactical_analysis
  for select using (
    exists (
      select 1 from public.analysis_events e
      join public.matches m on m.id = e.match_id
      where e.id = event_id and m.user_id = auth.uid()
    )
  );
create policy "tactical_analysis_insert_own" on public.tactical_analysis
  for insert with check (
    exists (
      select 1 from public.analysis_events e
      join public.matches m on m.id = e.match_id
      where e.id = event_id and m.user_id = auth.uid()
    )
  );

-- ---------------- match_statistics ----------------
create policy "match_statistics_select_own" on public.match_statistics
  for select using (
    exists (select 1 from public.matches m where m.id = match_id and m.user_id = auth.uid())
  );
create policy "match_statistics_upsert_own" on public.match_statistics
  for insert with check (
    exists (select 1 from public.matches m where m.id = match_id and m.user_id = auth.uid())
  );
create policy "match_statistics_update_own" on public.match_statistics
  for update using (
    exists (select 1 from public.matches m where m.id = match_id and m.user_id = auth.uid())
  );

-- ---------------- player_progress ----------------
create policy "player_progress_select_own" on public.player_progress
  for select using (auth.uid() = user_id);
create policy "player_progress_upsert_own" on public.player_progress
  for insert with check (auth.uid() = user_id);
create policy "player_progress_update_own" on public.player_progress
  for update using (auth.uid() = user_id);

-- ---------------- ai_coach_messages ----------------
create policy "ai_coach_messages_select_own" on public.ai_coach_messages
  for select using (auth.uid() = user_id);
create policy "ai_coach_messages_insert_own" on public.ai_coach_messages
  for insert with check (auth.uid() = user_id);

-- ---------------- Storage ----------------
-- Buckets are created as PRIVATE (see supabase/config.toml / dashboard).
-- Objects are keyed by path convention: `{user_id}/{match_id}/{filename}`.
-- These policies assume that convention so a user can only read/write
-- objects under their own uid prefix. Apply via Storage > Policies, or here
-- if using storage.objects RLS directly:

create policy "storage_raw_uploads_owner_rw"
  on storage.objects for all
  using (
    bucket_id = 'raw-uploads'
    and (storage.foldername(name))[1] = auth.uid()::text
  )
  with check (
    bucket_id = 'raw-uploads'
    and (storage.foldername(name))[1] = auth.uid()::text
  );

create policy "storage_processed_frames_owner_rw"
  on storage.objects for all
  using (
    bucket_id = 'processed-frames'
    and (storage.foldername(name))[1] = auth.uid()::text
  )
  with check (
    bucket_id = 'processed-frames'
    and (storage.foldername(name))[1] = auth.uid()::text
  );

-- No public bucket policies are defined: nothing is world-readable.
-- Serve files to the client via short-lived signed URLs generated
-- server-side (see apps/worker/src/storage.ts and any Edge Function
-- that mints them) rather than public bucket access.
