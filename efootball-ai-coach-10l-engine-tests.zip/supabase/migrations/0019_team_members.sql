-- Batch 7C — Team Members: junction table linking a user's own
-- player_library entries to their own team_library entries (the
-- CURRENT roster only). Player Library (0011) and Team Library
-- (0016/0018) already exist independently; this migration is the first
-- thing that connects them.
--
-- Design notes
-- ------------
-- * NO user_id COLUMN (explicit spec requirement: "Do NOT add player
--   ownership as a new column. Ownership must be derived through
--   team_library.user_id and player_library.user_id."). Unlike every
--   other user-owned table in this repo (player_library, team_library,
--   manager_library, matches, players, ...), team_members has no
--   `user_id` of its own — ownership is a two-hop derivation through
--   its two foreign keys instead of a direct column. Every RLS policy
--   below (and the ownership-consistency trigger) proves ownership via
--   `exists (select ... from team_library/player_library where ...)`,
--   never by comparing to a `user_id` that doesn't exist on this table.
-- * FOREIGN KEYS: team_id -> team_library(id), player_id ->
--   player_library(id), both `on delete cascade` per spec section 9 —
--   deleting a team or a player_library entry removes the membership
--   row, but never the other way around (removing a membership only
--   ever deletes this junction row; it cannot delete a team_library or
--   player_library row, since there is no reverse FK/trigger that could
--   do that).
-- * UNIQUENESS: `unique (team_id, player_id)` — a given player can only
--   be added to the same team once. Named explicitly
--   (team_members_team_player_uniq) rather than left to Postgres's
--   default constraint-naming, so application code
--   (packages/shared/src/teamMembers.ts) can reliably recognize a
--   unique-violation on this exact constraint via isUniqueViolation
--   (playerLibrary.ts) without depending on Postgres's naming
--   convention for an unnamed inline `unique (...)` clause.
-- * INDEXES: one on team_id (list a team's roster), one on player_id
--   (e.g. future "which teams is this player on" lookups) — spec
--   section 1 asks for both explicitly, beyond what the unique
--   constraint's composite index alone would cover (a composite unique
--   index on (team_id, player_id) already serves team_id-only lookups
--   efficiently as its leading column, but not player_id-only lookups,
--   which is why a separate player_id index is still added).
-- * NO PLAYER DATA DUPLICATION (spec section 4): this table has exactly
--   five columns — id, team_id, player_id, created_at, updated_at — and
--   nothing else. name/position/overall/playstyle/attributes/image stay
--   solely on player_library; a reader joins through player_id to get
--   them. This also means a later edit to a player_library card (e.g.
--   correcting its overall) is instantly reflected for every team it's
--   a member of, with nothing here to go stale.
-- * OWNERSHIP-CONSISTENCY TRIGGER (defense-in-depth, same convention as
--   check_match_player_statistics_ownership /
--   check_player_attributes_ownership in 0006_player_statistics.sql):
--   RLS's `with check` clauses (below) are what actually stop a
--   cross-user insert/update via the browser, but per spec section 2
--   ("Do not rely only on the foreign keys for authorization") and
--   section 12 ("verify RLS policies"), a second, independent check is
--   added directly on the table itself. This one couldn't compare
--   against a `user_id` column (there isn't one here) — instead it
--   directly asserts that the team_library row and the player_library
--   row referenced by a given team_members row belong to the SAME
--   auth.users id, which is the actual invariant this whole batch
--   exists to protect. This still holds even for a hypothetical future
--   service-role write that bypassed RLS entirely.
-- * HISTORICAL SAFETY (spec section 8): no column here references
--   matches, analysis_events, player_statistics, progress, or any
--   snapshot/AI-Coach/tournament table, and nothing in this migration
--   adds a column FROM those tables back to this one. team_members
--   represents the CURRENT roster only, freely editable without
--   touching any historical record, by construction.
-- * DEMO DATA: no rows are inserted for this table anywhere (this
--   migration or supabase/seed.sql) — there is no demo roster.

-- ============================================================
-- TEAM MEMBERS
-- ============================================================
create table public.team_members (
  id uuid primary key default gen_random_uuid(),
  team_id uuid not null references public.team_library(id) on delete cascade,
  player_id uuid not null references public.player_library(id) on delete cascade,

  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now(),

  -- See "UNIQUENESS" design note above.
  constraint team_members_team_player_uniq unique (team_id, player_id)
);

create index team_members_team_id_idx on public.team_members(team_id);
create index team_members_player_id_idx on public.team_members(player_id);

create or replace function public.touch_team_members_updated_at()
returns trigger
language plpgsql
as $$
begin
  new.updated_at := now();
  return new;
end;
$$;

create trigger team_members_touch_updated_at
  before update on public.team_members
  for each row execute procedure public.touch_team_members_updated_at();

-- See "OWNERSHIP-CONSISTENCY TRIGGER" design note above.
create or replace function public.check_team_members_ownership()
returns trigger
language plpgsql
as $$
begin
  if not exists (
    select 1
    from public.team_library t
    join public.player_library p on p.user_id = t.user_id
    where t.id = new.team_id
      and p.id = new.player_id
  ) then
    raise exception 'team_members: team % and player % do not belong to the same user', new.team_id, new.player_id;
  end if;
  new.updated_at := now();
  return new;
end;
$$;

create trigger team_members_ownership_check
  before insert or update on public.team_members
  for each row execute procedure public.check_team_members_ownership();

-- ============================================================
-- RLS
-- ============================================================
alter table public.team_members enable row level security;

-- SELECT: only the caller's own team's membership rows are visible
-- (spec: "read another user's team membership" must be impossible).
create policy "team_members_select_own" on public.team_members
  for select using (
    exists (
      select 1 from public.team_library t
      where t.id = team_id and t.user_id = auth.uid()
    )
  );

-- INSERT: both the team AND the player being added must belong to the
-- caller (spec section 2 — both ownership sides required).
create policy "team_members_insert_own" on public.team_members
  for insert with check (
    exists (
      select 1 from public.team_library t
      where t.id = team_id and t.user_id = auth.uid()
    )
    and exists (
      select 1 from public.player_library p
      where p.id = player_id and p.user_id = auth.uid()
    )
  );

-- UPDATE: same ownership conditions as INSERT, checked on both the
-- pre-update row (using) and the post-update row (with check) — so a
-- caller can't repoint an owned row's team_id/player_id at someone
-- else's team or player either.
create policy "team_members_update_own" on public.team_members
  for update using (
    exists (
      select 1 from public.team_library t
      where t.id = team_id and t.user_id = auth.uid()
    )
    and exists (
      select 1 from public.player_library p
      where p.id = player_id and p.user_id = auth.uid()
    )
  )
  with check (
    exists (
      select 1 from public.team_library t
      where t.id = team_id and t.user_id = auth.uid()
    )
    and exists (
      select 1 from public.player_library p
      where p.id = player_id and p.user_id = auth.uid()
    )
  );

-- DELETE: only team ownership is required (spec section 2 — "DELETE:
-- only if team_library.user_id = auth.uid()"), so a user can always
-- remove a member from their own team roster regardless of whether
-- they still own the underlying player_library row (e.g. it could only
-- have been added while they owned it, since INSERT required both
-- sides — this just doesn't re-require the player side on removal).
create policy "team_members_delete_own" on public.team_members
  for delete using (
    exists (
      select 1 from public.team_library t
      where t.id = team_id and t.user_id = auth.uid()
    )
  );

-- No service-role bypass is exposed to the browser: these are the only
-- policies on this table, all scoped to auth.uid() via team_library/
-- player_library ownership. The service role (worker) can still write
-- this table server-side if a future batch needs it to, but no
-- browser-reachable path grants cross-user access.
