-- Batch 7D — Manager Assignment: additive `manager_id` on team_library,
-- letting each team optionally reference ONE of the caller's own
-- manager_library entries. Builds on team_library (0016/0018),
-- manager_library (0014), and follows the same "additive migration,
-- existing table/RLS not rewritten except where strictly required"
-- convention 0018 itself already used to add team_image_path.
--
-- Design notes
-- ------------
-- * `manager_id uuid`, nullable, no default — see "NULL SAFETY" design
--   note below. FK -> manager_library(id) `on delete set null` (spec
--   section 1/5: "A team may have zero or one manager" / deleting the
--   manager must null the team out, never delete or block-delete the
--   team). No separate team_managers junction table is created — the
--   spec explicitly prefers a direct column here, unlike team_members
--   (0019), which needed a junction table because a team has *many*
--   players; a team has at most *one* manager, so a single nullable FK
--   column is the right shape and needs no id/created_at/updated_at of
--   its own.
-- * MANY-TEAMS-PER-MANAGER (spec section 1: "A manager may be assigned
--   to multiple teams... unless existing product rules explicitly
--   prohibit it"): no uniqueness constraint is added on manager_id.
--   Nothing in this repo's existing schema/RLS treats a manager
--   assignment as exclusive, so the default (many teams can share one
--   manager) is preserved rather than inventing a new restriction.
-- * NULL SAFETY (spec section 3): manager_id has no default and no
--   `not null` — a team can be created, or edited, with no manager at
--   all, forever, and this migration performs no backfill (every
--   pre-existing team_library row simply gets manager_id = NULL). This
--   is the same NULL-safety rule already applied to every optional
--   column across player_library/manager_library/team_library.
-- * OWNERSHIP (spec section 2 — "Do NOT rely only on the FK"): enforced
--   twice, same defense-in-depth pattern as team_members (0019) and
--   match_player_statistics (0006):
--     1. RLS: team_library_insert_own / team_library_update_own (0016,
--        additively modified by 0018 for team_image_path) are
--        recreated again here with an added clause requiring manager_id
--        to be either null or point at a manager_library row owned by
--        the SAME auth.uid() as the team being written. This is what
--        actually stops a browser client from assigning/reassigning to
--        another user's manager via INSERT or UPDATE. All of 0018's own
--        additions (image-path ownership) are preserved verbatim in the
--        same policies, not dropped.
--     2. Trigger: check_team_library_manager_ownership, BEFORE INSERT
--        OR UPDATE, independently re-verifies that manager_id (when not
--        null) belongs to the same user_id as the team row itself. This
--        still holds even for a hypothetical future service-role write
--        that bypassed RLS entirely, and is the same
--        belt-and-suspenders convention as
--        check_player_attributes_ownership (0006) and
--        check_team_members_ownership (0019). Layered onto — not
--        replacing — team_library_touch_updated_at (0016), which
--        continues to own `updated_at`.
-- * CROSS-USER PROTECTION (spec section 4): the two ownership layers
--   above are exactly what rejects "User A team + User B manager" on
--   both INSERT and UPDATE, while still allowing "User A team + User A
--   manager", clearing (NULL), and switching between two of User A's
--   own managers — none of those touch a manager_id belonging to a
--   different user_id, so none of them are blocked.
-- * DELETE BEHAVIOR (spec section 5): `on delete set null` is the FK's
--   own job — no trigger is needed to null out manager_id when a
--   manager_library row is deleted, Postgres does this natively. This
--   migration does not touch manager_library's own RLS
--   (manager_library_delete_own from 0014) at all — a user can still
--   only delete their own manager, same as before; this migration only
--   adds what happens to team_library when that deletion occurs.
-- * HISTORICAL SAFETY (spec section 9): no column here references
--   matches/analysis_events/player_statistics/progress/snapshots/AI
--   Coach/tournament tables, and manager_id is a plain live reference
--   with no snapshot semantics — exactly what the spec calls out as
--   Phase 9's job, not this batch's. Editing or clearing a team's
--   manager_id here cannot touch any historical record, by
--   construction.
-- * NO MANAGER DATA DUPLICATION (spec section 7): team_library gains
--   only the `manager_id` foreign key — no manager name/ratings/image
--   are copied onto team_library. The canonical manager stays solely in
--   manager_library; a reader joins through manager_id to get its
--   fields, same "reference, never duplicate" rule team_members (0019)
--   already applies to player_library.

alter table public.team_library
  add column manager_id uuid references public.manager_library(id) on delete set null;

create index team_library_manager_id_idx on public.team_library(manager_id);

-- See "OWNERSHIP" design note above (layer 2 — trigger).
create or replace function public.check_team_library_manager_ownership()
returns trigger
language plpgsql
as $$
begin
  if new.manager_id is not null and not exists (
    select 1 from public.manager_library m
    where m.id = new.manager_id and m.user_id = new.user_id
  ) then
    raise exception 'team_library.manager_id % does not belong to the same user as team_library.user_id', new.manager_id;
  end if;
  return new;
end;
$$;

create trigger team_library_manager_ownership_check
  before insert or update on public.team_library
  for each row execute procedure public.check_team_library_manager_ownership();

-- ============================================================
-- RLS — recreate insert/update to also enforce manager_id ownership.
-- All of 0018's existing team_image_path clauses are preserved
-- verbatim; only the manager_id clause is new.
-- ============================================================
drop policy if exists "team_library_insert_own" on public.team_library;
create policy "team_library_insert_own" on public.team_library
  for insert with check (
    auth.uid() = user_id
    and (
      team_image_path is null
      or team_image_path like (auth.uid()::text || '/%')
    )
    and (
      manager_id is null
      or exists (
        select 1 from public.manager_library m
        where m.id = manager_id and m.user_id = auth.uid()
      )
    )
  );

drop policy if exists "team_library_update_own" on public.team_library;
create policy "team_library_update_own" on public.team_library
  for update using (auth.uid() = user_id)
  with check (
    auth.uid() = user_id
    and (
      team_image_path is null
      or team_image_path like (auth.uid()::text || '/%')
    )
    and (
      manager_id is null
      or exists (
        select 1 from public.manager_library m
        where m.id = manager_id and m.user_id = auth.uid()
      )
    )
  );

-- team_library_select_own / team_library_delete_own (0016) are
-- untouched — reading or deleting a team never depends on manager_id
-- ownership, same reasoning 0018 already documented for team_image_path.
