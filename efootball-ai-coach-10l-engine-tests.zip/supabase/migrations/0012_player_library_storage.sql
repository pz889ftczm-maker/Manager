-- Batch 6A-2 — Player Library: private storage + RLS for player-card images.
--
-- The `player-cards` bucket itself was originally only created in
-- supabase/seed.sql (same convention as
-- raw-uploads/processed-frames/match-videos/video-clips — see that
-- file); it is now also created, with file_size_limit/allowed_mime_types
-- hardening, by migration 0013_player_cards_bucket.sql, which is what
-- actually applies to a real project (seed.sql does not). This migration
-- adds only the storage.objects RLS policies, scoped to that bucket id,
-- mirroring the
-- `(storage.foldername(name))[1] = auth.uid()::text` ownership convention
-- from 0002_rls.sql.
--
-- Path convention: `{user_id}/{safe-random-filename}.{extension}` — built
-- server-authoritatively by buildSafePlayerCardStoragePath
-- (packages/shared/src/uploadValidation.ts), never from a user-supplied
-- filename, so there is no client-controlled path component beyond the
-- user's own uid prefix (which these policies independently enforce
-- regardless of what the client claims).
--
-- Deliberately THREE narrow policies (select/insert/delete), not one
-- `for all` like the existing raw-uploads/processed-frames policies —
-- there is no update policy. Object names are random and the upload path
-- always uses upsert:false, so an object is immutable once created; the
-- only way to "replace" a card image is delete-then-reupload (a new random
-- name). Omitting update closes off in-place overwrite at the RLS layer
-- too, not just by client convention.
create policy "storage_player_cards_owner_select"
  on storage.objects for select
  using (
    bucket_id = 'player-cards'
    and (storage.foldername(name))[1] = auth.uid()::text
  );

create policy "storage_player_cards_owner_insert"
  on storage.objects for insert
  with check (
    bucket_id = 'player-cards'
    and (storage.foldername(name))[1] = auth.uid()::text
  );

create policy "storage_player_cards_owner_delete"
  on storage.objects for delete
  using (
    bucket_id = 'player-cards'
    and (storage.foldername(name))[1] = auth.uid()::text
  );

-- No service-role bypass is exposed to the browser: these policies apply
-- to the authenticated role via the anon key + user JWT, same as every
-- other bucket in 0002_rls.sql. The service role (used only server-side,
-- e.g. by the worker) continues to bypass RLS by design, but nothing in
-- this batch grants it — or any browser code — a new capability.
