-- Batch 5 — Production upload, reliability & security hardening.
--
-- This migration:
--   1. Adds a 'queued' match_status value used as an atomic hand-off
--      sentinel by supabase/functions/analysis-enqueue (idempotent
--      enqueue — Part J) so two concurrent enqueue calls for the same
--      match cannot both win and create two worker jobs.
--   2. Tightens RLS so authenticated clients can only ever create rows in
--      their OWN initial/pending state; every "this succeeded" transition
--      (processed / complete / a real score / a real stat) can only be
--      written by the service-role worker — exactly the same shape as the
--      existing precedent for ai_coach_messages (0003) and video_clips
--      (0008), extended here to matches/media/analysis_events/
--      tactical_analysis/match_statistics/player_progress/players/
--      match_player_statistics/player_attributes. Verified by grep against
--      the actual apps/web + supabase/functions source (Batch 5 audit)
--      that nothing legitimate currently relies on a client-scoped
--      INSERT/UPDATE beyond what's preserved below — every one of those
--      tables is written only by apps/worker's service-role client, which
--      bypasses RLS by design and is completely unaffected by policy
--      removal.
--   3. Adds defense-in-depth ownership + path-safety checks, mirroring
--      migration 0006's check_match_player_statistics_ownership (Part F:
--      "do not assume direct user_id checks alone are sufficient when
--      ownership is relational").
--   4. Adds a minimal Postgres-backed rate limiter (Part O) — no new
--      external service, reuses the database the Edge Functions already
--      talk to.
--   5. Adds indexes that back the new abandoned-upload cleanup sweep
--      (apps/worker/src/cleanup.ts) and other production query patterns
--      (Part V).

-- ============================================================
-- 1. New match_status value — idempotent-enqueue sentinel (Part J)
-- ============================================================
-- Set by analysis-enqueue in the SAME atomic UPDATE that claims a match
-- for processing (uploading|error -> queued), so a duplicate/retried
-- enqueue request for the same match can't win a second time. The
-- worker's own first status write for each job type (processMatchVideo ->
-- 'optimizing', processScreenshot -> 'analyzing') supersedes this within
-- moments once the job actually starts, exactly like every other status
-- value already does — 'queued' only exists in the short window between
-- hand-off and the worker actually picking the job up.
alter type match_status add value if not exists 'queued';

-- ============================================================
-- 2. matches — client may only ever create the initial row
-- ============================================================
drop policy if exists "matches_insert_own" on public.matches;
create policy "matches_insert_own_initial_state"
  on public.matches
  for insert
  with check (
    auth.uid() = user_id
    and status = 'uploading'
    and overall_score is null
    and error_message is null
  );

-- Audit finding (Part R/I): no client-scoped UPDATE policy. Every status
-- transition, overall_score, and error_message is written by the worker
-- via the service-role client. Confirmed (grep) that no frontend code
-- updates `matches` directly today — Analyze.tsx only INSERTs it,
-- analysis-enqueue/clip-request/coach-chat only SELECT it. Without this
-- fix, any authenticated user could call the Supabase client directly and
-- set their OWN match to status='complete'/overall_score=100 with no
-- analysis ever having run — the exact "fake success state" Part R
-- prohibits. If a future feature needs client-side edits (e.g. renaming a
-- match title), add a narrowly-scoped policy/RPC for that column then,
-- rather than reopening this one.
drop policy if exists "matches_update_own" on public.matches;

-- ---------------- media ----------------
drop policy if exists "media_insert_own" on public.media;
create policy "media_insert_own_initial_state"
  on public.media
  for insert
  with check (
    auth.uid() = user_id
    and status = 'uploaded'
    and storage_reference is not null
    and storage_reference like (auth.uid()::text || '/%')
    and storage_reference not like '%..%'
    -- Matches the real invariant of the upload flow: a client-created row
    -- is always the raw upload. Video's raw upload is temporary (the
    -- worker later writes a SEPARATE is_temporary=false row once it has
    -- actually produced a playable asset — see persistProcessedVideoMedia
    -- in processMatchVideo.ts); screenshots are kept as-is. A client can
    -- therefore never mint its own "permanent, already processed" video
    -- row — closing that off not only via the status check above but at
    -- this invariant too.
    and is_temporary = (type = 'video')
  );

-- Same reasoning as matches above: no frontend code updates `media`
-- directly (Analyze.tsx only INSERTs it; useMatchVideo.ts only SELECTs)
-- — every later status transition (optimized/processed/failed/
-- deleted_temp) and every storage_reference change is the worker's job.
drop policy if exists "media_update_own" on public.media;

-- Table-level (role-agnostic) path-traversal guard — belt-and-suspenders
-- on top of the RLS check above, so even a future service-role bug can't
-- persist a `..`-containing path (Part D).
alter table public.media
  add constraint media_storage_reference_no_traversal
  check (storage_reference is null or storage_reference !~ '\.\.');

-- Defense-in-depth ownership check (Part F: "indirect access... do not
-- assume direct user_id checks alone are sufficient when ownership is
-- relational"). Mirrors check_match_player_statistics_ownership (0006).
-- RLS's media_insert_own only checks media.user_id = auth.uid(); nothing
-- previously stopped a client from pointing match_id at a DIFFERENT
-- match_id than the one they actually own (the foreign key only requires
-- the row to exist, not that it belongs to the same user).
create or replace function public.check_media_ownership()
returns trigger
language plpgsql
as $$
begin
  if not exists (select 1 from public.matches m where m.id = new.match_id and m.user_id = new.user_id) then
    raise exception 'media.user_id does not match matches.user_id for match %', new.match_id;
  end if;
  return new;
end;
$$;

create trigger media_ownership_check
  before insert or update on public.media
  for each row execute procedure public.check_media_ownership();

-- ============================================================
-- 3. Tables that are entirely worker-written after their parent
--    match/event exists — remove the now-unused client insert/update
--    policies (Part F/R). Confirmed via grep: apps/web and the Edge
--    Functions only ever SELECT from these tables; every write already
--    goes through apps/worker's service-role client (which bypasses RLS
--    and is therefore completely unaffected by removing these policies).
--    SELECT and (where they existed) DELETE policies are left exactly as
--    they were — a user reading or removing their OWN data is not a fake
--    success state, so there's no reason to touch those.
-- ============================================================
drop policy if exists "analysis_events_insert_own" on public.analysis_events;
drop policy if exists "analysis_events_update_own" on public.analysis_events;

drop policy if exists "tactical_analysis_insert_own" on public.tactical_analysis;

drop policy if exists "match_statistics_upsert_own" on public.match_statistics;
drop policy if exists "match_statistics_update_own" on public.match_statistics;

drop policy if exists "player_progress_upsert_own" on public.player_progress;
drop policy if exists "player_progress_update_own" on public.player_progress;

drop policy if exists "players_insert_own" on public.players;
drop policy if exists "players_update_own" on public.players;

drop policy if exists "match_player_statistics_insert_own" on public.match_player_statistics;
drop policy if exists "match_player_statistics_update_own" on public.match_player_statistics;

drop policy if exists "player_attributes_insert_own" on public.player_attributes;
drop policy if exists "player_attributes_update_own" on public.player_attributes;

-- ============================================================
-- 4. video_clips — same path-traversal belt-and-suspenders as media
-- ============================================================
alter table public.video_clips
  add constraint video_clips_storage_path_no_traversal
  check (storage_path is null or storage_path !~ '\.\.');

-- ============================================================
-- 5. Minimal Postgres-backed rate limiter (Part O)
-- ============================================================
-- Deliberately reuses the database every Edge Function already talks to,
-- rather than standing up a separate rate-limit service. One row per
-- request attempt, pruned opportunistically — cheap at this app's scale
-- and easy to reason about.
create table public.rate_limit_hits (
  id bigint generated always as identity primary key,
  user_id uuid not null references auth.users(id) on delete cascade,
  bucket text not null, -- e.g. 'analysis-enqueue', 'clip-request', 'coach-chat'
  created_at timestamptz not null default now()
);

create index rate_limit_hits_user_bucket_created_idx
  on public.rate_limit_hits(user_id, bucket, created_at desc);

alter table public.rate_limit_hits enable row level security;
-- Deliberately NO policies for any role: the only supported access path
-- is the SECURITY DEFINER function below (callable by the user-scoped
-- client with the caller's own JWT) or the service-role client, which
-- bypasses RLS entirely. No direct client SELECT/INSERT on this table.

create or replace function public.check_and_record_rate_limit(
  p_user_id uuid,
  p_bucket text,
  p_max_hits integer,
  p_window_seconds integer
) returns boolean
language plpgsql
security definer set search_path = public
as $$
declare
  v_count integer;
begin
  -- Best-effort GC of old rows for this bucket, piggybacked on every call
  -- rather than a separate scheduled job — cheap since it's indexed and
  -- bounded to a small multiple of the caller's own window.
  delete from public.rate_limit_hits
    where bucket = p_bucket
      and created_at < now() - make_interval(secs => p_window_seconds * 4);

  select count(*) into v_count
    from public.rate_limit_hits
    where user_id = p_user_id
      and bucket = p_bucket
      and created_at > now() - make_interval(secs => p_window_seconds);

  if v_count >= p_max_hits then
    return false;
  end if;

  insert into public.rate_limit_hits (user_id, bucket) values (p_user_id, p_bucket);
  return true;
end;
$$;

comment on function public.check_and_record_rate_limit is
  'Atomic sliding-window rate limiter (Part O). Returns true and records a hit if the caller is under p_max_hits within the trailing p_window_seconds for (p_user_id, p_bucket); returns false (and records nothing) once the limit is reached. SECURITY DEFINER so it is safely callable via the user-scoped client (caller''s own JWT) without granting table-level access to rate_limit_hits itself — callers can only ever check/record a hit for the p_user_id they pass, and every call site passes the id the Edge Function already resolved from auth.getUser(), never a client-supplied value.';

revoke all on function public.check_and_record_rate_limit(uuid, text, integer, integer) from public;
grant execute on function public.check_and_record_rate_limit(uuid, text, integer, integer) to authenticated, service_role;

-- ============================================================
-- 6. Abandoned-upload cleanup support (Part N)
-- ============================================================
-- media rows that never made it into a worker job (status still
-- 'uploaded' long after created_at) or matches that never got past
-- 'uploading'/'queued' need a cheap way to find candidates. Index
-- directly on (status, created_at) for the sweep query
-- apps/worker/src/cleanup.ts runs.
create index if not exists media_status_created_at_idx
  on public.media(status, created_at);
create index if not exists matches_status_created_at_idx
  on public.matches(status, created_at);

-- ============================================================
-- 7. Production query indexes (Part V) — only what's justified by an
--    actual existing query pattern in the app.
-- ============================================================
-- MatchReport.tsx / useMatchVideo.ts / clip-request all look up the
-- permanent video media row by (match_id, type, is_temporary) together;
-- the existing media_match_id_idx only covers match_id alone.
create index if not exists media_match_type_temp_idx
  on public.media(match_id, type, is_temporary);

-- useVideoClips.ts polls by id (already the primary key); this backs a
-- future/worker-side "find stuck processing clips" sweep filtering by
-- status, matching the same pattern as media_status_created_at_idx above.
create index if not exists video_clips_status_idx
  on public.video_clips(status);

-- ============================================================
-- 8. Storage bucket hardening (Part C/G) — enforced by Storage itself, on
--    top of the application-level checks in
--    supabase/functions/analysis-enqueue and apps/worker (defense-in-
--    depth, not a replacement for either — those two layers enforce the
--    TIGHTER 15MB image / 500MB video split; Storage's own
--    allowed_mime_types can only allowlist by type, not size-per-type, so
--    raw-uploads — shared by both screenshots and raw video, see
--    apps/worker/src/storage.ts's RAW_BUCKET — allows every supported
--    format at the more permissive 500MB ceiling here). Deliberately in a
--    migration rather than supabase/seed.sql (where the original bucket
--    INSERTs already live): seed.sql only runs on `supabase db reset` /
--    local dev, but this needs to actually apply to an existing/
--    production database (Part Q), which only migrations reliably do.
--    processed-frames/match-videos/video-clips are worker-written only —
--    the service-role client bypasses these limits by design; this exists
--    to constrain what an authenticated CLIENT can push directly into
--    raw-uploads, the only bucket app code ever uploads to from the
--    browser.
-- NOTE: file_size_limit/allowed_mime_types columns are only present on
-- storage.buckets in reasonably recent Supabase Storage versions. Like the
-- rest of this file, this migration runs as one transaction, so if this
-- statement errors on an older project (missing columns), the whole
-- migration rolls back — not just this block. If that happens, remove or
-- comment out this last statement and re-apply the migration; every other
-- change above does not depend on it. The application-level checks
-- (analysis-enqueue, the worker) remain the authoritative enforcement
-- either way, so this block is a bonus, not a dependency.
update storage.buckets
  set file_size_limit = 500 * 1024 * 1024,
      allowed_mime_types = array[
        'video/mp4', 'video/quicktime', 'video/webm',
        'image/jpeg', 'image/png', 'image/webp'
      ]
  where id = 'raw-uploads';
