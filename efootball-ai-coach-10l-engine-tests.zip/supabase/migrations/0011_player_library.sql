-- Batch 6A-1 — Player Library: database + RLS foundation only.
--
-- Adds a single new table for a user's personal, reusable eFootball player
-- card library. This is deliberately NOT the same thing as public.players
-- (migration 0006_player_statistics.sql): that table is AI-derived identity
-- inferred FROM match footage for performance-tracking purposes (is_self,
-- stats trends, etc.). public.player_library is the opposite direction —
-- reusable source data the user curates themselves (or, in a later batch,
-- extracts from a card screenshot), which does not yet feed into, and is
-- not derived from, any match analysis. The two are intentionally
-- unconnected: no foreign key exists between them (see HISTORICAL SAFETY
-- note below).
--
-- Design notes
-- ------------
-- * NULL-safety (spec's "IMPORTANT NULL RULE"): every descriptive/attribute
--   column is nullable. A library entry may be created with only a name,
--   only a card image, or partial attributes — nothing here is ever
--   defaulted to 0 or invented. This mirrors the same rule already applied
--   to match_player_statistics/player_attributes in 0006.
-- * `attributes` and `metadata` are JSONB, not fixed columns, per this
--   batch's explicit spec ("visible attributes as structured JSONB") —
--   unlike player_attributes (0006), which models a fixed, validated set of
--   match-analysis card fields. No fixed shape is enforced here since a
--   card's visible attributes vary by what's actually legible/known, and
--   inventing a rigid schema would risk exactly the fabrication the spec
--   prohibits. A future batch that adds AI card extraction can validate
--   into this JSONB shape without a schema migration.
-- * `player_card_image_path` stores a Storage object path/reference only —
--   never image bytes/base64 in Postgres — same convention as
--   media.storage_reference (0001/0009) and video_clips.storage_path
--   (0008/0009). No bucket is created and no upload path is wired in this
--   batch (explicitly out of scope) — the path-format constraints below
--   exist so that whichever future batch adds the actual upload already has
--   a schema that only accepts the `{user_id}/...` convention.
-- * Duplicate prevention: eFootball legitimately has multiple distinct
--   cards for the same named player (different rarity/version, different
--   overall, different position). A uniqueness rule on name alone would
--   block those legitimate variants, so the unique index below is on
--   (user_id, lower(name), position, overall) — this blocks only an exact
--   repeat add of what looks like the identical card, while still allowing
--   any distinct variant (spec: "avoid over-aggressive uniqueness"). It
--   applies only when name is set (mirrors players_user_name_uniq in 0006)
--   since an unnamed entry has nothing meaningful to deduplicate on.
-- * HISTORICAL SAFETY: no column here references matches/analysis_events/
--   players, and nothing in this migration adds a column FROM those tables
--   back to this one. A library entry can be freely edited or deleted
--   without touching any historical match record, by construction — there
--   is currently no path by which it could.
-- * DEMO DATA: no rows are inserted for this table anywhere (this
--   migration or supabase/seed.sql) — there is no demo player library.

-- ============================================================
-- PLAYER LIBRARY
-- ============================================================
create table public.player_library (
  id uuid primary key default gen_random_uuid(),
  user_id uuid not null references auth.users(id) on delete cascade,

  name text,
  position text, -- free-form role tag, e.g. 'CAM' — same convention as players.position (0006)
  overall integer check (overall >= 0),
  playstyle text, -- free-form; eFootball playstyles aren't enumerated here to avoid inventing/mismatching an authoritative list

  player_card_image_path text, -- Storage object path only, never image bytes; see path-format constraint below
  attributes jsonb, -- visible card attributes as read, e.g. { "offensive_awareness": 87, "speed": null, ... } — shape intentionally not fixed, see design notes
  metadata jsonb,   -- optional additional free-form metadata

  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now(),

  -- Belt-and-suspenders (mirrors media_storage_reference_no_traversal /
  -- video_clips_storage_path_no_traversal in 0009): even though this table
  -- is user-writable directly (not worker-only), enforce the `{user_id}/...`
  -- prefix and reject path traversal at the table level, not just in RLS
  -- below, so no future role/policy change can silently bypass it.
  constraint player_library_image_path_owned_prefix
    check (
      player_card_image_path is null
      or player_card_image_path like (user_id::text || '/%')
    ),
  constraint player_library_image_path_no_traversal
    check (player_card_image_path is null or player_card_image_path !~ '\.\.')
);

create index player_library_user_id_idx on public.player_library(user_id);

-- See "Duplicate prevention" design note above.
create unique index player_library_user_variant_uniq
  on public.player_library(user_id, lower(name), position, overall)
  where name is not null;

create or replace function public.touch_player_library_updated_at()
returns trigger
language plpgsql
as $$
begin
  new.updated_at := now();
  return new;
end;
$$;

create trigger player_library_touch_updated_at
  before update on public.player_library
  for each row execute procedure public.touch_player_library_updated_at();

-- ============================================================
-- RLS
-- ============================================================
alter table public.player_library enable row level security;

create policy "player_library_select_own" on public.player_library
  for select using (auth.uid() = user_id);

create policy "player_library_insert_own" on public.player_library
  for insert with check (
    auth.uid() = user_id
    and (
      player_card_image_path is null
      or player_card_image_path like (auth.uid()::text || '/%')
    )
  );

create policy "player_library_update_own" on public.player_library
  for update using (auth.uid() = user_id)
  with check (
    auth.uid() = user_id
    and (
      player_card_image_path is null
      or player_card_image_path like (auth.uid()::text || '/%')
    )
  );

create policy "player_library_delete_own" on public.player_library
  for delete using (auth.uid() = user_id);

-- No service-role bypass is exposed to the browser: these are the only
-- policies on this table, all scoped to auth.uid() = user_id, same as
-- players/player_progress/profiles. The service role (worker) can still
-- write this table server-side if a future batch needs it to, but no
-- browser-reachable path grants cross-user access.
