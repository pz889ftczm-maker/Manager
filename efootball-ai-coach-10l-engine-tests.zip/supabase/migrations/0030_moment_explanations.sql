-- Batch 10J-1 — Persistence layer for the existing 10H MomentExplanation.
-- Schema + RLS only. No worker/pipeline wiring, no AI calls, no new
-- FullMatchContext table (10I's FullMatchContext is reconstructed from
-- this table plus already-existing match/event/context data — see
-- packages/shared/src/fullMatchContext.ts's own
-- buildFullMatchContextFromPersistedMoments) — all deferred/out of
-- scope per this batch's own spec.
--
-- Design notes
-- ------------
-- * ONE ROW PER (match_id, event_id) (spec — "Persist one
--   MomentExplanation per (match_id, event_id)"): both columns are
--   `not null`, and moment_explanations_match_event_uniq below is the
--   real, load-bearing idempotency guarantee — same
--   UNIQUE-index-as-idempotency-key convention as
--   analysis_events_match_dedupe_key_uniq (0005) and
--   match_snapshots_match_team_uniq (0025).
-- * PRESERVE FIELDS EXACTLY (spec — "Preserve football_type,
--   explanation fields, confidence, and evidence/source references
--   exactly"): every column here is a direct, 1:1 copy of one field on
--   packages/shared/src/momentExplanation.ts's own MomentExplanation —
--   see that file for the full evidence-first derivation this table
--   never re-runs. `player`/`better_option`/`positions`/
--   `passing_lane`/`space` are stored as jsonb because each is itself a
--   full nested shape (TacticalPositionPlayerRef / DecisionOption /
--   TacticalPositionState / PassingLane / Space) already defined
--   in-full elsewhere in packages/shared/src — storing the whole
--   already-validated object verbatim (mirrors match_snapshots'
--   positions/tactical_instructions/manager_ratings jsonb columns,
--   0025) is how "preserve ... exactly" is actually satisfied, without
--   this migration re-declaring or flattening any of those shapes into
--   new columns of its own.
-- * NULL SAFETY (spec — "Nullable/unknown values remain NULL"): every
--   column except match_id/event_id/has_sufficient_evidence is
--   nullable, no default. Nothing here backfills or fabricates a value
--   MomentExplanation itself did not carry.
-- * IMMUTABLE HISTORICAL RECORDS (spec — "client SELECT only; no client
--   INSERT/UPDATE/DELETE"): exactly the same structural enforcement as
--   match_snapshots (0025) — RLS is enabled with only a SELECT policy
--   defined below; with no matching INSERT/UPDATE/DELETE policy,
--   Postgres denies all three outright for any role subject to RLS.
--   Actual persistence (a later, trusted server-side/worker write) is
--   explicitly out of scope for this batch ("worker/pipeline
--   integration") — the service role can still write here without any
--   policy change, since RLS is not forced for that role.
-- * OWNERSHIP + EVENT-BELONGS-TO-MATCH (spec — "Enforce match/event
--   ownership and event belongs to match"): moment_explanations has no
--   direct user_id column (mirrors tactical_analysis, 0001/0002 —
--   ownership is derived through a parent row, never duplicated as its
--   own column, when the table already carries a foreign key that can
--   resolve it). The SELECT policy below derives ownership through
--   match_id -> matches.user_id directly (a one-hop join, same shape
--   as analysis_events_select_own). A malicious/buggy write with a
--   mismatched (match_id, event_id) pair — an event_id that doesn't
--   actually belong to match_id — is rejected independently of RLS by
--   check_moment_explanations_event_match, a BEFORE INSERT OR UPDATE
--   trigger (same "defense-in-depth, still applies even under a
--   service-role write that bypasses RLS entirely" reasoning as
--   check_match_snapshots_ownership, 0025).
-- * IDEMPOTENCY (spec — "Idempotency via UNIQUE (match_id, event_id)"):
--   moment_explanations_match_event_uniq below. A future worker write
--   path uses this exact constraint as its own upsert onConflict target
--   (same convention as analysis_events'
--   ON CONFLICT (match_id, dedupe_key), migration 0005) — not
--   implemented here (worker/pipeline integration is out of scope for
--   10J-1).
-- * JSONB SHAPE CHECKS (same convention as match_snapshots, 0025):
--   player/better_option/positions/passing_lane/space, when present,
--   must each be a jsonb object (never a bare scalar/array) — these
--   checks only constrain the shape of a value that IS present; every
--   one of the five stays fully nullable per the NULL SAFETY note
--   above.
-- * football_type IS A PLAIN text COLUMN, NOT A NEW ENUM TYPE: mirrors
--   matches.football_type's own convention (0029) — a CHECK constraint
--   allowing NULL or one of the two known values, not a Postgres enum.
-- * INDEXES: match_id and event_id each get their own plain index (in
--   addition to the composite unique index) for "all moment
--   explanations for this match" / "the moment explanation for this
--   event" lookups — same reasoning as match_snapshots' own separate
--   match_id index alongside its partial unique index (0025).
-- * NO DEMO DATA: no rows are inserted anywhere (this migration or
--   supabase/seed.sql).
-- * OUT OF SCOPE for this migration (per spec): worker/pipeline
--   integration (no code here ever calls INSERT on this table), AI
--   calls, 10J-2+, 10K+, any unrelated refactor. This migration adds
--   exactly one new table plus its supporting indexes/RLS/trigger.

create table public.moment_explanations (
  id uuid primary key default gen_random_uuid(),
  match_id uuid not null references public.matches(id) on delete cascade,
  event_id uuid not null references public.analysis_events(id) on delete cascade,

  -- Match-level attribute, copied verbatim from MomentExplanation.
  -- football_type — never independently supplied/re-derived here. See
  -- "football_type IS A PLAIN text COLUMN" design note above.
  football_type text,

  timestamp_seconds numeric(8,2),

  -- TacticalPositionPlayerRef, verbatim — see design notes above.
  player jsonb,

  -- WHAT/WHY happened — MomentExplanation's own what_happened/
  -- why_it_happened, verbatim.
  what_happened text,
  why_it_happened text[],

  -- DecisionOption, verbatim — populated only when MomentExplanation's
  -- own evidence gate already confirmed one (see momentExplanation.ts).
  -- This table performs no evidence evaluation of its own.
  better_option jsonb,
  why_better text[],
  actionable_improvement text,

  confidence numeric(5,2),

  -- De-duplicated union MomentExplanation itself already computed —
  -- never recomputed here.
  evidence text[],

  has_sufficient_evidence boolean not null,

  -- TacticalPositionState / PassingLane / Space, verbatim — see design
  -- notes above.
  positions jsonb,
  passing_lane jsonb,
  space jsonb,

  created_at timestamptz not null default now(),

  constraint moment_explanations_football_type_valid
    check (football_type is null or football_type in ('efootball', 'real_football')),
  constraint moment_explanations_confidence_valid
    check (confidence is null or confidence between 0 and 100),

  -- See "JSONB SHAPE CHECKS" design note above.
  constraint moment_explanations_player_shape_valid
    check (player is null or jsonb_typeof(player) = 'object'),
  constraint moment_explanations_better_option_shape_valid
    check (better_option is null or jsonb_typeof(better_option) = 'object'),
  constraint moment_explanations_positions_shape_valid
    check (positions is null or jsonb_typeof(positions) = 'object'),
  constraint moment_explanations_passing_lane_shape_valid
    check (passing_lane is null or jsonb_typeof(passing_lane) = 'object'),
  constraint moment_explanations_space_shape_valid
    check (space is null or jsonb_typeof(space) = 'object')
);

-- See "IDEMPOTENCY" design note above.
create unique index moment_explanations_match_event_uniq
  on public.moment_explanations(match_id, event_id);

-- See "INDEXES" design note above.
create index moment_explanations_match_id_idx on public.moment_explanations(match_id);
create index moment_explanations_event_id_idx on public.moment_explanations(event_id);

-- See "OWNERSHIP + EVENT-BELONGS-TO-MATCH" design note above.
create or replace function public.check_moment_explanations_event_match()
returns trigger
language plpgsql
as $$
begin
  if not exists (
    select 1
    from public.analysis_events e
    where e.id = new.event_id
      and e.match_id = new.match_id
  ) then
    raise exception 'moment_explanations: event % does not belong to match %', new.event_id, new.match_id;
  end if;
  return new;
end;
$$;

create trigger moment_explanations_event_match_check
  before insert or update on public.moment_explanations
  for each row execute procedure public.check_moment_explanations_event_match();

-- ============================================================
-- RLS
-- ============================================================
alter table public.moment_explanations enable row level security;

-- SELECT: ownership derives through match_id -> matches.user_id (same
-- one-hop-join shape as analysis_events_select_own, 0002) — see
-- "OWNERSHIP + EVENT-BELONGS-TO-MATCH" design note above.
create policy "moment_explanations_select_own" on public.moment_explanations
  for select using (
    exists (
      select 1 from public.matches m
      where m.id = match_id and m.user_id = auth.uid()
    )
  );

-- See "IMMUTABLE HISTORICAL RECORDS" design note above: deliberately no
-- INSERT/UPDATE/DELETE policy is created for this table. With RLS
-- enabled and no matching policy, every non-service-role write is
-- denied outright.
