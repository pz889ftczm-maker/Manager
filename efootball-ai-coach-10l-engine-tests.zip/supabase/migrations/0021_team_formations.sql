-- Batch 8A — Team Formation data model ONLY: schema + RLS. No Formation
-- UI, no player assignment, no starting XI/bench, no presets, no
-- historical snapshots — all of that is explicitly out of scope for this
-- batch and deferred to 8B/Phase 9 per the spec.
--
-- Design notes
-- ------------
-- * NO user_id COLUMN (explicit spec requirement, same reasoning as
--   team_members/0019): ownership is derived through a single hop —
--   team_formations.team_id -> team_library.user_id. Unlike
--   team_members (0019), this table only has ONE foreign key to an
--   owned table (team_library), so there is no second independent
--   owner to reconcile against — RLS's own `using`/`with check`
--   clauses below (each just one `exists (... team_library ...
--   user_id = auth.uid())`) are already the complete ownership check.
--   A separate ownership-consistency trigger (the pattern
--   team_members/0019 uses to reconcile TWO independent FKs) would
--   only restate that same single condition here, so none is added.
-- * NO PLAYER ASSIGNMENT (spec sections 3/11 — explicit, repeated):
--   `positions` stores formation LAYOUT only — stable slot
--   identifiers/roles and optional normalized (0..1) layout
--   coordinates, never a player_id, player name, or any other
--   Player Library data. This is enforced at the application layer
--   (packages/shared/src/teamFormations.ts's validateTeamFormationInput,
--   which rejects a `player_id` key on any position entry) rather than
--   as a database CHECK constraint — a CHECK that had to parse
--   arbitrary nested jsonb shapes (object-map OR array, per spec
--   section 3's "extensible" requirement) to hunt for a forbidden key
--   would itself become the kind of over-constraining, brittle
--   structural rule the spec asks this batch to avoid. The database
--   constraint below only checks the outermost shape (object or array,
--   never null/scalar) — see "POSITIONS SHAPE" below.
-- * POSITIONS SHAPE: `positions` is `not null` jsonb, with a single
--   check that it's an object or an array (`jsonb_typeof(positions) in
--   ('object','array')`) — spec section 3 asks only for "positions is
--   an object/array of valid position definitions", not a fixed
--   internal schema, so nothing about the shape of individual entries
--   (id/role/x/y, or a role-keyed map) is enforced here at the database
--   layer; that deeper (still deliberately loose/extensible) shape
--   check lives in teamFormations.ts instead, where it can evolve
--   without a migration.
-- * TACTICAL_INSTRUCTIONS: nullable jsonb. When present it must be a
--   jsonb *object* (`jsonb_typeof(...) = 'object'`) — an extensible
--   key/value bag rather than nothing at all, but with zero
--   eFootball-specific keys required or even suggested anywhere in
--   this migration (spec section 4 — "do NOT make this
--   eFootball-specific"). A bare scalar/array wouldn't make sense as an
--   "instructions" bag, so that much shape is rejected; nothing else
--   about its keys is.
-- * DUPLICATE PREVENTION: `unique (team_id, lower(name))`, named
--   explicitly (team_formations_team_name_uniq) so application code can
--   recognize this exact violation via isUniqueViolation
--   (playerLibrary.ts), same convention as
--   team_library_user_name_uniq/team_members_team_player_uniq. This
--   allows the same formation name across different teams (and
--   different users) while preventing two same-named formations on one
--   team (spec section 7).
-- * INDEXES (spec section 8 — "if the uniqueness constraint already
--   creates an appropriate index, do not duplicate it unnecessarily"):
--   the unique index on (team_id, lower(name)) already has team_id as
--   its leading column, so it already serves team_id-only lookups
--   efficiently — no separate plain `team_id` index is added. A
--   separate `updated_at` index IS added (spec asks for it explicitly
--   and nothing else already covers it).
-- * HISTORICAL SAFETY (spec section 10, repeated in section 11): no
--   column here references matches/analysis_events/player_statistics/
--   player_progress/snapshots/tournament_results/AI Coach, and nothing
--   in this migration adds a column FROM those tables back to this
--   one. team_formations represents the CURRENT formation only, freely
--   editable without touching any historical record, by construction.
--   Historical formation snapshots are explicitly deferred to Phase 9.
-- * NO player assignment tables of any kind (team_formation_players,
--   starting XI, bench) are created here — those belong to Batch 8B
--   per spec sections 2/11, and are not created by this migration.
-- * DEMO DATA: no rows are inserted for this table anywhere (this
--   migration or supabase/seed.sql) — there is no demo/sample formation.
-- * Out of scope for this batch (per spec): Formation UI, Formation
--   page changes, drag-and-drop, save/load UI, player assignment,
--   starting XI/bench, formation presets, historical snapshots, any
--   change to AI Coach/Football Analysis/Team Library UI. This
--   migration adds schema + RLS only.

-- ============================================================
-- TEAM FORMATIONS
-- ============================================================
create table public.team_formations (
  id uuid primary key default gen_random_uuid(),
  team_id uuid not null references public.team_library(id) on delete cascade,

  name text not null,
  formation_code text not null,
  positions jsonb not null,
  tactical_instructions jsonb,

  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now(),

  -- See "DUPLICATE PREVENTION" design note above — named so
  -- application code can recognize this exact violation.
  constraint team_formations_name_not_blank
    check (btrim(name) <> ''),

  constraint team_formations_formation_code_not_blank
    check (btrim(formation_code) <> ''),

  -- See "POSITIONS SHAPE" design note above.
  constraint team_formations_positions_shape_valid
    check (jsonb_typeof(positions) in ('object', 'array')),

  -- See "TACTICAL_INSTRUCTIONS" design note above.
  constraint team_formations_tactical_instructions_shape_valid
    check (tactical_instructions is null or jsonb_typeof(tactical_instructions) = 'object')
);

-- See "DUPLICATE PREVENTION" design note above.
create unique index team_formations_team_name_uniq
  on public.team_formations(team_id, lower(name));

-- See "INDEXES" design note above — team_id is intentionally NOT
-- duplicated as a standalone index here; the unique index above already
-- serves that.
create index team_formations_updated_at_idx on public.team_formations(updated_at);

-- Same per-table trigger convention as touch_team_library_updated_at
-- (0016) / touch_team_members_updated_at (0019).
create or replace function public.touch_team_formations_updated_at()
returns trigger
language plpgsql
as $$
begin
  new.updated_at := now();
  return new;
end;
$$;

create trigger team_formations_touch_updated_at
  before update on public.team_formations
  for each row execute procedure public.touch_team_formations_updated_at();

-- ============================================================
-- RLS
-- ============================================================
alter table public.team_formations enable row level security;

-- SELECT: only formations belonging to one of the caller's own teams
-- are visible (spec section 5 — "Clients must not be able to access
-- another user's formations").
create policy "team_formations_select_own" on public.team_formations
  for select using (
    exists (
      select 1 from public.team_library t
      where t.id = team_id and t.user_id = auth.uid()
    )
  );

-- INSERT: the referenced team must belong to the caller. There is no
-- user_id column on this table to additionally check — ownership is
-- entirely this one condition (spec section 5 — "Ownership must be
-- derived through team_formations.team_id -> team_library.user_id").
create policy "team_formations_insert_own" on public.team_formations
  for insert with check (
    exists (
      select 1 from public.team_library t
      where t.id = team_id and t.user_id = auth.uid()
    )
  );

-- UPDATE: same ownership condition checked on both the pre-update row
-- (using) and the post-update row (with check) — so a caller can't
-- repoint an owned formation's team_id at someone else's team either.
create policy "team_formations_update_own" on public.team_formations
  for update using (
    exists (
      select 1 from public.team_library t
      where t.id = team_id and t.user_id = auth.uid()
    )
  )
  with check (
    exists (
      select 1 from public.team_library t
      where t.id = team_id and t.user_id = auth.uid()
    )
  );

-- DELETE: same ownership condition.
create policy "team_formations_delete_own" on public.team_formations
  for delete using (
    exists (
      select 1 from public.team_library t
      where t.id = team_id and t.user_id = auth.uid()
    )
  );

-- No service-role bypass is exposed to the browser: these are the only
-- policies on this table, all scoped to auth.uid() via team_library
-- ownership. The service role (worker) can still write this table
-- server-side if a future batch needs it to, but no browser-reachable
-- path grants cross-user access.
