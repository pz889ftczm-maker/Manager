-- Batch 3.5 — real individual player statistics + evidence model.
--
-- Adds:
--   players                    (stable player identity per user)
--   match_player_statistics    (per-match, per-player performance numbers)
--   player_attributes          (player card attributes — NOT match performance)
--   analysis_events.player_id  (links a decision event to the player it belongs to)
--   analysis_events.statistics_evidence (which specific stat fields backed the finding)
--
-- Design notes
-- ------------
-- * eFootball statistics screenshots almost always show the human user's
--   own controlled-player performance; teammate/opponent breakdowns are
--   rarer but the schema supports them (spec section 2: "must support
--   multiple players in a match if the source provides them").
-- * Player identity persists across matches so trends are possible
--   (spec section 16). Identity is inherently fuzzy from a screenshot —
--   there's no stable external id — so:
--     - a named player is deduplicated per user by lower(name)
--     - the user's own ("self") player, when the source gives no name,
--       collapses to a single canonical per-user row instead of a new
--       row every match. If a name for the self player is discovered
--       later, it's written onto that same row (see resolvePlayerId in
--       apps/worker/src/playerStatistics.ts) rather than creating a
--       second identity.
-- * Every numeric stat column is NULLABLE and stores NULL, never a
--   fabricated value, when the source doesn't provide it (spec section 3/6).
-- * source + confidence + media_id + extraction_metadata trace every stat
--   row back to the evidence that produced it (spec section 5).
-- * is_valid / validation_errors record the outcome of semantic
--   validation (spec section 7) without silently discarding the whole
--   record — invalid individual fields are nulled by the caller before
--   insert, and the row is flagged rather than rejected outright when at
--   least some fields are still usable.

create type statistics_source as enum ('screenshot', 'structured_data', 'ai_confirmed', 'unavailable');

-- ============================================================
-- PLAYERS
-- ============================================================
create table public.players (
  id uuid primary key default gen_random_uuid(),
  user_id uuid not null references auth.users(id) on delete cascade,
  name text,
  is_self boolean not null default false, -- true = the human user's own controlled player
  position text, -- last-known role tag, e.g. 'CAM' — informational only, not authoritative
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now()
);

create index players_user_id_idx on public.players(user_id);
-- Named players are deduplicated per user (case-insensitive).
create unique index players_user_name_uniq on public.players(user_id, lower(name)) where name is not null;
-- Exactly one canonical "self, name unknown" row per user, so repeated
-- nameless self-detections reuse it instead of multiplying identities.
create unique index players_user_self_unnamed_uniq on public.players(user_id) where is_self and name is null;

-- ============================================================
-- MATCH PLAYER STATISTICS (spec section 3 — real per-match performance)
-- ============================================================
create table public.match_player_statistics (
  id uuid primary key default gen_random_uuid(),
  user_id uuid not null references auth.users(id) on delete cascade,
  match_id uuid not null references public.matches(id) on delete cascade,
  player_id uuid not null references public.players(id) on delete cascade,
  media_id uuid references public.media(id) on delete set null,

  source statistics_source not null,
  confidence numeric(5,2) check (confidence between 0 and 100),
  extraction_metadata jsonb, -- e.g. { model, promptVersion, rawFieldLabelsSeen }

  -- PASSING
  passes_attempted integer check (passes_attempted >= 0),
  passes_completed integer check (passes_completed >= 0),
  pass_completion_percentage numeric(5,2) check (pass_completion_percentage between 0 and 100),
  key_passes integer check (key_passes >= 0),
  through_passes integer check (through_passes >= 0),
  crosses integer check (crosses >= 0),
  progressive_passes integer check (progressive_passes >= 0),
  forward_passes integer check (forward_passes >= 0),
  backward_passes integer check (backward_passes >= 0),
  long_passes integer check (long_passes >= 0),
  short_passes integer check (short_passes >= 0),

  -- DRIBBLING / POSSESSION
  dribbles_attempted integer check (dribbles_attempted >= 0),
  successful_dribbles integer check (successful_dribbles >= 0),
  dribble_success_percentage numeric(5,2) check (dribble_success_percentage between 0 and 100),
  ball_control integer check (ball_control >= 0),
  tight_possession integer check (tight_possession >= 0),
  ball_retention integer check (ball_retention >= 0),
  possession_losses integer check (possession_losses >= 0),
  progressive_carries integer check (progressive_carries >= 0),

  -- DEFENDING
  tackles integer check (tackles >= 0),
  successful_tackles integer check (successful_tackles >= 0),
  interceptions integer check (interceptions >= 0),
  clearances integer check (clearances >= 0),
  blocks integer check (blocks >= 0),
  defensive_recoveries integer check (defensive_recoveries >= 0),
  defensive_actions integer check (defensive_actions >= 0),
  pressures integer check (pressures >= 0),

  -- DUELS
  total_duels integer check (total_duels >= 0),
  ground_duels integer check (ground_duels >= 0),
  ground_duels_won integer check (ground_duels_won >= 0),
  aerial_duels integer check (aerial_duels >= 0),
  aerial_duels_won integer check (aerial_duels_won >= 0),
  physical_challenges integer check (physical_challenges >= 0),
  duel_win_percentage numeric(5,2) check (duel_win_percentage between 0 and 100),

  -- ATTACK
  shots integer check (shots >= 0),
  shots_on_target integer check (shots_on_target >= 0),
  goals integer check (goals >= 0),
  assists integer check (assists >= 0),
  chances_created integer check (chances_created >= 0),
  touches_attacking_third integer check (touches_attacking_third >= 0),
  progressive_actions integer check (progressive_actions >= 0),

  -- GOALKEEPING
  saves integer check (saves >= 0),
  save_percentage numeric(5,2) check (save_percentage between 0 and 100),
  claims integer check (claims >= 0),
  punches integer check (punches >= 0),
  sweeper_actions integer check (sweeper_actions >= 0),
  goalkeeper_distribution integer check (goalkeeper_distribution >= 0),

  -- DISCIPLINE
  fouls integer check (fouls >= 0),
  yellow_cards integer check (yellow_cards >= 0),
  red_cards integer check (red_cards >= 0),
  offsides integer check (offsides >= 0),

  is_valid boolean not null default true,
  validation_errors text[] not null default '{}',

  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now(),

  -- One statistics record per (match, player, source) — a retry
  -- re-extracts the same screenshot and should upsert, not duplicate.
  unique (match_id, player_id, source)
);

create index match_player_statistics_match_id_idx on public.match_player_statistics(match_id);
create index match_player_statistics_player_id_idx on public.match_player_statistics(player_id);
create index match_player_statistics_user_id_idx on public.match_player_statistics(user_id);

-- Defense-in-depth (spec section 22: "do not trust client-provided
-- user_id"): even though only the service-role worker ever writes this
-- table, enforce that user_id actually matches the parent match and
-- player's owner, so a bug elsewhere in the worker can't silently write
-- statistics that are attributed to, or readable by, the wrong user.
create or replace function public.check_match_player_statistics_ownership()
returns trigger
language plpgsql
as $$
begin
  if not exists (select 1 from public.matches m where m.id = new.match_id and m.user_id = new.user_id) then
    raise exception 'match_player_statistics.user_id does not match matches.user_id for match %', new.match_id;
  end if;
  if not exists (select 1 from public.players p where p.id = new.player_id and p.user_id = new.user_id) then
    raise exception 'match_player_statistics.user_id does not match players.user_id for player %', new.player_id;
  end if;
  new.updated_at := now();
  return new;
end;
$$;

create trigger match_player_statistics_ownership_check
  before insert or update on public.match_player_statistics
  for each row execute procedure public.check_match_player_statistics_ownership();

-- ============================================================
-- PLAYER ATTRIBUTES (spec section 4 — card attributes, NOT performance)
-- ============================================================
create table public.player_attributes (
  id uuid primary key default gen_random_uuid(),
  user_id uuid not null references auth.users(id) on delete cascade,
  player_id uuid not null references public.players(id) on delete cascade,
  media_id uuid references public.media(id) on delete set null,
  source statistics_source not null,
  confidence numeric(5,2) check (confidence between 0 and 100),

  speed integer check (speed between 0 and 99),
  acceleration integer check (acceleration between 0 and 99),
  ball_control integer check (ball_control between 0 and 99),
  dribbling integer check (dribbling between 0 and 99),
  tight_possession integer check (tight_possession between 0 and 99),
  low_pass integer check (low_pass between 0 and 99),
  lofted_pass integer check (lofted_pass between 0 and 99),
  defensive_awareness integer check (defensive_awareness between 0 and 99),
  tackling integer check (tackling between 0 and 99),
  aggression integer check (aggression between 0 and 99),
  physical_contact integer check (physical_contact between 0 and 99),
  balance integer check (balance between 0 and 99),
  jump integer check (jump between 0 and 99),
  heading integer check (heading between 0 and 99),
  finishing integer check (finishing between 0 and 99),
  kicking_power integer check (kicking_power between 0 and 99),

  -- Goalkeeper attributes — only populated for a keeper's card.
  gk_awareness integer check (gk_awareness between 0 and 99),
  gk_catching integer check (gk_catching between 0 and 99),
  gk_parrying integer check (gk_parrying between 0 and 99),
  gk_reflexes integer check (gk_reflexes between 0 and 99),
  gk_coverage integer check (gk_coverage between 0 and 99),

  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now(),

  unique (player_id, source)
);

create index player_attributes_player_id_idx on public.player_attributes(player_id);
create index player_attributes_user_id_idx on public.player_attributes(user_id);

create or replace function public.check_player_attributes_ownership()
returns trigger
language plpgsql
as $$
begin
  if not exists (select 1 from public.players p where p.id = new.player_id and p.user_id = new.user_id) then
    raise exception 'player_attributes.user_id does not match players.user_id for player %', new.player_id;
  end if;
  new.updated_at := now();
  return new;
end;
$$;

create trigger player_attributes_ownership_check
  before insert or update on public.player_attributes
  for each row execute procedure public.check_player_attributes_ownership();

create or replace function public.touch_players_updated_at()
returns trigger
language plpgsql
as $$
begin
  new.updated_at := now();
  return new;
end;
$$;

create trigger players_touch_updated_at
  before update on public.players
  for each row execute procedure public.touch_players_updated_at();

-- ============================================================
-- ANALYSIS EVENTS: link to the player + the statistics evidence used
-- ============================================================
alter table public.analysis_events
  add column if not exists player_id uuid references public.players(id) on delete set null,
  add column if not exists statistics_evidence jsonb;
  -- statistics_evidence shape: array of short strings citing the exact
  -- stored numbers that back this finding, e.g.
  -- ["pass_completion_percentage: 87% (26/30)", "3 of 4 failed passes were forward_passes"]
  -- Populated only when a real match_player_statistics row supports the
  -- claim (spec section 20) — never fabricated to make an event look
  -- better-evidenced than it is.

create index if not exists analysis_events_player_id_idx on public.analysis_events(player_id);

comment on column public.analysis_events.player_id is
  'Which player this decision belongs to. Nullable: older events and events where the source screenshot could not be tied to a specific identified player have no player_id — they remain valid match-level evidence on their own (spec section 8).';
comment on column public.analysis_events.statistics_evidence is
  'Array of short strings citing the specific match_player_statistics fields that back this event''s description/reasoning. Null/empty when no stored statistic directly supports the finding.';

-- ============================================================
-- RLS
-- ============================================================
alter table public.players enable row level security;
alter table public.match_player_statistics enable row level security;
alter table public.player_attributes enable row level security;

create policy "players_select_own" on public.players
  for select using (auth.uid() = user_id);
create policy "players_insert_own" on public.players
  for insert with check (auth.uid() = user_id);
create policy "players_update_own" on public.players
  for update using (auth.uid() = user_id);
create policy "players_delete_own" on public.players
  for delete using (auth.uid() = user_id);

create policy "match_player_statistics_select_own" on public.match_player_statistics
  for select using (auth.uid() = user_id);
create policy "match_player_statistics_insert_own" on public.match_player_statistics
  for insert with check (auth.uid() = user_id);
create policy "match_player_statistics_update_own" on public.match_player_statistics
  for update using (auth.uid() = user_id);
create policy "match_player_statistics_delete_own" on public.match_player_statistics
  for delete using (auth.uid() = user_id);

create policy "player_attributes_select_own" on public.player_attributes
  for select using (auth.uid() = user_id);
create policy "player_attributes_insert_own" on public.player_attributes
  for insert with check (auth.uid() = user_id);
create policy "player_attributes_update_own" on public.player_attributes
  for update using (auth.uid() = user_id);
create policy "player_attributes_delete_own" on public.player_attributes
  for delete using (auth.uid() = user_id);

-- analysis_events / tactical_analysis RLS is untouched — still scoped
-- through matches.user_id per 0002_rls.sql; the new player_id column
-- doesn't change that policy's correctness since it's select-only exposure
-- of a column, not a new access path.
