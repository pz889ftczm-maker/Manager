-- Batch 6A-2 (follow-up) — create the `player-cards` storage bucket via
-- migration instead of relying on supabase/seed.sql for it.
--
-- Why: seed.sql only runs on `supabase db reset` (local dev) or a manual
-- psql re-run — it is NOT applied by `supabase db push` against a real
-- project, so a bucket that exists only in seed.sql never gets created in
-- production. 0012_player_library_storage.sql above added the
-- storage.objects RLS policies scoped to bucket_id = 'player-cards' but
-- assumed the bucket itself already existed; this migration removes that
-- assumption by creating the row here too, using the same
-- `insert ... on conflict (id) do nothing` pattern seed.sql already uses,
-- so it's a no-op (not an error, not a duplicate) whether or not the
-- bucket was already created by a prior seed.sql run.
--
-- seed.sql keeps its own player-cards insert as-is: on `supabase db
-- reset`, migrations run before seed.sql, so by the time seed.sql's
-- insert runs this row already exists and that insert is simply a no-op
-- (on conflict do nothing) — no duplicate row, no conflicting config.
insert into storage.buckets (id, name, public)
values ('player-cards', 'player-cards', false)
on conflict (id) do nothing;

-- Same file_size_limit / allowed_mime_types hardening already applied to
-- the raw-uploads bucket in 0009_production_hardening.sql (see that
-- migration's comment for the full caveat this repeats: these columns
-- only exist on reasonably recent Supabase Storage versions, this runs
-- in the same transaction as the insert above so an error here rolls
-- back the whole migration, and if that happens on an older project this
-- statement can be removed/commented out and the migration re-applied —
-- nothing else in this file depends on it).
--
-- A separate UPDATE by id (rather than folding limits into the INSERT
-- above) so this also takes effect for a player-cards row that already
-- exists from a prior seed.sql-only creation, which never set these
-- columns. 15MB matches DEFAULT_MAX_IMAGE_MB / VITE_MAX_IMAGE_UPLOAD_MB
-- (packages/shared/src/uploadValidation.ts, .env.example) — the same
-- image-size convention used everywhere else in this repo, not a new
-- number invented for this bucket.
--
-- This is additional, independent, server-side enforcement layered on
-- top of — not a replacement for — the existing client-side
-- validateUpload/sniffFileType magic-byte check in
-- apps/web/src/lib/playerCardStorage.ts. That browser-side check is not
-- server-authoritative on its own (a caller could bypass or tamper with
-- it); constraining format and size at the Storage bucket level is what
-- makes the constraint hold regardless.
--
-- SECURITY FIX (post-6A-3): also force `public = false` here, not just
-- file_size_limit/allowed_mime_types. The INSERT above already sets
-- public=false on first creation, but `on conflict (id) do nothing` means
-- that INSERT is a no-op whenever a `player-cards` row already exists —
-- including one that was somehow created/left as public=true (e.g. a
-- stale seed.sql run predating this migration, or a manual dashboard
-- change). Without this, such a bucket would keep serving object reads
-- unauthenticated despite every RLS policy in
-- 0012_player_library_storage.sql, since Storage never even consults
-- object-level RLS for a bucket flagged public. Folding `public = false`
-- into this same UPDATE ensures the bucket is forced back to private on
-- every migration run, regardless of how it got into a public state.
update storage.buckets
  set public = false,
      file_size_limit = 15 * 1024 * 1024,
      allowed_mime_types = array['image/jpeg', 'image/png', 'image/webp']
  where id = 'player-cards';
