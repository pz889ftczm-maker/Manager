# eFootball AI Coach — Monorepo Skeleton

A working full-stack scaffold for an AI football analyst: upload eFootball
screenshots or full-match video, get decision-by-decision coaching with
tactical diagrams, track improvement over time.

This is a **real, buildable skeleton**, not a UI mockup — the auth flow,
database, RLS, upload pipeline, and AI calls are actually wired together.
What's intentionally left as a documented stub is called out below so you
know exactly what to finish before this is production-ready.

## Layout

```
apps/web      React + TS + Tailwind frontend (Vite)
apps/worker   Video processing pipeline (ffmpeg) + BullMQ job workers
packages/shared  TypeScript types mirroring the DB schema
packages/ai   AI provider abstraction (Anthropic implementation included)
supabase      DB schema, RLS policies, seed data, Edge Functions
```

## Quickstart (local dev)

```bash
cp .env.example .env
npm install

# 1. Postgres + Auth + Storage + Edge Functions
supabase start          # applies supabase/migrations + supabase/seed.sql

# 2. Redis + video worker
docker compose up redis worker

# 3. Frontend
npm run dev:web         # http://localhost:5173
```

Fill in `.env` with the values `supabase start` prints out (anon key,
service role key, API URL) plus your `ANTHROPIC_API_KEY`.

Deploy the Edge Functions with:
```bash
supabase functions deploy analysis-enqueue
supabase functions deploy coach-chat
supabase secrets set ANTHROPIC_API_KEY=... WORKER_INTERNAL_URL=... WORKER_INTERNAL_SECRET=...
```

## What's real vs. stubbed

**Fully wired:**
- Email/password auth, protected routes, session persistence
- Full DB schema + RLS (every table scoped to `auth.uid()`, storage
  bucket policies keyed by `{user_id}/...` path prefix)
- Screenshot upload → Edge Function → worker job → real Anthropic vision
  call → persisted events + tactical diagrams → Match Report UI
- Video upload → ffmpeg compression → frame sampling → context-window
  extraction around candidate timestamps → real Anthropic call per window
  → timeline + tactical visualization
- AI Coach chat grounded in the user's actual stored matches/events
- Demo data seeded per-user, clearly labeled, never mixed with real data
- Temp video cleanup only after successful processing; preserved on
  failure for retry

**Documented stubs — finish these before shipping:**
- `apps/worker/src/pipeline/detectCandidateMoments.ts` — currently
  samples every Nth frame as a "candidate" rather than doing real
  scene/event detection. The file's doc comment lays out the two
  realistic approaches (cheap batched vision call, or ffmpeg scene-cut
  heuristics).
- Resumable/chunked video upload with real progress — the current
  `Analyze.tsx` upload uses a single PUT, fine for screenshots, not
  ideal for a 500MB video. Switch to Supabase's TUS resumable upload API.
- `player_progress` and playstyle/position inference (spec sections
  19-23) — the table and UI exist; the job that aggregates trends across
  matches and infers a playstyle from repeated evidence isn't written
  yet. Add it as a step at the end of `processMatchVideo.ts` /
  `processScreenshot.ts` once a user has 2+ real matches.
- `<video>` player wiring for "Watch Moment" — frame stills already work
  end-to-end; playing the actual `context_start..context_end` clip needs
  the processed video (or an extracted clip) kept in a short-lived signed
  URL, then a player component seeked to that timestamp.
- Coach chat currently duplicates a slice of prompt logic directly in
  the Edge Function (Deno) rather than reusing `packages/ai` (Node) —
  see the comment at the top of `supabase/functions/coach-chat/index.ts`
  for the tradeoff and how to unify it later.
- Google OAuth — schema/auth architecture leaves room for it, not wired.

## Security notes

- The Anthropic API key and Supabase service-role key are **only** read
  server-side (`apps/worker`, Edge Functions). `apps/web` only ever holds
  the anon key, which grants nothing on its own — RLS is the real gate.
- The worker's internal HTTP port (job submission) is guarded by a shared
  secret and should never be exposed outside your private network/VPC.
